"use client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Image from "next/image";
import Link from "next/link";
import React, { useState } from "react";

const SignUp = () => {
	const [showReferralCode, setShowReferralCode] = useState(false);
	return (
		<div className="flex flex-col lg:flex-row justify-center items-center min-h-screen bg-gray-100">
			<div className="bg-white rounded-lg shadow-lg w-full max-w-4xl p-8 flex flex-col lg:flex-row">
				<div className="lg:w-1/2 p-4 flex flex-col justify-center items-center border-r">
					<h2 className="text-2xl font-semibold mb-4 lg:text-left">
						Let&apos;s get started!
					</h2>
					<Image
						src="/signup01.png" // Adjust the path to your SVG image
						alt="Live Chat Support"
						width={400}
						height={350}
					/>
					<p className="text-lg  mt-4">
						Instant auto-sync between desktop & mobile
					</p>
				</div>
				<div className="lg:w-1/2 p-4">
					<div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
						<div>
							<Label htmlFor="firstName">First Name</Label>
							<Input
								id="firstName"
								className=" border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
								type="text"
								placeholder="First Name"
							/>
						</div>
						<div>
							<Label htmlFor="lastName">Last Name</Label>
							<Input
								id="lastName"
								className=" border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
								type="text"
								placeholder="Last Name"
							/>
						</div>
					</div>
					<div className="mb-4">
						<Label htmlFor="email">Email</Label>
						<Input
							id="email"
							className=" border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
							type="email"
							placeholder="zybrademo@gmail.com"
						/>
					</div>
					<div className="mb-4">
						<Label htmlFor="password">Password</Label>
						<Input
							id="password"
							className=" border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
							type="password"
							placeholder="Password"
						/>
					</div>
					<div className="mb-4">
						<Label htmlFor="mobileNumber">Mobile Number</Label>
						<Input
							id="mobileNumber"
							className=" border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
							type="tel"
							placeholder="Mobile Number"
						/>
					</div>

					{showReferralCode ? (
						<div className="mb-6">
							<Label htmlFor="referralCode">Referral Code</Label>
							<Input
								id="referralCode"
								className=" border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
								type="text"
								placeholder="Referral Code"
							/>
						</div>
					) : (
						<p
							className="text-sm text-center text-gray-700 hover:text-primary cursor-pointer mb-4"
							onClick={() => setShowReferralCode(!showReferralCode)}
						>
							Have a Referral Code?
						</p>
					)}

					<Button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white rounded-none shadow-xl py-2">
						Signup
					</Button>
					<p className="text-sm text-center mt-4">
						By signing up, you accept &apos;s{" "}
						<Link href="#" className="text-primary">
							Terms &apos; Conditions
						</Link>
					</p>
					<p className="text-sm text-center mt-2">
						Already have an account?{" "}
						<Link href="/auth" className="text-primary">
							Login
						</Link>
					</p>
				</div>
			</div>
		</div>
	);
};

export default SignUp;
