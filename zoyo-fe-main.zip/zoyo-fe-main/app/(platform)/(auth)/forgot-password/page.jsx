"use client";

import React from "react";
import { forgotPassword } from "@/actions/login/forgot-password";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import { TextInputField } from "@/components/custom-form-fields/custom-form-fields";
import { ReloadIcon } from "@radix-ui/react-icons";

const forgotPasswordSchema = z.object({
  email: z
    .string()
    .min(1, "Email is required")
    .email("Please enter a valid email address")
    .transform((email) => email.toLowerCase().trim()),
});

const ForgotPassword = () => {
  const form = useForm({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: "",
    },
  });

  const forgotPasswordMutation = useMutation({
    mutationFn: (data) => forgotPassword(data),
    onSuccess: (data) => {
      form.reset({ email: "" });
      toast.success(data?.data?.message);
    },
    onError: (error) => {
      toast.error(error.message || "Something went wrong");
    },
  });

  // Form submission handler
  const onSubmit = async (data) => {
    const payload = {
      email:(data.email).toLowerCase(),
    }
    try {
      await forgotPasswordMutation.mutateAsync(payload);
    } catch (error) {
      console.error("Form submission error:", error);
    }
  };

  return (
    <div className="min-h-screen mx-auto bg-[#2B4473]">
      {/* Main Content */}
      <div className="flex flex-col md:flex-row justify-center items-center pt-6 md:pt-[42px] px-8 max-w-[90%]  mx-auto">
        {/* Left Section */}
        <div className="w-full md:w-1/2 text-center md:text-left mb-8 md:mb-0">
          <div className="pb-6">
            <img
              src="/LogoContainer.png"
              alt="Company Logo"
              className="w-full max-w-[156.6px] max-h-[54px]"
            />
          </div>
          <div className="text-white">
            <h1 className="text-3xl md:text-4xl font-semibold mb-4">
              Welcome!
            </h1>
            <p className="text-gray-200">
              Lorem Ipsum has been the industrys standard dummy text
              <br className="hidden md:block" />
              ever since the 1500s,
            </p>
          </div>
          {/* Illustration - Hidden on mobile */}
          <div className="relative mt-8 hidden md:block">
            <div className="absolute inset-0 bg-white/10 rounded-full w-96 h-96 blur-2xl" />
            <img
              src="/logo.png"
              alt="Analytics Illustration"
              className="w-full max-w-[484px] max-h-[484px]"
            />
          </div>
        </div>
    <div className="w-full md:w-1/2 max-w-md px-4">
      <div className="bg-white p-6 md:p-8 rounded-lg shadow-lg w-full">
        <h2 className="text-xl font-semibold mb-2">Forgot Password</h2>
        <p className="text-gray-600 text-sm mb-6">
          Don&apos;t worry, just enter your email and submit.
        </p>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="mb-4">
              <TextInputField
                form={form}
                label="Email"
                type="text"
                name="email"
                className="w-full px-3 py-2  border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Enter Email"
              />
            </div>
            <Button
              type="submit"
              className="w-full text-white py-2 rounded transition-colors"
              disabled={forgotPasswordMutation.isPending}
            >
              {forgotPasswordMutation.isPending ? (
                <div className="flex items-center">
                  <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                  <span>sending...</span>
                </div>
              ) : (
                "Submit"
              )}
            </Button>
          </form>
        </Form>

        <div className="mt-6 text-center">
          <p className="text-gray-600">
            Remember Password?{" "}
            <Link href="/login" className="text-primary hover:underline">
              Login
            </Link>
          </p>
        </div>
      </div>
    </div>
    </div>
    </div>
  );
};

export default ForgotPassword;
