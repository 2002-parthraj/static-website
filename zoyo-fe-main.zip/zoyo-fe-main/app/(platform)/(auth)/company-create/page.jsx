"use client";

import React, { useEffect, useMemo, useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { Loader2 } from "lucide-react";
import {
  FormSelectField,
  GlobalCheckbox,
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import {
  optionforGSTRegistrationType,
  optionforIndustryType,
  optionforOrganizationType,
  optionforOwnership,
} from "@/components/enums/enums";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { stateList } from "@/actions/comman/state-list";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { addOrganizationsInfo } from "@/actions/organization-info/add-organization-info";
import { getGSTDetails } from "@/actions/gst-details/get-gst-details";
import { switchOrganization } from "@/actions/company-flow/switch-organization";

const formSchema = z.object({
  name: z
    .string({ message: "Please enter the name of organization." })
    .min(2, {
      message: "Organization's name must contain more than two characters.",
    })
    .max(255),
  ownershipType: z
    .enum(
      [
        "soleProprietorship",
        "partnership",
        "limitedLiabilityPartnership",
        "privateLimited",
        "publicLimited",
      ],
      {
        errorMap: () => ({ message: "Please select a valid ownership type" }),
      }
    )
    .optional(),

  organizationType: z.enum(
    ["retail", "wholesale", "distributor", "service", "manufacturer", "other"],
    {
      errorMap: () => ({ message: "Please select a valid organization type" }),
    }
  ),

  industryType: z.enum(
    [
      "accounting",
      "automobile",
      "banking",
      "education",
      "ecommerce",
      "entertainment",
      "financialServices",
      "foodServices",
      "healthcare",
      "insurance",
      "legal",
      "manufacturing",
      "realEstate",
      "retail",
      "software",
      "telecommunication",
      "transportation",
      "other",
    ],
    {
      errorMap: () => ({ message: "Please select a valid industry type" }),
    }
  ),

  booksStartFrom: z.string().min(1, { message: "Please select a year" }),

  panNumber: z
    .string()
    .refine(
      (value) => {
        if (!value) return true;
        const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        return panRegex.test(value);
      },
      { message: "Invalid PAN Number. Format should be: AAAPL1234C" }
    )
    .transform((val) => val || ""),

  tanNumber: z
    .string()
    .refine(
      (value) => {
        if (!value) return true;
        const tanRegex = /^[A-Z]{4}[0-9]{5}[A-Z]{1}$/;
        return tanRegex.test(value);
      },
      { message: "Invalid TAN Number. Format should be: AAAA99999A" }
    )
    .transform((val) => val || ""),

  cinNumber: z
    .string()
    .refine(
      (value) => {
        if (!value) return true;
        const cinRegex = /^[A-Z]{1}[0-9]{5}[A-Z]{2}[0-9]{4}[A-Z]{3}[0-9]{6}$/;
        return cinRegex.test(value);
      },
      { message: "Invalid CIN Number. Format should be: U74999DL2019PTC123456" }
    )
    .transform((val) => val || ""),

  fassaiNumber: z
    .string()
    .refine(
      (value) => {
        if (!value) return true;
        const fssaiRegex = /^[0-9]{12}$/;
        return fssaiRegex.test(value);
      },
      { message: "FSSAI Number must be exactly 12 digits" }
    )
    .transform((val) => val || ""),

  street: z.string().min(1, { message: "Please enter address." }),
  city: z.string().min(1, { message: "Please enter city. " }),
  stateId: z.string().min(1, { message: "please selcect a state." }),
  pincode: z
    .string({ message: "Please enter pincode." })
    .length(6, { message: "Pincode must be 6 digits." })
    .regex(/^\d+$/, { message: "Pincode must contain only numbers." }),

  country: z
    .string()
    .min(1, { message: "Country is required" })
    .default("India"),

  isGstRegistered: z.boolean().default(false),

  gstRegistrationType: z
    .enum(["composition", "regular"], {
      errorMap: () => ({
        message: "Please select a valid GST registration type",
      }),
    })
    .optional(),

  gstNumber: z.string().refine(
    (value) => {
      if (!value) return true;
      const gstRegex =
        /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
      return gstRegex.test(value);
    },
    { message: "Invalid GST Number format. Example: 27AAPFU0939F1Z5" }
  ),
});
const CompanyCreate = () => {
  const queryClient = useQueryClient();
  const router = useRouter();

  const [openDatePicker, setOpenDatePicker] = useState(false);
  const [activeTab, setActiveTab] = useState("profile");
  const [fetchedGSTNumber, setFetchedGSTNumber] = useState("");

  const tabSequence = ["profile", "address", "otherDetails"];
  const getCurrentTabIndex = () => tabSequence.indexOf(activeTab);

  // Handle next button click
  const handleNext = async () => {
    const currentTabIndex = getCurrentTabIndex();
    const isLastTab = currentTabIndex === tabSequence.length - 1;

    // Validate current tab fields
    let isValid = true;
    const currentFields = {
      profile: [
        "name",
        "ownershipType",
        "organizationType",
        "industryType",
        "booksStartFrom",
        "isGstRegistered",
        "gstNumber",
        "gstRegistrationType",
      ],
      address: ["street", "city", "stateId", "pincode"],
      otherDetails: ["panNumber", "tanNumber", "fassaiNumber"],
    }[activeTab];

    await form.trigger(currentFields);

    // Check if there are any errors in the current tab's fields
    const hasErrors = currentFields.some(
      (field) => form.formState.errors[field]
    );

    if (hasErrors) {
      return;
    }

    if (isLastTab) {
      // Submit form if on last tab
      form.handleSubmit(onSubmit)();
    } else {
      // Move to next tab
      setActiveTab(tabSequence[currentTabIndex + 1]);
    }
  };

  // Handle back button click
  const handleBack = () => {
    const currentTabIndex = getCurrentTabIndex();
    if (currentTabIndex === 0) {
      router.back();
    } else {
      setActiveTab(tabSequence[currentTabIndex - 1]);
    }
  };

  const { data: state } = useQuery({
    queryKey: ["states"],
    queryFn: stateList,
    onError: (error) => {
      toast.error(error || "Failed to load state list. Please try again.");
    },
  });

  const stateOptions = useMemo(
    () =>
      state?.data?.map((state) => ({
        value: state.id,
        label: state.name,
      })) || [],
    [state]
  );

  const currentYear = useMemo(() => new Date().getFullYear().toString(), []);

  const yearsOptions = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const yearsList = [];
    for (let year = 2000; year <= currentYear; year++) {
      yearsList.push({
        value: year.toString(),
        label: year.toString(),
      });
    }
    return yearsList;
  }, []);

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      ownershipType: "",
      organizationType: "",
      industryType: "",
      booksStartFrom: currentYear,
      panNumber: "",
      tanNumber: "",
      cinNumber: "",
      fassaiNumber: "",
      street: "",
      city: "",
      stateId: "",
      pincode: "",
      country: "India",
      isGstRegistered: false,
      //   gstRegistrationType: "",
      gstNumber: "",
    },
    mode: "all",
  });

  //get GST details code

  const gstNumber = form.watch("gstNumber");
  // Validate GST number format
  const isValidGSTFormat = (gst) => {
    return /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(
      gst
    );
  };
  const mapOwnershipType = (gstOwnershipType) => {
    const typeMapping = {
      Proprietorship: "soleProprietorship",
      Partnership: "partnership",
      LLP: "limitedLiabilityPartnership",
      "Private Limited Company": "privateLimited",
      "Public Limited Company": "publicLimited",
    };

    // Convert to lowercase for case-insensitive matching
    const normalizedType = gstOwnershipType?.toLowerCase() || "";

    // Find the matching type
    const matchedType = Object.entries(typeMapping).find(([key]) =>
      normalizedType.includes(key.toLowerCase())
    );

    return matchedType ? matchedType[1] : "";
  };

  // Function to fetch GST details
  const { mutate: fetchGSTDetails, isLoading: isLoadingGST } = useMutation({
    mutationFn: getGSTDetails,
    onSuccess: (response) => {
      // If response is an error message string
      if (
        typeof response === "string" &&
        response.includes("status code 400")
      ) {
        toast.error("Failed to fetch GST details");
        return;
      }

      if (response?.data?.success && response?.data?.data) {
        const gstData = response?.data?.data;

        setFetchedGSTNumber(gstNumber); // Store the GST number we've fetched

        // Auto-fill form fields

        form.setValue("name", gstData.name || "");
        // Map ownership type using the helper function
        const mappedOwnershipType = mapOwnershipType(gstData.ownershipType);
        if (mappedOwnershipType) {
          form.setValue("ownershipType", mappedOwnershipType);
        }

        // Set GST Type
        if (gstData.gstType?.toLowerCase() === "regular") {
          form.setValue("gstRegistrationType", "regular");
        } else if (gstData.gstType?.toLowerCase() === "composition") {
          form.setValue("gstRegistrationType", "composition");
        }

        // Auto-fill address
        if (gstData.address) {
          form.setValue("street", gstData.address.street || "");
          form.setValue("city", gstData.address.city || "");

          // Find state ID from state name
          const stateObj = stateOptions.find(
            (state) =>
              state.label.toLowerCase() === gstData.address.state.toLowerCase()
          );
          if (stateObj) {
            form.setValue("stateId", stateObj.value.toString());
          }

          form.setValue("pincode", gstData.address.pincode || "");
        }

        toast.success("GST details fetched successfully");
        if (gstData.status?.toLowerCase() === "cancelled") {
          toast.warning("GST number is cancelled");
        }
      }
    },
    onError: (error) => {
      toast.error(error.message || "Failed to fetch GST details");
    },
  });

  // Effect to handle GST number changes
  useEffect(() => {
    const handleGSTChange = () => {
      // Only proceed if we have a GST number and haven't already fetched it
      if (
        gstNumber &&
        gstNumber.length === 15 &&
        isValidGSTFormat(gstNumber) &&
        gstNumber !== fetchedGSTNumber
      ) {
        fetchGSTDetails(gstNumber);
      }
    };

    // Add a small delay to avoid immediate API calls while typing
    const timeoutId = setTimeout(handleGSTChange, 1000);
    return () => clearTimeout(timeoutId);
  }, [gstNumber, fetchedGSTNumber, fetchGSTDetails]);

  const switchCompanyMutation = useMutation({
    mutationFn: (id) => switchOrganization(id),
    onSuccess: (data) => {
      localStorage.setItem("companyname", data?.data?.data?.name);
      // router.push("/home");
      // toast.success(data.data.message);
      queryClient.invalidateQueries(["organizations"]);
    },
  });

  const organizationMutation = useMutation({
    mutationFn: (data) => addOrganizationsInfo(data),
    onSuccess: (data) => {
      console.log(data);
      if (data?.status === 200 || data?.status === 201) {
        toast.success("Organization created successfully!");
        switchCompanyMutation.mutateAsync(data?.data?.data?.id);
        router.push("/home");
      } else {
        toast.error(
          data?.data?.error[0]?.message || "An unexpected error occurred"
        );
      }
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create organization");
    },
  });
  const errorsData = form?.formState?.errors;

  const onSubmit = async (formData) => {
    try {
      // Structure the data according to the API requirements
      const payload = {
        name: formData.name,
        ownershipType: formData.ownershipType,
        organizationType: formData.organizationType,
        industryType: formData.industryType,
        booksStartFrom: formData.booksStartFrom,
        panNumber: formData.panNumber,
        tanNumber: formData.tanNumber,
        cinNumber: formData.cinNumber,
        fassaiNumber: formData.fassaiNumber,

        // Address details nested under address key
        address: {
          street: formData.street,
          city: formData.city,
          stateId: Number(formData.stateId),
          pincode: Number(formData.pincode),
          country: formData.country,
        },

        // GST info nested under gstInfo key
        gstInfo: {
          isGstRegistered: formData.isGstRegistered,
          gstRegistrationType: formData.gstRegistrationType,
          gstNumber: formData.gstNumber,
        },
      };

      await organizationMutation.mutateAsync(payload);
    } catch (error) {
      toast.error("Failed to create organization");
    }
  };

  return (
    <div className="relative min-h-screen bg-[#2B4473] flex flex-col">
      <div className="absolute pt-8 px-8">
        <img src="/LogoContainer.png" alt="Retail POS" className="w-40" />
      </div>

      <div className="flex-1 flex p-3 items-center justify-center">
        <Card className="rounded-lg w-[696px]">
          <Form {...form}>
            <form onSubmit={(e) => e.preventDefault()}>
              <Tabs
                value={activeTab}
                className="w-full"
                onValueChange={(value) => setActiveTab(value)}
              >
                <div className="border-b pb-[14px] border-gray-300 text-center ">
                  <TabsList className="grid w-full py-2 grid-cols-3  text-center	 rounded-lg  bg-white">
                    <TabsTrigger
                      value="profile"
                      className={
                        errorsData?.name ||
                        errorsData?.ownershipType ||
                        errorsData?.organizationType ||
                        errorsData?.industryType ||
                        errorsData?.booksStartFrom
                          ? "text-red-500 flex-1 pb-4 rounded-none text-sm font-medium    data-[state=active]:bg-white data-[state=active]:shadow-none  data-[state=active]:border-b-2 data-[state=active]:border-primary"
                          : "flex-1 pb-4 rounded-none text-sm font-medium text-gray-700   data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                      }
                    >
                      Organization Details
                    </TabsTrigger>
                    <TabsTrigger
                      value="address"
                      className={
                        errorsData?.city ||
                        errorsData?.pincode ||
                        errorsData?.stateId ||
                        errorsData?.street
                          ? "text-red-500 flex-1 pb-4 rounded-none text-sm font-medium    data-[state=active]:bg-white data-[state=active]:shadow-none  data-[state=active]:border-b-2 data-[state=active]:border-primary"
                          : "flex-1 pb-4 rounded-none text-sm font-medium text-gray-700   data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                      }
                    >
                      Address Details
                    </TabsTrigger>
                    <TabsTrigger
                      value="otherDetails"
                      className="flex-1 rounded-none pb-4 text-sm font-medium text-black data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary  data-[state=active]:border-b-2 data-[state=active]:border-primary"
                    >
                      Other Details
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="profile">
                  <CardContent className="px-6 pb-6 pt-4">
                    <GlobalCheckbox
                      form={form}
                      name="isGstRegistered"
                      label="I Have GST Number"
                      className="p-0"
                    />

                    {form.watch("isGstRegistered") === true && (
                      <>
                        <div className="w-full pt-2">
                          <TextInputField
                            form={form}
                            name="gstNumber"
                            label="GST Number"
                            type="text"
                            placeholder="GST Number"
                            className="flex flex-col space-y-1.5"
                          />
                        </div>
                        <div className="w-full pt-2">
                          <FormSelectField
                            control={form.control}
                            name="gstRegistrationType"
                            label="GST Type"
                            options={optionforGSTRegistrationType}
                            placeholder="Choose Option"
                            className="w-full p-2 border rounded"
                          />
                        </div>
                      </>
                    )}

                    <hr className="my-3 border-gray-300" />

                    <div className="w-full ">
                      <TextInputField
                        form={form}
                        name="name"
                        label="Organization Name"
                        type="text"
                        placeholder="Write Company Name Here"
                        required
                      />
                    </div>
                    <div className="w-full pt-2">
                      <FormSelectField
                        control={form.control}
                        name="ownershipType"
                        label="Type of Ownership "
                        options={optionforOwnership}
                        placeholder="Choose Option"
                        className="w-full p-2 border rounded"
                        required
                      />
                    </div>
                    <div className="w-full pt-2">
                      <FormSelectField
                        control={form.control}
                        name="organizationType"
                        label="Type of Business"
                        options={optionforOrganizationType}
                        placeholder="Choose Option"
                        required
                      />
                    </div>
                    <div className="w-full pt-2">
                      <FormSelectField
                        control={form.control}
                        name="industryType"
                        label="Industry"
                        options={optionforIndustryType}
                        placeholder="Choose Option "
                        required
                      />
                    </div>
                    <div className="w-full pt-3">
                      <FormSelectField
                        control={form.control}
                        name="booksStartFrom"
                        label="Financial Accounts Start From"
                        options={yearsOptions}
                        placeholder="Select Year"
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  </CardContent>
                </TabsContent>

                <TabsContent value="address">
                  <CardContent className="px-6 pb-6 pt-3">
                    <div className="w-full ">
                      <TextareaInputField
                        form={form}
                        name={"street"}
                        placeholder={"Flat, House No, Comapany"}
                        label={"Address Line "}
                        type={"text"}
                        required
                      />
                    </div>

                    <div className="w-full pt-4">
                      {" "}
                      <TextInputField
                        form={form}
                        name={"city"}
                        placeholder={"City Name"}
                        label={"Town/City"}
                        type={"text"}
                        required
                      />
                    </div>

                    <div className="w-full pt-4">
                      <FormSelectField
                        control={form.control}
                        name="stateId"
                        label="State"
                        placeholder="Select a state"
                        options={stateOptions.map((option) => ({
                          ...option,
                          value: option.value.toString(),
                        }))}
                        required
                      />
                    </div>

                    <div className="w-full pt-4">
                      <TextInputField
                        form={form}
                        name={"pincode"}
                        placeholder={"123456"}
                        label={"Pincode"}
                        type={"text"}
                        required
                      />
                    </div>
                  </CardContent>
                </TabsContent>

                <TabsContent value="otherDetails">
                  <CardContent className="px-6 pb-6 pt-3">
                    <div className="w-full ">
                      <TextInputField
                        form={form}
                        name="panNumber"
                        label="PAN Number"
                        type="text"
                        placeholder="PAN Number"
                        className="flex flex-col space-y-1.5"
                      />
                    </div>
                    <div className="w-full pt-2">
                      <TextInputField
                        form={form}
                        name="tanNumber"
                        label="TAN Number"
                        type="text"
                        placeholder="TAN Number"
                        className="flex flex-col space-y-1.5"
                      />
                    </div>
                    <div className="w-full pt-2">
                      <TextInputField
                        form={form}
                        name="fassaiNumber"
                        label="FSSAI Number"
                        type="text"
                        placeholder="FSSAI Number"
                        className="flex flex-col space-y-1.5"
                      />
                    </div>
                  </CardContent>
                </TabsContent>
              </Tabs>

              <div className=" flex gap-3 justify-between rounded-b-lg p-6 border-t bg-white">
                <Button
                  type="button"
                  variant="outline"
                  className="w-[90px]"
                  onClick={handleBack}
                >
                  Back
                </Button>
                <Button
                  onClick={handleNext}
                  className="w-24"
                  disabled={organizationMutation.isPending}
                >
                  {organizationMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : getCurrentTabIndex() === tabSequence.length - 1 ? (
                    "Submit"
                  ) : (
                    "Next"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </Card>
      </div>
    </div>
  );
};

export default CompanyCreate;
