// auth/utils.js
import Cookies from "js-cookie";
import axios from "@/lib/axios";

export const setAuthTokens = (tokens) => {
  if (typeof window !== "undefined") {
    // Set in localStorage
    localStorage.setItem("auth_token", tokens.accessToken);
    localStorage.setItem("refresh_token", tokens.refreshToken);

    // Set in cookies with proper configuration
    Cookies.set("token", tokens.accessToken, {
      expires: 7,
      path: "/",
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
    });

    // Set in axios default headers
    axios.defaults.headers.common[
      "Authorization"
    ] = `Bearer ${tokens.accessToken}`;
  }
};

export const getAuthTokens = () => {
  if (typeof window !== "undefined") {
    // Try localStorage first, then cookies as fallback
    const accessToken =
      localStorage.getItem("auth_token") || Cookies.get("token");
    const refreshToken = localStorage.getItem("refresh_token");

    return {
      accessToken,
      refreshToken,
    };
  }
  return { accessToken: null, refreshToken: null };
};

export const clearAuthTokens = () => {
  if (typeof window !== "undefined") {
    // Clear localStorage
    localStorage.removeItem("auth_token");
    localStorage.removeItem("refresh_token");

    // Clear cookies
    Cookies.remove("token", { path: "/" });

    // Clear axios headers
    delete axios.defaults.headers.common["Authorization"];
  }
};

export const isAuthenticated = () => {
  if (typeof window !== "undefined") {
    const { accessToken } = getAuthTokens();
    return !!accessToken;
  }
  return false;
};
