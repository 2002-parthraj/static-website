"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { toast } from "sonner";
// Components
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { TextInputField, TextInputFieldLogin } from "@/components/custom-form-fields/custom-form-fields";
// Auth utilities
import axios from "@/lib/axios-auth";
const formSchema = z.object({
  email: z.preprocess(
    (value) => (typeof value === 'string' ? value.trim() : value),
    z.string().min(1, "Email is required").email("Invalid email format")
  ),
  password: z.string().min(1, "Password is required"),
});
const AuthPage = () => {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });
  // Inside your AuthPage component, update the onSuccess handler:
  const { mutate: login, isPending } = useMutation({
    mutationFn: async (credentials) => {
      try {
        const response = await axios.post("/auth/login", credentials);
        return response.data;
      } catch (error) {
        if (error.response?.status === 401) {
          throw new Error("Invalid email or password");
        }
        throw new Error(
          error.response?.data?.error?.[0]?.message || "Login failed"
        );
      }
    },
    onSuccess: (data) => {
      // Update React Query cache
      queryClient.setQueryData(["user"], data.user);
      // localStorage.setItem("organizations", JSON.stringify(data.organizations));
      // queryClient.setQueryData(["organizations"], data.organizations);

      // Store user data in localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem("user", JSON.stringify(data.user));
      }
      if (data.user.forcePasswordChange) {
        router.push("/change-password");
      } else if (!data.organizations || data.organizations.length === 0) {
        // If no organizations, redirect to create organization page
        router.push("/company-create");
      } else {
        // Get the 'from' parameter from URL or default to '/home'
        const params = new URLSearchParams(window.location.search);
        const from = params.get("from") || "/home";
        router.push(from);
      }
      toast.success("Login successful");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });
  const onSubmit = async (values) => {
    
    const payload = {
      email:(values.email).toLowerCase(),
      password:values.password
    }
    
    setIsSubmitting(true);
    try {
      await login(payload);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleFormSubmit = (e) => {
    e.preventDefault();
    form.handleSubmit(onSubmit)(e);
  };
  return (
    <div className="min-h-screen mx-auto bg-[#2B4473]">
      {/* Main Content */}
      <div className="flex flex-col md:flex-row justify-center items-center pt-6 md:pt-[42px] px-8 max-w-[90%]  mx-auto">
        {/* Left Section */}
        <div className="w-full md:w-1/2 text-center md:text-left mb-8 md:mb-0">
          <div className="pb-6">
            <img
              src="/LogoContainer.png"
              alt="Company Logo"
              className="w-full max-w-[156.6px] max-h-[54px]"
            />
          </div>
          <div className="text-white">
            <h1 className="text-3xl md:text-4xl font-semibold mb-4">
              Welcome!
            </h1>
            <p className="text-gray-200">
              Lorem Ipsum has been the industrys standard dummy text
              <br className="hidden md:block" />
              ever since the 1500s,
            </p>
          </div>
          {/* Illustration - Hidden on mobile */}
          <div className="relative mt-8 hidden md:block">
            <div className="absolute inset-0 bg-white/10 rounded-full w-96 h-96 blur-2xl" />
            <img
              src="/logo.png"
              alt="Analytics Illustration"
              className="w-full max-w-[484px] max-h-[484px]"
            />
          </div>
        </div>
        {/* Right Section - Login Form */}
        <div className="w-full md:w-1/2 max-w-md px-4">
          <div className="bg-white p-6 md:p-8 rounded-lg shadow-lg w-full">
            <h2 className="text-xl font-semibold mb-2">Login</h2>
            <p className="text-gray-600 text-sm mb-6">
              Enter your credentials to get started
            </p>
            <Form {...form}>
              <form
                 onSubmit={handleFormSubmit}
                className="space-y-4"
              >
                {/* Email Field */}
                <TextInputFieldLogin
                  form={form}
                  name="email"
                  placeholder="Enter Email Here"
                  label="Email ID"
                  type="text"
                  required
                  disabled={isSubmitting}
                />
                {/* Password Field */}
                <div className="relative">
                  <TextInputFieldLogin
                    form={form}
                    name="password"
                    placeholder="Enter Password Here"
                    label="Password"
                    type={showPassword ? "text" : "password"}
                    required
                    disabled={isSubmitting}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-[50px] transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
               
                {/* Submit Button */}
                <div className="pt-4">
                <Button
                  type="submit"
                  className="w-full text-white py-2 rounded transition-colors"
                  disabled={isPending || isSubmitting}
                >
                  {isPending || isSubmitting ? (
                    <div className="flex items-center justify-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                    </div>
                  ) : (
                    "Login"
                  )}
                </Button>
                </div>
                 {/* Remember Me & Forgot Password */}
                 <div className="flex flex-col sm:flex-row items-center sm:items-center justify-center">
                  <Button
                    type="button"
                    className="text-sm bg-white shadow-none rounded-none text-primary hover:underline p-0"
                    onClick={() => router.push("/forgot-password")}
                    disabled={isSubmitting}
                  >
                    Forgot password?
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
};
export default AuthPage;
