"use client";
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form } from "@/components/ui/form";
import { toast } from "sonner";
import { changePassword } from "@/actions/login/change-password";
import { TextInputField } from "@/components/custom-form-fields/custom-form-fields";
import { Card } from "@/components/ui/card";

const formSchema = z
  .object({
    newPassword: z.string().min(6, "Password must be at least 6 characters"),
    confirmPassword: z
      .string()
      .min(6, "Password must be at least 6 characters"),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "New password and confirm password don't match",
    path: ["confirmPassword"],
  })
  .refine((data) => data.currentPassword !== data.newPassword, {
    message: "New password must be different from current password",
    path: ["newPassword"],
  });

const ChangePassword = () => {
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      newPassword: "",
      confirmPassword: "",
    },
  });

  const { mutate: userChangePasswordMutation, isPanding } = useMutation({
    mutationFn: (payload) => changePassword(payload),
    onMutate: () => {
      setIsSubmitting(true);
    },
    onSuccess: (data) => {
      if (data?.status === 200) {
        toast.success("Password changed successfully");
        form.reset();
        if (!data.organizations || data.organizations.length === 0) {
          // If no organizations, redirect to create organization page
          router.push("/company-create");
        } else {
          router.push("/home");
        }
      } else {
        toast.error("Invalid response format");
      }
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast.error(
        `Failed to change password. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
      setIsSubmitting(false);
    },
  });

  const onSubmit = (values) => {
    const payload = {
      newPassword: values.newPassword,
    };
    userChangePasswordMutation(payload);
  };

  return (
    <div className="relative min-h-screen bg-[#2B4473] flex flex-col">
      <div className="pt-8 px-8 absolute">
        <img src="/LogoContainer.png" alt="Retail POS" className="w-40" />
      </div>

      <div className="flex-1 flex items-center justify-center">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <Card className="bg-white">
              <div className="bg-white rounded-lg p-8 w-full max-w-md mx-4">
                <h2 className="text-lg font-semibold mb-1">Set New Password</h2>
                <p className="text-sm text-gray-500 mb-6">
                  Please set a new password which you will use for Future Login
                  Sessions
                </p>

                {/* New Password Field */}
                <div className="space-y-1 ">
                  <div className="relative">
                    <TextInputField
                      form={form}
                      name="newPassword"
                      placeholder="Enter New Password"
                      label="New Password"
                      type={showNewPassword ? "text" : "password"}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-[50px] transform -translate-y-1/2 text-gray-500"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                    >
                      {showNewPassword ? (
                        <EyeOff size={16} />
                      ) : (
                        <Eye size={16} />
                      )}
                    </button>
                  </div>
                </div>

                {/* Confirm Password Field */}
                <div className="space-y-1 pt-6">
                  <div className="relative">
                    <TextInputField
                      form={form}
                      name="confirmPassword"
                      placeholder="Confirm New Password"
                      label="Confirm Password"
                      type={showConfirmPassword ? "text" : "password"}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-[50px] transform -translate-y-1/2 text-gray-500"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                    >
                      {showConfirmPassword ? (
                        <EyeOff size={16} />
                      ) : (
                        <Eye size={16} />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 justify-between rounded-b-lg p-6 border-t bg-white">
                <div />
                <Button
                  type="submit"
                  className=""
                  disabled={
                    userChangePasswordMutation.isPanding || isSubmitting
                  }
                >
                  {userChangePasswordMutation.isPanding || isSubmitting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    "Submit"
                  )}
                </Button>
              </div>
            </Card>
          </form>
        </Form>
      </div>
    </div>
  );
};

export default ChangePassword;
