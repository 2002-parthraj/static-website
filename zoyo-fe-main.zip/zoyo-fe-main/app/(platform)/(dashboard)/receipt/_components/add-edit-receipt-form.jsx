"use client";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CommonCalendarInput,
  FormSelectField,
  GlobalSwitch,
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { toast } from "sonner";
import { formatDate, set } from "date-fns";
import { optionforPaymentMode } from "@/components/enums/enums";
import { addReceipts } from "@/actions/receipts/add-receipts";
import { editReceipts } from "@/actions/receipts/edit-receipts";
import { getSuggestionOfOppositeAccounts } from "@/actions/payments/get-all-paymentdata";
import useDebounce from "@/hooks/use-debounce";
import { getBillOrInvoiceOfPartyAndAccount } from "@/actions/receipts/get-bill-and-invoice";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { getReceiptsDataById } from "@/actions/receipts/get-all-receipts";
import { getAllBankAccountData } from "@/actions/bank-account/get-all-bankAccount";
import { ReloadIcon } from "@radix-ui/react-icons";
import { cn } from "@/lib/utils";
import AutoCompleteRecieptSelector from "@/components/custom-receipt-selections-model/custom-receipt-selections-model";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { fetchInitialPartiesforDeleiveryChalan } from "@/actions/delivery_challan/search-customer-suggestion";
import { getAllPaymentMode } from "@/actions/payment-modes/get-all-payment-modes";
import PaymentModeConfig from "@/components/payment-mode-config/payment-mode-config";
import { useSheetStore } from "@/hooks/stores/useSheetStore";

const formSchema = z.object({
  date: z.date({
    required_error: "Date is required",
    invalid_type_error: "Date must be a valid date",
  }),
  depositToAccountId: z
    .string()
    .min(1, { message: "Deposit To Account Name is required" })
    .transform((val) => Number.parseFloat(val)),
  oppositeAccountOrPartyId: z
    .string()
    .min(1, { message: "Opposite Account or Party Name is required" })
    .transform((val) => Number.parseFloat(val)),
  paymentModeId: z.string().min(1, { message: "Payment mode is required" }),
  onAccount: z.boolean().optional(),
  amount: z
    .string({
      required_error: "Amount is required",
    })
    .superRefine((val, ctx) => {
      const numVal = Number.parseFloat(val);

      // Basic validation for all cases
      if (Number.isNaN(numVal)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Amount must be a valid number",
        });
        return;
      }

      if (numVal <= 0) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Amount must be greater than 0",
        });
        return;
      }

      // Only apply maximum amount validation if a party is selected
      if (ctx?.parent?.selectedType === "party") {
        if (numVal > ctx.parent.maxAmount) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: `Amount cannot exceed ${ctx.parent.maxAmount}`,
          });
        }
      }
    }),
  chequeNumber: z.string().optional(),
  chequeDate: z.date().optional(),
  referenceNumber: z.string().max(50).optional(),
  notes: z.string().optional(),
});

export const AddEditReceiptForm = ({ receipt, onClose }) => {
  const openSheet = useSheetStore((state) => state.openSheet);

  const queryClient = useQueryClient();
  const isEditing = !!receipt;
  const formInitialized = useRef(false);

  const [partyOrAccountType, setPartyOrAccountType] = useState("");
  const [partyOrAccountId, setPartyOrAccountId] = useState(null);
  const [paymentModeId, setPaymentModeId] = useState();
  const [totalAmountData, setTotalAmountData] = useState(0);
  const [oppositeAccountSearchQuery, setOppositeAccountSearchQuery] =
    useState("");
  const [oppositeAccountValues, setOppositeAccountValues] = useState([]);
  const [lineItemsData, setLineItemsData] = useState([]);
  const debouncedOppositeAccountSearchQuery = useDebounce(
    oppositeAccountSearchQuery,
    300
  );
  const [partyInputValues, setPartyInputValues] = useState({});
  const [maxAmount, setMaxAmount] = useState(0);
  const [markAllPaid, setMarkAllPaid] = useState(false);

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      date: new Date(),
      depositToAccountId: "",
      oppositeAccountOrPartyId: "",
      paymentModeId: "",
      amount: "",
      chequeNumber: "",
      chequeDate: undefined,
      referenceNumber: "",
      notes: "",
      selectedType: "",
      maxAmount: 0,
    },
    context: {
      selectedType: "",
      maxAmount: 0,
    },
  });

  const { data: receiptData } = useQuery({
    queryKey: ["paymentsingledata", receipt],
    queryFn: () => getReceiptsDataById(receipt?.id ? receipt?.id : receipt),
    refetchOnWindowFocus: false,
    enabled: isEditing,
    onError: (error) => {
      toast.error(error || "Failed to load receipt data. Please try again.");
    },
  });

  const fetchOppositeAccountSuggestions = useCallback(async () => {
    if (debouncedOppositeAccountSearchQuery) {
      const suggestions = await getSuggestionOfOppositeAccounts(
        debouncedOppositeAccountSearchQuery
      );
      const formattedSuggestions = [
        ...suggestions.data.accounts.map((account) => ({
          label: account.name,
          value: account.id.toString(),
          type: "account",
        })),
        ...suggestions.data.parties.map((party) => ({
          label: party.name,
          value: party.id.toString(),
          type: "party",
        })),
      ];
      setOppositeAccountValues(formattedSuggestions);
    }
  }, [debouncedOppositeAccountSearchQuery]);

  const fetchSuggestionsforParty = useCallback(async () => {
    const initialParties = await fetchInitialPartiesforDeleiveryChalan();
    // Map over the array to add type:'party' to each option
    const partiesWithType = initialParties.map((party) => ({
      ...party,
      type: "party", // Add type field to each party
    }));
    setOppositeAccountValues(partiesWithType);
  }, []);

  // Use this query to fetch suggestions
  useQuery({
    queryKey: ["suggestionsforparty"],
    queryFn: fetchSuggestionsforParty,
    enabled: true,
  });

  useQuery({
    queryKey: [
      "oppositeAccountSuggestions",
      debouncedOppositeAccountSearchQuery,
    ],
    refetchOnWindowFocus: false,
    queryFn: fetchOppositeAccountSuggestions,
    enabled: true,
  });

  const { data: accountname } = useQuery({
    queryKey: ["accountname"],
    queryFn: getAllBankAccountData,
    refetchOnWindowFocus: false,
    onError: (error) => {
      toast.error(error || "Failed to load account groups. Please try again.");
    },
  });

  const { data: allPaymentModes } = useQuery({
    queryKey: ["allPaymentModes"],
    queryFn: getAllPaymentMode,
    refetchOnWindowFocus: false,
    staleTime: 1000, // 1 second
    onError: (error) => {
      toast.error(error || "Failed to load payment mode. Please try again.");
    },
  });

  const selectedParty = form.watch("oppositeAccountOrPartyId");

  useEffect(() => {
    const selectedOption = oppositeAccountValues.find(
      (option) => option.value === selectedParty
    );

    if (selectedOption) {
      setPartyOrAccountType(selectedOption.type);
      setPartyOrAccountId(selectedOption.value);
      if (selectedOption.type === "account") {
        setMaxAmount(0);
        form.setValue("maxAmount", 0);
        form.setValue("onAccount", true); // Force onAccount to true for accounts
        setTotalAmountData(0); // Reset total amount for accounts
        setLineItemsData([]); // Clear line items for accounts
      } else if (selectedOption.type === "party") {
        form.setValue("onAccount", false);
      }
    } else if (selectedParty) {
      if (receiptData) {
        const newType = receiptData?.partyId === null ? "account" : "party";
        setPartyOrAccountType(newType);
        setOppositeAccountValues([
          ...oppositeAccountValues,
          receiptData?.partyId === null
            ? {
                label: receiptData.oppositeAccountName,
                value: `${receiptData.oppositeAccountId}`,
                type: "account",
              }
            : {
                label: receiptData.partyName,
                value: `${receiptData.partyId}`,
                type: "party",
              },
        ]);
      }
      setPartyOrAccountId(selectedParty);
    } else {
      setPartyOrAccountType("");
      setPartyOrAccountId(null);
    }
  }, [selectedParty, receiptData, oppositeAccountValues, form]);

  const onAccountData = form.watch("onAccount");

  useEffect(() => {
    if (receiptData) {
      const oppositeAccountOrPartyId =
        receiptData.partyId ?? receiptData.oppositeAccountId;
      form.reset({
        ...receiptData,
        chequeNumber: receiptData.chequeNumber?.toString() || "",
        date: receiptData.date ? new Date(receiptData.date) : new Date(),
        depositToAccountId: `${receiptData.depositToAccountId}` || "",
        oppositeAccountOrPartyId: oppositeAccountOrPartyId?.toString() || "",
        paymentModeId: receiptData?.paymentModeId?.toString() || "",
        chequeDate: receiptData.chequeDate
          ? new Date(receiptData.chequeDate)
          : undefined,
        amount: receiptData.amount?.toString() || "0",
        referenceNumber: receiptData?.referenceNumber || "",
        notes: receiptData?.notes || "",
      });

      setPartyOrAccountType(receiptData.partyId ? "party" : "account");
      setPartyOrAccountId(oppositeAccountOrPartyId?.toString());
      const newValue = receiptData.partyId
        ? {
            label: receiptData.partyName,
            value: receiptData.partyId.toString(),
            type: "party",
          }
        : receiptData.oppositeAccountId
        ? {
            label: receiptData.oppositeAccountName,
            value: receiptData.oppositeAccountId.toString(),
            type: "account",
          }
        : null;

      if (
        newValue &&
        !oppositeAccountValues.some((v) => v.value === newValue.value)
      ) {
        setOppositeAccountValues((prev) => [...prev, newValue]);
      }
    }
  }, [receiptData, form, oppositeAccountValues]);

  useEffect(() => {
    form.setValue("selectedType", partyOrAccountType);
    form.setValue("maxAmount", totalAmountData);
  }, [partyOrAccountType, totalAmountData, form]);

  // Modified handleAmountChange to respect selection type
  const handleAmountChange = (event) => {
    let newAmount = event.target.value;

    // Clean up the input
    newAmount = newAmount.replace(/[^\d.]/g, "");

    const parts = newAmount.split(".");
    if (parts.length > 2) {
      newAmount = parts[0] + "." + parts.slice(1).join("");
    }

    if (parts[1] && parts[1].length > 2) {
      newAmount = Number.parseFloat(newAmount).toFixed(2);
    }

    // Set the new amount value
    form.setValue("amount", newAmount, { shouldValidate: true });

    const numAmount = Number.parseFloat(newAmount);
    if (!Number.isNaN(numAmount)) {
      // Only apply maximum amount validation for party type
      if (
        partyOrAccountType === "party" &&
        onAccountData === false &&
        numAmount > totalAmountData
      ) {
        form.setValue("amount", totalAmountData.toFixed(2), {
          shouldValidate: true,
        });
      }
      setIsAmountChangedByUser(true);
    }
  };

  const { data: selectedBillOrInvoiceData, refetch: refetchBillOrInvoice } =
    useQuery({
      queryKey: ["invoice-or-bill", partyOrAccountId, partyOrAccountType],
      queryFn: () =>
        getBillOrInvoiceOfPartyAndAccount(
          partyOrAccountType,
          Number(partyOrAccountId)
        ),
      refetchOnWindowFocus: false,
      enabled: !!partyOrAccountId && partyOrAccountType !== "unknown",
    });

  useEffect(() => {
    if (partyOrAccountId && partyOrAccountType !== "unknown") {
      refetchBillOrInvoice();
    }
  }, [partyOrAccountId, partyOrAccountType, refetchBillOrInvoice]);

  useEffect(() => {
    let lineItems = [];
    let selectedInvoiceIds = new Set();

    // First handle selectedBillOrInvoiceData if available
    if (
      selectedBillOrInvoiceData?.data &&
      selectedBillOrInvoiceData.data.length > 0
    ) {
      lineItems = selectedBillOrInvoiceData.data.map((item) => {
        selectedInvoiceIds.add(item.id);
        // Find matching voucher from receipt data if it exists
        const matchingVoucher = receiptData?.vouchers?.find(
          (v) => v.id === item.id
        );

        const currentDueAmount = Number.parseFloat(item?.dueAmount) || 0;
        const receiptAmount = matchingVoucher
          ? Number.parseFloat(matchingVoucher.amount) || 0
          : 0;

        // When editing, add back the current receipt's amount to show original due amount
        const adjustedDueAmount = isEditing
          ? currentDueAmount + receiptAmount
          : currentDueAmount;

        return {
          voucherNumber: item.voucherNumber,
          date: item?.date,
          total: Number.parseFloat(item?.total) || 0,
          dueAmount: adjustedDueAmount,
          paymentClear: receiptAmount,
          id: item?.id,
        };
      });
    }

    // Then add receipt vouchers that aren't already included
    if (receiptData?.vouchers?.length > 0) {
      const additionalVouchers = receiptData.vouchers
        .filter((voucher) => !selectedInvoiceIds.has(voucher.id))
        .map((voucher) => ({
          id: voucher.id,
          voucherNumber: voucher.invoiceNo || "N/A",
          date: voucher.invoiceDate || receiptData.date,
          total: Number.parseFloat(voucher.invoiceAmount) || 0,
          dueAmount: Number.parseFloat(voucher.amount) || 0,
          paymentClear: Number.parseFloat(voucher.amount) || 0,
        }));

      // Merge the additional vouchers with existing line items
      lineItems = [...additionalVouchers, ...lineItems];
    }

    const totalDueAmount = lineItems.reduce(
      (total, item) => total + item.dueAmount,
      0
    );

    setLineItemsData(lineItems);
    setTotalAmountData(totalDueAmount);
  }, [selectedBillOrInvoiceData, receiptData, isEditing]);

  const addReceiptMutation = useMutation({
    mutationFn: addReceipts,
    onSuccess: handleMutationSuccess,
    onError: handleMutationError,
  });

  const editReceiptMutation = useMutation({
    mutationFn: (data) => editReceipts(data, receiptData.id),
    onSuccess: handleMutationSuccess,
    onError: handleMutationError,
  });

  function handleMutationSuccess(data) {
    queryClient.invalidateQueries({ queryKey: ["receiptdata"] });
    if (data?.status === 200 || data?.status === 201) {
      form.reset();
      onClose?.();
      toast.success(`Receipt ${isEditing ? "updated" : "added"} successfully`);
    } else if (data?.status === 409) {
      toast.warning(data?.data?.error[0]?.message || "A conflict occurred");
    } else {
      toast.error(
        data?.response?.data?.error[0]?.message ||
          "An unexpected error occurred"
      );
    }
  }

  function handleMutationError(error) {
    toast.error(error || "Something went wrong, try again");
  }

  function onSubmit(values) {
    // console.log(values);
    const lineItemFromatedVal = lineItemsData
      ?.filter((val) => val?.paymentClear > 0) // Only include vouchers with non-zero amounts
      ?.map((val) => ({
        id: val?.id,
        amount: val?.paymentClear,
      }));

    const formattedValues = {
      ...values,
      amount: Number(values.amount),
      date: values.date ? formatDate(values.date, "yyyy-MM-dd") : undefined,
      chequeDate: values.chequeDate
        ? formatDate(values.chequeDate, "yyyy-MM-dd")
        : undefined,
      paymentModeId: Number(values.paymentModeId),
    };

    if (!values.onAccount) formattedValues.vouchers = lineItemFromatedVal;

    const selectedOption = oppositeAccountValues.find(
      (option) =>
        option.value === formattedValues.oppositeAccountOrPartyId.toString()
    );

    if (selectedOption) {
      if (selectedOption.type === "account") {
        formattedValues.oppositeAccountId =
          formattedValues.oppositeAccountOrPartyId;
        formattedValues.partyId = undefined;
      } else if (selectedOption.type === "party") {
        formattedValues.partyId = formattedValues.oppositeAccountOrPartyId;
        formattedValues.oppositeAccountId = undefined;
      }
    } else {
      formattedValues.oppositeAccountId = undefined;
      formattedValues.partyId = undefined;
    }

    delete formattedValues.oppositeAccountOrPartyId;

    const filteredValues = Object.fromEntries(
      Object.entries(formattedValues).filter(([, value]) => value !== "")
    );

    if (isEditing) {
      editReceiptMutation.mutate(filteredValues);
    } else {
      addReceiptMutation.mutate(filteredValues);
    }
  }

  const [isAmountChangedByUser, setIsAmountChangedByUser] = useState(false);
  const prevWatchAmountRef = useRef();

  const watchAmount = form.watch("amount");

  useEffect(() => {
    if (
      watchAmount !== prevWatchAmountRef.current &&
      isAmountChangedByUser &&
      lineItemsData.length > 0
    ) {
      let remainingAmount = Number.parseFloat(watchAmount);

      // Sort line items by due amount in descending order
      const sortedLineItems = [...lineItemsData].sort(
        (a, b) => b.dueAmount - a.dueAmount
      );

      const updatedLineItems = sortedLineItems.map((item) => {
        const currentDueAmount = item.dueAmount;

        if (remainingAmount > 0) {
          // Fill the current voucher with either its full due amount or the remaining amount
          const paymentClear = Math.min(currentDueAmount, remainingAmount);
          remainingAmount -= paymentClear;

          return {
            ...item,
            paymentClear: Number.parseFloat(paymentClear.toFixed(2)),
          };
        }

        // If no remaining amount, set payment to 0
        return {
          ...item,
          paymentClear: 0,
        };
      });

      // Restore original order before updating state
      const reorderedItems = lineItemsData.map((originalItem) => {
        return updatedLineItems.find(
          (updatedItem) => updatedItem.id === originalItem.id
        );
      });

      setLineItemsData(reorderedItems);
      setIsAmountChangedByUser(false);
    }
    prevWatchAmountRef.current = watchAmount;
  }, [watchAmount, lineItemsData, isAmountChangedByUser]);

  useEffect(() => {
    if (!lineItemsData?.length) return;

    const updatedLineItems = lineItemsData.map((item) => ({
      ...item,
      paymentClear: markAllPaid ? Number(item.dueAmount) : 0,
    }));

    setLineItemsData(updatedLineItems);

    // Calculate and update total amount
    const newTotalAmount = updatedLineItems.reduce(
      (total, item) => total + (item.paymentClear || 0),
      0
    );

    form.setValue("amount", newTotalAmount.toFixed(2), {
      shouldValidate: true,
    });
  }, [markAllPaid]);

  const handlePaymentClearChange = useCallback(
    (index, value) => {
      setLineItemsData((prevItems) => {
        const updatedItems = [...prevItems];

        let newPaymentClear = Number.parseFloat(value);
        if (isNaN(newPaymentClear)) {
          newPaymentClear = 0;
        }

        newPaymentClear = Math.round(newPaymentClear * 100) / 100;
        newPaymentClear = Math.min(
          newPaymentClear,
          updatedItems[index].dueAmount
        );

        updatedItems[index] = {
          ...updatedItems[index],
          paymentClear: newPaymentClear,
        };

        const newTotalAmount = updatedItems.reduce(
          (total, item) => total + (item.paymentClear || 0),
          0
        );

        form.setValue("amount", newTotalAmount.toFixed(2), {
          shouldValidate: true,
        });

        return updatedItems;
      });
    },
    [form]
  );

  const handleAmountKeyDown = (event) => {
    if (event.key === "Backspace") {
      const currentValue = form.getValues("amount");
      const newValue = currentValue.slice(0, -1);
      form.setValue("amount", newValue, { shouldValidate: true });
      event.preventDefault();
    }
  };

  console.log(form?.formState?.errors, "ERRORS");

  const handlePartyInputChange = useCallback((value, fieldName) => {
    setPartyInputValues((prev) => ({ ...prev, [fieldName]: value }));
  }, []);

  const handleConfigurePaymentMode = () => {
    openSheet({
      title: "Configure Payment Mode",
      component: (
        <PaymentModeConfig
          onPaymentModeCreated={async (newPaymentMode) => {
            console.log(newPaymentMode);
            // Set the newly created payment mode as selected
            setPaymentModeId(newPaymentMode);
            form.setValue("paymentModeId", newPaymentMode?.toString());
            // Immediately refetch the payment modes list

            await queryClient.invalidateQueries({
              queryKey: ["allPaymentModes"],
            });
            // If useSheetStore has a closeSheet method, you can use it here ,Close the sheet (if needed)
            const closeSheet = useSheetStore.getState().closeSheet;
            if (closeSheet) {
              closeSheet();
            }
          }}
        />
      ),
    });
  };

  // Add this effect near your other useEffect hooks
  useEffect(() => {
    if (allPaymentModes?.data?.data && paymentModeId) {
      // Check if the selected payment mode exists in the options
      const paymentModeExists = allPaymentModes.data.data.some(
        (mode) => mode.id.toString() === paymentModeId
      );

      if (!paymentModeExists) {
        form.setValue("paymentModeId", "");
      }

      form.setValue("paymentModeId", paymentModeId?.toString());
    }
  }, [allPaymentModes?.data?.data, form, paymentModeId]);

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="flex items-center h-[76px] px-4 border-b bg-indigo-50 rounded-tl-2xl">
        <h1 className="text-lg font-semibold">
          {isEditing ? "Edit Receipt" : "Add Receipt"}
        </h1>
      </div>

      <Form {...form}>
        <form
          id="receiptForm"
          onSubmit={form.handleSubmit(onSubmit)}
          className="flex-1 overflow-auto"
        >
          <div className="   space-y-6">
            {/* First Row */}
            <div className="px-6 pt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <div className="space-y-2">
                <CommonCalendarInput
                  form={form}
                  name="date"
                  label="Date"
                  placeholder="Select Date"
                  className="w-full"
                />
              </div>
              <div className="space-y-2">
                <FormSelectField
                  control={form.control}
                  name="depositToAccountId"
                  label="Deposit To "
                  placeholder="Choose Account"
                  options={accountname?.data?.data?.map((group) => ({
                    value: `${group.id}`,
                    label: group.name,
                  }))}
                  className="w-full"
                  required
                />
              </div>
              <div className="space-y-2 mt-[4px]">
                <FormField
                  control={form.control}
                  name="oppositeAccountOrPartyId"
                  render={({ field }) => (
                    <FormItem className={cn("space-y-1")}>
                      <FormLabel className="text-[#40566D]">
                        Received From
                      </FormLabel>
                      <FormControl>
                        <AutoCompleteRecieptSelector
                          value={field.value}
                          inputValue={
                            receipt?.id
                              ? receiptData?.partyId === null
                                ? receiptData?.oppositeAccountName
                                : receiptData?.partyName
                              : partyInputValues[field.name]
                          }
                          onInputChange={(value) =>
                            handlePartyInputChange(value, field.name)
                          }
                          onSelect={(selectPartyID) => {
                            field.onChange(
                              selectPartyID ? selectPartyID : null
                            );
                            form.setValue(
                              "oppositeAccountOrPartyId",
                              selectPartyID?.toString()
                            );
                          }}
                          options={oppositeAccountValues}
                          onSearch={setOppositeAccountSearchQuery}
                          placeholder="Choose Account"
                          emptyMessage="No parties / Account found"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="space-y-2">
                <FormSelectField
                  control={form.control}
                  name="paymentModeId"
                  label="Payment Mode"
                  placeholder="Choose Payment Mode"
                  options={allPaymentModes?.data?.data?.map((mode) => ({
                    value: `${mode.id}`,
                    label: mode.name,
                  }))}
                  className="w-full"
                  required
                  customButtonLabel="Mange Payment Mode"
                  onCustomButtonClick={handleConfigurePaymentMode}
                  // value={form.watch("paymentModeId")}
                  // onChange={(newValue) => {
                  //   form.setValue("paymentModeId", newValue, {
                  //     shouldValidate: true,
                  //   });
                  // }}
                />
              </div>
            </div>

            <div className="px-6 pb-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <div className="space-y-2">
                <TextInputField
                  form={form}
                  name="amount"
                  label="Amount"
                  type="text"
                  placeholder="Enter Amount Here"
                  onChange={handleAmountChange}
                  onKeyDown={handleAmountKeyDown}
                  className="flex flex-col space-y-1.5"
                  required
                />
                <div className="text-xs font-semibold">
                  {partyOrAccountType === "party" &&
                    onAccountData === false && (
                      <>Total Due: {Number(totalAmountData).toFixed(2)}</>
                    )}
                </div>
              </div>
              <div className="">
                <TextInputField
                  form={form}
                  name="referenceNumber"
                  type="text"
                  label="Reference No."
                  placeholder="Enter Reference No. Here"
                  className="w-full"
                />
              </div>
              <div className="space-y-2">
                <TextareaInputField
                  form={form}
                  name="notes"
                  label="Remarks"
                  placeholder="Write your Remarks Here"
                  rows={1}
                />
              </div>

              {partyOrAccountType === "party" && (
                <>
                  <div className="space-y-2  my-auto">
                    <GlobalSwitch
                      form={form}
                      name="onAccount"
                      label="Received Lump Sump Amount"
                      className="p-0"
                      switchClassName="data-[state=checked]: "
                      onChange={() => form.setValue("amount", "0")}
                    />
                  </div>
                </>
              )}
            </div>

            <div className="" />
            {onAccountData === false && (
              <>
                <div className="flex justify-end items-center space-x-2 w-[100%] px-6  mx-auto">
                  <Label
                    htmlFor="is-inclusive-tax"
                    className="font-normal text-sm text-[#192839] "
                  >
                    Mark all Paid ({Number(totalAmountData).toFixed(2)})
                  </Label>
                  <Switch
                    id="mark-all-paid"
                    checked={markAllPaid}
                    onCheckedChange={(checked) => {
                      setMarkAllPaid(checked);
                    }}
                    className="data-[state=checked]: "
                  />
                </div>

                {/* {!onAccountData && ( */}
                <div className="w-[100%] px-6  mx-auto overflow-x-auto">
                  <div className="border rounded-lg overflow-hidden">
                    <Table className=" w-full">
                      <TableHeader className="bg-[#F5F8FF]">
                        <TableRow>
                          <TableHead className="border-r w-1/5 px-2 py-1 text-left text-[#192839] font-semibold font">
                            Date
                          </TableHead>
                          <TableHead className="border-r w-1/5 px-2 py-1 text-left text-[#192839] font-semibold font">
                            Invoice No.
                          </TableHead>
                          <TableHead className="border-r w-1/5 px-2 py-1 text-right text-[#192839] font-semibold font">
                            Invoice Amount
                          </TableHead>
                          <TableHead className="border-r w-1/5 px-2 py-1  text-right text-[#192839] font-semibold font">
                            Due Amount
                          </TableHead>
                          <TableHead className=" px-2 w-1/5 py-1 text-left text-[#192839] font-semibold font">
                            Amount
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {!lineItemsData || lineItemsData.length === 0 ? (
                          <TableRow>
                            <TableCell
                              colSpan="5"
                              className=" h-[130px] px-2 py-4 text-center text-gray-500"
                            >
                              No invoices found
                            </TableCell>
                          </TableRow>
                        ) : (
                          lineItemsData.map((item, index) => (
                            <TableRow key={item.voucherNumber}>
                              <TableCell className="border-r px-2 py-1 text-left">
                                {formatDate(item.date, "dd-MM-yyyy")}
                              </TableCell>
                              <TableCell className="border-r px-2 py-1 text-left">
                                {item.voucherNumber}
                              </TableCell>
                              <TableCell className="border-r px-2 py-1 text-right">
                                {item.total.toFixed(2)}
                              </TableCell>
                              <TableCell className="border-r px-2 py-1 text-right">
                                {item?.dueAmount.toFixed(2)}
                              </TableCell>
                              <TableCell className=" px-2 py-1 text-left">
                                <input
                                  type="text"
                                  value={item.paymentClear}
                                  onChange={(e) =>
                                    handlePaymentClearChange(
                                      index,
                                      e.target.value
                                    )
                                  }
                                  className="w-full p-1 border rounded"
                                  onFocus={(e) => {
                                    e.target.select();
                                  }}
                                  max={item.dueAmount}
                                />
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </>
            )}

            <div className="p-3 md:p-6 flex flex-col md:flex-row gap-4 md:justify-end">
              {/* Total Amount Section */}
              {onAccountData === false && (
                <div className="w-full md:w-[366px]">
                  <div className="border border-[#D2D6DB] rounded-lg">
                    <div className="flex justify-between items-center  border-[#D2D6DB] px-4 md:px-6 py-3 text-sm">
                      <span className="text-[#40566D]">
                        Total Amount Received
                      </span>
                      <span className="font-medium">{watchAmount}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </form>
      </Form>

      {/* Footer */}
      <div className="border-t p-4 rounded-bl-2xl bg-indigo-50 h-[76px] flex justify-end space-x-4">
        <Button
          type="submit"
          form="receiptForm"
          className="  text-white hover: "
          disabled={
            addReceiptMutation.isPending || editReceiptMutation.isPending
          }
        >
          {addReceiptMutation.isPending || editReceiptMutation.isPending ? (
            <>
              <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
              {isEditing ? "Updating..." : "Adding..."}
            </>
          ) : (
            "Save"
          )}
        </Button>
      </div>
    </div>
  );
};
