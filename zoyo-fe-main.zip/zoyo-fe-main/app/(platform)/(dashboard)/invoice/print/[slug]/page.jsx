"use client";
import CustomGlobalPDFdownloaderByUrl from "@/components/custom-global-pdf-download/custom-global-pdf-download-by-url";
import { Loader2 } from "lucide-react";
import { useParams } from "next/navigation";
import React from "react";

const PrintTemplate = () => {
  const { slug } = useParams();
  if (!slug) {
    return (
      <>
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
          <p className="mt-2 text-sm text-gray-600">Loading template...</p>
        </div>
      </>
    );
  }
  return (
    <>
      <CustomGlobalPDFdownloaderByUrl userdata={slug} voucherType={"invoice"} />
    </>
  );
};

export default PrintTemplate;
