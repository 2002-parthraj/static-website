"use client";

import React, { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ChevronDown,
  ChevronUp,
  CloudUpload,
  Copy,
  EllipsisVertical,
  PencilLine,
  Send,
  Trash2,
  XCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import CustomGlobalPDFdownloader from "@/components/custom-global-pdf-download/custom-global-pdf-download";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Card } from "@/components/ui/card";
import CustomTable from "@/components/custom-table/custom-table";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { useRouter } from "next/navigation";
import useDebounce from "@/hooks/use-debounce";
import { getAllEwayBills } from "@/actions/ewaybills/get-all-ewaybills";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { deleteEwayBills } from "@/actions/ewaybills/delete-e-way-bills";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { generateEwayBills } from "@/actions/ewaybills/generate-e-way-bills";
import { toast } from "sonner";

const EwayBillsListingpage = () => {
  const queryClient = useQueryClient();
  const router = useRouter();
  const { confirmDelete } = useDeleteConfirmation();

  const [sortBy, setSortBy] = useState("voucherDate");
  const [selectedPartyId, setSelectedPartyId] = useState(null);
  const [sortOrder, setSortOrder] = useState("desc");
  const [changePageCount, setChangePageCount] = useState(1);
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [status, setStatus] = useState({
    key: "draft",
    heading: "Draft",
  });
  const [isEwayBillsSheetOpen, setEwayBillsIsSheetOpen] = useState(false);
  const [editEwayBillsData, seteditEwayBillsData] = useState(null);

  const debouncedSearchValue = useDebounce(searchValue, 500);

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const {
    data: EwayBillsListing,
    isLoading,
    error,
  } = useQuery({
    queryKey: [
      "eway-listing",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
      status,
    ],
    queryFn: () =>
      getAllEwayBills(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue,
        status
      ),
  });

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const deleteMutation = useMutation({
    mutationFn: (id) => deleteEwayBills(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["eway-listing"] });
      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(
          data?.data?.message || "E-way Bills deleted successfully"
        );
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to delete the E-way Bills. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const generateEwayBillMutation = useMutation({
    mutationFn: (id) => generateEwayBills(id),
    onSuccess: (data) => {
      console.log(data?.data);
      if (data.data.success === false || data?.data?.error) {
        const errorMessage =
          data.data?.errors?.[0]?.message?.split("\r\n")[0] ||
          data.data?.error?.[0]?.details?.[0]?.message ||
          "Something went wrong";
        toast.error(errorMessage);
      } else {
        toast.success("E-way bill generated successfully!");
      }
    },
    onError: (error) => {
      console.log(error);
      toast.error(
        `Failed to generate the E-way Bills. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (userId) => {
    confirmDelete(`e-way bills ${userId?.partyName}`, () => {
      deleteMutation.mutate(userId?.id);
    });
  };

  const handleSheetClose = () => {
    setEwayBillsIsSheetOpen(false);
    seteditEwayBillsData(null);
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case "approved":
        return (
          <Badge className="text-[#039855] bg-[#ECFDF3] rounded-3xl">
            Approved
          </Badge>
        );
      case "draft":
        return (
          <Badge className="text-[#BD7D00] bg-[#FCF0D3] rounded-3xl">
            Draft
          </Badge>
        );
      case "submitted":
        return <Badge variant="destructive">Submitted</Badge>;
      case "rejected":
        return (
          <Badge className="text-red-500" variant="outline">
            Rejected
          </Badge>
        );
      default:
        return null;
    }
  };

  const handleEwaybilssEdit = (userdata) => {
    setEwayBillsIsSheetOpen(true);
    seteditEwayBillsData(userdata?.id);
  };

  const myEstimatesColumns = [
    {
      id: "select",
      header: ({ table }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedItemId !== null}
            onCheckedChange={(value) => {
              if (!value) {
                setSelectedItemId(null);
                table?.toggleAllPageRowsSelected(false);
              }
            }}
            aria-label="Select item"
          />
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedItemId === row.original.id}
            onCheckedChange={(value) => {
              if (value) {
                setSelectedItemId(row.original.id);
              } else {
                setSelectedItemId(null);
              }
            }}
            aria-label="Select row"
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
    },

    {
      id: "voucherDate",
      accessorKey: "voucherDate",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("voucherDate")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("voucherDate");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Date
              {renderSortIcon("voucherDate")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const date = new Date(row?.original.voucherDate);
        const formattedDate = date
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          })
          .split("/")
          .join("-");
        return <div className="text-left">{formattedDate}</div>;
      },
    },

    {
      id: "voucherNumber",
      accessorKey: "voucherNumber",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("voucherNumber")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("voucherNumber");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Voucher No.
              {renderSortIcon("voucherNumber")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left">{row?.getValue("voucherNumber")}</div>
      ),
    },

    {
      id: "partyName",
      accessorKey: "partyName",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("partyName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("partyName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Party Name
              {renderSortIcon("partyName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left">{row?.getValue("partyName")}</div>
      ),
    },

    {
      id: "documentType",
      accessorKey: "documentType",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("documentType")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("documentType");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Transaction Type
              {renderSortIcon("documentType")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left">{row?.getValue("documentType")}</div>
      ),
    },
    {
      id: "status",
      accessorKey: "status",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("status")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === "") {
                onSortChange("status");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Status
              {renderSortIcon("status")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left capitalize">
          {renderStatusBadge(row?.getValue("status"))}
        </div>
      ),
    },
    {
      id: "amount",
      accessorKey: "amount",
      header: ({ column }) => (
        <div className="flex justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("amount")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("amount");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Amount
              {renderSortIcon("amount")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right">
          {Number(row?.getValue("amount") || 0).toFixed(2)}
        </div>
      ),
    },
    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className=" flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEwaybilssEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            {/* <div className="border-r border-gray-300 flex items-center">
              <div className="flex items-center mr-2">
                <CustomGlobalPDFdownloader userdata={userdata} />
              </div>
            </div> */}
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => {
                  console.log(userdata),
                    generateEwayBillMutation.mutate(userdata.id);
                }}
              >
                <CloudUpload className="h-4 w-4" />
              </Button>
            </div>
            <div className=" flex items-center">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    size="icon"
                    className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                  >
                    <EllipsisVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem className="cursor-pointer">
                    <Send className="mr-2 h-4 w-4" />
                    Send
                  </DropdownMenuItem>

                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="cursor-pointer text-red-600"
                    onClick={() => handleDelete(userdata)}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        );
      },
    },
  ];

  const statusOptions = [
    {
      key: "submitted",
      heading: "Submitted",
    },
    {
      key: "draft",
      heading: "Draft",
    },
    {
      key: "approved",
      heading: "Approved",
    },
  ];

  const ChangeStatus = (param) => {
    setStatus(param);
  };

  const otherFields = () => {
    return (
      <>
        <div className="pt-4 pb-4 flex justify-between ">
          <div className="mr-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center gap-2">
                  {status.heading}
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {statusOptions.map((option) => (
                  <DropdownMenuItem
                    key={option.key}
                    onClick={() => ChangeStatus(option)}
                    className="cursor-pointer"
                  >
                    {option.heading}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </>
    );
  };

  return (
    <main>
      <Card className="rounded-md">
        <CustomTable
          data={EwayBillsListing?.data?.data || []}
          columns={myEstimatesColumns}
          isLoading={isLoading}
          error={error}
          tableHeader="e-Way Bills"
          tableWidth={"100%"}
          paginationData={EwayBillsListing?.data?.pagination}
          pageChangeCount={setChangePageCount}
          totalRowCount={setTotalRowCount}
          getSerchValue={setSearchValue}
          serchPlaceholder={"Search"}
          filterFields={otherFields()}
          addbuttonLable={"Add e-Way Bills"}
          onClickAddbutton={() => {
            seteditEwayBillsData(null);
            setEwayBillsIsSheetOpen(true);
          }}
          module="eway-bills"
        />

        <Custom_Sheet
          isOpen={isEwayBillsSheetOpen}
          onClose={handleSheetClose}
          activeKey={"ewaybills"}
          editId={editEwayBillsData}
        />
      </Card>
    </main>
  );
};

export default EwayBillsListingpage;
