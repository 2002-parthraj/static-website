import { getAllTransporter } from "@/actions/ewaybills/get-all-transporter";
import { getAllVoucharsEwayBills } from "@/actions/ewaybills/get-all-voucher-eway";
import {
  CommonCalendarInput,
  FormSelectField,
  RadioGroupField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import AutoCompletePartySelector from "@/components/custom-party-selections-model/AutoCompletePartySelector";
import {
  documentsTypeOptions,
  documentSubTypeMap,
  TransportationOptions,
  TransporterOptions,
  transportModeLabels,
  VehicleTypeOptions,
} from "@/components/enums/enums";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import useDebounce from "@/hooks/use-debounce";
import { cn } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { AddEwayBills } from "@/actions/ewaybills/add-e-way-bills";
import { editEwayBills } from "@/actions/ewaybills/edit-e-way-bills";
import { toast } from "sonner";
import { ReloadIcon } from "@radix-ui/react-icons";
import { getSingleEwayBills } from "@/actions/ewaybills/get-single-e-waybills";
import { useTransporterModalStore } from "@/hooks/stores/useModalStore";
import { deleteTransporter } from "@/actions/ewaybills/delete-transporter";
import {
  fetchInitialPartiesforDeleiveryChalan,
  getSuggestionOfPartiesforDeleiveryChalan,
} from "@/actions/delivery_challan/search-customer-suggestion";
import { formatDate } from "date-fns";
import Link from "next/link";
import { ExternalLink } from "lucide-react";
import { useConfirmationModalStore } from "@/hooks/stores/use-delete-confirm-store";

const documentTypeToApiKey = {
  deliveryChallan: "delivery-challans",
  creditNote: "credit-notes",
  invoice: "invoices",
  // Add more mappings as needed
};

const EwayBillsformSchema = z
  .object({
    documentType: z.string({
      required_error: "Please select a document type.",
    }),
    transactionSubType: z.string({
      required_error: "Please select a transaction sub type.",
    }),
    distance: z
      .string({ message: "Please enter distance." })
      .min(1, "Distance is required")
      .regex(/^\d+$/, "Distance must be a valid number."),
    voucherNumber: z.string({
      required_error: "Please select a document type.",
    }),
    partyId: z
      .string({
        required_error: "Party is required.", // Message when party is not selected
        invalid_type_error: "Please select a valid party.", // Message for invalid type
      })
      .nullable() // Allow null values
      .refine((val) => val !== null && val !== "", {
        message: "Please select a party.",
      }),
    transportMode: z.string().optional(),
    vehicleType: z.string().optional(),
    vehicleNumber: z.string().optional(),
    transporterId: z.string().optional(),
    transporterDocNumber: z.string().optional(),
    transporterDocDate: z.date().optional(),
  })
  .superRefine((data, ctx) => {
    // Validation for Road transport
    if (data.transportMode === "road") {
      if (!data.vehicleType) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Vehicle type is required for road transport",
          path: ["vehicleType"],
        });
      }
      if (!data.vehicleNumber) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Vehicle number is required for road transport",
          path: ["vehicleNumber"],
        });
      }
    }

    // Validation for Rail transport
    if (data.transportMode === "rail" && !data.transporterDocNumber) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "RR number is required for rail transport",
        path: ["transporterDocNumber"],
      });
    }

    // Validation for Ship transport
    if (data.transportMode === "ship" && !data.transporterDocNumber) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Bill of Lading number is required for ship transport",
        path: ["transporterDocNumber"],
      });
    }

    // Validation for Air transport
    if (data.transportMode === "air" && !data.transporterDocNumber) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Air way bill number is required for air transport",
        path: ["transporterDocNumber"],
      });
    }
  });

const AddEditeEwayBills = ({ editId, onClose }) => {
  const { openModal } = useTransporterModalStore();

  const queryClient = useQueryClient();

  const [subTypeOptions, setSubTypeOptions] = useState([]);
  const [partyInputValues, setPartyInputValues] = useState({});
  const [vouchernputValues, setVoucherInputValues] = useState({});

  const [searchValue, setSearchValue] = useState("");
  const [selectedVoucherData, setSelectedVoucherData] = useState(null);
  const [partyValues, setPartyValues] = useState([]);

  const debouncedSearchValue = useDebounce(searchValue, 500);

  const form = useForm({
    resolver: zodResolver(EwayBillsformSchema),
    defaultValues: {
      amount: "",
      voucherId: "",
      voucherDate: "",
      transportMode: "",
      vehicleType: "",
      vehicleNumber: "",
      partyId: "",
      status: "draft",
      // transporterDocNumber: "",
      transporterDocDate: new Date(),
    },
  });

  const watchDocumentType = form.watch("documentType");
  const currentApiKey = documentTypeToApiKey[watchDocumentType] || "";

  const { data: voucherData } = useQuery({
    queryKey: ["E-way-bills-vouchars", debouncedSearchValue, currentApiKey],
    queryFn: () => getAllVoucharsEwayBills(debouncedSearchValue, currentApiKey),
    enabled: !!currentApiKey, // Only run query when we have a valid API key
  });

  const { data: transportersResponse, refetch: getAllTransporterData } =
    useQuery({
      queryKey: ["All-transporters"],
      queryFn: getAllTransporter,
    });

  const { data: getewayBillDataByID, isLoading: isLoadingEwayBill } = useQuery({
    queryKey: ["getewayBillDataByID", editId],
    queryFn: () => getSingleEwayBills(editId),
    enabled: !!editId,
  });

  const handlePartySearch = useCallback(async (query) => {
    if (query) {
      const partySuggestions = await getSuggestionOfPartiesforDeleiveryChalan(
        query
      );
      setPartyValues(partySuggestions);
    }
  }, []);

  const fetchSuggestionsforParty = useCallback(async () => {
    const initialParties = await fetchInitialPartiesforDeleiveryChalan();
    setPartyValues(initialParties);
  }, []);

  // Use this query to fetch suggestions
  useQuery({
    queryKey: ["suggestionsforparty"],
    queryFn: fetchSuggestionsforParty,
    enabled: true,
  });

  useEffect(() => {
    if (watchDocumentType) {
      const subTypes = documentSubTypeMap[0][watchDocumentType] || [];
      const options = subTypes.map((type) => ({
        value: type,
        id: type,
        label: type
          .split("_")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" "),
      }));

      setSubTypeOptions(options);
    } else {
      setSubTypeOptions([]);
    }
  }, [watchDocumentType]);

  const watchTransportMode = form.watch("transportMode");

  const currentTransportLabels =
    transportModeLabels[watchTransportMode] || transportModeLabels.road;

  // Create dynamic vehicle type options based on transport mode
  const filteredVehicleTypeOptions = useMemo(() => {
    if (watchTransportMode === "road") {
      return VehicleTypeOptions; // Show all options for road transport
    }
    return VehicleTypeOptions.filter(
      (option) => option.value !== "overDimensionalCargo"
    );
  }, [watchTransportMode]);

  // Reset vehicle type when transport mode changes
  useEffect(() => {
    form.setValue("vehicleType", ""); // Reset vehicle type when transport mode changes
  }, [watchTransportMode, form]);

  const handleVoucherInputChange = (value, fieldName) => {
    setVoucherInputValues((prev) => ({
      ...prev,
      [fieldName]: value,
    }));
    setSearchValue(value);
  };

  const handlePartyInputChange = useCallback((value, fieldName) => {
    setPartyInputValues((prev) => ({ ...prev, [fieldName]: value }));
  }, []);

  // Transform transporter data into options format
  const transporterOptions = useMemo(() => {
    if (!transportersResponse?.data?.data) return [];

    return transportersResponse.data.data.map((transporter) => ({
      value: transporter.id.toString(),
      label: transporter.name,
      id: transporter.id,
      transporterId: transporter.transporterId,
    }));
  }, [transportersResponse?.data?.data]);

  // Transform voucher data into options format
  const voucherOptions =
    voucherData?.data?.data?.map((voucher) => ({
      id: voucher.id,
      label: `${voucher.voucherNumber}  (${formatDate(
        voucher.date,
        "dd-MM-yyyy"
      )})`,
      value: voucher.id.toString(),
      voucherData: voucher, // Store the complete voucher data
    })) || [];

  const handleVoucherSelect = (selectedVoucher) => {
    console.log(selectedVoucher);
    if (selectedVoucher) {
      const voucherData = voucherOptions.find(
        (opt) => opt.id === Number(selectedVoucher)
      )?.voucherData;

      if (voucherData) {
        setSelectedVoucherData(voucherData);
        // form.setValue("amount", Number.parseFloat(voucherData.total));
        form.setValue("voucherId", voucherData.id);
        form.setValue("voucherNumber", voucherData.voucherNumber);
        form.setValue("voucherDate", voucherData.date);
      }
    }
  };

  useEffect(() => {
    if (getewayBillDataByID) {
      form.setValue("documentType", getewayBillDataByID.documentType);
      form.setValue("transportMode", getewayBillDataByID.transportMode || "");
      setTimeout(() => {
        form.setValue(
          "transactionSubType",
          getewayBillDataByID.transactionSubType
        );
        form.setValue("vehicleType", getewayBillDataByID.vehicleType || "");
      }, 0);

      form.setValue("voucherNumber", getewayBillDataByID.voucherNumber);
      form.setValue("partyId", getewayBillDataByID.partyId.toString());

      // Set remaining fields
      form.setValue("distance", getewayBillDataByID.distance?.toString() || "");
      form.setValue("vehicleNumber", getewayBillDataByID.vehicleNumber || "");
      form.setValue(
        "transporterId",
        getewayBillDataByID.transporterId?.toString() || ""
      );
      form.setValue(
        "transporterDocNumber",
        getewayBillDataByID.transporterDocNumber || ""
      );

      if (getewayBillDataByID.transporterDocDate) {
        form.setValue(
          "transporterDocDate",
          new Date(getewayBillDataByID.transporterDocDate)
        );
      }

      setPartyInputValues({ partyId: getewayBillDataByID?.partyName || "" });

      setSelectedVoucherData({
        id: getewayBillDataByID.voucherId,
        voucherNumber: getewayBillDataByID.voucherNumber || "",
        date: getewayBillDataByID.voucherDate || "",
        total: getewayBillDataByID.amount || 0,
      });

      if (getewayBillDataByID.voucherNumber) {
        setVoucherInputValues({
          voucherNumber: getewayBillDataByID.voucherNumber,
        });
        setSearchValue(getewayBillDataByID.voucherNumber);
      }
    }
  }, [form, getewayBillDataByID]);

  const AddEditMutation = useMutation({
    mutationFn: editId ? (data) => editEwayBills(data, editId) : AddEwayBills,

    onSuccess: (data) => {
      if (data.status === 201 || data.status === 200) {
        toast.success(
          editId
            ? "E-way bill updated successfully!"
            : "E-way bill added successfully!"
        );
        onClose();
        form.reset();
      } else {
        toast.error(data.response.error[0].message || "Something went wrong!");
      }
      queryClient.invalidateQueries(["eway-listing"]);
    },
    onError: (error) => {
      // toast.error(error?.message || "Something went wrong!");
      console.error("E-way bill operation failed:", error);
    },
  });

  const deleteTransporterMutation = useMutation({
    mutationKey: ["delete-Transporter-person"],
    mutationFn: deleteTransporter,
    onSuccess: () => {
      toast.success("Transporter deleted successfully!!");
      getAllTransporterData();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete sales person");
    },
  });

  const formatingDate = (date) => {
    if (!date) return "";
    const d = new Date(date);
    return d.toISOString().split("T")[0]; // This will format date as YYYY-MM-DD
  };

  const onSubmit = (data) => {
    console.log(data, "SUBMITDATA");
    const payload = {
      documentType: data.documentType,
      voucherId: Number.parseInt(selectedVoucherData.id),
      partyId: Number(data.partyId),
      transactionSubType: data.transactionSubType,
      voucherNumber: data.voucherNumber,
      voucherDate: selectedVoucherData.date,
      distance: Number.parseInt(data.distance),
      transportMode: data.transportMode || undefined,
      vehicleType: data.vehicleType || undefined,
      vehicleNumber: data.vehicleNumber,
      transporterId: Number.parseInt(data.transporterId) || undefined,
      status: "draft",
      amount: Number.parseFloat(selectedVoucherData.total),
      transporterDocDate: formatingDate(data.transporterDocDate) || new Date(),
      transporterDocNumber: data.transporterDocNumber,
    };

    AddEditMutation.mutate(payload);
  };

  return (
    <>
      <div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-[#ECF1FF] p-6 border-b">
        <h2 className="text-lg text-[#192839] font-semibold">
          {editId ? "Edit" : "Add"} E-Way Bills
        </h2>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <main className=" h-[calc(100vh-153px)] overflow-y-auto  ">
            <div className="mx-auto w-[90%] gap-4 py-2">
              <FormSelectField
                control={form.control}
                name="documentType"
                label="Document Type"
                placeholder="Choose Document Type"
                options={documentsTypeOptions}
                required
              />
            </div>

            <div className="mx-auto w-[90%] gap-4 py-2">
              <FormSelectField
                control={form.control}
                name="transactionSubType"
                label="Transaction Sub Type"
                placeholder="Choose Transaction Sub Type"
                options={subTypeOptions}
                required
                disabled={!watchDocumentType}
              />
            </div>

            <div className="mx-auto w-[90%] gap-4 py-2">
              <FormField
                control={form.control}
                name="partyId"
                render={({ field }) => (
                  <FormItem className={cn("space-y-1")}>
                    <FormLabel className="text-[#40566D] mb-1">
                      Party Name <span className="text-red-500 ml-1">*</span>
                    </FormLabel>
                    <FormControl>
                      <AutoCompletePartySelector
                        value={field.value}
                        inputValue={partyInputValues[field.name] || ""}
                        onInputChange={(value) =>
                          handlePartyInputChange(value, field.name)
                        }
                        onSelect={(selectPartyID) => {
                          form.setValue("partyId", selectPartyID?.toString());
                        }}
                        onSelectPartyDetails={(selectedparty) =>
                          setSearchValue(selectedparty.label)
                        }
                        options={partyValues}
                        onSearch={handlePartySearch}
                        placeholder="Choose Party"
                        emptyMessage="No parties found"
                        onAddNewParty={() => setAddPartyIsSheetOpen(true)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="mx-auto w-[90%] gap-4 py-2">
              <FormField
                control={form.control}
                name="voucherNumber"
                render={({ field }) => (
                  <FormItem className={cn("space-y-1")}>
                    <FormLabel className="text-[#40566D] mb-1">
                      Vouchars No.<span className="text-red-500 ml-1">*</span>
                    </FormLabel>
                    <FormControl>
                      <AutoCompletePartySelector
                        value={field.value}
                        inputValue={vouchernputValues[field.name] || ""}
                        onInputChange={(value) =>
                          handleVoucherInputChange(value, field.name)
                        }
                        onSelect={(selectVoucherID) => {
                          handleVoucherSelect(selectVoucherID);
                        }}
                        options={voucherOptions}
                        onSearch={(query) => setSearchValue(query)}
                        placeholder="Select Vouchars"
                        emptyMessage="No Vouchars Found"
                        showAddNewButton={false}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Tabs
              defaultValue="Part A"
              className="w-full  border-t-4 border-gray-200"
            >
              <div className="border-b pb-[14px] border-gray-300 text-center">
                <TabsList className="grid w-full py-2 grid-cols-2  text-center	 rounded-none  bg-white">
                  <TabsTrigger
                    value="Part A"
                    className={
                      "flex-1 pb-4 rounded-none text-sm font-medium text-gray-700 data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary  data-[state=active]:border-b-2 data-[state=active]:border-primary"
                    }
                  >
                    Part A
                  </TabsTrigger>
                  <TabsTrigger
                    value="Part B"
                    className={
                      "flex-1 rounded-none pb-4 text-sm font-medium text-gray-700   data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                    }
                  >
                    Part B
                  </TabsTrigger>
                </TabsList>
              </div>
              <TabsContent value="Part A">
                <div>
                  <div className="w-[90%] pt-4 mx-auto">
                    <FormSelectField
                      control={form.control}
                      name={"transporterId"}
                      label={"Transporter"}
                      placeholder={"Choose Transporter name "}
                      options={transporterOptions}
                      customButtonLabel="Manage Transporters"
                      onCustomButtonClick={openModal}
                      showActions={true}
                      // onDelete={(transporterID) =>
                      //   deleteTransporterMutation.mutate(transporterID)
                      // }
                      onDelete={(transporterID) => {
                        useConfirmationModalStore
                          .getState()
                          .setModalData(
                            "Delete Transporter",
                            "Are you sure you want to delete this transporter ? This action cannot be undone.",
                            () =>
                              deleteTransporterMutation.mutate(transporterID)
                          );
                      }}
                      onEdit={(transporterData) => {
                        openModal(transporterData);
                      }}
                    />
                  </div>
                  <div className="w-[90%] pt-4 mx-auto">
                    <TextInputField
                      form={form}
                      name="distance"
                      placeholder="0"
                      label="Distance (in Km)"
                      type="text"
                    />
                    <p>
                      If you enter 0 as the distance, e-Way Bill system will
                      automatically calculate it based on the dispatch and
                      delivery locations.
                    </p>
                    <Link
                      href="https://ewaybillgst.gov.in/Others/P2PDistance.aspx"
                      className=" pt-2 text-blue-700 "
                      target="_blank"
                    >
                      <span className="flex  items-center gap-1">
                        Calculate Distance{" "}
                        <ExternalLink className="mr-2 h-4 w-4" />
                      </span>
                    </Link>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="Part B">
                <div>
                  <div className="w-[90%] pt-4 mx-auto">
                    <FormSelectField
                      control={form.control}
                      name={"transportMode"}
                      label="Mode of Transportation"
                      placeholder={"Choose Mode of Transportation"}
                      options={TransportationOptions}
                    />
                  </div>
                  {watchTransportMode === "road" && (
                    <div className="w-[90%] pt-4 mx-auto">
                      <FormSelectField
                        control={form.control}
                        name={"vehicleType"}
                        label="Vehicle Type"
                        placeholder={"Choose Vehicle Type"}
                        options={filteredVehicleTypeOptions}
                        disabled={!watchTransportMode}
                      />
                    </div>
                  )}

                  {watchTransportMode === "road" && (
                    <div className="w-[90%] pt-4 mx-auto">
                      <TextInputField
                        form={form}
                        name="vehicleNumber"
                        placeholder="Enter Vehicle number"
                        label="Vehicle No"
                        type="text"
                      />
                    </div>
                  )}

                  <div className="w-[90%] pt-4 mx-auto">
                    <TextInputField
                      form={form}
                      name="transporterDocNumber"
                      placeholder={`Enter ${currentTransportLabels.docNoLabel}`}
                      label={currentTransportLabels.docNoLabel}
                      type={"text"}
                    />
                  </div>

                  <div className="w-[90%] py-4  mx-auto">
                    <CommonCalendarInput
                      form={form}
                      name="transporterDocDate"
                      label={currentTransportLabels.docDateLabel}
                      placeholder={`Choose ${currentTransportLabels.docDateLabel}`}
                      labelClassName="pt-0"
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </main>

          <div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0  h-[76px] left-0 w-full p-4 shadow-lg">
            <Button
              type="submit"
              className="  mr-3 mt-1 text-white "
              disabled={AddEditMutation.isPending}
            >
              {AddEditMutation.isPending ? (
                <>
                  <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                  {editId ? "Updating..." : "Saving..."}
                </>
              ) : editId ? (
                "Edit E-way Bill"
              ) : (
                "Add E-way Bill"
              )}
            </Button>
          </div>
        </form>
      </Form>
    </>
  );
};

export default AddEditeEwayBills;
