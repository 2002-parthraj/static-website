"use client";
import React, { useEffect, useState } from "react";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ChevronDown,
  ChevronsUpDown,
  ChevronUp,
  ListFilter,
  Pencil,
  PencilLine,
  Trash2,
} from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import CustomTable from "@/components/custom-table/custom-table";
import { toast } from "sonner";
import { getAllJournalsData } from "@/actions/journals/get-all-journals-list";
import useDebounce from "@/hooks/use-debounce";
import { deleteJournals } from "@/actions/journals/delete-journals";
import { getJournalsById } from "@/actions/journals/get-single-journals";

const JournalsPage = () => {
  const [changePageCount, setChangePageCount] = useState(1);
  const [sortBy, setSortBy] = useState("date");
  const [sortOrder, setSortOrder] = useState("desc");
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");
  const debouncedSearchValue = useDebounce(searchValue, 500);

  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editJournalsData, setEditJournalsData] = useState(null);
  const [editId, setEditId] = useState(null);

  const queryClient = useQueryClient();

  const { confirmDelete } = useDeleteConfirmation();

  const {
    data: journalsdata,
    isLoading,
    error,
  } = useQuery({
    queryKey: [
      "journalsdata",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
    ],

    queryFn: () =>
      getAllJournalsData(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue
      ),

    onError: (error) => {
      toast.error(error || "Failed to load state list. Please try again.");
    },
  });
  const { data: journalsingledata, refetch } = useQuery({
    queryKey: ["journalsingledata", editId],
    queryFn: () => getJournalsById(editId),
    onError: (error) => {
      toast.error(error || "Failed to load account groups. Please try again.");
    },
  });

  useEffect(() => {
    if (isSheetOpen) {
      refetch();
    }
  }, [isSheetOpen, refetch]);

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const tableData = journalsdata?.data?.data;
 
  
  const pagination_data = journalsdata?.data?.pagination;

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      try {
        return await deleteJournals(id);
      } catch (error) {
        console.error("Delete request failed:", error); // Log here if deleteJournals fails
        throw error; // Re-throw to let `onError` handle it
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["journalsdata"] });
      toast.success(data?.message || "Journal deleted successfully");
    },
    onError: (error) => {
      const errorMessage =
        typeof error === "object" && error?.message
          ? error.message
          : String(error);

      toast.error(
        `Failed to delete the Receipts. Error: ${
          errorMessage || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (Journal) => {
    try {
      confirmDelete(
        `Are you sure you want to delete Journals ${Journal?.voucherNumber}?`,
        () => {
          deleteMutation.mutate(Journal.id);
        }
      );
    } catch (error) {
      console.error("Failed to delete Journal:", error);
    }
  };

  const handleEdit = (data) => {
    setEditId(data.id);
    setIsSheetOpen(true);
  };

  useEffect(() => {
    if (journalsingledata && editId) {
      setEditJournalsData(journalsingledata);
    }
  }, [journalsingledata, editId]);

  const handleAddJournals = () => {
    setEditId(null);
    setEditJournalsData(null); // Reset edit data when adding a new account
    setIsSheetOpen(true); // Open sheet for adding
  };

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const myColumns = [
    {
      id: "date",
      accessorKey: "date",
      lable: "Date",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("date")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("date");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Date
              {renderSortIcon("date")}
            </span>
          </div>
        </div>
      ),

      cell: ({ row }) => {
        const rawDate = row?.getValue("date");
        const formattedDate = new Date(rawDate).toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        });
        return (
          <div className="text-left text-wrap">
            <div className="overflow-hidden text-ellipsis whitespace-nowrap">
              {formattedDate}
            </div>
          </div>
        );
      },
    },
    {
      id: "voucherNumber",
      accessorKey: "voucherNumber",
      lable: "Voucher Number",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">Voucher Number</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("voucherNumber")}
          </div>
        </div>
      ),
    },
    {
      id: "total",
      accessorKey: "total",
      lable: "Total",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">Total</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
          {Number(row?.getValue("total")).toFixed(2)}
          </div>
        </div>
      ),
    },
    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                onClick={() => handleDelete(userdata)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      },
    },
  ];

  const otherFilterFields = () => {
    return <div className=" pt-4 pb-4 flex justify-between "></div>;
  };
  return (
    <>
      <Card className="rounded-md ">
        <CustomTable
          tableHeader="Journals"
          data={tableData}
          columns={myColumns}
          isLoading={isLoading}
          error={error}
          paginationData={pagination_data}
          pageChangeCount={setChangePageCount}
          totalRowCount={setTotalRowCount}
          getSerchValue={setSearchValue}
          serchPlaceholder={"Search"}
          addbuttonLable={" Add Journal"}
          onClickAddbutton={handleAddJournals}
          filterFields={otherFilterFields()}
          tableWidth="100%"
          module="journals"
        />

        <Custom_Sheet
          isOpen={isSheetOpen}
          onClose={() => setIsSheetOpen(false)}
          activeKey={"journals"}
          editId={editJournalsData}
        />
      </Card>
    </>
  );
};

export default JournalsPage;
