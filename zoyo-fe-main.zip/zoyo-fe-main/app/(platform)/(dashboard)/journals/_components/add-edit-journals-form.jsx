import React, { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
	Form,
	FormControl,
	FormField,
	FormItem,
	FormLabel,
	FormMessage,
} from "@/components/ui/form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
	CommonCalendarInput,
	FormSelectField,
	GlobalCheckbox,
	TextareaInputField,
	TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { toast } from "sonner";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { format, formatDate } from "date-fns";
import { getAllAccountsData } from "@/actions/accounts/get-all-accounts";
import { cn } from "@/lib/utils";
import { addJournals } from "@/actions/journals/add-journals";
import { editJournals } from "@/actions/journals/edit-journals";
import { JounralTable, JournalTable } from "./journals-table";
import {
	fetchInitialAccounts,
	getSuggestionOfAccounts,
} from "@/actions/expense/get-all-expense";
import useDebounce from "@/hooks/use-debounce";
import {
	Card,
	CardContent,
	CardFooter,
	CardHeader,
	CardTitle,
} from "@/components/ui/card";
import { ReloadIcon } from "@radix-ui/react-icons";

const formSchema = z
	.object({
		date: z.date({
			required_error: "Date is required",
			invalid_type_error: "That's not a valid date",
		}),
		isAutoNumber: z.boolean(),
		voucherNumber: z
			.string()
			.min(1, "Voucher number is required")
			.max(50, "Voucher number must be 50 characters or less"),
		notes: z.string().optional(),
		items: z
			.array(
				z
					.object({
						accountId: z
							.string()
							.min(1, { message: "Account Name is required" })
							.transform((val) => parseFloat(val)),
						description: z.string().optional(),
						debit: z
							.string({
								required_error: "debit is required",
							})
							.regex(
								/^\d+(\.\d{1,2})?$/,
								"debit must be a number with up to 2 decimal places",
							)
							.transform((val) => parseFloat(val)),
						credit: z
							.string({
								required_error: "credit is required",
							})
							.regex(
								/^\d+(\.\d{1,2})?$/,
								"credit must be a number with up to 2 decimal places",
							)
							.transform((val) => parseFloat(val)),
					})
					.refine((data) => !(data.debit === 0 && data.credit === 0), {
						message: "Both debit and credit cannot be 0",
						path: ["debit"],
					}),
			)
			.min(1, "At least one journal item is required")
			.refine(
				(items) => {
				  const accountIds = items.map((item) => item.accountId);
				  const uniqueAccountIds = new Set(accountIds);
				  return accountIds.length === uniqueAccountIds.size;
				},
				{
				  message: "Each account can only be used once",
				  path: ["items"],
				}
			  ),
	})
	.refine(
		(data) => {
			// Calculate total debit and credit
			const totalDebit = data.items.reduce((acc, item) => acc + item.debit, 0);
			const totalCredit = data.items.reduce(
				(acc, item) => acc + item.credit,
				0,
			);

			// Ensure totals are the same
			return totalDebit === totalCredit;
		},
		{
			message: "Total debit and credit amounts must be equal",
			path: ["items"], // Specify the field to attach the error to
		},
	);

export const AddEditJournalsForm = ({ journals = null, onClose }) => {
	const [searchQuery, setSearchQuery] = useState("");
	const [accountValues, setAccountValues] = useState([]);
	const debouncedSearchQuery = useDebounce(searchQuery, 300);

	const [openDatePicker, setOpenDatePicker] = useState(false);

	const queryClient = useQueryClient();
	const isEditing = !!journals;

	const fetchSuggestions = useCallback(async () => {
		if (debouncedSearchQuery) {
			const [accountSuggestions] = await Promise.all([
				getSuggestionOfAccounts(debouncedSearchQuery),
			]);
			setAccountValues(accountSuggestions);
		} else {
			const [initialAccounts] = await Promise.all([fetchInitialAccounts()]);
			setAccountValues(initialAccounts);
		}
	}, [debouncedSearchQuery]);
	useQuery({
		queryKey: ["suggestions", debouncedSearchQuery],
		queryFn: fetchSuggestions,
		enabled: true,
	});

	const form = useForm({
		resolver: zodResolver(formSchema),
		defaultValues: {
			date: journals?.date ? new Date(journals.date) : new Date(),
			isAutoNumber: journals?.isAutoNumber ?? false,
			voucherNumber: journals?.voucherNumber || "",
			notes: journals?.notes || "",
			items: journals?.items || [
				{
					accountId: "",
					description: "",
					debit: "0",
					credit: "0",
				},
				{
					accountId: "",
					description: "",
					debit: "0",
					credit: "0",
				},
			],
		},
	});

	useEffect(() => {
		if (journals) {
			form.reset({
				date: journals?.date ? new Date(journals.date) : new Date(),
				isAutoNumber: journals?.isAutoNumber ?? false,
				voucherNumber: journals?.voucherNumber || "",
				notes: journals?.notes || "",
				items: journals?.items?.map((item) => ({
					accountId: item.accountId?.toString() || "",
					description: item.description || "",
					debit: item.debit ? parseFloat(item.debit).toString() : "0", // Ensure debit is treated as a number
					credit: item.credit ? parseFloat(item.credit).toString() : "0", // Ensure credit is treated as a number
				})) || [
					{
						accountId: "",
						description: "",
						debit: "0",
						credit: "0",
					},
					{
						accountId: "",
						description: "",
						debit: "0",
						credit: "0",
					},
				],
			});
		}
	}, [journals, form]);

	const addJournalsMutation = useMutation({
		mutationFn: addJournals,
		onSuccess: handleMutationSuccess,
		onError: handleMutationError,
	});

	const editJournalsMutation = useMutation({
		mutationFn: (data) => editJournals(data, journals.id),
		onSuccess: handleMutationSuccess,
		onError: handleMutationError,
	});

	function handleMutationSuccess(data) {
		queryClient.invalidateQueries({ queryKey: ["journalsdata"] });
		if (data?.status === 200 || data?.status === 201) {
			form.reset();
			onClose?.();
			toast.success(`Journals ${isEditing ? "updated" : "added"} successfully`);
		} else if (data?.status === 409) {
			toast.warning(data?.data?.error[0]?.message || "A conflict occurred");
		} else {
			toast.error(
				data?.data?.error[0]?.message || "An unexpected error occurred",
			);
		}
	}

	function handleMutationError(error) {
		toast.error(error || "Something went wrong, try again");
	}

	function onSubmit(values) {
		const formattedValues = {
			...values,
			date: formatDate(values.date, "yyyy-MM-dd"),
		};

		if (isEditing) {
			editJournalsMutation.mutate(formattedValues);
		} else {
			addJournalsMutation.mutate(formattedValues);
		}
	}

	const { errors } = form.formState; // Destructure the form errors
	console.log(errors);
	

	return (
		<>
			<div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
				<h2 className="text-lg font-semibold">
					{isEditing ? "Edit Journal" : "Add Journal"}
				</h2>
			</div>

			<Form {...form} className="p-4">
				<form
					id="paymentForm"
					onSubmit={form.handleSubmit(onSubmit)}
					className="space-y-4 w-full "
				>
					<main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto">
						{/* Input Fields */}
						<div className="w-[90%] pt-4 mx-auto grid grid-cols-1 sm:grid-cols-2 gap-4 ">
							<div>
								<CommonCalendarInput
									form={form}
									name="date"
									label=" Date"
									placeholder="Select  Date"
								/>
							</div>

							{/* Voucher Number Field */}
							<div>
								<TextInputField
									form="form"
									name="voucherNumber"
									label="Voucher No."
									type="text"
									placeholder="Enter Voucher Number"
									className="flex flex-col space-y-1.5"
									required
								/>
							</div>
						</div>

						{/* Notes Field */}
						<div className="w-[90%] pt-2 mx-auto">
							<TextInputField
								form="form"
								name="notes"
								label="Remarks"
								type="text"
								placeholder="Enter remarks Here"
								className="flex flex-col space-y-1.5"
							/>
						</div>

						<div className="w-[90%] mt-6 mx-auto">
							<JounralTable
								formControl={form}
								accountname={accountValues}
								search={setSearchQuery}
								className="w-full"
							/>
							<FormMessage>{errors?.items?.root?.message}</FormMessage>
							<FormMessage>{errors?.items?.items?.message}</FormMessage>
							
							
						</div>
					</main>
					<div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0 h-[76px] left-0 w-full p-4 shadow-lg">
						<Button
							type="submit"
							className="  mr-3 mt-1 text-white  "
							disabled={
								addJournalsMutation.isPending || editJournalsMutation.isPending
							}
						>
							{editJournalsMutation.isPending ||
							addJournalsMutation.isPending ? (
								<>
									<ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
									{editJournalsMutation.isPending ? "Updating..." : "Adding..."}
								</>
							) : isEditing ? (
								"Update"
							) : (
								"Add"
							)}
						</Button>
					</div>
				</form>
			</Form>
		</>
	);
};
