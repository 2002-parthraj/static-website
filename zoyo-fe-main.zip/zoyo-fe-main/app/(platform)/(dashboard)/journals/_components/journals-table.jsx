"use client";

import React, { useEffect, useState } from "react";
import { useFieldArray, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import {
  FormSelectField,
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { ComboboxForm } from "@/components/custom-compobox-select/custom-global-compobox-select";
import { Trash2 } from "lucide-react";

export const JounralTable = ({
  formControl,
  TaxDataType,
  accountname,
  search,
}) => {
  const { control, setValue, getValues,formState: { errors } } = formControl;

  const { fields, append, remove } = useFieldArray({
    control,
    name: "items",
  });

  const watchedItems = useWatch({
    control,
    name: "items",
  });

  // Ensure there are always two rows initially
  useEffect(() => {
    if (fields.length === 0) {
      append({ accountId: "", description: "", debit: "0", credit: "0" });
      append({ accountId: "", description: "", debit: "0", credit: "0" });
    }
  }, [fields, append]);

  const addNewRow = () => {
    append({
      accountId: "",
      description: "",
      debit: "0",
      credit: "0",
    });
  };

  const removeRow = (index) => {
    // Only allow removal of rows that are not among the first two
    if (index >= 2) {
      remove(index);
    }
  };

  const handleFieldChange = (index, fieldName, value) => {
    // Check if the value is valid number or not
    const numericValue = parseFloat(value);

    if (fieldName === "debit") {
      if (!isNaN(numericValue) && numericValue > 0) {
        // Set debit value and reset credit to "0"
        setValue(`items.${index}.debit`, value);
        setValue(`items.${index}.credit`, "0");
      } else {
        // Reset both fields if value is invalid
        setValue(`items.${index}.debit`, "0");
        setValue(`items.${index}.credit`, "0");
      }
    } else if (fieldName === "credit") {
      if (!isNaN(numericValue) && numericValue > 0) {
        // Set credit value and reset debit to "0"
        setValue(`items.${index}.credit`, value);
        setValue(`items.${index}.debit`, "0");
      } else {
        // Reset both fields if value is invalid
        setValue(`items.${index}.credit`, "0");
        setValue(`items.${index}.debit`, "0");
      }
    } else {
      // Handle other fields if necessary
      setValue(`items.${index}.${fieldName}`, value);
    }
  };

  const calculateTotal = (fieldName) => {
    return watchedItems?.reduce(
      (total, item) => total + (parseFloat(item?.[fieldName]) || 0),
      0
    );
  };

  const debitTotal = calculateTotal("debit");
  const creditTotal = calculateTotal("credit");

  return (
    <div className="overflow-hidden rounded-lg border border-gray-200">
      <Table>
        <TableHeader>
          <TableRow className="bg-[#F5F8FF]">
            <TableCell className="border-b border-r p-4 font-medium text-[#192839] ">
              Account
            </TableCell>
            <TableCell className="border-b border-r p-4 font-medium text-[#192839]">
              Description
            </TableCell>
            <TableCell className="border-b border-r p-4 font-medium text-[#192839]">
              Debits
            </TableCell>
            <TableCell className="border-b border-r p-4 font-medium text-[#192839]">
              Credits
            </TableCell>
            <TableCell className="border-b p-4 font-medium text-[#192839]">
              Actions
            </TableCell>
          </TableRow>
        </TableHeader>

        <TableBody>
          {fields.map((field, index) => (
            <TableRow key={field.id}>
              <TableCell className="border-b text-left border-r p-4 ">
               
                <ComboboxForm
                  form={formControl}
                  name={`items.${index}.accountId`}
                  placeholder="Choose Account"
                  options={accountname}
                  className="w-32"
                />
                
                 
              </TableCell>
              <TableCell className="border-b text-left border-r p-4">
                <TextareaInputField
                  form={formControl}
                  name={`items.${index}.description`}
                  type="text"
                  className="min-w-20"
                />
              </TableCell>
              <TableCell className="border-b text-left border-r p-4">
                <TextInputField
                  form={formControl}
                  name={`items.${index}.debit`}
                  type="text"
                  onChange={(e) =>
                    handleFieldChange(index, "debit", e.target.value)
                  }
                  className="min-w-20"
                />
              </TableCell>
              <TableCell className="border-b text-left border-r p-4">
                <TextInputField
                  form={formControl}
                  name={`items.${index}.credit`}
                  type="text"
                  onChange={(e) =>
                    handleFieldChange(index, "credit", e.target.value)
                  }
                  className="min-w-20"
                />
              </TableCell>
              <TableCell className="border-b p-4">
                <Button
                  type="button"
                  variant="outline"
                  className="ml-2 bg-white text-black hover:bg-gray-50"
                  onClick={() => removeRow(index)}
                  disabled={index < 2}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
          <TableRow className="bg-[#F5F8FF]">
            <TableCell className="border-r p-4 ">
              <Button
                type="button"
                onClick={addNewRow}
                variant="outline"
                className="flex items-center gap-2 border border-primary text-primary hover:bg-blue-50"
              >
                <span className="text-lg font-bold">+</span> Add Row
              </Button>
            </TableCell>
            <TableCell className="border-r p-4 text-right font-medium">
              Total
            </TableCell>
            <TableCell className="border-r p-4 text-right font-medium">
              {debitTotal.toFixed(2)}
            </TableCell>
            <TableCell className="border-r p-4 text-right font-medium">
              {creditTotal.toFixed(2)}
            </TableCell>
            <TableCell className="p-4"></TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </div>
  );
};
