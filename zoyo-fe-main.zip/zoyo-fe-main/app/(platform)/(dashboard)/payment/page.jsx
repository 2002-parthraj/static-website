"use client";
import React, { useEffect, useState } from "react";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ChevronDown,
  ChevronsUpDown,
  ChevronUp,
  ListFilter,
  Pencil,
  PencilLine,
  Trash2,
} from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import CustomTable from "@/components/custom-table/custom-table";
import { toast } from "sonner";
import {
  getAllPaymentData,
  getPaymentDataById,
} from "@/actions/payments/get-all-paymentdata";
import { deletePayments } from "@/actions/payments/delete-payment";
import useDebounce from "@/hooks/use-debounce";

const PaymentPage = () => {
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editPaymentData, setEditPaymentData] = useState(null);
  const [editId, setEditId] = useState(null);

  const queryClient = useQueryClient();

  const { confirmDelete } = useDeleteConfirmation();

  const [changePageCount, setChangePageCount] = useState(1);
  const [sortBy, setSortBy] = useState("date");
  const [sortOrder, setSortOrder] = useState("desc");
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");

  const debouncedSearchValue = useDebounce(searchValue, 500);

  const { data, isLoading, error } = useQuery({
    queryKey: [
      "paymentdata",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
    ],
    queryFn: () =>
      getAllPaymentData(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue
      ),
  });

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const tableData = data?.data?.data;
  const pagination_data = data?.data?.pagination;

  const deleteMutation = useMutation({
    mutationFn: (id) => deletePayments(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["paymentdata"] });

      if (!data?.message) {
        toast.error(data || data?.message || "Something Went Wrong");
      } else {
        toast.success(data?.message || "Receipts deleted successfully");
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to delete the Receipts. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (payment) => {
    try {
      confirmDelete(
        `Are you sure you want to delete Payment ${payment?.id}?`,
        () => {
          deleteMutation.mutate(payment.id);
        }
      );
    } catch (error) {
      console.error("Failed to delete tax group:", error);
    }
  };

  const handleEdit = (data) => {
    setEditId(data.id);
    setIsSheetOpen(true);
  };

  const handleAddAccount = () => {
    setEditPaymentData(null); // Reset edit data when adding a new account
    setEditId(null);
    setIsSheetOpen(true); // Open sheet for adding
  };

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const myColumns = [
    {
      id: "date",
      accessorKey: "date",
      lable: "Date",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("date")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("date");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Date
              {renderSortIcon("date")}
            </span>
          </div>
        </div>
      ),

      cell: ({ row }) => {
        const date = new Date(row?.original.date);
        const formattedDate = date
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          })
          .split("/")
          .join("-");

        return <div className="text-left">{formattedDate}</div>;
      },
    },
    {
      id: "paidFromAccountName",
      accessorKey: "paidFromAccountName",
      lable: "Deposit Account Name",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("paidFromAccountName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("paidFromAccountName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Deposit Account Name
              {renderSortIcon("paidFromAccountName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("paidFromAccountName")}
          </div>
        </div>
      ),
    },
    {
      id: "oppositeAccountName",
      accessorKey: "oppositeAccountName",
      lable: "Opposite Account Name",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("oppositeAccountName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("oppositeAccountName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span style={{ display: "flex", alignItems: "center" }}>
              Opposite Account Name
              {renderSortIcon("oppositeAccountName")}
            </span>
          </div>
        </div>
      ),

      cell: ({ row }) => {
        // Access the original data directly from the row
        const oppositeAccountName = row.original.oppositeAccountName;
        const partyName = row.original.partyName;

        // Use the first available value
        const displayName =
          oppositeAccountName !== null && oppositeAccountName !== undefined
            ? oppositeAccountName
            : partyName !== null && partyName !== undefined
            ? partyName
            : "";

        return (
          <div className="text-left text-wrap">
            <div className="overflow-hidden text-ellipsis whitespace-nowrap">
              {displayName}
            </div>
          </div>
        );
      },
    },
    {
      id: "paymentModeName",
      accessorKey: "paymentModeName",
      lable: "paymentMode Name",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("paymentModeName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("paymentModeName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Payment Mode
              {renderSortIcon("paymentModeName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("paymentModeName")?.toString().toUpperCase()}
          </div>
        </div>
      ),
    },

    {
      id: "amount",
      accessorKey: "amount",
      lable: "Amount",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("amount")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("amount");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Amount
              {renderSortIcon("amount")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("amount")}
          </div>
        </div>
      ),
    },
    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                onClick={() => handleDelete(userdata)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      },
    },
  ];

  const otherFilterFields = () => {
    return <div className=" pt-4 pb-4 flex justify-between "></div>;
  };

  return (
    <Card className="rounded-md ">
      <CustomTable
        data={tableData}
        columns={myColumns}
        isLoading={isLoading}
        error={error}
        tableWidth="100%"
        tableHeader="Payments"
        addbuttonLable={"Add Payment"}
        onClickAddbutton={handleAddAccount}
        paginationData={pagination_data}
        pageChangeCount={setChangePageCount}
        totalRowCount={setTotalRowCount}
        getSerchValue={setSearchValue}
        serchPlaceholder={"Search"}
        filterFields={otherFilterFields()}
        module="payments"
      />

      <Custom_Sheet
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        activeKey={"payment"}
        editId={editId}
      />
    </Card>
  );
};

export default PaymentPage;
