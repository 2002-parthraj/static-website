"use client";
import React, { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ChevronDown,
  ChevronDownIcon,
  ChevronsUpDown,
  ChevronUp,
  ListFilter,
  Pencil,
  PencilLine,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import CustomTable from "@/components/custom-table/custom-table";
import useDebounce from "@/hooks/use-debounce";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { getAllItems } from "@/actions/items/get-all-items";
import { deleteItems } from "@/actions/items/delete-item";
import { patchtoggleItemStatus } from "@/actions/items/toggle-item-status";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { getAllLocation } from "@/actions/location/get-all-location";
import { format } from "date-fns";
import { deleteLocation } from "@/actions/location/delete-location";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { patchtoggleLocationsStatus } from "@/actions/location/toggle-location-status";
import { useStatusToggleStore } from "@/hooks/stores/use-status-toggle-store";

const LocationList = () => {
  const queryClient = useQueryClient();
  const router = useRouter();

  const { confirmDelete } = useDeleteConfirmation();
  const openConfirmDialog = useStatusToggleStore(
    (state) => state.openConfirmDialog
  );

  const [changePageCount, setChangePageCount] = useState(1);
  const [sortBy, setSortBy] = useState("createdAt");
  const [sortOrder, setSortOrder] = useState("desc");
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");

  const [selectedItemId, setSelectedItemId] = useState(null);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editUserData, setEditUserData] = useState(null);

  const debouncedSearchValue = useDebounce(searchValue, 500);

  const { data, isLoading, error } = useQuery({
    queryKey: [
      "location",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
    ],
    queryFn: () =>
      getAllLocation(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue
      ),
  });

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const formatDateToISO = (date) => {
    if (!date) return null;
    return format(date, "yyyy-MM-dd");
  };

  const deleteMutation = useMutation({
    mutationFn: (id) => deleteLocation(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["location"] });

      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(data?.data?.message || "Party deleted successfully");
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to delete the party. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (userId) => {
    confirmDelete(`Location : ${userId?.name}`, () => {
      deleteMutation.mutate(userId?.id);
    });
  };

  const handleEdit = (userdata) => {
    setIsSheetOpen(true);
    setEditUserData(userdata);
  };

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const handleLocationNameClick = (locationId) => {
    router.push(`location/location-item/${locationId}`);
  };

  const toggleStatusMutation = useMutation({
    mutationFn: (id) => patchtoggleLocationsStatus(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["location"] });

      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(data?.data?.message);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed . Error: ${error?.message || error || "Something went wrong"}`
      );
    },
  });

  const handleStatusToggle = (id, currentStatus) => {
    openConfirmDialog({
      itemId: id,
      currentStatus: currentStatus,
      entityType: "Warehouse",
      onConfirmCallback: (itemId) => {
        toggleStatusMutation.mutate(itemId);
      },
    });
  };

  const myColumns = [
    {
      id: "select",
      header: ({ table }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedItemId !== null}
            onCheckedChange={(value) => {
              if (!value) {
                setSelectedItemId(null);
                table?.toggleAllPageRowsSelected(false);
              }
            }}
            aria-label="Select item"
          />
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedItemId === row.original.id}
            onCheckedChange={(value) => {
              if (value) {
                setSelectedItemId(row.original.id);
              } else {
                setSelectedItemId(null);
              }
            }}
            aria-label="Select row"
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
    },
    {
      id: "name",
      accessorKey: "name",
      lable: "Warehouse Name",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("name")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("name");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Warehouse Name
              {renderSortIcon("name")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div
            className="overflow-hidden text-ellipsis whitespace-nowrap cursor-pointer hover:text-blue-500"
            onClick={() => handleLocationNameClick(row.original.id)}
          >
            {row?.getValue("name")}
          </div>
        </div>
      ),
    },

    {
      id: "isActive",
      accessorKey: "isActive",
      lable: "Status",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-nowrap text-gray-900"
            onClick={() => onSortChange("isActive")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("isActive");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Status
              {renderSortIcon("isActive")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex items-center justify-left">
          <Switch
            checked={row.getValue("isActive")}
            onCheckedChange={() => {
              handleStatusToggle(row.original.id, row.getValue("isActive"));
            }}
            className="data-[state=checked]: "
            aria-label="Toggle status"
          />
          <span className="text-sm font-medium pl-2 text-black w-16 text-left">
            {row.getValue("isActive") ? "Active" : "Inactive"}
          </span>
        </div>
      ),
    },
    {
      id: "createdAt",
      accessorKey: "createdAt",
      lable: "Created On",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("createdAt")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("createdAt");
              }
            }}
          >
            <span className="flex items-center gap-1">
              Created On
              {renderSortIcon("createdAt")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const date = new Date(row?.original.createdAt);
        const formattedDate = date
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          })
          .split("/")
          .join("-");

        return <div className="text-left">{formattedDate}</div>;
      },
    },

    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                onClick={() => handleDelete(userdata)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      },
    },
  ];

  const otherFilterFields = () => {
    return <div className=" pt-4 pb-4 flex justify-between "></div>;
  };

  const handleAddLocation = () => {
    setEditUserData(null);
    setIsSheetOpen(true); // Open sheet for adding
  };

  const otherFields = () => {
    return (
      <>
        <div className="p-4 flex justify-between">
          <div className="flex space-x-3">tt</div>
        </div>
      </>
    );
  };

  const tableData = data?.data?.data;

  const pagination_data = data?.data?.pagination;

  return (
    <Card className="rounded-md ">
      <CustomTable
        data={tableData || []}
        columns={myColumns || []}
        isLoading={isLoading}
        error={error}
        tableHeader="Warehouse"
        tableWidth={"100%"}
        paginationData={pagination_data}
        pageChangeCount={setChangePageCount}
        totalRowCount={setTotalRowCount}
        getSerchValue={setSearchValue}
        serchPlaceholder={"Search"}
        addbuttonLable={"Add Warehouse"}
        onClickAddbutton={handleAddLocation}
        filterFields={otherFilterFields()}
      />

      <Custom_Sheet
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        activeKey={"location"}
        editId={editUserData}
      />
    </Card>
  );
};

export default LocationList;
