"use client";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";
import { ReloadIcon } from "@radix-ui/react-icons";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { addLocation } from "@/actions/location/add-location";
import { editLocation } from "@/actions/location/edit-location";
import { getStatesData } from "@/actions/comman/get-state-data";
import {
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { ComboboxForm } from "@/components/custom-compobox-select/custom-global-compobox-select";
import { Switch } from "@/components/ui/switch";

// Helper function to check if a value is empty
const isEmptyValue = (value) => {
  return value === undefined || value === null || value === "";
};

// Address validation schema
const addressSchema = z
  .object({
    street: z.string().optional(),
    city: z.string().optional(),
    stateId: z.string().optional(),
    pincode: z.coerce
      .number({ message: "Please enter valid pincode" })
      .nullable()
      .optional()
      .refine(
        (val) =>
          !val ||
          (val.toString().length === 6 && val >= 100000 && val <= 999999),
        { message: "Pincode must be exactly 6 digits" }
      ),
  })
  .superRefine((data, ctx) => {
    const hasAnyData = Object.values(data).some(
      (value) => !isEmptyValue(value)
    );

    if (hasAnyData) {
      if (!data.city) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "City is required when any address field is provided",
          path: ["city"],
        });
      }
      if (!data.stateId) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "State is required when any address field is provided",
          path: ["stateId"],
        });
      }
    }
  });

const formSchema = z
  .object({
    name: z
      .string()
      .min(1, "Name is required")
      .max(20, "Maximum length is 20 characters"),
    isActive: z.boolean(),
    type: z.string().optional(),
    street: z.string().optional(),
    city: z.string().optional(),
    stateId: z.string().optional(),
    pincode: z.coerce.number().optional().nullable(),
    latitude: z.coerce.number().optional(),
    longitude: z.coerce.number().optional(),
  })
  .superRefine((data, ctx) => {
    // Create an address object to validate
    const addressData = {
      street: data.street,
      city: data.city,
      stateId: data.stateId,
      pincode: data.pincode,
    };

    try {
      addressSchema.parse(addressData);
    } catch (error) {
      error.errors.forEach((err) => {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: err.message,
          path: err.path,
        });
      });
    }
  });

const AddEditLocationForm = ({ onClose, editId }) => {
  const queryClient = useQueryClient();
  const [isFormSubmitting, setIsFormSubmitting] = useState(false);

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      isActive: true,
    },
  });

  const { data: stateData } = useQuery({
    queryKey: ["state"],
    queryFn: () => getStatesData(),
  });

  useEffect(() => {
    if (editId) {
      form.reset({
        name: editId?.name || "",
        isActive: editId?.isActive,
        street: editId?.street ?? undefined,
        city: editId?.city ?? undefined,
        stateId: editId?.stateId?.toString() ?? undefined,
        pincode: editId?.pincode ?? undefined,
      });
    }
  }, [editId, form]);

  const { mutate: addLocationMutation } = useMutation({
    mutationFn: (payload) => addLocation(payload),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["location"] });
      if (data?.status === 201) {
        setIsFormSubmitting(false);
        toast.success("Location added successfully");
        form.reset();
        onClose(false);
      } else {
        toast.error(data?.data?.error?.[0]?.message || "Something went wrong");
        setIsFormSubmitting(false);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to Add location. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
      setIsFormSubmitting(false);
    },
  });

  const { mutate: editLocationMutation } = useMutation({
    mutationFn: (payload) => editLocation(payload, editId?.id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["location"] });
      if (data?.status === 200) {
        setIsFormSubmitting(false);
        toast.success("Edit location successfully");
        form.reset();
        onClose(false);
      } else {
        toast.error(data?.data?.error?.[0]?.message || "Something went wrong");
        setIsFormSubmitting(false);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to edit location. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
      setIsFormSubmitting(false);
    },
  });

  const stateOptions = stateData?.data?.map((val) => ({
    value: `${val?.id}`,
    label: val?.name,
  }));

  const onSubmit = (values) => {
    setIsFormSubmitting(true);
    const finalPayload = {
      name: values.name,
      isActive: values.isActive,
      street: values.street,
      city: values.city,
      stateId: Number(values.stateId) || undefined,
      pincode: Number(values.pincode) || undefined,
    };

    editId
      ? editLocationMutation(finalPayload)
      : addLocationMutation(finalPayload);
  };

  return (
    <>
      <div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
        <h2 className="text-lg font-semibold">
          {editId ? "Edit Warehouse" : "Add Warehouse"}
        </h2>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto">
            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form={form}
                name="name"
                placeholder="Enter Location Name Here"
                label="Location Name"
                type="text"
                required
              />
            </div>

            <div className="w-[90%] pt-4 mx-auto pb-6">
              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center flex-start">
                    <div className="space-y-0.5 pr-2 pt-2 text-sm">
                      <FormLabel className="text-base">
                        Is Location Active
                      </FormLabel>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        // className="data-[state=checked]: "
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            {/* Conditional Address Fields */}
            <div className="border-t-4 border-gray-200" />
            <div className="w-[90%] pt-4 mx-auto space-y-4">
              <div className="text-lg">Location Address (optional)</div>

              <TextareaInputField
                form={form}
                name="street"
                placeholder="Area, Street, Sector"
                label="Address Line"
                rows={3}
              />

              <TextInputField
                form={form}
                name="pincode"
                placeholder="Enter Pincode"
                label="Pincode"
                type="text"
              />

              <TextInputField
                form={form}
                name="city"
                placeholder="Enter Town/City Name"
                label="Town/City"
                type="text"
              />

              <ComboboxForm
                form={form}
                name="stateId"
                label="State"
                placeholder="Choose State"
                options={stateOptions}
              />
            </div>
          </main>

          <div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0 h-[76px] left-0 w-full p-4 shadow-lg">
            <Button
              type="submit"
              className="  mr-3 mt-1 text-white  "
              disabled={isFormSubmitting}
            >
              {isFormSubmitting ? (
                <>
                  <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                  {editId ? "Updating..." : "Saving..."}
                </>
              ) : editId ? (
                "Update Warehouse"
              ) : (
                "Add Warehouse"
              )}
            </Button>
          </div>
        </form>
      </Form>
    </>
  );
};

export default AddEditLocationForm;
