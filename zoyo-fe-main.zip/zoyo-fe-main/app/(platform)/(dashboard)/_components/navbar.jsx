"use client";

import React, { useEffect, useRef, useState } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  ChevronDown,
  Headset,
  HelpCircle,
  Info,
  LogOut,
  PhoneCall,
  Plus,
  Search,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getUserOrganizations } from "@/actions/company-flow/get-user-organizations";
import { setDefaultOrganizations } from "@/actions/company-flow/set-default-organizations";
import { toast } from "sonner";
import { switchOrganization } from "@/actions/company-flow/switch-organization";
import { Input } from "@/components/ui/input";
import { useChangePassWordModalStore } from "@/hooks/stores/use-change-password-store";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { Card, CardContent } from "@/components/ui/card";

export const Navbar = ({ isSidebarOpen }) => {
  const queryClient = useQueryClient();

  const { openChangePassword } = useChangePassWordModalStore();

  const router = useRouter();
  const { logout } = useAuth();

  const [searchTerm, setSearchTerm] = useState("");
  const [userInfo, setUserInfo] = useState(
    JSON.parse(localStorage.getItem("user"))
  );

  const selectedCompany = localStorage.getItem("companyname");

  const { data: companies } = useQuery({
    queryKey: ["organizations"],
    queryFn: getUserOrganizations,
  });

  // Filter companies based on search term
  const filteredCompanies = companies?.data?.data?.filter((company) =>
    company.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Mutation for switching company
  const changeDefaultStatusMutation = useMutation({
    mutationFn: (id) => setDefaultOrganizations(id),
    onSuccess: (data) => {
      window.location.reload();
      toast.success(data.data.message);
      queryClient.invalidateQueries(["organizations"]);
    },
  });

  // Mutation for changing default status
  const switchCompanyMutation = useMutation({
    mutationFn: (id) => switchOrganization(id),
    onSuccess: (data) => {
      // setSelectedCompany(data.data.data);
      localStorage.setItem("companyname", data?.data?.data?.name);
      router.push("/home");
      toast.success(data.data.message);
      queryClient.invalidateQueries(["organizations"]);
    },
  });

  const handleCompanySelect = async (company) => {
    await switchCompanyMutation.mutateAsync(company.id);
  };

  const handleDefaultStatusChange = async (company) => {
    console.log(company);
    await changeDefaultStatusMutation.mutateAsync(company.id);
  };

  const handleCreateCompanyClick = () => {
    router.push("/company-create"); // Navigate to the create-company page
  };

  const menuItems = [
    // { label: 'Add Invoices', path: '/invoice/add' },
    { label: "Add Estimate", path: "/estimate/add" },
    { label: "Add Delivery Challan ", path: "/delivery-challan/add" },
    { label: "Add Credit Notes", path: "/credit-note/add" },
    { label: "Add Purchase Order", path: "/purchase-order/add" },
    { label: "Add Purchase Bill", path: "/bills/add" },
    { label: "Add Debit Notes", path: "/debit-note/add" },
    { label: "Add Expense", path: "/expense" },
    { label: "Add Receipt", path: "/receipt" },
    { label: "Add Payment", path: "/payment" },
  ];

  const handleSelect = (path) => {
    router.push(path);
  };

  const getInitials = (name) => {
    if (!name) return "G";

    // Split the name into words
    const words = name.split(" ");

    // Get first letter of each word and join them
    const initials = words
      .map((word) => word.charAt(0))
      .join("")
      .toUpperCase();

    // Return first two letters if there are multiple words,
    // or just the first letter if it's a single word
    return initials.slice(0, 2);
  };

  return (
    //z-50
    <header className="sticky top-0 z-10 flex flex-wrap sm:justify-start sm:flex-nowrap w-full shadow-sm  bg-white dark:bg-background dark:text-white text-sm py-2 ">
      <nav className="max-w-full w-full mx-auto  sm:flex sm:items-center sm:justify-between">
        <div className="flex items-center justify-between w-full ">
          <span className=" ml-3 items-center">
            {isSidebarOpen ? (
              <a
                className="flex items-center text-xl font-semibold text-white  -ml-1 md:-ml-1 lg:-ml-0.5 "
                href="/home"
              >
                {/* <Image src="/icons/sidebaricon.svg" alt="Home Icon"className="text-white mr-2 " width={25} height={25} /> */}
                <Image
                  src="/icons/companyLogo.svg"
                  alt="Home Icon"
                  className="text-white ml-2 "
                  width={80}
                  height={25}
                />
              </a>
            ) : (
              <a
                className="flex items-center text-xl font-semibold text-white  -ml-1 md:-ml-1 lg:-ml-0.5 "
                href="/home"
              >
                {/* <Image src="/icons/sidebaricon.svg" alt="Home Icon"className="text-white mr-2 " width={25} height={25} /> */}
                <Image
                  src="/icons/companyLogo.svg"
                  alt="Home Icon"
                  className="text-white ml-2 "
                  width={80}
                  height={25}
                />
              </a>
            )}
          </span>
          <div className="flex items-center space-x-4">
            <div className="flex items-center ">
              {/* Company Selector Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="flex items-center gap-2 text-sm"
                  >
                    <span>
                      {selectedCompany ||
                        companies?.data?.data?.find(
                          (company) => company.isDefault
                        ).name}
                    </span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="start"
                  className="w-80 max-h-80 overflow-auto py-0"
                >
                  {/* Search Input */}
                  <div className="px-2 sticky top-0 bg-white border-b z-10">
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground " />
                      <Input
                        placeholder="Search organizations..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-8  border-none border-b bg-white focus-visible:ring-0"
                      />
                    </div>
                  </div>
                  {filteredCompanies?.map((company, index) => (
                    <DropdownMenuItem
                      key={index}
                      className={
                        "flex items-center justify-between p-2 cursor-pointer"
                      }
                      onClick={() => handleCompanySelect(company)}
                    >
                      <span>{company.name}</span>
                      <Button
                        variant={
                          company.isDefault === true ? "primary" : "Outline"
                        }
                        className={`rounded-md px-2 h-7 text-xs border ${
                          company.isDefault ? "bg-primary text-white" : ""
                        }`}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDefaultStatusChange(company);
                        }}
                      >
                        Default
                      </Button>
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <div className="flex justify-center items-center sticky bottom-0 bg-white py-1">
                    <Button
                      className="w-full"
                      onClick={() => router.push("/company-create")}
                    >
                      Add Organization
                    </Button>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="flex items-center ">
              {/* Main Add Invoice Button */}
              <Button
                onClick={() => router.push("/invoice/add")}
                className="bg-primary hover:bg-primary text-white rounded-r-none"
              >
                Add Invoice
              </Button>

              {/* Dropdown Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="bg-[#254A88] hover:bg-[#254A88] rounded-l-none"
                  >
                    <ChevronDown className="h-5 w-5 text-white" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {menuItems.map((item) => (
                    <DropdownMenuItem
                      key={item.path}
                      className="cursor-pointer hover:bg-slate-100"
                      onClick={() => handleSelect(item.path)}
                    >
                      {item.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="flex items-center border-l h-6 text-gray-300"></div>

            <div className="flex items-center min-w-5 cursor-pointer">
              {" "}
              {/* <Image
                      src="/icons/massageicon.svg"
                      alt="Massage Icon"
                      className="text-slate-600  "
                      width={20}
                      height={20}
                    /> */}
              <HoverCard>
                <HoverCardTrigger asChild>
                  <Button variant="link" className="p-0">
                    {" "}
                    <Headset />
                  </Button>
                </HoverCardTrigger>
                <HoverCardContent className="w-full  max-w-xs md:max-w-lg">
                  <CardContent className="p-0 space-y-6">
                    <div className="flex flex-col sm:flex-row mx-auto items-start gap-4">
                      <div className="p-4 bg-[#F2F5F8] mx-auto rounded-full">
                        <HelpCircle className="w-6 h-6 text-primary" />
                      </div>
                      <div className="mx-auto">
                        <h3 className="font-medium text-gray-900">
                          Need Help?
                        </h3>
                        <p className="text-sm text-gray-600">
                          We are available 24×7! Enter your mobile number and we
                          will contact you soon!
                        </p>
                        <div className="mt-2 mx-auto space-x-2">
                          <Button
                            variant="default"
                            className="bg-primary hover:bg-primary"
                          >
                            Request A Call Back
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="text-center text-sm text-gray-500">OR</div>

                    {/* Direct Call Section */}
                    <div className="flex flex-col sm:flex-row items-start gap-4">
                      <div className="p-4 bg-[#F2F5F8] mx-auto rounded-full">
                        <PhoneCall className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1 mx-auto">
                        <h3 className="font-medium">Call: 07969 223344</h3>
                        <p className="text-sm text-gray-600">
                          You can call us directly to speak to our customer care
                          representative!
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </HoverCardContent>
              </HoverCard>
            </div>

            <div className="flex items-center  ">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center mr-4 p-0 "
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-black">
                        {" "}
                        {getInitials(
                          JSON.parse(localStorage.getItem("user"))?.name ||
                            "Guest"
                        )}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1 font-medium">
                    <p className="text-sm">{userInfo.name}</p>
                    <p className="text-xs text-gray-500">{userInfo.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="flex items-center gap-2 cursor-pointer"
                    onClick={openChangePassword}
                  >
                    <span>Change Password</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-red-600 flex items-center gap-2 cursor-pointer"
                    onClick={() => logout()}
                  >
                    <LogOut size={16} />
                    <span>Sign Out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
};
