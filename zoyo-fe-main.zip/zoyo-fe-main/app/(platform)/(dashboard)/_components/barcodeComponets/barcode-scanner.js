import React, { useEffect, useState, useCallback } from "react";

const BarcodeScanner = ({ onBarcodeScanned, isModalOpen }) => {
	const [barcodeBuffer, setBarcodeBuffer] = useState("");
	const [lastCharTime, setLastCharTime] = useState(0);
	const [isScanning, setIsScanning] = useState(false);

	// Configuration for barcode scanner
	const SCANNER_CONFIG = {
		maxDelayBetweenChars: 100,
		minBarcodeLength: 4,
		maxTotalScanTime: 1000,
		terminationChars: new Set(["Enter", "Tab", "\n", "\r"]),
	};

	const processBarcodeInput = useCallback(
		(barcode) => {
			if (barcode.length >= SCANNER_CONFIG.minBarcodeLength) {
				const cleanBarcode = barcode.trim();
				if (cleanBarcode) {
					onBarcodeScanned(cleanBarcode);
				}
			}
			setBarcodeBuffer("");
			setIsScanning(false);
		},
		[onBarcodeScanned],
	);

	const handleKeyDown = useCallback(
		(event) => {
			// Don't process if modal is open
			if (isModalOpen) {
				return;
			}

			// Skip processing if the target is an input or textarea
			if (
				event.target.tagName === "INPUT" ||
				event.target.tagName === "TEXTAREA" ||
				event.target.contentEditable === "true"
			) {
				return;
			}

			const currentTime = Date.now();
			const timeSinceLastChar = currentTime - lastCharTime;

			// Handle termination characters
			if (SCANNER_CONFIG.terminationChars.has(event.key)) {
				if (isScanning) {
					event.preventDefault();
					processBarcodeInput(barcodeBuffer);
				}
				return;
			}

			// Only process single printable characters
			if (event.key.length === 1) {
				// Start new scan if enough time has passed
				if (timeSinceLastChar > SCANNER_CONFIG.maxDelayBetweenChars) {
					setBarcodeBuffer(event.key);
					setIsScanning(true);
				} else if (isScanning) {
					// Append to existing barcode buffer only if we're in scanning mode
					setBarcodeBuffer((prev) => prev + event.key);
				}

				setLastCharTime(currentTime);

				// Only prevent default if we're in scanning mode
				if (isScanning) {
					event.preventDefault();
					event.stopPropagation();
				}
			}
		},
		[barcodeBuffer, lastCharTime, isModalOpen, processBarcodeInput, isScanning],
	);

	useEffect(() => {
		if (barcodeBuffer.length > 0) {
			const timeoutId = setTimeout(() => {
				if (barcodeBuffer.length >= SCANNER_CONFIG.minBarcodeLength) {
					processBarcodeInput(barcodeBuffer);
				} else {
					setBarcodeBuffer("");
					setIsScanning(false);
				}
			}, SCANNER_CONFIG.maxTotalScanTime);

			return () => clearTimeout(timeoutId);
		}
	}, [barcodeBuffer, processBarcodeInput]);

	useEffect(() => {
		window.addEventListener("keydown", handleKeyDown, { capture: true });
		return () => {
			window.removeEventListener("keydown", handleKeyDown, { capture: true });
		};
	}, [handleKeyDown]);

	return null;
};

export default BarcodeScanner;
