import React, { useState, useEffect } from "react";
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogClose,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { X } from "lucide-react";

const BarcodeModal = ({ isOpen, onClose, onBarcodeScanned }) => {
	const [barcodeInput, setBarcodeInput] = useState("");
	const [manualInput, setManualInput] = useState("");
	const [lastScanTime, setLastScanTime] = useState(0);

	useEffect(() => {
		if (!isOpen) {
			setBarcodeInput("");
			setManualInput("");
			return;
		}

		const scannerConfig = {
			maxDelayBetweenChars: 50,
			minBarcodeLength: 4,
			terminationChars: new Set(["Enter"]),
		};

		const handleKeyDown = (event) => {
			// Handle manual input Enter key press
			if (event.key === "Enter" && manualInput.trim()) {
				event.preventDefault();
				onBarcodeScanned(manualInput.trim());
				// onClose();
				return;
			}

			// Handle barcode scanner input
			const currentTime = Date.now();

			if (document.activeElement.tagName === "INPUT") {
				return; // Don't process scanner input if we're in a text field
			}

			if (scannerConfig.terminationChars.has(event.key)) {
				if (barcodeInput.length >= scannerConfig.minBarcodeLength) {
					onBarcodeScanned(barcodeInput);
					event.preventDefault();
					// onClose();
				}
				setBarcodeInput("");
				return;
			}

			if (currentTime - lastScanTime > scannerConfig.maxDelayBetweenChars) {
				setBarcodeInput(event.key);
			} else {
				setBarcodeInput((prev) => prev + event.key);
			}

			setLastScanTime(currentTime);
		};

		// window.addEventListener("keydown", handleKeyDown);
		// return () => window.removeEventListener("keydown", handleKeyDown);
	}, [
		isOpen,
		barcodeInput,
		lastScanTime,
		onBarcodeScanned,
		onClose,
		manualInput,
	]);

	const handleManualInputKeyDown = (e) => {
		if (e.key === "Enter") {
			e.preventDefault();
			if (manualInput.trim()) {
				onBarcodeScanned(manualInput.trim());
				// onClose();
			}
			setBarcodeInput("");
			setManualInput("");
		}
	};

	return (
		<Dialog open={isOpen} onOpenChange={onClose}>
			<DialogContent className="sm:max-w-md">
				<DialogHeader className="flex flex-row items-center justify-between">
					<DialogTitle>Barcode Input</DialogTitle>
					<DialogClose className="w-6 h-6 opacity-70 ring-offset-white transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-slate-950 focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-slate-100 data-[state=open]:text-slate-500" />
				</DialogHeader>
				<div className="space-y-4 pt-4">
					<div className="flex flex-col space-y-2">
						<Input
							type="text"
							placeholder="Enter barcode manually"
							value={manualInput}
							onChange={(e) => setManualInput(e.target.value)}
							onKeyDown={handleManualInputKeyDown}
							className="w-full"
							autoFocus
						/>
					</div>
					<div className="text-center text-sm text-gray-500">
						<p>Please scan barcode or enter manually and press Enter</p>
						{barcodeInput && (
							<p className="text-sm font-mono mt-2">
								Last scan: {barcodeInput}
							</p>
						)}
					</div>
				</div>
			</DialogContent>
		</Dialog>
	);
};

export default BarcodeModal;
