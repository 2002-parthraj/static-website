"use client";

import React, { Fragment, useEffect, useState } from "react";
import "@/app/globals.css";
import { usePathname, useRouter } from "next/navigation";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { AlignJustify, ArrowLeft, ChevronDown, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import Link from "next/link";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import Image from "next/image";
import { useQuery } from "@tanstack/react-query";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";

export function Sidebar({ isSidebarOpen, setIsSidebarOpen }) {
  const [selectedMenu, setSelectedMenu] = useState(null);
  const [selectedSubmenu, setSelectedSubmenu] = useState(null);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [activeKey, setActiveKey] = useState();
  const router = useRouter();
  const pathname = usePathname();

  const [openPopover, setOpenPopover] = useState(null);
  const [hoveredMenu, setHoveredMenu] = useState(null);
  const [hoverTimeout, setHoverTimeout] = useState(null);

  const { data: commonInitInventoryData, isLoading: isCommonDataLoading } =
    useQuery({
      queryKey: ["commonInitInventoryData"],
      queryFn: () => getCommonInitData(),
    });

  const commonInventoryData =
    commonInitInventoryData?.data?.preferences?.inventory;
    
    

  const menus = [
    {
      name: "Home",
      label: "",
      icon: (
        <Image src="/icons/home.svg" alt="Home Icon" width={24} height={24} />
      ),
      icon3: (
        <Image
          src="/icons/selectedhome.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/home",
    },
    {
      name: "Parties",
      label: "",
      icon: (
        <Image
          src="/icons/parties.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedparties.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/parties",
      icon2: <Plus size={15} className="ml-4" />,
      key: "Parties",
    },
    {
      name: "Inventory",
      label: "",
      href: "/items",
      icon: (
        <Image
          src="/icons/inventory.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedinventory.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      submenu: [
        {
          name: "Items",
          href: "/items",
          icon2: <Plus size={15} className="ml-4" />,
          key: "items",
        },
        ...(commonInventoryData?.category
          ? [
              {
                name: "Categories",
                href: "/categories",
                icon2: <Plus size={15} className="ml-4" />,
                key: "categories",
              },
            ]
          : []),
        ...(commonInventoryData?.multiLocation
          ? [
              {
                name: "Warehouse",
                href: "/location",
                icon2: <Plus size={15} className="ml-4" />,
                key: "location",
              },
            ]
          : []),
        ...(commonInventoryData?.group
          ? [
              {
                name: "Groups",
                href: "/groups",
                icon2: <Plus size={15} className="ml-4" />,
                key: "groups",
              },
            ]
          : []),
        ...(commonInventoryData?.priceList
          ? [
              {
                name: "Price List",
                href: "/pricelist",
                icon2: <Plus size={15} className="ml-4" />,
                key: "pricelist",
              },
            ]
          : []),
      ],
    },
    {
      label: "",
      name: "Banking",
      icon: (
        <Image
          src="/icons/banking.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedbanking.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/bank-account",
      submenu: [
        {
          name: "Bank Account",
          href: "/bank-account",
          icon2: <Plus size={15} className="ml-4" />,
          key: "bankAccount",
        },
        {
          name: "Receipt",
          href: "/receipt",
          icon2: <Plus size={15} className="ml-4" />,
          key: "receipt",
        },
        {
          name: "Payment",
          href: "/payment",
          icon2: <Plus size={15} className="ml-4" />,
          key: "payment",
        },
      ],
    },
    {
      label: "",
      name: "Sales",
      icon: (
        <Image src="/icons/sales.svg" alt="Home Icon" width={24} height={24} />
      ),
      icon3: (
        <Image
          src="/icons/selectedsales.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/estimate",
      submenu: [
        {
          name: "Estimate",
          href: "/estimate",
          icon2: <Plus size={15} className="ml-4" />,
          addHref: "/estimate/add",
        },
        {
          name: "Delivery Challan",
          href: "/delivery-challan",
          icon2: <Plus size={15} className="ml-4" />,
          addHref: "/delivery-challan/add",
        },
        {
          name: "Invoice",
          href: "/invoice",
          icon2: <Plus size={15} className="ml-4" />,
          addHref: "/invoice/add",
        },
        {
          name: "Credit Note",
          href: "/credit-note",
          icon2: <Plus size={15} className="ml-4" />,
          addHref: "/credit-note/add",
        },
      ],
    },
    {
      label: "",
      name: "Purchase",
      icon: (
        <Image
          src="/icons/purchase.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedpurchase.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/purchase-order",
      submenu: [
        {
          name: "Purchase Order",
          href: "/purchase-order",
          icon2: <Plus size={15} className="ml-4" />,
          addHref: "/purchase-order/add",
        },
        {
          name: "Purchase Bill",
          href: "/bills",
          icon2: <Plus size={15} className="ml-4" />,
          addHref: "/bills/add",
        },
        {
          name: "Debit Notes",
          href: "/debit-note",
          icon2: <Plus size={15} className="ml-4" />,
          addHref: "/debit-note/add",
        },
        {
          name: "Expense",
          href: "/expense",
          icon2: <Plus size={15} className="ml-4" />,
          key: "expenses",
        },
      ],
    },

    {
      name: "e-Way Bills",
      label: "",
      icon: (
        <Image
          src="/icons/ewaybills.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedewaybills.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/eway-bills",
    },

    {
      label: "",
      name: "Accountant",
      icon: (
        <Image
          src="/icons/accountant.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedaccountant.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/chart-of-accounts",
      submenu: [
        {
          name: "Chart of Accounts",
          href: "/chart-of-accounts",
        },
        {
          name: "Journals",
          href: "/journals",
        },
      ],
    },

    {
      label: "",
      name: "Utility",
      icon: (
        <Image
          src="/icons/utility.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedutility.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "",
      submenu: [
        {
          name: "Barcode",
          href: "/barcode",
        },
      ],
    },
    // {
    //   name: "GST",
    //   label: "",
    //   icon: (
    //     <Image src="/icons/gst.svg" alt="Home Icon" width={24} height={24} />
    //   ),
    //   icon3: (
    //     <Image
    //       src="/icons/selectedgst.svg"
    //       alt="Home Icon"
    //       width={24}
    //       height={24}
    //     />
    //   ),
    //   href: "/gst",
    // },
    {
      name: "Reports",
      label: "",
      icon: (
        <Image
          src="/icons/reports.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedreports.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/reports",
    },

    {
      label: "",
      name: "Settings",
      icon: (
        <Image
          src="/icons/settings.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      icon3: (
        <Image
          src="/icons/selectedsettings.svg"
          alt="Home Icon"
          width={24}
          height={24}
        />
      ),
      href: "/setting",
    },
  ];

  // Add collapse handler
  const handleCollapse = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  useEffect(() => {
    for (const menu of menus) {
      if (menu.submenu) {
        for (const submenu of menu.submenu) {
          if (submenu.href === pathname) {
            setSelectedMenu(menu.name);
            setSelectedSubmenu(submenu.name);
            return;
          }
        }
      } else if (menu.href === pathname) {
        setSelectedMenu(menu.name);
        setSelectedSubmenu(null);
        return;
      }
    }
  }, [pathname]);

  const uniqueLabels = Array.from(new Set(menus.map((menu) => menu.label)));

  const handleMouseEnter = (menu) => {
    if (hoverTimeout) {
      clearTimeout(hoverTimeout);
      setHoverTimeout(null);
    }
    setOpenPopover(menu.name);
    setHoveredMenu(menu.name);
  };

  const handleMouseLeave = (e) => {
    const relatedTarget = e.relatedTarget;
    if (
      !relatedTarget?.closest(".popover-content") &&
      !relatedTarget?.closest(".menu-item")
    ) {
      const timeout = setTimeout(() => {
        setOpenPopover(null);
        setHoveredMenu(null);
      }, 150);
      setHoverTimeout(timeout);
    }
  };

  const renderSubmenu = (menu, isPopover = false) => (
    <div className={cn("bg-[#254A88] rounded-b-md", isPopover ? "p-2" : "")}>
      {menu.submenu.map((submenu) => (
        <div
          key={submenu.name}
          className={cn(
            `flex items-center h-10 mb-0 bg-[#254A88] text-white hover:bg-blue-50 hover:text-primary hover:rounded-sm mx-2 mt-1`,
            selectedSubmenu === submenu.name
              ? "bg-white text-primary rounded-sm mx-2 mt-1"
              : ""
          )}
          onClick={() => {
            setSelectedSubmenu(submenu.name);
            if (!isSidebarOpen) {
              router.push(submenu.href);
              setOpenPopover(null);
            }
          }}
        >
          <div className="flex justify-between items-center w-full px-2">
            <Link
              href={submenu.href}
              className={cn("flex-1", isSidebarOpen ? "pl-6" : "")}
            >
              <span>{submenu.name}</span>
            </Link>
            {submenu.icon2 && (
              <span
                className="cursor-pointer mr-0"
                onClick={(e) => {
                  e.stopPropagation();
                  if (submenu.addHref) {
                    router.push(submenu.addHref);
                  } else {
                    setActiveKey(submenu.key);
                    setIsSheetOpen(true);
                  }
                  if (!isSidebarOpen) {
                    setOpenPopover(null);
                  }
                }}
              >
                {submenu.icon2}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );

  const renderSubmenu1 = (menu, isPopover = false) => (
    <div className={cn("bg-[#254A88] rounded-b-md", isPopover ? "p-2" : "")}>
      {menu.submenu.map((submenu) => (
        <div
          key={submenu.name}
          className={cn(
            `flex items-center h-10 mb-0 bg-[#254A88] text-white hover:bg-blue-50 hover:text-primary hover:rounded-sm `,
            selectedSubmenu === submenu.name
              ? "bg-white text-primary rounded-sm "
              : ""
          )}
          onClick={() => {
            setSelectedSubmenu(submenu.name);
            if (!isSidebarOpen) {
              router.push(submenu.href);
              setOpenPopover(null);
            }
          }}
        >
          <div className="flex justify-between items-center w-full px-2">
            <Link
              href={submenu.href}
              className={cn("flex-1", isSidebarOpen ? "pl-6" : "")}
            >
              <span>{submenu.name}</span>
            </Link>
            {submenu.icon2 && (
              <span
                className="cursor-pointer mr-0"
                onClick={(e) => {
                  e.stopPropagation();
                  if (submenu.addHref) {
                    router.push(submenu.addHref);
                  } else {
                    setActiveKey(submenu.key);
                    setIsSheetOpen(true);
                  }
                  if (!isSidebarOpen) {
                    setOpenPopover(null);
                  }
                }}
              >
                {submenu.icon2}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );

  const handleMenuClick = (menu) => {
    if (!isSidebarOpen) {
      if (!menu.submenu) {
        router.push(menu.href);
      }
    } else {
      setSelectedMenu(selectedMenu === menu.name ? null : menu.name);
    }
  };

  const handlePopoverClick = (menu) => {
    if (!menu.submenu) {
      router.push(menu.href);
      setOpenPopover(null);
    } else {
      // If menu has submenu, navigate to first submenu item
      const firstSubmenuItem = menu.submenu[0];
      router.push(firstSubmenuItem.href);
      setOpenPopover(null);
    }
  };
  return (
    //h-vh-minus-50
    <div
      className={cn(
        "bg-primary h-screen rounded-br-[16px] rounded-tr-[16px] overflow-y-auto overflow-x-hidden transition-all duration-500 ease-in-out flex flex-col justify-between relative",
        isSidebarOpen
          ? "lg:w-52 md:w-48 w-52 opacity-100 "
          : "w-16 opacity-100 "
      )}
    >
      <div
        className={cn(
          "transition-all duration-300 ease-in-out",
          !isSidebarOpen && "flex flex-col items-center"
        )}
      >
        <div className="flex items-center h-12 pb-0">
          <button
            onClick={handleCollapse}
            className="pl-1  hover:text-primary rounded transition-colors flex items-center gap-2"
          >
            {isSidebarOpen ? (
              <>
                <ArrowLeft className="ml-[10px] h-5 w-5 text-white" />
                <div className="text-sm text-start pl-1 text-white w-36 font-medium ">
                  Collapse
                </div>
              </>
            ) : (
              <AlignJustify className="h-6 -ml-1 w-6 text-white" />
            )}
          </button>
        </div>
        <div>
          {uniqueLabels.map((label) => (
            <React.Fragment key={label}>
              {menus
                .filter((menu) => menu.label === label)
                .map((menu) => (
                  <Fragment key={menu.name}>
                    {isSidebarOpen ? (
                      <Accordion
                        type="single"
                        className="p-0 pt-0 font-normal"
                        collapsible
                        value={selectedMenu === menu.name ? menu.name : ""}
                      >
                        <AccordionItem
                          value={menu.name}
                          className="m-0 p-0 border-none"
                        >
                          <AccordionTrigger
                            className={cn(
                              `text-white flex items-center justify-between py-2 px-2  bg-primary hover:bg-blue-50  hover:text-primary hover:rounded-sm mt-1 mx-2 hover:no-underline transition-all duration-300 ease-in-out`,
                              (selectedMenu === menu.name && !menu.submenu) ||
                                selectedMenu === menu.icon
                                ? "bg-[#F5F8FF] text-primary rounded-sm mt-1  mx-2"
                                : ""
                            )}
                            onClick={() => handleMenuClick(menu)}
                            onMouseEnter={() => setHoveredMenu(menu.name)}
                            onMouseLeave={() => setHoveredMenu(null)}
                          >
                            <div className="flex justify-between w-full items-center">
                              <Link
                                href={menu.href}
                                className="flex flex-1 items-center"
                              >
                                <span>
                                  {" "}
                                  {(selectedMenu === menu.name &&
                                    !menu.submenu) ||
                                  hoveredMenu === menu.name
                                    ? menu.icon3
                                    : menu.icon}
                                </span>

                                <span className="ml-2 text-sm font-normal">
                                  {menu.name}
                                </span>
                              </Link>
                              {menu.icon2 && (
                                <span
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setActiveKey(menu.key);
                                    setIsSheetOpen(true);
                                  }}
                                >
                                  {menu.icon2}
                                </span>
                              )}
                              {menu.submenu && (
                                <ChevronDown className="h-4 w-4 shrink-0 transition-transform duration-200" />
                              )}
                            </div>
                          </AccordionTrigger>
                          {menu.submenu && (
                            <AccordionContent className="overflow-y-auto pb-0 pt-0.5 transition-all duration-300 ease-in-out">
                              {renderSubmenu(menu)}
                            </AccordionContent>
                          )}
                        </AccordionItem>
                      </Accordion>
                    ) : (
                      <Popover
                        open={openPopover === menu.name}
                        onOpenChange={(open) => {
                          if (open) {
                            handleMouseEnter(menu);
                          } else {
                            setOpenPopover(null);
                          }
                        }}
                      >
                        <PopoverTrigger asChild>
                          <div
                            className={cn(
                              "w-[40px] h-10 flex justify-center items-center text-white hover:bg-blue-50 hover:text-primary cursor-pointer menu-item",
                              selectedMenu === menu.name ||
                                hoveredMenu === menu.name ||
                                openPopover === menu.name
                                ? "bg-white rounded-sm m-1 text-primary"
                                : "m-1"
                            )}
                            onMouseEnter={() => handleMouseEnter(menu)}
                            onMouseLeave={handleMouseLeave}
                            onClick={() => handlePopoverClick(menu)}
                          >
                            <span>
                              {selectedMenu === menu.name ||
                              hoveredMenu === menu.name ||
                              openPopover === menu.name
                                ? menu.icon3
                                : menu.icon}
                            </span>
                          </div>
                        </PopoverTrigger>
                        <PopoverContent
                          side="right"
                          className="w-48 p-0 popover-content border-none bg-none"
                          align="start"
                          sideOffset={13}
                          onMouseEnter={() => handleMouseEnter(menu)}
                          onMouseLeave={handleMouseLeave}
                        >
                          {menu.submenu ? (
                            <div className="flex flex-col">
                              <div className="flex items-center px-4 py-2 rounded-tl-md rounded-tr-md bg-primary text-white border-b border-white">
                                <span className=" font-medium">
                                  {menu.name}
                                </span>
                              </div>
                              {renderSubmenu1(menu, true)}
                            </div>
                          ) : (
                            <div
                              onClick={() => handleMenuClick(menu)}
                              className="flex cursor-pointer items-center rounded-md  px-4 py-2 bg-primary text-white w-full"
                            >
                              <span className="">{menu.name}</span>
                            </div>
                          )}
                        </PopoverContent>
                      </Popover>
                    )}
                  </Fragment>
                ))}
            </React.Fragment>
          ))}
        </div>
      </div>
      <Custom_Sheet
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        activeKey={activeKey}
      />
    </div>
  );
}
