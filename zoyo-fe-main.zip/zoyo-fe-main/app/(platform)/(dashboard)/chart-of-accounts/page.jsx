"use client";
import React, { useState, useCallback, useMemo } from "react";
import { getAllAccountsGroupsData } from "@/actions/accounts/get-all-account-group";
import { getAllAccountsData } from "@/actions/accounts/get-all-accounts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Pencil, PencilLine, Trash2 } from "lucide-react";
import { deleteAccount } from "@/actions/accounts/delete-account";
import { toast } from "sonner";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import CustomTable from "@/components/custom-table/custom-table";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";

const ChartOfAccountsPage = () => {
	const [isSheetOpen, setIsSheetOpen] = useState(false);
	const [isSheetOpen1, setIsSheetOpen1] = useState(false);
	const [editUserData, setEditUserData] = useState(null);
	const queryClient = useQueryClient();
	const { confirmDelete } = useDeleteConfirmation();

	const {
		data: accounts,
		isLoading: accountsLoading,
		error: accountsError,
	} = useQuery({
		queryKey: ["accounts"],
		queryFn: getAllAccountsData,
		onError: (error) => {
			toast.error(error || "Failed to load accounts list. Please try again.");
		},
	});
	console.log(accounts);
	

	const { data: accountGroups } = useQuery({
		queryKey: ["accountGroups"],
		queryFn: getAllAccountsGroupsData,
		onError: (error) => {
			toast.error(
				error || "Failed to load account groups list. Please try again.",
			);
		},
	});

	const matchedAccounts = useMemo(() => {
		return (
			accounts?.data?.data?.map((account) => {
				const matchedGroup = accountGroups?.data?.data?.find(
					(group) => group.id === account.groupId,
				);
				return {
					...account,
					GroupName: matchedGroup?.name || "No Group",
					accountType: matchedGroup?.accountType || "No Type",
				};
			}) || []
		);
	}, [accounts, accountGroups]);

	const deleteMutation = useMutation({
		mutationFn: (id) => deleteAccount(id),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["accounts"] });
			if (!data?.message) {
				toast.error(data || data?.message || "Something Went Wrong");
			} else {
				toast.success(data?.message || "Account deleted successfully");
			}
		},
		onError: (error) => {
			toast.error(
				`Failed to delete the account. Error: ${
					error?.message || error || "Something went wrong"
				}`,
			);
		},
	});

	const handleDelete = useCallback(
		(account) => {
			confirmDelete(`Account ${account?.name}?`, () => {
				deleteMutation.mutate(account.id);
			});
		},
		[confirmDelete, deleteMutation],
	);

	const handleEdit = (data) => {
		setIsSheetOpen(true);
		setEditUserData(data);
	};

	const handleAddAccount = () => {
		setEditUserData(null); // Reset edit data when adding a new account
		setIsSheetOpen(true); // Open sheet for adding
	};
	const handleAddAccountGroup = () => {
		setIsSheetOpen1(true); // Open sheet for adding
	};

	const columns = [
		{
			id: "name",
			accessorKey: "name",
			lable: "Account Name",
			width: 200,
			header: ({ column }) => (
				<div className="flex   justify-start">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						tabIndex={0}
						role="button"
					>
						<span className="flex items-center gap-1">Account Name</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-left  text-wrap">
					<div className="overflow-hidden text-ellipsis whitespace-nowrap">
						{row?.getValue("name")}
					</div>
				</div>
			),
		},
		{
			id: "GroupName",
			accessorKey: "GroupName",
			lable: "Account Group Name",
			width: 200,
			header: ({ column }) => (
				<div className="flex   justify-start">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						tabIndex={0}
						role="button"
					>
						<span className="flex items-center gap-1">Account Group Name</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-left  text-wrap">
					<div className="overflow-hidden text-ellipsis whitespace-nowrap">
						{row?.getValue("GroupName")}
					</div>
				</div>
			),
		},
		{
			id: "accountType",
			accessorKey: "accountType",
			lable: "Account Type",
			width: 200,
			header: ({ column }) => (
				<div className="flex   justify-start">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						tabIndex={0}
						role="button"
					>
						<span className="flex items-center gap-1">Account Type</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-left  text-wrap">
					<div className="overflow-hidden text-ellipsis whitespace-nowrap">
					{row?.getValue("accountType")?.charAt(0).toUpperCase() + row?.getValue("accountType")?.slice(1)}
					</div>
				</div>
			),
		},

		{
			id: "actions",
			enableHiding: false,
			header: ({ column }) => (
				<div className="flex justify-end">
					<div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
						<span style={{ display: "flex", alignItems: "center" }}>
							Actions
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => {
				const userdata = row?.original;
				const isSystemDefault = userdata?.isSystemDefault;
				return (
					<div className="flex justify-end capitalize">
						<div className="border-r border-gray-300 flex items-center">
							<Button
								size="icon"
								className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
								onClick={() => handleEdit(userdata)}
								disabled={isSystemDefault}
							>
								<PencilLine className="h-4 w-4" />
							</Button>
						</div>
						<div className="flex items-center">
							<Button
								size="icon"
								className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
								onClick={() => handleDelete(userdata)}
								disabled={isSystemDefault}
							>
								<Trash2 className="h-4 w-4" />
							</Button>
						</div>
					</div>
				);
			},
		},
	];

	const otherFilterFields = () => {
		return <div className=" pt-4 pb-4 flex justify-between "></div>;
	};

	return (
		<Card className="rounded-md ">
			<CustomTable
				data={matchedAccounts}
				columns={columns}
				isLoading={accountsLoading}
				error={accountsError}
				tableWidth="100%"
				tableHeader="Chart of Accounts"
				addbuttonLable={"Add Account Group"}
				onClickAddbutton={handleAddAccountGroup}
				addbuttonLable2={"Add Account "}
				onClickAddbutton2={handleAddAccount}
				filterFields={otherFilterFields()}
			/>

			<Custom_Sheet
				isOpen={isSheetOpen}
				onClose={() => setIsSheetOpen(false)}
				activeKey={"accounts"}
				editId={editUserData}
			/>
			<Custom_Sheet
				isOpen={isSheetOpen1}
				onClose={() => setIsSheetOpen1(false)}
				activeKey={"accountGroup"}
			/>
		</Card>
	);
};

export default ChartOfAccountsPage;
