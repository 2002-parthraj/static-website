import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { addAccountGroup } from "@/actions/accounts/add-accountGroups";
import { getAllAccountsGroupsData } from "@/actions/accounts/get-all-account-group";
import {
	FormSelectField,
	TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { optionforAccountType } from "@/components/enums/enums";
import { toast } from "sonner";
import { Form } from "@/components/ui/form";
import {
	Card,
	CardContent,
	CardFooter,
	CardHeader,
	CardTitle,
} from "@/components/ui/card";
import { ReloadIcon } from "@radix-ui/react-icons";

const formSchema = z.object({
	name: z
		.string()
		.min(1, "Group Name is required")
		.max(100, "Group Name must be less than 100 characters"),
	label: z
		.string()
		.max(100, "Group Label must be less than 100 characters")
		.optional(),
	accountType: z.enum(["assets", "liabilities", "expense", "income"], {
		errorMap: () => ({ message: "Account Type is required" }),
	}),
	parentGroupId: z
		.string()
		.transform((val) => (val ? parseFloat(val) : undefined))
		.optional(),
});

export const AddAccountGroupForm = ({ onClose }) => {
	const queryClient = useQueryClient();

	const { data: accountGroups } = useQuery({
		queryKey: ["accountGroups"],
		queryFn: getAllAccountsGroupsData,
		onError: (error) => {
			toast.error(error || "Failed to load account groups. Please try again.");
		},
	});

	const form = useForm({
		resolver: zodResolver(formSchema),
		defaultValues: {
			name: "",
			label: "",
			accountType: "",
			parentGroupId: "",
		},
	});

	const addAccountGroupMutation = useMutation({
		mutationFn: addAccountGroup,
		onSuccess: handleMutationSuccess,
		onError: handleMutationError,
	});

	function handleMutationSuccess(data) {
		queryClient.invalidateQueries({ queryKey: ["accountGroups"] });
		if (data?.status === 200 || data?.status === 201) {
			form.reset();
			onClose?.();
			toast.success("Account Group added successfully");
		} else if (data?.status === 409) {
			toast.warning(data?.data?.error[0]?.message || "A conflict occurred");
		} else {
			toast.error(
				data?.response?.data?.error[0]?.message ||
					"An unexpected error occurred",
			);
		}
	}

	function handleMutationError(error) {
		toast.error(error || "Something went wrong, try again");
	}

	function onSubmit(values) {
		const filteredValues = Object.fromEntries(
			Object.entries(values).filter(
				([, value]) => value !== undefined && value !== null && value !== "",
			),
		);
		addAccountGroupMutation.mutate(filteredValues);
	}

	return (
		<>
			<div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
				<h2 className="text-lg font-semibold">Add Account Group</h2>
			</div>

			<Form {...form} className="p-4">
				<form
					id="accountForm"
					onSubmit={form.handleSubmit(onSubmit)}
					className="space-y-4"
				>
					<main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto">
						<div className="w-[90%] pt-4 mx-auto">
							<TextInputField
								form="form"
								name="name"
								label="Group Name"
								type="text"
								placeholder="Enter Group Name Here"
								className="flex flex-col space-y-1.5"
								required
							/>
						</div>
						<div className="w-[90%] pt-4 mx-auto">
							<TextInputField
								form="form"
								name="label"
								label="Group Label"
								type="text"
								placeholder="Enter Group Label Here"
								className="flex flex-col space-y-1.5"
							/>
						</div>
						<div className="w-[90%] pt-4 mx-auto">
							<FormSelectField
								control={form.control}
								name="accountType"
								label="Account Type"
								options={optionforAccountType}
								placeholder="Choose Account Type"
								className="w-full p-2 border rounded"
								required
							/>
						</div>
						<div className="w-[90%] pt-4 mx-auto">
							<FormSelectField
								control={form.control}
								name="parentGroupId"
								label="Parent Group Name"
								options={accountGroups?.data?.data?.map((group) => ({
									value: `${group.id}`,
									label: group.name,
								}))}
								placeholder="Choose Parent Group Type"
								className="w-full p-2 border rounded"
							/>
						</div>
					</main>
					<div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0 h-[76px] left-0 w-full p-4 shadow-lg">
						<Button
							type="submit"
							form="accountForm"
							className="  mr-3 mt-1 text-white  "
							disabled={addAccountGroupMutation.isPending}
						>
							{addAccountGroupMutation.isPending ? (
								<>
									<ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
									Adding...
								</>
							) : (
								"Add"
							)}
						</Button>
					</div>
				</form>
			</Form>
		</>
	);
};
