import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getAllAccountsGroupsData } from "@/actions/accounts/get-all-account-group";
import {
	FormSelectField,
	TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { toast } from "sonner";
import { addAccounts } from "@/actions/accounts/add-accounts";
import { editAccount } from "@/actions/accounts/edit-account";
import {
	Card,
	CardContent,
	CardFooter,
	CardHeader,
	CardTitle,
} from "@/components/ui/card";
import { ReloadIcon } from "@radix-ui/react-icons";

const formSchema = z.object({
	code: z
		.string()
		.min(1, { message: "Account Code is required" })
		.max(20, { message: "Account Code cannot exceed 20 characters" }),
	name: z
		.string()
		.min(1, { message: "Account Name is required" })
		.max(100, { message: "Account Name cannot exceed 100 characters" }),
	label: z
		.string()
		.max(100, { message: "Account Label cannot exceed 100 characters" })
		.optional(),
	groupId: z
		.string()
		.min(1, { message: "Group Name is required" })
		.transform((val) => parseFloat(val)),
});

export const AddEditAccountsForm = ({ account = null, onClose }) => {
	const queryClient = useQueryClient();
	const isEditing = !!account;

	const { data: accountGroups } = useQuery({
		queryKey: ["accountGroups"],
		queryFn: getAllAccountsGroupsData,
		onError: (error) => {
			toast.error(error || "Failed to load account groups. Please try again.");
		},
	});

	const form = useForm({
		resolver: zodResolver(formSchema),
		defaultValues: {
			code: account?.code || "",
			name: account?.name || "",
			label: account?.label || "",
			groupId: account?.groupId?.toString() || "",
		},
	});

	useEffect(() => {
		if (account) {
			form.reset({
				code: account.code || "",
				name: account.name || "",
				label: account.label || "",
				groupId: account.groupId?.toString() || "",
			});
		}
	}, [account, form]);

	const addAccountsMutation = useMutation({
		mutationFn: addAccounts,
		onSuccess: handleMutationSuccess,
		onError: handleMutationError,
	});

	const editAccountMutation = useMutation({
		mutationFn: (data) => editAccount(data, account.id),
		onSuccess: handleMutationSuccess,
		onError: handleMutationError,
	});

	function handleMutationSuccess(data) {
		queryClient.invalidateQueries({ queryKey: ["accounts"] });
		if (data?.status === 200 || data?.status === 201) {
			form.reset();
			onClose?.();
			toast.success(`Account ${isEditing ? "updated" : "added"} successfully`);
		} else if (data?.status === 409) {
			toast.warning(data?.data?.error[0]?.message || "A conflict occurred");
		} else {
			toast.error(
				data?.response?.data?.error[0]?.message ||
					"An unexpected error occurred",
			);
		}
	}

	function handleMutationError(error) {
		toast.error(error || "Something went wrong, try again");
	}

	function onSubmit(values) {
		const filteredValues = Object.fromEntries(
			Object.entries(values).filter(([, value]) => value !== ""),
		);
		if (isEditing) {
			editAccountMutation.mutate(filteredValues);
		} else {
			addAccountsMutation.mutate(filteredValues);
		}
	}

	return (
		<>
			<div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
				<h2 className="text-lg font-semibold">
					{isEditing ? "Edit Account" : "Add Account"}
				</h2>
			</div>

			<Form {...form} className="p-4">
				<form
					id="accountForm"
					onSubmit={form.handleSubmit(onSubmit)}
					className="space-y-4"
				>
					<main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto">
						<div className="w-[90%] pt-4 mx-auto">
							<TextInputField
								form="form"
								name="code"
								label="Account Code"
								type="text"
								placeholder="Enter Account Code Here"
								className="flex flex-col space-y-1.5"
								required
							/>
						</div>
						<div className="w-[90%] pt-4 mx-auto">
							<TextInputField
								form="form"
								name="name"
								label="Account Name"
								type="text"
								placeholder="Enter Account Name Here"
								className="flex flex-col space-y-1.5"
								required
							/>
						</div>
						<div className="w-[90%] pt-4 mx-auto">
							<TextInputField
								form="form"
								name="label"
								label="Account Label"
								type="text"
								placeholder="Enter Account Label Here"
								className="flex flex-col space-y-1.5"
							/>
						</div>
						<div className="w-[90%] pt-4 mx-auto">
							<FormSelectField
								control={form.control}
								name="groupId"
								label="Group Name"
								options={accountGroups?.data?.data?.map((group) => ({
									value: `${group.id}`,
									label: group.name,
								}))}
								placeholder="Choose Group Name"
								className="w-full p-2 border rounded"
								required
							/>
						</div>
					</main>

					<div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0 h-[76px] left-0 w-full p-4 shadow-lg">
						<Button
							type="submit"
							className="  mr-3 mt-1 text-white  "
							disabled={
								addAccountsMutation.isPending || editAccountMutation.isPending
							}
						>
							{editAccountMutation.isPending ||
							addAccountsMutation.isPending ? (
								<>
									<ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
									{editAccountMutation.isPending ? "Updating..." : "Adding..."}
								</>
							) : isEditing ? (
								"Update"
							) : (
								"Add"
							)}
						</Button>
					</div>
				</form>
			</Form>
		</>
	);
};
