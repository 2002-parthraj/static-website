"use client";
import { useState } from "react";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartConfig,
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Spinner from "@/components/custom-spinner/spinner";
import { useQuery } from "@tanstack/react-query";
import { getDashboardCashflowData } from "@/actions/dashboard/get-dashboard-cashflow-data";
import { LineChart, Loader2 } from "lucide-react";

const chartConfig = {
  cashIn: {
    label: "Cash In",
    color: "#2E5391",
  },
  cashOut: {
    label: "Cash Out",
    color: "#BDCAE0",
  },
};

const transformMonthlyData = (data) => {
  if (!data || !Array.isArray(data)) return [];
  
  const monthlyData = data.reduce((acc, curr) => {
    const monthYear = curr.date.substring(0, 7);
    if (!acc[monthYear]) {
      acc[monthYear] = {
        date: monthYear + "-01",
        cashIn: 0,
        cashOut: 0
      };
    }
    acc[monthYear].cashIn += curr.cashIn;
    acc[monthYear].cashOut += curr.cashOut;
    return acc;
  }, {});

  return Object.values(monthlyData).sort((a, b) => 
    new Date(a.date) - new Date(b.date)
  );
};



const VisitorCashflow = () => {
  const [selectedAccount, setSelectedAccount] = useState("");
  const [interval, setInterval] = useState("daily");

  const {
    data: cashflowChart,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["cashflowChart", interval],
    queryFn:() => getDashboardCashflowData(interval),
  });

  const NoDataMessage = () => (
    <div className="h-[287px] flex items-center justify-center">
      <div className="text-center">
        <div className="rounded-full h-16 w-16 bg-slate-50 mx-auto mb-2 flex items-center justify-center">
          {isLoading ? (
            <Loader2 className="text-blue-800 font-bold animate-spin" />
          ) : (
            <LineChart className="text-blue-800 font-bold" />
          )}
        </div>
        <p className="text-gray-500 text-sm">
          {isLoading ? "Loading..." : "No Data Available"}
        </p>
      </div>
    </div>
  );

  
  if (error) return <div>Error loading data</div>;

  const accounts = cashflowChart?.data?.data || [];
  
  // Get the selected account's data or use the first account if none selected
  const currentAccount = accounts.find(acc => acc.accountId.toString() === selectedAccount) || accounts[0];
  
  // Transform data based on interval
  const rawChartData = currentAccount?.cashflow || [];
  const chartData = interval === "monthly" 
    ? transformMonthlyData(rawChartData)
    : rawChartData;

  const hasData = chartData.length > 0;

  return (
    <div className="w-full max-w-[668px]">
      <Card className="w-full h-[313px]">
        <CardHeader className="flex flex-row items-stretch justify-between space-y-0 border-b p-0 overflow-x-auto overflow-y-hidden">
          <div className="flex flex-wrap items-center gap-4">
            <CardTitle className="font-medium ml-4">Cashflow</CardTitle>
          </div>

          <div className="flex gap-2 py-1 pr-4">
            <Select value={selectedAccount} onValueChange={setSelectedAccount}>
              <SelectTrigger className="w-52">
                <SelectValue placeholder="Choose Bank Account" />
              </SelectTrigger>
              <SelectContent>
                {accounts.map((account) => (
                  <SelectItem 
                    key={account.accountId} 
                    value={account.accountId.toString()}
                  >
                    {account.accountName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={interval} onValueChange={setInterval}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Day Wise" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Day Wise</SelectItem>
                <SelectItem value="monthly">Month Wise</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {hasData ? (
            <ChartContainer
              config={chartConfig}
              className="h-[252px] aspect-auto w-full"
            >
              <BarChart
                data={chartData}
                margin={{ top: 20, right: 20, left: 30, bottom: 30 }}
                width={800}
                height={288}
              >
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey="date"
                  tickLine={true}
                  tickMargin={8}
                  axisLine={true}
                  tickFormatter={(value) => {
                    const date = new Date(value);
                    return date.toLocaleDateString("en-US", {
                      month: "short",
                      day: interval === "daily" ? "numeric" : undefined,
                      year: interval === "monthly" ? "numeric" : undefined
                    });
                  }}
                />
                <YAxis
                  tickFormatter={(value) => 
                    new Intl.NumberFormat('en-IN', {
                      style: 'currency',
                      currency: 'INR',
                      minimumFractionDigits: 0,
                      maximumFractionDigits: 0,
                    }).format(value)
                  }
                />
                <ChartTooltip
                  cursor={false}
                  content={<ChartTooltipContent indicator="dashed" />}
                />
                <ChartLegend content={<ChartLegendContent />} />
                <Bar dataKey="cashIn" fill="var(--color-cashIn)" radius={4} />
                <Bar dataKey="cashOut" fill="var(--color-cashOut)" radius={4} />
              </BarChart>
            </ChartContainer>
          ) : (
            <NoDataMessage />
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default VisitorCashflow;