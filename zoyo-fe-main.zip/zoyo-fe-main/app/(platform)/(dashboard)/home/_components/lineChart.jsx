"use client";

import React, { useMemo, useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  XAxis,
  YAxis,
} from "recharts";
import {
  Card,
  CardContent,
  CardHeader,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import Spinner from "@/components/custom-spinner/spinner";
import { getDashboardLineChartData } from "@/actions/dashboard/get-dashboard-linechart-data";
import { ChartContainer, ChartTooltip } from "@/components/ui/chart";
import { LineChart as LineChartIcon, Loader2 } from "lucide-react";

const chartConfig = {
  sales: {
    label: "Sales",
    colors: ["#2E5391"],
  },
  purchase: {
    label: "Purchase",
    colors: ["#039855"],
  },
  expense: {
    label: "Expense",
    colors: ["#DC9203"],
  },
};



const VisitorLineChart = () => {
  const [activeMetric, setActiveMetric] = useState("sales");
  const [interval, setInterval] = useState("daily");

  const { data: apiResponse, isLoading, error } = useQuery({
    queryKey: ["dashboard", interval],
    queryFn: () => getDashboardLineChartData(interval),
  });

  const NoDataMessage = () => (
    <div className="h-[287px] flex items-center justify-center">
      <div className="text-center">
        <div className="rounded-full h-16 w-16 bg-slate-50 mx-auto mb-2 flex items-center justify-center">
          {isLoading ? (
            <Loader2 className="text-blue-800 font-bold animate-spin" />
          ) : (
            <LineChartIcon className="text-blue-800 font-bold" />
          )}
        </div>
        <p className="text-gray-500 text-sm">
          {isLoading ? "Loading..." : "No Data Available"}
        </p>
      </div>
    </div>
  );

  const groupDataByMonth = (data) => {
    if (!data) return [];
    
    const monthlyData = {};
    data.forEach((item) => {
      const month = item.date.substring(0, 7);
      if (!monthlyData[month]) {
        monthlyData[month] = {
          date: month,
          sales: 0,
          purchase: 0,
          expense: 0,
        };
      }
      monthlyData[month].sales += item.sales;
      monthlyData[month].purchase += item.purchase;
      monthlyData[month].expense += item.expense;
    });
    
    return Object.values(monthlyData);
  };

  const processedData = useMemo(() => {
    const chartData = apiResponse?.data?.data;
    if (!chartData) return [];
    
    if (interval === "monthly") {
      return groupDataByMonth(chartData);
    }
    
    return chartData;
  }, [apiResponse, interval]);

  const totals = useMemo(
    () => ({
      sales: processedData.reduce((acc, curr) => acc + (curr.sales || 0), 0),
      purchase: processedData.reduce((acc, curr) => acc + (curr.purchase || 0), 0),
      expense: processedData.reduce((acc, curr) => acc + (curr.expense || 0), 0),
    }),
    [processedData]
  );

  const formatDate = (value) => {
    if (interval === "monthly") {
      const date = new Date(value + "-01");
      return date.toLocaleDateString("en-US", {
        month: "short",
        year: "numeric",
      });
    } else {
      const date = new Date(value);
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });
    }
  };

  if (error) return <div>Error loading data</div>;

  const hasData = processedData && processedData.length > 0;

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-stretch justify-between space-y-0 border-b p-0 overflow-x-auto overflow-y-hidden">
        <div className="flex items-center gap-4">
          {Object.entries(chartConfig).map(([key, config]) => (
            <button
              key={key}
              onClick={() => setActiveMetric(key)}
              className={`rounded p-3 ${
                activeMetric === key ? "border-b-2 border-primary" : ""
              }`}
            >
              <div className="font-medium min-w-[100px]">{config.label}</div>
            </button>
          ))}
        </div>

        <div className="flex gap-2 pt-2 pr-4">
          <Select value={interval} onValueChange={setInterval}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Select time frame" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Day Wise</SelectItem>
              <SelectItem value="monthly">Month Wise</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {hasData ? (
          <div className="h-[294px] w-full">
            <ChartContainer
              config={chartConfig}
              className="aspect-auto h-[340px] w-full pt-6"
            >
              <LineChart
                data={processedData}
                margin={{ top: 20, right: 30, left: 0, bottom: 30 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tickFormatter={formatDate} />
                <YAxis />
                <ChartTooltip
                  formatter={(value, name) => [
                    value,
                    chartConfig[name].label
                  ]}
                />
                <Line
                  type="monotone"
                  dataKey={activeMetric}
                  name={activeMetric}
                  stroke={chartConfig[activeMetric].colors[0]}
                  strokeWidth={2}
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ChartContainer>
          </div>
        ) : (
          <NoDataMessage />
        )}
      </CardContent>
    </Card>
  );
};

export default VisitorLineChart;