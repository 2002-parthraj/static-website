"use client";
import { useState } from "react";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChartConfig,
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { getDashboardSalesConversionChartData } from "@/actions/dashboard/get-dashboard-sales-conversion-data";
import { BarChart2, Loader2 } from "lucide-react";

const chartConfig = {
  sent: {
    label: "Estimates Sent",
    color: "#2E5391",
  },
  invoiced: {
    label: "Invoiced",
    color: "#BDCAE0",
  },
  expired: {
    label: "Expired",
    color: "#E0E0E0",
  }
};

const transformMonthlyData = (data) => {
  if (!data || !Array.isArray(data)) return [];
  
  const monthlyData = data.reduce((acc, curr) => {
    const monthYear = curr.date.substring(0, 7); // Gets "YYYY-MM"
    if (!acc[monthYear]) {
      acc[monthYear] = {
        date: monthYear + "-01", // First day of month for sorting
        sent: 0,
        invoiced: 0,
        expired: 0
      };
    }
    acc[monthYear].sent += curr.sent;
    acc[monthYear].invoiced += curr.invoiced;
    acc[monthYear].expired += curr.expired;
    return acc;
  }, {});

  return Object.values(monthlyData).sort((a, b) => 
    new Date(a.date) - new Date(b.date)
  );
};



const VisitorBarChart = () => {
  const [interval, setInterval] = useState("daily");

  const {
    data: salesConversionData,
    isLoading,
    error
  } = useQuery({
    queryKey: ["salesConversiondata", interval],
    queryFn: () => getDashboardSalesConversionChartData(interval),
  });

  const NoDataMessage = () => (
    <div className="h-[287px] flex items-center justify-center">
      <div className="text-center">
        <div className="rounded-full h-16 w-16 bg-slate-50 mx-auto mb-2 flex items-center justify-center">
          {isLoading ? (
            <Loader2 className="text-blue-800 font-bold animate-spin" />
          ) : (
            <BarChart2 className="text-blue-800 font-bold" />
          )}
        </div>
        <p className="text-gray-500 text-sm">
          {isLoading ? "Loading..." : "No Data Available"}
        </p>
      </div>
    </div>
  );

  const chartData = salesConversionData?.data?.data || [];
  const displayData = interval === "monthly" 
    ? transformMonthlyData(chartData)
    : chartData;

  const hasData = displayData && displayData.length > 0;

  return (
    <div className="w-full max-w-[668px]">
      <Card className="w-full h-[313px]">
        <CardHeader className="flex flex-row items-stretch justify-between space-y-0 border-b p-0 overflow-x-auto overflow-y-hidden">
          <div className="flex flex-wrap items-center gap-4">
            <CardTitle className="font-medium ml-4">
              Sales Conversion Summary
            </CardTitle>
          </div>

          <div className="flex gap-2 py-1 pr-4">
            <Select value={interval} onValueChange={setInterval}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Day Wise" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Day Wise</SelectItem>
                <SelectItem value="monthly">Month Wise</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {hasData ? (
            <ChartContainer
              config={chartConfig}
              className="h-[262px] aspect-auto w-full"
            >
              <BarChart
                data={displayData}
                margin={{ top: 20, right: 20, left: 0, bottom: 30 }}
                width={800}
                height={288}
              >
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  tickMargin={10}
                  axisLine={true}
                  tickFormatter={(value) => {
                    const date = new Date(value);
                    return date.toLocaleDateString("en-US", {
                      month: "short",
                      day: interval === "daily" ? "numeric" : undefined,
                      year: interval === "monthly" ? "numeric" : undefined
                    });
                  }}
                />
                <YAxis
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => `${value}`}
                />
                <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                <ChartLegend content={<ChartLegendContent />} />
                <Bar
                  dataKey="sent"
                  stackId="a"
                  fill="var(--color-sent)"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="invoiced"
                  stackId="a"
                  fill="var(--color-invoiced)"
                  radius={[0, 0, 0, 0]}
                />
                <Bar
                  dataKey="expired"
                  stackId="a"
                  fill="var(--color-expired)"
                  radius={[0, 0, 4, 4]}
                />
              </BarChart>
            </ChartContainer>
          ) : (
            <NoDataMessage />
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default VisitorBarChart;