import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { getDashboardTopLeastItemData } from "@/actions/dashboard/get-dashboard-top-least-item";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2, PackageSearch } from "lucide-react";

const InventoryTable = () => {
  const { data: test, isLoading, error } = useQuery({
    queryKey: ["dashboardTopLeastItem"],
    queryFn: getDashboardTopLeastItemData,
    onError: (error) => {
      toast.error(error || "Failed to load data. Please try again.");
    },
  });

  const TopSelling = test?.data?.topSelling;
  const LowSelling = test?.data?.lowSelling;

  const NoDataMessage = () => (
    <div className="h-[287px] flex items-center justify-center">
      <div className="text-center">
        <div className="rounded-full h-16 w-16 bg-slate-50 mx-auto mb-2 flex items-center justify-center">
          {isLoading ? (
            <Loader2 className="text-blue-800 font-bold animate-spin" />
          ) : (
            <PackageSearch className="text-blue-800 font-bold" />
          )}
        </div>
        <p className="text-gray-500 text-sm">
          {isLoading ? "Loading..." : "No Data Available"}
        </p>
      </div>
    </div>
  );

  return (
    <div className="w-full max-w-[668px]">
      <Card className="w-full h-[338px]">
        <CardContent className="p-0">
          <Tabs defaultValue="top-selling" className="w-full">
            <div className="border-b pb-[2px] border-gray-300 text-center overflow-x-auto overflow-y-hidden">
              <TabsList className="w-full mt-2 flex flex-row justify-start rounded-lg bg-white">
                <TabsTrigger
                  value="top-selling"
                  className="pb-4 rounded-none text-sm font-medium text-black data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                >
                  Top Selling Items
                </TabsTrigger>
                <TabsTrigger
                  value="least-selling"
                  className="rounded-none pb-4 text-sm font-medium text-black data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                >
                  Least Selling Items
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="top-selling" className="mt-0">
              {TopSelling?.length > 0 ? (
                <div className="h-[287px] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 bg-[#F8F8F8]">
                      <TableRow className={cn("h-[35px]")}>
                        <TableHead className="text-left p-3 max-w-[200px] w-[40%]">Item Name</TableHead>
                        <TableHead className="text-left p-3 max-w-[100px] w-[20%]">Unit</TableHead>
                        <TableHead className="text-right p-3 max-w-[100px] w-[20%]">Quantity</TableHead>
                        <TableHead className="text-right p-3 max-w-[100px] w-[20%]">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {TopSelling.map((item, index) => (
                        <TableRow key={index} className={cn("h-[35px]")}>
                          <TableCell className="text-left font-medium p-3 max-w-[200px] truncate">
                            {item.itemName}
                          </TableCell>
                          <TableCell className="text-left font-medium p-3 max-w-[100px] truncate">
                            {item.unit}
                          </TableCell>
                          <TableCell className="text-right p-3 max-w-[100px]">
                            {item.quantity}
                          </TableCell>
                          <TableCell className="text-right p-3 max-w-[100px]">
                            
                            {Number(item.amount).toLocaleString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <NoDataMessage />
              )}
            </TabsContent>

            <TabsContent value="least-selling" className="mt-0">
              {LowSelling?.length > 0 ? (
                <div className="h-[287px] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 bg-[#F8F8F8]">
                      <TableRow className={cn("h-[35px]")}>
                        <TableHead className="text-left p-3 max-w-[200px] w-[40%]">Item Name</TableHead>
                        <TableHead className="text-left p-3 max-w-[100px] w-[20%]">Unit</TableHead>
                        <TableHead className="text-right p-3 max-w-[100px] w-[20%]">Quantity</TableHead>
                        <TableHead className="text-right p-3 max-w-[100px] w-[20%]">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {LowSelling.map((item, index) => (
                        <TableRow key={index} className={cn("h-[35px]")}>
                          <TableCell className="text-left font-medium p-3 max-w-[200px] truncate">
                            {item.itemName}
                          </TableCell>
                          <TableCell className="text-left font-medium p-3 max-w-[100px] truncate">
                            {item.unit}
                          </TableCell>
                          <TableCell className="text-right p-3 max-w-[100px]">
                            {item.quantity}
                          </TableCell>
                          <TableCell className="text-right p-3 max-w-[100px]">
                          {Number(item.amount).toLocaleString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <NoDataMessage />
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default InventoryTable;