import React from "react";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const GSTTable = () => {
	const data = [
		{
			partyName: "Party A",
			gstRating: "10",
			itcAmount: "1,20,928",
			balance: "1,20,928",
		},
		{
			partyName: "Party B",
			gstRating: "2",
			itcAmount: "1,20,928",
			balance: "1,20,928",
		},
		{
			partyName: "Party C",
			gstRating: "10",
			itcAmount: "1,20,928",
			balance: "1,20,928",
		},
		{
			partyName: "Party D",
			gstRating: "7",
			itcAmount: "1,20,928",
			balance: "1,20,928",
		},
		{
			partyName: "Party A",
			gstRating: "7",
			itcAmount: "1,20,928",
			balance: "1,20,928",
		},
	];

	return (
		<div className="w-full max-w-[668px] ">
			<Card className="w-full h-[338px]">
				<CardHeader className="border-b p-4">
					<CardTitle className="font-medium">
						GST Rating & ITC Details
					</CardTitle>
				</CardHeader>
				<CardContent className="p-0">
					<div className="h-[287px] overflow-y-auto ">
						<Table>
							<TableHeader className="bg-[#F8F8F8]">
								<TableRow className={cn("h-[35px]")}>
									<TableHead className="text-left p-3">Party Name</TableHead>
									<TableHead className="text-right p-3">GST Rating</TableHead>
									<TableHead className="text-right p-3">ITC Amount</TableHead>
									<TableHead className="text-right p-3">Balance</TableHead>
								</TableRow>
							</TableHeader>
							<TableBody>
								{data.map((row) => (
									<TableRow key={row.partyName} className={cn("h-[35px]")}>
										<TableCell className="text-left font-medium p-3">
											{row.partyName}
										</TableCell>
										<TableCell className="text-right p-3">
											{row.balance}
										</TableCell>
										<TableCell className="text-right p-3">
											{row.itcAmount}
										</TableCell>
										<TableCell className="text-right p-3">
											{row.balance}
										</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</div>
				</CardContent>
			</Card>
		</div>
	);
};

export default GSTTable;
