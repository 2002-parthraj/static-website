import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { getDashboardTopLeastItemData } from "@/actions/dashboard/get-dashboard-top-least-item";
import { getDashboardTopPayableReceivableData } from "@/actions/dashboard/get-dashboard-top-payable-receivable";
import { Loader2, Users } from "lucide-react";

const PayableTable = () => {
  const { data: payable,isLoading } = useQuery({
    queryKey: ["dashboardTopPayableReceivable"],
    queryFn: getDashboardTopPayableReceivableData,
    onError: (error) => {
      toast.error(error || "Failed to load data. Please try again.");
    },
  });
  
  const TopPayable = payable?.data.topPayable;
  const TopReceivable = payable?.data.topReceivable;

  const NoDataMessage = () => (
    <div className="h-[287px] flex items-center justify-center">
      <div className="text-center">
        <div className="rounded-full h-16 w-16 bg-slate-50 mx-auto mb-2 flex items-center justify-center">
          {isLoading ? (
            <Loader2 className="text-blue-800 font-bold animate-spin" />
          ) : (
            <Users className="text-blue-800 font-bold" />
          )}
        </div>
        <p className="text-gray-500 text-sm">
          {isLoading ? "Loading..." : "No Data Available"}
        </p>
      </div>
    </div>
  );

  return (
    <div className="w-full max-w-[668px]">
      <Card className="w-xl h-[338px]">
        <CardContent className="p-0">
          <Tabs defaultValue="payable" className="w-full">
            <div className="border-b pb-[2px] border-gray-300 text-center overflow-x-auto overflow-y-hidden">
              <TabsList className="w-full mt-2 flex flex-row justify-start rounded-lg bg-white">
                <TabsTrigger
                  value="payable"
                  className="pb-4 rounded-none text-sm font-medium text-black data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                >
                  Top Payable
                </TabsTrigger>
                <TabsTrigger
                  value="receivable"
                  className="rounded-none pb-4 text-sm font-medium text-black data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                >
                  Top Receivable
                </TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="payable" className="mt-0">
              {TopPayable?.length > 0 ? (
                <div className="h-[287px] overflow-y-auto">
                  <Table>
                    <TableHeader className="bg-[#F8F8F8]">
                      <TableRow className={cn("h-[35px]")}>
                        <TableHead className="text-left p-3 max-w-[200px] w-[40%]">Party Name</TableHead>
                        <TableHead className="text-right p-3 max-w-[100px] w-[20%]">
                          Payment Due
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {TopPayable.map((row) => (
                        <TableRow key={row.partyName} className={cn("h-[35px]")}>
                          <TableCell className="text-left font-medium p-3 max-w-[200px] truncate">
                            {row.partyName}
                          </TableCell>
                          <TableCell className="text-right p-3 max-w-[100px]">
                          {Number(row.paymentDue).toLocaleString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <NoDataMessage />
              )}
            </TabsContent>
            <TabsContent value="receivable" className="mt-0">
              {TopReceivable?.length > 0 ? (
                <div className="h-[287px] overflow-y-auto">
                  <Table>
                    <TableHeader className="bg-[#F8F8F8]">
                      <TableRow className={cn("h-[35px]")}>
                        <TableHead className="text-left p-3 max-w-[200px] w-[40%]">Party Name</TableHead>
                        <TableHead className="text-right p-3 max-w-[100px] w-[20%]">
                          Payment Due
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {TopReceivable.map((row) => (
                        <TableRow key={row.partyName} className={cn("h-[35px]")}>
                          <TableCell className="text-left font-medium p-3 max-w-[200px] truncate">
                            {row.partyName}
                          </TableCell>
                          <TableCell className="text-right p-3 max-w-[100px]">
                          {Number(row.paymentDue).toLocaleString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <NoDataMessage />
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default PayableTable;