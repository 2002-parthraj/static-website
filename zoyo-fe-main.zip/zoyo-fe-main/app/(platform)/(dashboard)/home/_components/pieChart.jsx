import React from 'react';
import { Pie, PieChart } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import Spinner from "@/components/custom-spinner/spinner";
import { useQuery } from "@tanstack/react-query";
import { getPieChaRtreceiptsByPaymentData } from "@/actions/dashboard/get-piechart-receipts-by-payment";
import { Loader2, PieChart as PieChartIcon } from "lucide-react";

const chartColors = ["#2E5391", "#BDCAE0", "#4A90E2", "#81A3D0"];

const transformChartData = (apiData) => {
  if (!apiData || !Array.isArray(apiData)) return [];
  
  return apiData.map((item, index) => ({
    name: item?.paymentModeName?.charAt(0).toUpperCase() + item?.paymentModeName?.slice(1),
    value: Number.parseFloat(item?.amount),
    fill: chartColors[index % chartColors.length]
  }));
};

const transformChartConfig = (apiData) => {
  if (!apiData || !Array.isArray(apiData)) return {};
  
  const config = {
    value: {
      label: "Amount",
    }
  };

  apiData.forEach((item, index) => {
    const formattedAmount = parseFloat(item.amount).toLocaleString('en-IN', {
      style: 'currency',
      currency: 'INR'
    });
    const name = item?.paymentModeName?.charAt(0).toUpperCase() + item?.paymentModeName?.slice(1);
    
    config[name] = {
      label: `${name} ${formattedAmount}`,
      color: chartColors[index % chartColors.length]
    };
  });

  return config;
};

const CustomLegend = ({ chartData }) => {
  return (
    <div className="flex flex-col justify-center gap-4">
      {chartData.map((entry, index) => (
        <div key={index} className="flex items-center gap-2">
          <div
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: entry.fill }}
          />
          <span className="text-sm text-gray-600">
            {`${entry.name} - ${parseFloat(entry.value).toLocaleString('en-IN', {
              style: 'currency',
              currency: 'INR'
            })}`}
          </span>
        </div>
      ))}
    </div>
  );
};



const PaymentBifurcation = () => {
  const {
    data: pieChart,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["pieChart"],
    queryFn: getPieChaRtreceiptsByPaymentData,
  });

  const chartData = transformChartData(pieChart?.data?.data);
  const chartConfig = transformChartConfig(pieChart?.data?.data);


  if (error) return <div>Error loading data</div>;

  const hasData = chartData && chartData.length > 0;

  const NoDataMessage = () => (
    <div className="h-[287px] flex items-center justify-center">
      <div className="text-center">
        <div className="rounded-full h-16 w-16 bg-slate-50 mx-auto mb-2 flex items-center justify-center">
          {isLoading ? (
            <Loader2 className="text-blue-800 font-bold animate-spin" />
          ) : (
            <PieChartIcon className="text-blue-800 font-bold" />
          )}
        </div>
        <p className="text-gray-500 text-sm">
          {isLoading ? "Loading..." : "No Data Available"}
        </p>
      </div>
    </div>
  );

  return (
    <div className="w-full max-w-[668px]">
      <Card className="w-full h-[313px]">
        <CardHeader className="border-b p-4">
          <CardTitle className="font-medium">Payment Bifurcation</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          {hasData ? (
            <div className="flex items-center justify-between w-full h-full">
              <div className="w-2/3">
                <ChartContainer config={chartConfig} className="h-[220px] w-full">
                  <PieChart width={400} height={220}>
                    <ChartTooltip
                      cursor={false}
                      content={<ChartTooltipContent />}
                    />
                    <Pie
                      data={chartData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={60}
                      outerRadius={90}
                      cx={200}
                      cy={110}
                    />
                  </PieChart>
                </ChartContainer>
              </div>
              <div className="w-2/3 text-center">
                <CustomLegend chartData={chartData} />
              </div>
            </div>
          ) : (
            <NoDataMessage />
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentBifurcation;