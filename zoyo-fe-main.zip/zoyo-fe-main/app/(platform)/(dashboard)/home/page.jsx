"use client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
	ArrowDownRight,
	ArrowUpRight,
	DollarSign,
	FileText,
	Settings,
	ShoppingBag,
	ShoppingCart,
	TrendingDown,
	Wallet,
} from "lucide-react";
import React, { useState } from "react";
import VisitorLineChart from "./_components/lineChart";
import VisitorBarChart from "./_components/barChart";
import VisitorPaymentBifurcation from "./_components/pieChart";
import VisitorCashflow from "./_components/cashflowChart";
import InventoryTable from "./_components/inventoryTable";
import GSTTable from "./_components/gstTable";
import PayableTable from "./_components/payableTable";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@/components/ui/popover";
import { useQuery } from "@tanstack/react-query";
import { getDashboardSummaryData } from "@/actions/dashboard/grt-dashboard-summary";
import { getAllDashboardLineChartData } from "@/actions/dashboard/get-dashboard-linechart-data";
import { toast } from "sonner";
import { getDashboardProfitLossData } from "@/actions/dashboard/get-dashboard-profit-loss-data";

const Icon = () => (
	<svg
		width="28"
		height="27"
		viewBox="0 0 28 27"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
	>
		<path
			d="M15.7207 9.39584C15.0767 9.85494 14.2886 10.125 13.4375 10.125C11.2629 10.125 9.5 8.36212 9.5 6.1875C9.5 4.01288 11.2629 2.25 13.4375 2.25C14.8471 2.25 16.0837 2.99072 16.7793 4.10416M7.25 22.598H10.1866C10.5695 22.598 10.95 22.6436 11.3212 22.7347L14.424 23.4887C15.0973 23.6528 15.7986 23.6687 16.4789 23.5366L19.9096 22.8691C20.8159 22.6926 21.6495 22.2586 22.3029 21.6231L24.7301 19.2619C25.4233 18.5888 25.4233 17.4965 24.7301 16.8222C24.106 16.2151 23.1178 16.1468 22.4118 16.6616L19.5829 18.7255C19.1778 19.0216 18.6849 19.1811 18.1779 19.1811H15.4462L17.1849 19.181C18.165 19.181 18.9588 18.4087 18.9588 17.4554V17.1103C18.9588 16.3187 18.405 15.6285 17.6158 15.4371L14.9322 14.7845C14.4954 14.6785 14.0482 14.625 13.5985 14.625C12.5131 14.625 10.5484 15.5237 10.5484 15.5237L7.25 16.903M23 7.3125C23 9.48712 21.2371 11.25 19.0625 11.25C16.8879 11.25 15.125 9.48712 15.125 7.3125C15.125 5.13788 16.8879 3.375 19.0625 3.375C21.2371 3.375 23 5.13788 23 7.3125ZM2.75 16.425L2.75 22.95C2.75 23.5801 2.75 23.8951 2.87262 24.1357C2.98048 24.3474 3.15258 24.5195 3.36426 24.6274C3.60491 24.75 3.91994 24.75 4.55 24.75H5.45C6.08006 24.75 6.39509 24.75 6.63574 24.6274C6.84742 24.5195 7.01952 24.3474 7.12738 24.1357C7.25 23.8951 7.25 23.5801 7.25 22.95V16.425C7.25 15.7949 7.25 15.4799 7.12738 15.2393C7.01952 15.0276 6.84742 14.8555 6.63574 14.7476C6.39509 14.625 6.08006 14.625 5.45 14.625L4.55 14.625C3.91994 14.625 3.60491 14.625 3.36426 14.7476C3.15258 14.8555 2.98048 15.0276 2.87262 15.2393C2.75 15.4799 2.75 15.7949 2.75 16.425Z"
			stroke="#D92D20"
			strokeWidth="1.6875"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</svg>
);
const DatabaseIcon = ({ width = 28, height = 27, color = "#039855" }) => (
	<svg
		width={width}
		height={height}
		viewBox="0 0 28 27"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
	>
		<path
			d="M15.125 5.625C15.125 6.86764 12.3548 7.875 8.9375 7.875C5.52024 7.875 2.75 6.86764 2.75 5.625M15.125 5.625C15.125 4.38236 12.3548 3.375 8.9375 3.375C5.52024 3.375 2.75 4.38236 2.75 5.625M15.125 5.625V7.3125M2.75 5.625V19.125C2.75 20.3676 5.52024 21.375 8.9375 21.375M8.9375 12.375C8.74789 12.375 8.56027 12.3719 8.375 12.3658C5.22134 12.2625 2.75 11.2987 2.75 10.125M8.9375 16.875C5.52024 16.875 2.75 15.8676 2.75 14.625M25.25 12.9375C25.25 14.1801 22.4798 15.1875 19.0625 15.1875C15.6452 15.1875 12.875 14.1801 12.875 12.9375M25.25 12.9375C25.25 11.6949 22.4798 10.6875 19.0625 10.6875C15.6452 10.6875 12.875 11.6949 12.875 12.9375M25.25 12.9375V21.375C25.25 22.6176 22.4798 23.625 19.0625 23.625C15.6452 23.625 12.875 22.6176 12.875 21.375V12.9375M25.25 17.1562C25.25 18.3989 22.4798 19.4062 19.0625 19.4062C15.6452 19.4062 12.875 18.3989 12.875 17.1562"
			stroke={color}
			strokeWidth="1.6875"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</svg>
);

const DocumentIcon = ({ width = 28, height = 27, color = "#2E5391" }) => (
	<svg
		width={width}
		height={height}
		viewBox="0 0 28 27"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
	>
		<path
			d="M7.25 12.375V16.875M20.75 10.125V14.625M19.625 4.5C22.3798 4.5 23.8698 4.92161 24.6111 5.24862C24.7099 5.29217 24.7592 5.31395 24.9017 5.44992C24.9871 5.53142 25.143 5.77057 25.1831 5.8816C25.25 6.06683 25.25 6.16808 25.25 6.37058V18.4625C25.25 19.4849 25.25 19.9961 25.0967 20.2588C24.9407 20.5261 24.7903 20.6504 24.4984 20.7531C24.2115 20.8541 23.6322 20.7428 22.4737 20.5202C21.6628 20.3644 20.7011 20.25 19.625 20.25C16.25 20.25 12.875 22.5 8.375 22.5C5.6202 22.5 4.13022 22.0784 3.38887 21.7514C3.29014 21.7078 3.24077 21.686 3.0983 21.5501C3.0129 21.4686 2.85701 21.2294 2.8169 21.1184C2.75 20.9332 2.75 20.8319 2.75 20.6294L2.75 8.53746C2.75 7.5151 2.75 7.00391 2.90331 6.74116C3.05926 6.47388 3.20966 6.34963 3.50157 6.24691C3.78853 6.14593 4.36779 6.25723 5.52631 6.47983C6.3372 6.63563 7.29891 6.75 8.375 6.75C11.75 6.75 15.125 4.5 19.625 4.5ZM16.8125 13.5C16.8125 15.0533 15.5533 16.3125 14 16.3125C12.4467 16.3125 11.1875 15.0533 11.1875 13.5C11.1875 11.9467 12.4467 10.6875 14 10.6875C15.5533 10.6875 16.8125 11.9467 16.8125 13.5Z"
			stroke={color}
			strokeWidth="1.6875"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</svg>
);

const RefreshIcon = ({ width = 28, height = 28, color = "#2E5391" }) => (
	<svg
		width={width}
		height={height}
		viewBox="0 0 28 28"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
	>
		<path
			d="M25.2266 13.3181C25.0028 13.3181 24.7882 13.407 24.6299 13.5652C24.4717 13.7235 24.3828 13.9381 24.3828 14.1619C24.3828 16.22 23.7725 18.232 22.629 19.9433C21.4856 21.6546 19.8604 22.9884 17.9589 23.776C16.0574 24.5636 13.965 24.7697 11.9464 24.3682C9.92779 23.9666 8.07358 22.9755 6.61824 21.5202C5.1629 20.0649 4.1718 18.2106 3.77027 16.192C3.36874 14.1734 3.57482 12.0811 4.36245 10.1796C5.15007 8.27807 6.48387 6.65284 8.19517 5.50938C9.90646 4.36593 11.9184 3.75562 13.9766 3.75562C14.2003 3.75562 14.415 3.66672 14.5732 3.50849C14.7314 3.35025 14.8203 3.13564 14.8203 2.91187C14.8203 2.68809 14.7314 2.47348 14.5732 2.31524C14.415 2.15701 14.2003 2.06812 13.9766 2.06812C11.5847 2.06812 9.24645 2.7774 7.25764 4.10628C5.26883 5.43516 3.71875 7.32394 2.8034 9.53379C1.88805 11.7436 1.64856 14.1753 2.1152 16.5212C2.58184 18.8672 3.73365 21.0221 5.425 22.7134C7.11634 24.4048 9.27124 25.5566 11.6172 26.0232C13.9632 26.4899 16.3948 26.2504 18.6046 25.335C20.8145 24.4197 22.7033 22.8696 24.0322 20.8808C25.361 18.892 26.0703 16.5538 26.0703 14.1619C26.0703 13.9381 25.9814 13.7235 25.8232 13.5652C25.665 13.407 25.4503 13.3181 25.2266 13.3181Z"
			fill={color}
			stroke={color}
			strokeWidth="0.289286"
		/>
		<path
			d="M18.8008 8.88104C18.865 9.0348 18.973 9.16622 19.1115 9.25886C19.25 9.35151 19.4127 9.40127 19.5793 9.40192L24.0793 9.40192C24.1901 9.40192 24.2998 9.38009 24.4022 9.33769C24.5046 9.29529 24.5976 9.23314 24.6759 9.15479C24.7543 9.07644 24.8164 8.98342 24.8588 8.88106C24.9012 8.77869 24.923 8.66897 24.923 8.55817C24.923 8.44736 24.9012 8.33765 24.8588 8.23528C24.8164 8.13291 24.7543 8.03989 24.6759 7.96155C24.5976 7.8832 24.5046 7.82105 24.4022 7.77864C24.2998 7.73624 24.1901 7.71442 24.0793 7.71442L21.6155 7.71442L25.8005 3.52942C25.8834 3.45217 25.9499 3.35902 25.996 3.25552C26.0422 3.15202 26.067 3.0403 26.069 2.92701C26.071 2.81371 26.0501 2.70118 26.0077 2.59612C25.9652 2.49106 25.9021 2.39562 25.822 2.3155C25.7418 2.23538 25.6464 2.17222 25.5413 2.12978C25.4363 2.08734 25.3237 2.0665 25.2105 2.0685C25.0972 2.0705 24.9854 2.0953 24.8819 2.14141C24.7784 2.18753 24.6853 2.25402 24.608 2.33692L20.423 6.52192L20.423 4.05817C20.423 3.83439 20.3341 3.61978 20.1759 3.46154C20.0177 3.30331 19.8031 3.21442 19.5793 3.21442C19.3555 3.21442 19.1409 3.30331 18.9827 3.46154C18.8244 3.61978 18.7355 3.83439 18.7355 4.05817L18.7355 8.55817C18.7359 8.66903 18.7581 8.77874 18.8008 8.88104Z"
			fill={color}
			stroke={color}
			strokeWidth="0.289286"
		/>
		<path
			d="M17.1238 11.5995C17.6144 11.5995 17.9674 12.0708 17.8294 12.5416C17.7376 12.8548 17.4502 13.07 17.1238 13.07H10.4416C9.95108 13.07 9.5981 12.5987 9.73608 12.128C9.82789 11.8147 10.1152 11.5995 10.4416 11.5995H17.1238ZM14.888 21.5127C14.4853 21.5127 14.104 21.3318 13.8492 21.02L9.78123 16.0406C9.6716 15.9064 9.60984 15.7395 9.60572 15.5663C9.5953 15.1289 9.94702 14.7687 10.3845 14.7687H11.8939C12.4939 14.7687 13.0052 14.6842 13.4278 14.5152C13.8503 14.3419 14.1736 14.0841 14.3975 13.7419C14.6215 13.3954 14.7335 12.9601 14.7335 12.4362C14.7335 11.6629 14.5011 11.0565 14.0363 10.6171C13.5714 10.1734 12.8573 9.95153 11.8939 9.95153H10.4174C9.94085 9.95153 9.59965 9.49138 9.73807 9.03542C9.82888 8.73627 10.1047 8.53174 10.4174 8.53174H11.8939C12.9249 8.53174 13.77 8.70287 14.4292 9.04515C15.0927 9.38319 15.5828 9.84801 15.8997 10.4396C16.2209 11.0269 16.3815 11.6925 16.3815 12.4362C16.3815 13.108 16.2336 13.7271 15.9378 14.2933C15.6462 14.8553 15.1772 15.3075 14.5307 15.6497C13.8884 15.992 13.039 16.1631 11.9826 16.1631C11.9674 16.1631 11.959 16.1808 11.9687 16.1926L16.2125 21.3907C16.2234 21.404 16.2293 21.4207 16.2293 21.4379C16.2293 21.4792 16.1959 21.5127 16.1546 21.5127H14.888ZM17.1267 8.53174C17.6158 8.53174 17.9678 9.00164 17.8302 9.47103C17.738 9.78539 17.4485 10.0005 17.1209 9.9979L12.1639 9.95902C11.6873 9.95528 11.3482 9.49422 11.4866 9.03809C11.5779 8.73735 11.8552 8.53174 12.1695 8.53174H17.1267Z"
			fill={color}
			stroke={color}
			strokeWidth="0.289286"
		/>
	</svg>
);

const RefreshCounterIcon = ({ width = 28, height = 28, color = "#2E5391" }) => (
	<svg
		width={width}
		height={height}
		viewBox="0 0 28 28"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
	>
		<path
			d="M25.2246 13.3181C25.0008 13.3181 24.7862 13.407 24.628 13.5652C24.4698 13.7235 24.3809 13.9381 24.3809 14.1619C24.3809 16.22 23.7705 18.232 22.6271 19.9433C21.4836 21.6546 19.8584 22.9884 17.9569 23.776C16.0554 24.5636 13.9631 24.7697 11.9445 24.3682C9.92584 23.9666 8.07163 22.9755 6.61628 21.5202C5.16094 20.0649 4.16985 18.2106 3.76832 16.192C3.36679 14.1734 3.57287 12.0811 4.36049 10.1796C5.14812 8.27807 6.48191 6.65284 8.19321 5.50938C9.90451 4.36593 11.9165 3.75562 13.9746 3.75562C14.1984 3.75562 14.413 3.66672 14.5712 3.50849C14.7295 3.35025 14.8184 3.13564 14.8184 2.91187C14.8184 2.68809 14.7295 2.47348 14.5712 2.31524C14.413 2.15701 14.1984 2.06812 13.9746 2.06812C11.5827 2.06812 9.24449 2.7774 7.25569 4.10628C5.26688 5.43516 3.71679 7.32394 2.80145 9.53379C1.8861 11.7436 1.6466 14.1753 2.11324 16.5212C2.57988 18.8672 3.7317 21.0221 5.42304 22.7134C7.11438 24.4048 9.26928 25.5566 11.6152 26.0232C13.9612 26.4899 16.3928 26.2504 18.6027 25.335C20.8125 24.4197 22.7013 22.8696 24.0302 20.8808C25.3591 18.892 26.0684 16.5538 26.0684 14.1619C26.0684 13.9381 25.9795 13.7235 25.8212 13.5652C25.663 13.407 25.4484 13.3181 25.2246 13.3181Z"
			fill={color}
			stroke={color}
			strokeWidth="0.289286"
		/>
		<path
			d="M26.0034 2.58905C25.9392 2.4353 25.8312 2.30387 25.6927 2.21123C25.5542 2.11858 25.3915 2.06882 25.2249 2.06818H20.7249C20.6141 2.06818 20.5044 2.09 20.402 2.1324C20.2996 2.17481 20.2066 2.23696 20.1283 2.3153C20.0499 2.39365 19.9878 2.48667 19.9454 2.58904C19.903 2.69141 19.8812 2.80112 19.8812 2.91193C19.8812 3.02273 19.903 3.13245 19.9454 3.23482C19.9878 3.33718 20.0499 3.4302 20.1283 3.50855C20.2066 3.5869 20.2996 3.64905 20.402 3.69145C20.5044 3.73385 20.6141 3.75568 20.7249 3.75568H23.1887L19.0037 7.94068C18.9208 8.01792 18.8543 8.11107 18.8082 8.21457C18.762 8.31807 18.7372 8.4298 18.7352 8.54309C18.7332 8.65638 18.7541 8.76891 18.7965 8.87397C18.839 8.97904 18.9021 9.07447 18.9822 9.15459C19.0624 9.23472 19.1578 9.29788 19.2629 9.34031C19.3679 9.38275 19.4805 9.40359 19.5937 9.40159C19.707 9.39959 19.8188 9.3748 19.9223 9.32868C20.0258 9.28256 20.1189 9.21607 20.1962 9.13318L24.3812 4.94818V7.41193C24.3812 7.6357 24.47 7.85031 24.6283 8.00855C24.7865 8.16678 25.0011 8.25568 25.2249 8.25568C25.4487 8.25568 25.6633 8.16678 25.8215 8.00855C25.9798 7.85031 26.0687 7.6357 26.0687 7.41193V2.91193C26.0683 2.80106 26.0461 2.69135 26.0034 2.58905Z"
			fill={color}
			stroke={color}
			strokeWidth="0.289286"
		/>
		<path
			d="M17.1206 11.5996C17.6112 11.5996 17.9642 12.0709 17.8262 12.5416C17.7344 12.8549 17.447 13.0701 17.1206 13.0701H10.4385C9.9479 13.0701 9.59492 12.5988 9.73291 12.128C9.82472 11.8148 10.1121 11.5996 10.4385 11.5996H17.1206ZM14.8848 21.5128C14.4822 21.5128 14.1008 21.3319 13.8461 21.0201L9.77806 16.0406C9.66843 15.9065 9.60667 15.7395 9.60254 15.5663C9.59213 15.1289 9.94384 14.7688 10.3813 14.7688H11.8907C12.4908 14.7688 13.002 14.6842 13.4246 14.5152C13.8472 14.342 14.1704 14.0842 14.3944 13.7419C14.6183 13.3954 14.7303 12.9602 14.7303 12.4362C14.7303 11.663 14.4979 11.0566 14.0331 10.6171C13.5683 10.1734 12.8542 9.95159 11.8907 9.95159H10.4142C9.93767 9.95159 9.59648 9.49144 9.73489 9.03548C9.82571 8.73633 10.1015 8.5318 10.4142 8.5318H11.8907C12.9218 8.5318 13.7669 8.70293 14.4261 9.04521C15.0895 9.38325 15.5796 9.84807 15.8966 10.4396C16.2177 11.027 16.3783 11.6925 16.3783 12.4362C16.3783 13.1081 16.2304 13.7271 15.9346 14.2934C15.643 14.8554 15.174 15.3075 14.5275 15.6498C13.8852 15.9921 13.0359 16.1632 11.9795 16.1632C11.9642 16.1632 11.9559 16.1809 11.9655 16.1926L16.2093 21.3907C16.2202 21.4041 16.2262 21.4208 16.2262 21.438C16.2262 21.4793 16.1927 21.5128 16.1514 21.5128H14.8848ZM17.1235 8.5318C17.6126 8.5318 17.9646 9.0017 17.827 9.47109C17.7349 9.78545 17.4453 10.0005 17.1178 9.99796L12.1608 9.95908C11.6841 9.95534 11.345 9.49428 11.4835 9.03815C11.5748 8.73741 11.8521 8.5318 12.1664 8.5318H17.1235Z"
			fill={color}
			stroke={color}
			strokeWidth="0.289286"
		/>
	</svg>
);

const transformMetricsToStats = (data) => {
	
	if (!data) return [
		{
		  title: "Total Sales",
		  value: 0,
		  icon: ShoppingCart,
		  change: "0",
		  trend: "up",
		  subtitle: "Last Month",
		},
		{
		  title: "Total Purchase",
		  value: 0,
		  icon: ShoppingBag,
		  change: "0",
		  trend: "up",
		  subtitle: "Last Month",
		},
		{
		  title: "Receivable",
		  value: 0,
		  icon: RefreshIcon,
		  change: "0",
		  trend: "up",
		  subtitle: "Last Month",
		},
		{
		  title: "Total Payable",
		  value: 0,
		  icon: RefreshCounterIcon,
		  change: "0",
		  trend: "up",
		  subtitle: "Last Month",
		},
	  ];
	
	return [
        {
            title: "Total Sales",
            value: data.sales.amount,
            icon: ShoppingCart,
            change: `${data.sales.change}`,
            trend: parseFloat(data.sales.change) >= 0 ? "up" : "down",
            subtitle: "Last Month",
        },
        {
            title: "Total Purchase",
            value: data.purchase.amount,
            icon: ShoppingBag,
            change: `${data.purchase.change}`,
            trend: parseFloat(data.purchase.change) >= 0 ? "up" : "down",
            subtitle: "Last Month",
        },
        {
            title: "Total Receivable",
            value: data.receivable.amount,
            icon: RefreshIcon,
            change: `${data.receivable.change}`,
            trend: parseFloat(data.receivable.change) >= 0 ? "up" : "down",
            subtitle: "Last Month",
        },
        {
            title: "Total Payable",
            value: data.payable.amount,
            icon: RefreshCounterIcon,
            change: `${data.payable.change}`,
            trend: parseFloat(data.payable.change) >= 0 ? "up" : "down",
            subtitle: "Last Month",
        },
    ];
};




const formatCurrency = (amount) => {
	return new Intl.NumberFormat("en-IN").format(amount);
};

const MetricCard = ({ data }) => (
	<Card className="flex-1 bg-white shadow-sm min-w-0">
		<CardContent className="p-4">
			<div className="flex items-center gap-2 sm:gap-4 justify-center">
				<div className={`p-2 sm:p-3 ${data.bgColor} rounded-lg shrink-0`}>
					<data.icon className={`w-4 h-4 sm:w-6 sm:h-6 ${data.textColor}`} />
				</div>
				<div className="min-w-0 flex-1">
					<p className="text-xs sm:text-sm text-gray-500 truncate text-left">
						{data.label}
					</p>
					<p
						className={`text-lg sm:text-2xl font-semibold ${data.textColor} truncate text-left`}
					>
						₹{formatCurrency(data.amount)}
					</p>
				</div>
			</div>
		</CardContent>
	</Card>
);

// ProfitLossSection Component
const ProfitLossSection = ({ profitLossData }) => {
	const transformedData = {
	  revenue: {
		amount: profitLossData?.revenue || '0',
		icon: DocumentIcon,
		label: "Revenue",
		bgColor: "bg-blue-100",
		textColor: "text-primary",
	  },
	  expense: {
		amount: profitLossData?.expense || '0',
		icon: Icon,
		label: "Expense",
		bgColor: "bg-red-100",
		textColor: "text-red-600",
	  },
	  profit: {
		amount: profitLossData?.profit || '0',
		icon: DatabaseIcon,
		label: "Profit",
		bgColor: "bg-green-100",
		textColor: "text-green-600",
	  },
	};
  
	return (
	  <Card className="w-full h-[313px]">
		<CardHeader className="border-b p-4">
		  <CardTitle className="font-medium">Profit & Loss</CardTitle>
		</CardHeader>
		<CardContent className="p-3 sm:p-6">
		  <div className="h-[222px] flex flex-col overflow-y-auto">
			<div className="flex flex-col lg:flex-row gap-2 sm:gap-4 min-h-fit justify-center">
			  <MetricCard data={transformedData.revenue} />
			  <div className="hidden lg:flex items-center justify-center">
				<span className="text-xl sm:text-2xl font-bold text-gray-400">−</span>
			  </div>
			  <MetricCard data={transformedData.expense} />
			</div>
			<div className="mt-2 sm:mt-4">
			  <MetricCard data={transformedData.profit} />
			</div>
		  </div>
		</CardContent>
	  </Card>
	);
  };

const Homepage = () => {
	const [date, setDate] = useState(new Date());
	const { data:summary } = useQuery({
		queryKey: ["dashboardsummary"],
		queryFn: getDashboardSummaryData,
		onError: (error) => {
			toast.error(error || "Failed to load data. Please try again.");
		},
	});
	
	// Now data will be the actual data object, not wrapped in response
	const stats = transformMetricsToStats(summary?.data?.data);
	
	const { data:profitLoss } = useQuery({
		queryKey: ["profitLoss"],
		queryFn: getDashboardProfitLossData,
		onError: (error) => {
			toast.error(error || "Failed to load data. Please try again.");
		},
	});

	return (
		<div className="bg-slate-100 -m-4 flex flex-col p-2 items-center">
			<div className="flex items-start justify-between w-full max-w-[1338px] p-2">
				<div>
					<p className="text-lg font-medium text-[#40566D]">Welcome {JSON.parse(localStorage.getItem('user'))?.name || 'Guest'}!</p>
				</div>

				<div>
					<div className="flex items-center gap-4">
						<Popover>
							<PopoverTrigger asChild>
								<Button
									variant="outline"
									className={cn(
										"w-[240px] justify-start text-left font-normal",
										!date && "text-muted-foreground",
									)}
									disabled={true}
								>
									<CalendarIcon className="mr-2 h-4 w-4" />
									{date ? format(date, "PPP") : <span>Pick a date</span>}
								</Button>
							</PopoverTrigger>
							<PopoverContent className="w-auto p-0" align="start">
								<Calendar
									mode="single"
									selected={date}
									onSelect={setDate}
									initialFocus
								/>
							</PopoverContent>
						</Popover>

						
					</div>
				</div>
			</div>
			<div className="w-full max-w-[1338px] py-2">
				<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
					{stats.map((stat, index) => (
						<Card key={index} className="p-4 relative overflow-hidden">
							<div className="flex items-center gap-4 justify-center">
								<div className={"p-2 rounded-lg bg-[#F2F5F8]"}>
									<stat.icon className={"w-6 h-6 text-primary"} />
								</div>
								<div>
									<p className="text-sm text-gray-500">{stat.title}</p>
									<div className="flex items-center mt-2">
										<span className={"text-xl font-semibold"}>
										₹{Number(stat.value).toLocaleString()}
										</span>
										<span
											className={`text-sm ml-3  font-medium ${
												stat.trend === "up" ? "text-[#006C3F]" : "text-red-500"
											}`}
										>
											{stat.change} {stat.subtitle}
										</span>
									</div>
								</div>
							</div>
						</Card>
					))}
				</div>
			</div>

			<div className="w-full max-w-[1338px] pb-2">
				<VisitorLineChart />
			</div>

			<div className="w-full max-w-[1338px] pb-2">
				<div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
					<div className="flex justify-center">
						<VisitorBarChart />
					</div>

					<div className="flex justify-center mx-auto w-full max-w-[668px] ">
						
						 <ProfitLossSection profitLossData={profitLoss?.data?.data} />
					</div>
				</div>
			</div>

			<div className="w-full max-w-[1338px] pb-2">
				<div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
					<div className="flex justify-center">
						<VisitorPaymentBifurcation />
					</div>
					<div className="flex justify-center">
						<VisitorCashflow />
					</div>
				</div>
			</div>

			<div className="w-full max-w-[1338px] pb-2">
				<div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
					<div className="flex justify-center">
						<InventoryTable />
					</div>
					<div className="flex justify-center">
						
						<PayableTable />
					</div>
				</div>
			</div>

			<div className="w-full max-w-[1338px] pb-2">
				<div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
					<div className="flex justify-center">
					{/* <GSTTable /> */}
					</div>
					<div></div>
				</div>
			</div>
		</div>
	);
};

export default Homepage;
