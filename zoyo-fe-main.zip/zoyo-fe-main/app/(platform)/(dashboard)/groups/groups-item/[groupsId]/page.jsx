"use client";
import React, { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ChevronDown,
  ChevronDownIcon,
  ChevronsUpDown,
  ChevronUp,
  ListFilter,
  PencilLine,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import CustomTable from "@/components/custom-table/custom-table";
import useDebounce from "@/hooks/use-debounce";
import { getAllItemsGroups } from "@/actions/items/get-all-items";
import { patchtoggleItemStatus } from "@/actions/items/toggle-item-status";
import { useParams } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";

const GroupsItemList = () => {
  const queryClient = useQueryClient();

  const params = useParams();
  const groupsId = params.groupsId;
  const [changePageCount, setChangePageCount] = useState(1);
  const [sortBy, setSortBy] = useState("createdAt");
  const [sortOrder, setSortOrder] = useState("desc");
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [status, setStatus] = useState({
    key: "all",
    heading: "All",
  });
  const [filterBy, setFilterBy] = useState({
    key: "both",
    heading: "All",
  });

  const debouncedSearchValue = useDebounce(searchValue, 500);

  const { data, isLoading, error } = useQuery({
    queryKey: [
      "items",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
      status,
      filterBy,
      groupsId,
    ],
    queryFn: () =>
      getAllItemsGroups(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue,
        status,
        filterBy,
        groupsId
      ),
  });

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const myColumns = [
    {
      id: "select",
      header: ({ table }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedItemId !== null}
            onCheckedChange={(value) => {
              if (!value) {
                setSelectedItemId(null);
                table?.toggleAllPageRowsSelected(false);
              }
            }}
            aria-label="Select item"
          />
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedItemId === row.original.id}
            onCheckedChange={(value) => {
              if (value) {
                setSelectedItemId(row.original.id);
              } else {
                setSelectedItemId(null);
              }
            }}
            aria-label="Select row"
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
    },
    {
      id: "itemName",
      accessorKey: "itemName",
      lable: "Item Name",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("itemName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("itemName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Item Name
              {renderSortIcon("itemName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">{row?.getValue("itemName")}</div>
      ),
    },
    {
      id: "groupName",
      accessorKey: "groupName",
      lable: "Group Name",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-nowrap text-gray-900"
            onClick={() => onSortChange("groupName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("groupName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Group Name
              {renderSortIcon("groupName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">
          {row?.getValue("groupName") || "-"}
        </div>
      ),
    },

    {
      id: "categoryName",
      accessorKey: "categoryName",
      lable: "Category Name",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("categoryName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("categoryName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Category Name
              {renderSortIcon("categoryName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left">{row?.getValue("categoryName") || "-"}</div>
      ),
    },
    {
      id: "isActive",
      accessorKey: "isActive",
      lable: "Status",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-nowrap text-gray-900"
            onClick={() => onSortChange("isActive")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("isActive");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Status
              {renderSortIcon("isActive")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex items-center justify-start">
          <Switch
            checked={row.getValue("isActive")}
            onCheckedChange={() => {
              toggleStatusMutation.mutate(row.original.id);
            }}
            className="data-[state=checked]:"
            aria-label="Toggle status"
            // disabled={toggleStatusMutation.isPending}
          />
          <span className="text-sm font-medium pl-2 text-black w-16 text-left">
            {row.getValue("isActive") ? "Active" : "Inactive"}
          </span>
        </div>
      ),
    },

    {
      id: "purchaseRate",
      accessorKey: "purchaseRate",
      lable: "Last Purchase Rate",
      header: ({ column }) => (
        <div className="flex justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("purchaseRate")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("purchaseRate");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Last Purchase Rate
              {renderSortIcon("purchaseRate")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right capitalize">
          {Number(row?.getValue("purchaseRate") || 0).toFixed(2)}
        </div>
      ),
    },

    {
      id: "salesRate",
      accessorKey: "salesRate",
      lable: "Sales Rate",
      header: ({ column }) => (
        <div className="flex justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("salesRate")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("salesRate");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Sales Rate
              {renderSortIcon("salesRate")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right capitalize">
          {Number(row?.getValue("salesRate") || 0).toFixed(2)}
        </div>
      ),
    },

    {
      id: "availableStock.total",
      // accessorKey: "availableStock",
      accessorFn: (row) => row.availableStock?.total,
      lable: "Available Stock",
      header: ({ column }) => (
        <div className="flex justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("availableStock")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("availableStock");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Available Stock
              {renderSortIcon("availableStock")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right capitalize">
          {Number(row?.getValue("availableStock.total") || 0).toFixed(2)}
        </div>
      ),
    },

    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                onClick={() => handleDelete(userdata)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      },
    },
  ];

  const ChangeStatus = (param) => {
    setStatus(param);
    setSelectedItemId(null);
  };

  const toggleItemStatusMutation = useMutation({
    mutationFn: (id) => patchtoggleItemStatus(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["items"] });

      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(
          data?.data?.message || "Item activate or inactivate successfully"
        );
        setSelectedItemId(null);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed . Error: ${error?.message || error || "Something went wrong"}`
      );
    },
  });

  const handleFilterByChange = (params) => {
    setFilterBy(params);
    setSelectedItemId(null);
  };

  const handleActiveInactiveItem = (id) => {
    toggleItemStatusMutation.mutate(id);
  };

  const otherFields = () => {
    return (
      <>
        <div className=" pt-4 pb-4 flex justify-between ">
          {selectedItemId && (
            <>
              <div className="pr-3">
                {status?.key !== "active" ? (
                  <Button
                    variant="outline"
                    onClick={() => handleActiveInactiveItem(selectedItemId)}
                    className="ml-auto"
                  >
                    Mark as Active
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    onClick={() => handleActiveInactiveItem(selectedItemId)}
                    className="ml-auto"
                  >
                    Mark as Inactive
                  </Button>
                )}
              </div>
            </>
          )}
          <div className="mr-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto">
                  {filterBy?.heading}{" "}
                  <ChevronDownIcon className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  className="ml-auto"
                  onClick={() =>
                    handleFilterByChange({
                      key: "both",
                      heading: "All",
                    })
                  }
                >
                  All
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="ml-auto"
                  onClick={() =>
                    handleFilterByChange({
                      key: "goods",
                      heading: "Goods",
                    })
                  }
                >
                  Goods
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="ml-auto"
                  onClick={() =>
                    handleFilterByChange({
                      key: "service",
                      heading: "Service",
                    })
                  }
                >
                  Service
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </>
    );
  };

  const tableData = data?.data?.data;
  const pagination_data = data?.data?.pagination;

  return (
    <Card className="rounded-md">
      <CustomTable
        data={tableData || []}
        columns={myColumns || []}
        isLoading={isLoading}
        error={error}
        tableHeader="Items"
        tableWidth={"100%"}
        paginationData={pagination_data}
        pageChangeCount={setChangePageCount}
        totalRowCount={setTotalRowCount}
        getSerchValue={setSearchValue}
        serchPlaceholder={"Search"}
        filterFields={otherFields()}
      />
    </Card>
  );
};

export default GroupsItemList;
