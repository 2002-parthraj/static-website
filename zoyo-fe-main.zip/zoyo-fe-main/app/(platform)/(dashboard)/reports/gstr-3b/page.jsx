"use client";
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Gstr3bData from "./Gstr3bData.json";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import { Button } from "@/components/ui/button";
import { ChevronLeft, LoaderCircle, Printer, Upload } from "lucide-react";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useRouter } from "next/navigation";
const Gstr2Report = () => {
  const router = useRouter();

  const generatePDF = false;
  const widthForThreePointTwotable = (column) => {
    if (column === "Place Of Supply") {
      return "";
    } else {
      return "372px";
    }
  };

  return (
    <div className="bg-[#FFFFFF]">
      <div className="flex bg-[#FFFFFF] items-center justify-between border-b px-2 py-2 border-gray-300 h-16">
        <div className="flex items-center space-x-2 pl-1 pr-4">
          <Button
            size="icon"
            className="bg-white hover:bg-inherit  shadow-none border text-black"
            onClick={() => router.push(`/reports`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-left font-medium text-[16px] leading-6 text-[#212121] font-poppins">
            GSTR-3B Summary
          </div>
        </div>
        <div>
          <div className="flex  items-center">
            <div className="">
              <ReportDateSelector
                mode="range"
                //   onDateChange={handleAsOfDateChange}
                className="w-[200px]  "
              />
            </div>
            <div className="w-[16px] flex justify-center h-full ">
              <div className="w-[1px] bg-[#D2D6DB] h-[38px]"></div>
            </div>
            <div className="mr-[8px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={() => handlePrint()}
              >
                {generatePDF ? (
                  <div className="animate-spin">
                    <LoaderCircle />
                  </div>
                ) : (
                  <>
                    <Printer className="h-4 w-4" />
                    <span className="ml-1">Print</span>
                  </>
                )}
              </Button>
            </div>
            <div className="mr-[8px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"

                //onClick={handleExport}
              >
                <Upload className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div>
        <div className="mt-[12px] bg-[#ECF4FF] ">
          <div className="flex items-center">
            <div
              style={{
                backgroundColor: "#2E5391",
                borderBottomRightRadius: "2px",
                borderTopRightRadius: "2px",
                width: "10.62px",
                height: "32px",
              }}
            ></div>
            <div className="ml-[10px]">
              <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                3.1 Details of Outward Supplies and inward supplies liable to
                reverse charge
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className={`rounded-md border w-full overflow-y-auto `}>
                <Table className="border-collapse	">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {Gstr3bData.columns.map((column, index) => (
                        <TableHead key={index} className="border-r p-2 text-sm">
                          <div
                            className={`text-[12px] text-${
                              column === "Nature of Supply" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Gstr3bData.data.map((row, rowIndex) => (
                      <TableRow key={rowIndex} className=" ">
                        <TableCell className="border-r text-left p-2 text-[12px] font-normal text-[#192839]	">
                          {row.natureofSupply}
                        </TableCell>
                        <TableCell className="border-r w-[149px]   p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.taxableValue || "00"}
                        </TableCell>
                        <TableCell className="border-r  p-2 w-[149px]  text-[12px] font-normal text-[#192839] text-right">
                          {row.integratedTax || "00"}
                        </TableCell>
                        <TableCell className=" border-r p-2 w-[149px]  text-[12px] font-normal text-[#192839] text-right">
                          {row.centralTax || "00"}
                        </TableCell>
                        <TableCell className=" border-r p-2 w-[149px]  text-[12px] font-normal text-[#192839] text-right">
                          {row.stateUTTax || "00"}
                        </TableCell>
                        <TableCell className="p-2 border-r w-[149px] text-[12px] font-normal text-[#192839]  text-right">
                          {row.cessTax || "00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3.2  component  */}
      <div>
        <div className="mt-[12px] bg-[#ECF4FF] ">
          <div className="flex items-center">
            <div
              style={{
                backgroundColor: "#2E5391",
                borderBottomRightRadius: "2px",
                borderTopRightRadius: "2px",
                width: "10.62px",
                height: "32px",
              }}
            ></div>
            <div className="ml-[10px]">
              <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                3.2 Of the supplies shown in 3.1(a) above, details of
                inter-state supplies made to unregistered perosns, composition
                taxable persons and UIN holders
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className={`rounded-md border w-full overflow-y-auto `}>
                <Table style={{ width: "100%" }} className=" border-collapse  	">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {Gstr3bData.columns1.map((column, index) => (
                        <TableHead
                          key={index}
                          className={` w-[${widthForThreePointTwotable(
                            column
                          )}] border-r p-2 text-sm`}
                        >
                          <div
                            className={`text-[12px]  text-${
                              column === "Place Of Supply" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>

                  {Gstr3bData.data1.map((row, rowIndex) => (
                    <>
                      <div
                        style={{ width: "246.4%" }}
                        className=" flex justify-center  text-[12px] font-semibold	 text-[#192839] "
                      >
                        <div className="py-[8px]  ">{row?.titel}</div>
                      </div>
                      {row?.titel === "Supplies made to UIN holders" ? (
                        <>
                          <div
                            style={{ width: "246.4%" }}
                            className="border-t flex justify-center  border-gray-300  text-[12px] font-semibold	 text-[#D92D20] "
                          >
                            <div className="py-[8px]  ">
                              We are not tracking supplies made to UIN holders
                            </div>
                          </div>
                        </>
                      ) : null}
                      {row?.EligibleDetails?.map((val, ind) => (
                        <>
                          <TableBody>
                            <TableRow key={ind} className="bg-white ">
                              <TableCell className="border-r border-t border-b text-left border-gray-300 p-2 text-[12px] font-normal text-[#192839]	">
                                {val.placeOfSupply || "00"}
                              </TableCell>
                              <TableCell className="border-r border-t  border-b text-right w-[372px] border-gray-300 p-2 text-[12px] font-normal text-[#192839]	">
                                {val.taxableValue || "00"}
                              </TableCell>
                              <TableCell className="border-r border-t  border-b text-right w-[372px] border-gray-300 p-2 text-[12px] font-normal text-[#192839]	">
                                {val.integratedTax || "00"}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </>
                      ))}
                    </>
                  ))}
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {
        // eligible its component
      }

      <div>
        <div className="mt-[12px] bg-[#ECF4FF]">
          <div className="flex items-center">
            <div
              style={{
                backgroundColor: "#2E5391",
                borderBottomRightRadius: "2px",
                borderTopRightRadius: "2px",
                width: "10.62px",
                height: "32px",
              }}
            ></div>
            <div className="ml-[10px]">
              <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                4 Eligible ITC
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className={`rounded-md border w-full overflow-y-auto `}>
                <Table className="border-collapse">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {Gstr3bData.eligible.map((column, index) => (
                        <TableHead
                          key={index}
                          className={`border-r  p-2 text-sm`}
                        >
                          <div
                            className={`text-[12px] bo  text-${
                              column === "Details" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>

                  {Gstr3bData.EligibleData.map((row, rowIndex) => (
                    <>
                      <TableBody>
                        <TableRow
                          className={`h-[42px] ${
                            rowIndex === 0 ? "" : " border-t"
                          } border-b w-[246.8%] flex justify-center items-center`}
                        >
                          <div className=" flex text-center py-[8px]  text-[12px] font-semibold	 text-[#192839] ">
                            {row?.titel}
                          </div>
                        </TableRow>

                        {row?.EligibleDetails?.map((val, ind) => (
                          <>
                            <TableRow key={ind} className="bg-white  ">
                              <TableCell className="border-r   text-left border-gray-300 p-2 text-[12px] font-normal text-[#192839]	">
                                {val.details || "00"}
                              </TableCell>
                              <TableCell className="border-r w-[186px]  text-right border-gray-300 p-2 text-[12px] font-normal text-[#192839]	">
                                {val.integratedTax || "00"}
                              </TableCell>
                              <TableCell className="border-r w-[186px]  text-right border-gray-300 p-2 text-[12px] font-normal text-[#192839]	">
                                {val.centralTax || "00"}
                              </TableCell>
                              <TableCell className="border-r w-[186px]  text-right border-gray-300 p-2 text-[12px] font-normal text-[#192839]	">
                                {val.stateUTTax || "00 "}
                              </TableCell>
                              <TableCell className=" w-[186px]   text-right border-gray-300 p-2 text-[12px] font-normal text-[#192839]	">
                                {val.cessTax || "00"}
                              </TableCell>
                            </TableRow>
                          </>
                        ))}
                      </TableBody>
                    </>
                  ))}
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {
        //values of exemot
      }

      <div>
        <div className="mt-[12px] bg-[#ECF4FF] ">
          <div className="flex items-center">
            <div
              style={{
                backgroundColor: "#2E5391",
                borderBottomRightRadius: "2px",
                borderTopRightRadius: "2px",
                width: "10.62px",
                height: "32px",
              }}
            ></div>
            <div className="ml-[10px]">
              <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                5 Values of exempt, nil-rated, non-GST inward supplies
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className={`rounded-md border w-full overflow-y-auto `}>
                <Table className="border-collapse	">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {Gstr3bData.Supply.map((column, index) => (
                        <TableHead
                          key={index}
                          className="border-r  p-2 text-sm"
                        >
                          <div
                            className={`text-[12px] text-${
                              column === "Nature of Supply" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Gstr3bData.SupplyData.map((row, rowIndex) => (
                      <TableRow key={rowIndex} className="bg-white ">
                        <TableCell className=" text-left border-r p-2 text-[12px] font-normal text-[#192839]	">
                          {row.natureofSupply}
                        </TableCell>
                        <TableCell className="   p-2  border-r w-[372px] text-[12px] font-normal text-[#192839] text-right">
                          {row.interStateSupplies || "00"}
                        </TableCell>
                        <TableCell className="  p-2  text-[12px] w-[372px]  font-normal text-[#192839] text-right">
                          {row.intraStateSupplies || "00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-5 h-[30px]"></div>
    </div>
  );
};

export default Gstr2Report;
