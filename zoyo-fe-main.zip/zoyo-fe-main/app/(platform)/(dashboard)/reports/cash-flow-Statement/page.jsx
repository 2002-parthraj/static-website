"use client";
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { getBusinessCashFlowReport } from "@/actions/reports/get-business-cash-flow-report";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import { handleDataExport } from "@/lib/exportUtils";
import { Button } from "@/components/ui/button";
import {
  ChevronLeft,
  LoaderCircle,
  Printer,
  Upload,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useRouter } from "next/navigation";
const CashFlowStatementReport = () => {
  const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const router = useRouter();

  const { data, isLoading } = useQuery({
    queryKey: ["InventorySummary", startDate, endDate],
    queryFn: () => getBusinessCashFlowReport(startDate, endDate),
  });

  const { data: organization } = useQuery({
    queryKey: ["organization"],
    queryFn: getCommonInitData,
  });

  const organizationName = organization?.data?.organization?.info?.name;
  const inventorySummary = data?.data?.data;
  const formatDateToISO = (date) => {
    if (!date) return null;
    return format(date, "yyyy-MM-dd");
  };
  const handleExport = () => {
    if (inventorySummary) {
      const result = handleDataExport(
        inventorySummary,
        "cash-flow-Statement-report"
      );
      if (!result.success) {
        // Handle error - maybe show a toast notification
        toast.error(result.error);
      }
    }
  };

  const handleAsOfDateChange = (date) => {
    
    const startDate = format(date.from, "yyyy-MM-dd");
    const endDate = format(date.to, "yyyy-MM-dd");
    setStartDate(startDate);
    setEndDate(endDate);
  };

  const formatDate = (dateString) => {
    return format(new Date(dateString), "yyyy-MM-dd");
  };

  const renderActivitySection = (section) => {
    if (!section) return null;

    return (
      <>
        <tr className="bg-gray-50 border border-gray-300">
          <td className="text-left py-2 px-4 w-2/4 font-medium">
            {section.title}
          </td>
          <td className="text-right py-2 px-4 w-1/4"></td>
          <td className="text-right py-2 px-4 w-1/4 font-medium">
            {section.total?.toFixed(2)}
          </td>
        </tr>
        {section.items.map((item, index) => (
          <tr key={index} className="border-b border-gray-200">
            <td className="py-1 text-left px-8 text-sm">{item.type}</td>
            <td className="text-right py-1 px-4 text-sm">
              {formatDate(item.date)}
            </td>
            <td className="text-right py-1 px-4 text-sm">
              {item.amount?.toFixed(2)}
            </td>
          </tr>
        ))}
        <tr className="h-4">
          <td colSpan="3"></td>
        </tr>
      </>
    );
  };

  const renderSection = (section) => {
    if (!section) return null;
    return (
      <>
        <div>
          <div className="mt-[12px] bg-[#ECF4FF]">
            <div className="flex items-center">
              <div
                style={{
                  backgroundColor: "#2E5391",
                  border: "1px solid #2d518f",
                  borderBottomRightRadius: "2px",
                  borderTopRightRadius: "2px",
                  width: "12px",
                  height: "32px",
                }}
              ></div>
              <div className="ml-[10px]">
                <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                  {section?.title}
                </div>
              </div>
            </div>
          </div>
          <div className="mt-[10px]">
            <div className="">
              <div className="mr-[16px] ml-[16px] ">
                <div className="rounded-md border w-full overflow-y-auto ">
                  <Table className="	">
                    <TableHeader className="bg-[#F2F5F8]">
                      <TableRow>
                        <TableHead className="border-r p-2 text-sm">
                          <div
                            className={`text-[12px] text-"left"
                                 font-semibold text-[#192839]`}
                          >
                            Type
                          </div>
                        </TableHead>
                        <TableHead className="border-r w-[200px] p-2 text-sm">
                          <div
                            className={`text-[12px] text-left
                                font-semibold text-[#192839]`}
                          >
                            Date
                          </div>
                        </TableHead>
                        <TableHead className="w-[200px] border-r p-2 text-sm">
                          <div
                            className={`text-[12px] text-right
                                font-semibold text-[#192839]`}
                          >
                            Amount
                          </div>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {section?.items?.map((row, rowIndex) => (
                        <TableRow key={rowIndex} className="bg-white ">
                          <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                            {row.type || " - "}
                          </TableCell>

                          <TableCell className="border-r w-[200px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                            {formatDateToISO(row.date) || "-"}
                          </TableCell>
                          <TableCell className="border-r w-[200px] border-gray-300 p-2   text-[12px] font-normal text-[#192839] text-right">
                            {row.amount || "00"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  <div
                    style={{
                      display: section?.items?.length > 0 ? "none " : "flex",
                    }}
                  >
                    <div className="flex flex-col w-full items-center justify-center p-4">
                      {" "}
                      <div className="rounded-full h-16  w-full bg-slate-50 text-center flex items-center justify-center">
                        <Users className="text-blue-800 font-bold" />
                      </div>
                      <p className="text-gray-500 text-sm">No Data Added Yet</p>
                    </div>
                  </div>
                  <div className="flex border-t justify-between">
                    <div
                      className={`text-[12px] 
                                 font-semibold p-2 text-[#192839]`}
                    >
                      Total
                    </div>
                    <div
                      className={`text-[12px] p-2
                        font-semibold text-[#192839]`}
                    >
                      {section.total?.toFixed(2)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };
  const generatePDF = false;
  if (isLoading) {
    return <div className="p-4">Loading...</div>;
  }

  const sectionData = inventorySummary?.sections;

  return (
    <>
      <div className="bg-[#FFFFFF]">
        <div className="flex items-center justify-between border-b px-2 py-2 border-gray-300 h-16">
          <div className="flex items-center space-x-2 pl-1 pr-4">
            <Button
              size="icon"
              className="bg-white hover:bg-inherit  shadow-none border text-black"
              onClick={() => router.push(`/reports`)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="text-left font-medium text-[16px] leading-6 text-[#212121] font-poppins">
              Cash Flow Statement
            </div>
          </div>
          <div>
            <div className="flex  items-center">
              <div className="">
                <ReportDateSelector
                  mode="range"
                   onDateChange={handleAsOfDateChange}
                  className="w-[200px]"
                />
              </div>
              <div className="w-[16px] flex justify-center h-full ">
                <div className="w-[1px] bg-[#D2D6DB] h-[38px]"></div>
              </div>
              <div className="mr-[8px]">
                <Button
                  style={{ border: "1px solid #d3d6db" }}
                  variant="outline"
                  onClick={() => handlePrint()}
                >
                  {generatePDF ? (
                    <div className="animate-spin">
                      <LoaderCircle />
                    </div>
                  ) : (
                    <>
                      <Printer className="h-4 w-4" />
                      <span className="ml-1">Print</span>
                    </>
                  )}
                </Button>
              </div>
              <div className="mr-[10px]">
                <Button
                  style={{ border: "1px solid #d3d6db" }}
                  variant="outline"
                  onClick={handleExport}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div className="mt-[12px] bg-[#ECF4FF]">
            <div className="flex items-center">
              <div
                style={{
                  backgroundColor: "#2E5391",
                  border: "1px solid #2d518f",
                  borderBottomRightRadius: "2px",
                  borderTopRightRadius: "2px",
                  width: "12px",
                  height: "32px",
                }}
              ></div>
              <div className="ml-[10px] w-[97%]">
                <div className="flex justify-between ">
                  <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                    Opening Balance
                  </div>
                  <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                    {inventorySummary?.openingBalance?.toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          {renderSection(inventorySummary?.sections?.operatingActivities)}
          {renderSection(inventorySummary?.sections?.investingActivities)}
          {renderSection(inventorySummary?.sections?.financingActivities)}
        </div>
        <div>
          <div>
            <div className="mt-[12px] bg-[#ECF4FF]">
              <div className="flex items-center">
                <div
                  style={{
                    backgroundColor: "#2E5391",
                    border: "1px solid #2d518f",
                    borderBottomRightRadius: "2px",
                    borderTopRightRadius: "2px",
                    width: "12px",
                    height: "32px",
                  }}
                ></div>
                <div className="ml-[10px] w-[97%]">
                  <div className="flex justify-between ">
                    <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                      Net Cash Flow
                    </div>
                    <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                      {inventorySummary?.netCashFlow?.toFixed(2)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div>
            <div className="mt-[12px] bg-[#ECF4FF]">
              <div className="flex items-center">
                <div
                  style={{
                    backgroundColor: "#2E5391",
                    border: "1px solid #2d518f",
                    borderBottomRightRadius: "2px",
                    borderTopRightRadius: "2px",
                    width: "12px",
                    height: "32px",
                  }}
                ></div>
                <div className="ml-[10px] w-[97%]">
                  <div className="flex justify-between ">
                    <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                      Closing Balance
                    </div>
                    <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                      {inventorySummary?.closingBalance?.toFixed(2)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-10 h-2"></div>
      </div>
    </>
  );
};

export default CashFlowStatementReport;
