"use client";
import React, { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import salesByItemData from "./salesByItemData.json";
import { format } from "date-fns";
import { getSalesItemsReport } from "@/actions/reports/get-sales-by-items-report";
import { useQuery } from "@tanstack/react-query";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import { handleDataExport } from "@/lib/exportUtils";
import { Button } from "@/components/ui/button";
import { LoaderCircle, Printer, Upload } from "lucide-react";
import { toast } from "sonner";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Columns } from "lucide-react";
import CustomTableForReports from "@/components/custom-table/custom-table-for-reports";

const SalesByItemReport = () => {
  const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [generatePDF, setGeneratePDF] = useState(false);
  const [chunkedlineItems, setChunkedLineItems] = useState([]);
  const [lineItemData, setLineItemData] = useState(null);
  const { data, isLoading, error } = useQuery({
    queryKey: ["InventorySummary", startDate, endDate],
    queryFn: () => getSalesItemsReport(startDate, endDate),
  });
  const [columnVisibility, setColumnVisibility] = useState({});

  const { data: organization } = useQuery({
    queryKey: ["organization"],
    queryFn: getCommonInitData,
    onError: (error) => {
      toast.error(error || "Failed to load state list. Please try again.");
    },
  });
  const organizationName = organization?.data?.organization?.info?.name;

  const handleAsOfDateChange = (date) => {
    const startDate = format(date.from, "yyyy-MM-dd");
    const endDate = format(date.to, "yyyy-MM-dd");

    setStartDate(startDate);
    setEndDate(endDate);
  };
  const inventorySummary = data?.data?.data;
  const inventorySummaryTotal = data?.data?.meta?.totals;

  const handleExport = () => {
    if (inventorySummary) {
      const result = handleDataExport(inventorySummary, "sales-by-item-report");
      if (!result.success) {
        // Handle error - maybe show a toast notification
        toast.error(result.error);
      }
    }
  };

  const ITEMS_PER_PAGE = 40;

  const chunkArray = (array, size) => {
    const chunked = [];
    for (let i = 0; i < array.length; i += size) {
      chunked.push(array.slice(i, i + size));
    }
    return chunked;
  };

  useEffect(() => {
    if (lineItemData && lineItemData.length > 0) {
      // Create chunks of line items, with 5 items per chunk
      const chunks = chunkArray(lineItemData, ITEMS_PER_PAGE);
      setChunkedLineItems(chunks);
    }
  }, [lineItemData]);

  const TableData = data?.data?.data;

  useEffect(() => {
    if (TableData?.length > 0) {
      setLineItemData(TableData);
    }
  }, [TableData]);

  const maxLengthPartyName = (TableData, maxLength = 30) => {
    return TableData?.length > maxLength
      ? TableData.slice(0, maxLength) + "..."
      : TableData;
  };

  const renderStatement = (TableData, index) => {
    const pageCount = index;
    const currentPageCount = pageCount + 1;
    return (
      <>
        <div
          style={{
            width: "210mm", // A4 width
            minHeight: "297mm", // A4 height
            // padding: "10mm", // Add some padding
            boxSizing: "border-box",
            backgroundColor: "#ffffff",
          }}
          className="p-4"
        >
          <div className="">
            <div className=" text-center mb-4">
              <h1 className="text-xl font-bold">{organizationName}</h1>
              <p className="font-bold mt-2">Sales By Item</p>
              <div className="">
                <span className="mr-1">From:</span>
                <span className="mr-2">{startDate}</span>
                <span className="mr-1">to:</span>
                <span>{endDate}</span>
              </div>
            </div>

            {/* After compelition of code use print-only hidden in div classname*/}
            <div className=" ">
              <table className="w-[100%] border-collapse">
                <thead>
                  <tr className="border-t-2 border-b-2 border-black ">
                    <th className="text-left">
                      <div className="mb-4 text-[15px]">Item Name</div>
                    </th>
                    <th className="text-left">
                      <div className="mb-4 text-[15px] ">Item Unit</div>
                    </th>
                    <th className="text-left">
                      <div className="mb-4 text-[15px] ">Item Type</div>
                    </th>
                    {/* <th>
                      <div className="mb-4 text-[15px] "> Category Name</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">Group Name</div>
                    </th> */}
                    <th>
                      <div className="mb-4 text-[15px] ">HSN</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">SAC</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">Quantity</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">Amount</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">Invoice Count</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">CGST</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">SGST</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">IGST</div>
                    </th>
                    <th>
                      <div className="mb-4 text-[15px] ">taxTotal</div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {TableData?.map((data, index) => (
                    <tr key={index}>
                      <td className=" text-left">
                        {maxLengthPartyName(data?.itemName)}
                      </td>
                      <td className="text-left">{data?.itemUnit}</td>
                      <td className="text-left">{data?.itemType}</td>
                      {/* <td>{data?.categoryName}</td>
                      <td>{data?.groupName}</td> */}
                      <td className="text-right">{data?.hsn}</td>
                      <td className="text-right">{data?.sac}</td>
                      <td className="text-right">{data?.quantity}</td>
                      <td className="text-right">{data?.amount}</td>
                      <td className="text-right">{data?.invoiceCount}</td>
                      <td className="text-right">{data?.cgst}</td>
                      <td className="text-right">{data?.sgst}</td>
                      <td className="text-right">{data?.igst}</td>
                      <td className="text-right">{data?.totalTax}</td>
                    </tr>
                  ))}
                  <div className="pb-2"></div>
                  {chunkedlineItems?.length === index + 1 ? (
                    <>
                      <tr className="text-left   border-t-2 border-black">
                        {/* <td></td> */}
                        <td className="text-left font-bold">
                          <div className="mb-3"></div>
                        </td>
                        <td className="font-bold mb-3"></td>
                        <td></td>
                        <td className=" text-right ">
                          {/* <div className="mb-3">
                            {inventorySummaryTotal?.amount.toFixed(2)}
                          </div> */}
                        </td>
                        <td></td>
                        <td className="text-right">
                          <div className=" mb-3"></div>
                        </td>
                        <td className="text-right ">
                          <div className=" mb-3">
                            {inventorySummaryTotal?.amount?.toFixed(2)}
                          </div>
                        </td>
                        <td className="text-right">
                          <div className="mb-3">
                            {inventorySummaryTotal?.invoiceCount}
                          </div>
                        </td>
                        <td className="text-right ">
                          <div className=" mb-3">
                            {inventorySummaryTotal?.cgst?.toFixed(2)}
                          </div>
                        </td>
                        <td className="text-right ">
                          <div className=" mb-3">
                            {inventorySummaryTotal?.sgst?.toFixed(2)}
                          </div>
                        </td>
                        <td className="text-right ">
                          <div className=" mb-3">
                            {inventorySummaryTotal?.igst?.toFixed(2)}
                          </div>
                        </td>
                        <td className="text-right">
                          <div className="mb-3">
                            {inventorySummaryTotal?.totalTax?.toFixed(2)}
                          </div>
                        </td>
                      </tr>
                    </>
                  ) : (
                    ""
                  )}
                </tbody>
              </table>
            </div>
          </div>
          <div className="text-right">
            <span className="ml-[5px] text-xs">
              Page {currentPageCount} of {chunkedlineItems.length}
            </span>
          </div>
        </div>
      </>
    );
  };

  const handlePrint = async () => {
    if (generatePDF) return;
    try {
      setGeneratePDF(true);

      const renderTemplate = (lineItems, i) => (
        <div
          style={{
            width: "210mm",
            minHeight: "297mm",
            backgroundColor: "#ffffff",
          }}
        >
          {renderStatement(lineItems, i)}
        </div>
      );

      // Create container for rendering
      const templateId = "statement-template";
      const container = document.createElement("div");
      container.id = templateId;
      container.style.position = "absolute";
      container.style.left = "-9999px";
      container.style.top = "0";
      container.style.width = "210mm"; // A4 width
      container.style.backgroundColor = "#ffffff";
      document.body.appendChild(container);

      // Initialize PDF with A4 size
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
        compress: true,
      });

      // PDF dimensions
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      // Render template using React
      const { createRoot } = await import("react-dom/client");
      const root = createRoot(container);

      // Process each chunk/page
      for (let i = 0; i < chunkedlineItems.length; i++) {
        // Render current page
        await new Promise((resolve) => {
          root.render(
            <div id={templateId}>{renderTemplate(chunkedlineItems[i], i)}</div>
          );
          setTimeout(resolve, 500); // Wait for rendering
        });

        // HTML2Canvas options
        const options = {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
          width: 793, // A4 width in pixels (210mm at 96 DPI)
          height: 1122, // A4 height in pixels (297mm at 96 DPI)
          onclone: (clonedDoc) => {
            const notifications =
              clonedDoc.getElementsByClassName("notification");
            Array.from(notifications).forEach((notification) =>
              notification.remove()
            );
          },
        };

        try {
          // Generate canvas for current page
          const canvas = await html2canvas(container.firstChild, options);
          const imgData = canvas.toDataURL("image/jpeg", 1.0);

          // Calculate scaling to fit A4
          const imgWidth = canvas.width;
          const imgHeight = canvas.height;
          const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);

          // Center image on page
          const xOffset = (pdfWidth - imgWidth * ratio) / 2;
          const yOffset = 0;

          // Add new page if not first page
          if (i > 0) {
            pdf.addPage();
          }

          // Add image to PDF
          pdf.addImage(
            imgData,
            "JPEG",
            xOffset,
            yOffset,
            imgWidth * ratio,
            imgHeight * ratio,
            undefined,
            "FAST"
          );

          canvas.remove();
        } catch (error) {
          console.error(`Error generating page ${i + 1}:`, error);
          throw error;
        }
      }

      // Save the complete PDF
      await pdf.save("Sales by Item.pdf", { returnPromise: true });

      // Cleanup
      root.unmount();
      document.body.removeChild(container);
    } catch (error) {
      console.error("PDF generation error:", error);
      toast.error("Failed to generate PDF. Please try again.");
    } finally {
      setGeneratePDF(false);
    }
  };

  const handleColumnVisibilityChange = (columnId, isVisible) => {
    setColumnVisibility((prev) => ({
      ...prev,
      [columnId]: isVisible,
    }));
  };
  const myColumns = [
    {
      id: "itemName",
      accessorKey: "itemName",
      lable: "Item Name",
      header: ({ column }) => (
        <div className="flex  justify-start">
          <div
            className="bg-inherit hover:bg-inherit  w-[130px] font-semibold text-center  text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Item Name
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap text-[12px] text-[#212121] font-normal	 ">
          {row?.getValue("itemName")}
        </div>
      ),
    },

    {
      id: "itemUnit",
      accessorKey: "itemUnit",
      lable: "Item Unit",
      header: ({ column }) => (
        <div className="flex  justify-start">
          <div
            className="bg-inherit hover:bg-inherit  w-[130px] font-semibold text-center  text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Item Unit
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap text-[12px] text-[#212121] font-normal	 ">
          {row?.getValue("itemUnit")}
        </div>
      ),
    },

    {
      id: "itemType",
      accessorKey: "itemType",
      lable: "Item Type",
      header: ({ column }) => (
        <div className="flex  justify-start">
          <div
            className="bg-inherit hover:bg-inherit  w-[130px] font-semibold text-center  text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Item Type
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap text-[12px] text-[#212121] font-normal	 ">
          {row?.getValue("itemType")}
        </div>
      ),
    },

    {
      id: "categoryName",
      accessorKey: "categoryName",
      lable: "Category Name",
      header: ({ column }) => (
        <div className="flex  justify-start">
          <div
            className="bg-inherit hover:bg-inherit  w-[130px] font-semibold text-center  text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Category Name
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap text-[12px] text-[#212121] font-normal	 ">
          {row?.getValue("categoryName")}
        </div>
      ),
    },

    {
      id: "groupName",
      accessorKey: "groupName",
      lable: "Group Name",
      header: ({ column }) => (
        <div className="flex  justify-start">
          <div
            className="bg-inherit hover:bg-inherit  w-[130px] font-semibold text-center  text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Group Name
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap text-[12px] text-[#212121] font-normal	 ">
          {row?.getValue("groupName")}
        </div>
      ),
    },

    {
      id: "hsn",
      accessorKey: "hsn",
      lable: "HSN/SAC",
      header: ({ column }) => (
        <div className="flex  justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold   text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              HSN/SAC
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right text-[12px] text-[#212121] font-normal 	">
          {row?.getValue("hsn") || row?.getValue("sac")}{" "}
        </div>
      ),
    },

    {
      id: "quantity",
      accessorKey: "quantity",
      lable: "Quantity",
      header: ({ column }) => (
        <div className="flex  justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold   text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Quantity
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right text-[12px] text-[#212121] font-normal 	">
          {row?.getValue("quantity")}{" "}
        </div>
      ),
    },

    {
      id: "amount",
      accessorKey: "amount",
      lable: "Amount",
      header: ({ column }) => (
        <div className="flex  justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center  text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Amount
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right text-[12px] text-[#212121] font-normal	">
          {row?.getValue("amount")}
        </div>
      ),
    },

    {
      id: "invoiceCount",
      accessorKey: "invoiceCount",
      lable: "Invoice Count",
      header: ({ column }) => (
        <div className="flex  justify-end w-[100px]">
          <div
            className="bg-inherit hover:bg-inherit font-semibold   text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Invoice Count
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right text-[12px] text-[#212121] font-normal 	">
          {row?.getValue("invoiceCount")}
        </div>
      ),
    },

    {
      id: "cgst",
      accessorKey: "cgst",
      lable: "CGST ",
      header: ({ column }) => (
        <div className="flex  justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold   w-[80px] text-gray-900"
            tabIndex={0}
            role="button"
          >
            <div className="flex items-center justify-end  text-right  text-[12px]  text-[#192839] font-semibold">
              CGST
            </div>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right text-[12px] text-[#212121] font-normal	">
          {row?.getValue("cgst")}
        </div>
      ),
    },

    {
      id: "sgst",
      accessorKey: "sgst",
      lable: "SGST ",
      header: ({ column }) => (
        <div className="flex  justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold   w-[80px] text-gray-900"
            tabIndex={0}
            role="button"
          >
            <div className="flex items-center justify-end  text-right  text-[12px]  text-[#192839] font-semibold">
              SGST
            </div>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right text-[12px] text-[#212121] font-normal	">
          {row?.getValue("sgst") || "0"}
        </div>
      ),
    },

    {
      id: "igst",
      accessorKey: "igst",
      lable: "IGST ",
      header: ({ column }) => (
        <div className="flex  justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold   w-[80px] text-gray-900"
            tabIndex={0}
            role="button"
          >
            <div className="flex items-center justify-end  text-right  text-[12px]  text-[#192839] font-semibold">
              IGST
            </div>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right text-[12px] text-[#212121] font-normal	">
          {row?.getValue("igst") || "0"}
        </div>
      ),
    },

    {
      id: "totalTax",
      accessorKey: "totalTax",
      lable: "Total Tax",
      header: ({ column }) => (
        <div className="flex  justify-end w-[80px]">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-right  text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center   text-[12px]  text-[#192839] font-semibold">
              Total Tax
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right text-[12px] text-[#212121] font-normal	">
          {row?.getValue("totalTax")}
        </div>
      ),
    },
  ];
  const tableData = inventorySummary;

  const otherFilterFields = () => {
    return (
      <div className="w-[100%] pt-4 pb-4 flex justify-between">
        <div className="flex items-center">
          <div className="">
            <ReportDateSelector
              mode="range"
              onDateChange={handleAsOfDateChange}
              className="w-[200px]"
            />
          </div>
          <div className="w-[16px] h-full flex justify-center">
            <div className=" border-r h-full "></div>
            <div className=""></div>
          </div>
          <div className="mr-[8px]">
            <DropdownMenu className="">
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  className="ml-auto  border-[#2d518f] text-[#2d518f]"
                >
                  <Columns className="mr-2 h-4 w-4" />
                  Manage Columns
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {myColumns.map((column) => (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    className="capitalize"
                    checked={columnVisibility[column.id] !== false}
                    onCheckedChange={(checked) =>
                      handleColumnVisibilityChange(column.id, checked)
                    }
                  >
                    {column.label || column.id}
                  </DropdownMenuCheckboxItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="mr-[8px]">
            <Button variant="outline" onClick={handlePrint}>
              {generatePDF ? (
                <div className="animate-spin">
                  <LoaderCircle />
                </div>
              ) : (
                <>
                  <Printer className="h-4 w-4" />
                  <span className="ml-1">Print</span>
                </>
              )}
            </Button>
          </div>
          <div>
            <Button variant="outline" onClick={handleExport}>
              <Upload className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-[#FFFFFF]">
      <CustomTableForReports
        // data={tableData || []}

        data={tableData || []}
        columns={myColumns || []}
        isLoading={isLoading}
        error={error}
        tableHeader="Sales by Items"
        tableWidth={"100%"}
        // filterFields={otherFilterFields()}

        headerContent={otherFilterFields()}
        module="Sales by Items"
        columnVisibility={columnVisibility}
        onColumnVisibilityChange={setColumnVisibility}
        backPath="/reports"
      />
    </div>
  );
};

export default SalesByItemReport;
