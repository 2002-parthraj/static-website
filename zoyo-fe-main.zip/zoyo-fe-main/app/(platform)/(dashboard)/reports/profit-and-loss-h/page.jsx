"use client";
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { getBusinessProfitLossReport } from "@/actions/reports/get-business-profit-loss-report";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import { handleDataExport } from "@/lib/exportUtils";
import { Button } from "@/components/ui/button";
import {
  ChevronLeft,
  LoaderCircle,
  Printer,
  Upload,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

const ProfitAndLossReportH = () => {
  const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));

  const { data, isLoading } = useQuery({
    queryKey: ["InventorySummary", startDate, endDate],
    queryFn: () => getBusinessProfitLossReport(startDate, endDate),
  });
  const router = useRouter();

  const { data: organization } = useQuery({
    queryKey: ["organization"],
    queryFn: getCommonInitData,
  });

  const inventorySummary = data?.data?.data;

  const handleExport = () => {
    if (inventorySummary) {
      const result = handleDataExport(
        inventorySummary,
        "profit-and-loss-report"
      );
      if (!result.success) {
        toast.error(result.error);
      }
    }
  };

  const handleAsOfDateChange = (date) => {
    const startDate = format(date.from, "yyyy-MM-dd");
    const endDate = format(date.to, "yyyy-MM-dd");
    setStartDate(startDate);
    setEndDate(endDate);
  };
  const BlankTableSection = ({ rowCount }) => {
    // Function to generate empty rows
    const generateEmptyRows = (count) => {
      return Array.from({ length: count }).map((_, index) => (
        <TableRow key={`empty-${index}`} className="hover:bg-gray-50">
          <TableCell className="p-2 text-xs font-normal text-slate-800 text-left">
            &nbsp;
          </TableCell>
          <TableCell className=" p-2  text-[12px] font-normal text-[#192839] text-left">
            &nbsp;
          </TableCell>
          <TableCell className="p-2 text-xs font-normal text-slate-800 text-right">
            &nbsp;
          </TableCell>
        </TableRow>
      ));
    };

    return (
      <React.Fragment>
        <TableRow className="bg-slate-50 border-y">
          <TableCell colSpan={2}>
            <div className="text-[12px] font-semibold  text-[#192839]">
              &nbsp;
            </div>
          </TableCell>
          <TableCell className="py-3"></TableCell>
        </TableRow>
        {generateEmptyRows(rowCount)}

        <TableRow className="border-t  font-medium">
          <TableCell
            colSpan={2}
            className="text-[12px] border-b font-semibold text-left   text-[#192839]"
          >
            &nbsp;
          </TableCell>
          <TableCell className="text-[12px] font-semibold  text-[#192839]">
            &nbsp;
          </TableCell>
        </TableRow>
      </React.Fragment>
    );
  };

  const renderSection = (section, indent = 4) => {
    const sectionLength = section?.sections?.length;

    if (!section || !section.sections) return null;

    if (sectionLength === 0) {
      return (
        <>
          <div className="w-full">
            <div className="flex flex-col items-center justify-end w-full h-32 p-4">
              <div className="rounded-full h-16 w-16 bg-slate-50 text-center flex items-center justify-center">
                <Users className="text-blue-800 font-bold" />
              </div>
              <p className="text-gray-500 text-sm">No Data Added Yet</p>
            </div>
          </div>
        </>
      );
    }

    return section.sections.map((sectionData, index, sections) => (
      <React.Fragment key={index}>
        <TableRow className="bg-slate-50 border-y">
          <TableCell colSpan={2}>
            <div className="text-[12px] font-semibold  text-[#192839]">
              {sectionData.name}
            </div>
          </TableCell>
          <TableCell className="py-3"></TableCell>
        </TableRow>
        {sectionData.items.map((item) => (
          <TableRow key={item.accountId} className="hover:bg-gray-50">
            <TableCell className=" p-2  text-[12px] font-normal text-[#192839] text-left">
              {item.accountName}
            </TableCell>
            <TableCell></TableCell>
            <TableCell className="p-2  text-[12px] font-normal text-[#192839] text-right">
              {item.amount.toFixed(2)}
            </TableCell>
          </TableRow>
        ))}
        {padTable(maximumRowCount, sectionData.items?.length)}
        <TableRow className="border-t  font-medium">
          <TableCell
            colSpan={2}
            className="text-[12px] border-b font-semibold text-left   text-[#192839]"
          >
            Total {sectionData.name}
          </TableCell>
          <TableCell className="text-[12px] font-semibold  text-[#192839]">
            {sectionData.total.toFixed(2)}
          </TableCell>
        </TableRow>
      </React.Fragment>
    ));
  };

  function getMaxSectionsCount(data) {
    const leftSections = data?.left?.sections?.length || 0;
    const rightSections = data?.right?.sections?.length || 0;

    return Math.max(leftSections, rightSections);
  }

  const maxSections = getMaxSectionsCount(inventorySummary);

  function findMaxArrayLength(obj) {
    let maxLength = 0;

    function traverse(current) {
      if (Array.isArray(current)) {
        maxLength = Math.max(maxLength, current.length);

        current.forEach((item) => {
          if (typeof item === "object" && item !== null) {
            traverse(item);
          }
        });
      } else if (typeof current === "object" && current !== null) {
        Object.values(current).forEach((value) => {
          if (typeof value === "object" && value !== null) {
            traverse(value);
          }
        });
      }
    }

    traverse(obj);
    return maxLength;
  }

  const maximumRowCount = findMaxArrayLength(inventorySummary);

  const padTable = (maximumRowCount, currentRows) => {
    const emptyRows = maximumRowCount - currentRows;

    return Array.from({ length: Math.max(0, emptyRows) }, (_, i) => (
      <TableRow key={`empty-${i}`}>
        <TableCell className=" p-2  text-[12px] font-normal text-[#192839] text-left">
          &nbsp;
        </TableCell>
        <TableCell className=" p-2  text-[12px] font-normal text-[#192839] text-left">
          &nbsp;
        </TableCell>
        <TableCell className=" p-2  text-[12px] font-normal text-[#192839] text-left">
          &nbsp;
        </TableCell>
      </TableRow>
    ));
  };

  const renderTable = (data, title, isRightSide = false) => {
    if (!data) return null;

    const curruntLength = data?.sections?.length;

    const addOnSectioncount = maxSections - curruntLength;

    return (
      <div
        className={`border  ${
          isRightSide ? "rounded-r-md" : "rounded-l-md"
        }  w-full overflow-y-auto`}
      >
        <Table className="border-collapse">
          <TableHeader className="bg-[#F2F5F8]">
            <TableRow className=" border-b ">
              <TableCell colSpan={2} className="">
                <div
                  className={`text-[12px] text-left font-semibold text-[#192839]`}
                >
                  {title}
                </div>
              </TableCell>
              <TableCell>
                <div className="text-[12px] text-right font-semibold text-[#192839]">
                  {format(new Date(startDate), "dd/MM/yyyy")}
                </div>
              </TableCell>
            </TableRow>
          </TableHeader>
          <TableBody>
            {renderSection(data)}

            {/* {
              // Array.from({ length: count }).map((_, index) => ())}
              Array.from({ length: addOnSectioncount })?.map((_, ind) => (
                <>{addOnSectioncount > 0 ? BlankTableSection(maximumRowCount) : null}</>
              ))
            }
             */}
            {addOnSectioncount > 0 &&
              Array.from({ length: addOnSectioncount }).map((_, index) => (
                <React.Fragment key={`blank-section-${index}`}>
                  <BlankTableSection rowCount={maximumRowCount} />
                </React.Fragment>
              ))}
          </TableBody>
          <TableFooter>
            <TableRow className="border-t  bg-slate-50">
              <TableCell
                colSpan={2}
                className="text-[12px] font-semibold  text-[#192839] text-left"
              >
                {isRightSide ? "Total" : "Net Profit"}
              </TableCell>
              <TableCell className="text-[12px] font-semibold  text-[#192839] text-right">
                {isRightSide
                  ? inventorySummary?.total.toFixed(2)
                  : inventorySummary?.netProfit.toFixed(2)}
              </TableCell>
            </TableRow>
          </TableFooter>
        </Table>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-4">
        <Card className="rounded-none shadow-lg">
          <CardContent className="flex items-center justify-center h-64">
            <div className="text-lg">Loading...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const generatePDF = false;

  return (
    <div className="bg-white">
      <div className="flex items-center justify-between border-b px-4 py-3 border-gray-200">
        <div className="flex items-center space-x-3">
          <Button
            size="icon"
            className="bg-white hover:bg-gray-50 shadow-none border text-gray-700"
            onClick={() => router.push(`/reports`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-lg font-medium text-gray-900">Profit and Loss</h1>
        </div>
        <div className="flex items-center space-x-4">
          <ReportDateSelector
            mode="range"
            onDateChange={handleAsOfDateChange}
            className="w-64"
          />
          <div className="h-8 w-px bg-gray-200" />
          <Button
            variant="outline"
            onClick={() => handlePrint()}
            className="border-gray-200"
          >
            {generatePDF ? (
              <LoaderCircle className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <Printer className="h-4 w-4 mr-2" />
                Print
              </>
            )}
          </Button>
          <Button
            variant="outline"
            onClick={handleExport}
            className="border-gray-200"
          >
            <Upload className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="p-4">
        <div className="w-full overflow-x-auto">
          <div className="flex min-w-[1000px]">
            <div className="flex-1">
              {renderTable(inventorySummary?.left, "Particulars", false)}
            </div>
            <div className="flex-1">
              {renderTable(inventorySummary?.right, "Particulars", true)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfitAndLossReportH;
