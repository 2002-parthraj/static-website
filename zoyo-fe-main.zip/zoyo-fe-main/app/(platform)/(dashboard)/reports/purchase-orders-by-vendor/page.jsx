import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import purchaseOrdersByVendorData from "./purchaseOrdersByVendorData.json";

const PurchaseOrdersByVendorReport = () => {
	return (
		<div className="container mx-auto p-4 ">
			<Card className="rounded-none shadow-lg mx-auto w-[100%] lg:w-[72%]">
				<CardHeader className="p-3">
					<CardTitle className="text-xl font-bold">
						Purchase Orders by Vendor
					</CardTitle>
				</CardHeader>
				<hr className="mb-6" />
				<CardContent>
					<div className="text-center py-4">
						<h2 className="text-xl pb-2">
							{purchaseOrdersByVendorData.company}
						</h2>
						<h3 className="text-2xl pb-2">
							{purchaseOrdersByVendorData.reportTitle}
						</h3>
						<p className="text-sm">
							Form {purchaseOrdersByVendorData.period.start} To{" "}
							{purchaseOrdersByVendorData.period.end}
						</p>
					</div>

					<div className="overflow-x-auto">
						<table className="min-w-full bg-white border-collapse ">
							<thead>
								<tr className="bg-gradient-to-b from-white to-gray-50 border border-gray-200">
									{purchaseOrdersByVendorData.columns.map((col, idx) => (
										<th
											key={idx}
											// className="text-left px-4 py-2 text-sm  text-blue-700 whitespace-nowrap border-r border-gray-300"
											className={`px-4 py-2 text-sm whitespace-nowrap border-r border-gray-200 text-blue-700 ${
												idx === 0 ? "text-left" : "text-right"
											}`}
										>
											{col}
										</th>
									))}
								</tr>
							</thead>
							<tbody>
								{/* Data Rows */}
								{purchaseOrdersByVendorData.data.map((row, idx) => (
									<tr
										key={idx}
										className={`border-b text-sm text-gray-800 ${
											idx === purchaseOrdersByVendorData.data.length - 1
												? "border-neutral-500"
												: ""
										}`}
									>
										<td className="px-4 py-2  text-left ">{row.vendorName}</td>
										<td className="px-4 py-2  text-right ">{row.orderCount}</td>
										<td className="px-4 py-2  text-right ">{row.amount}</td>
									</tr>
								))}

								{/* Totals Row */}
								<tr className="bg-stone-50 text-sm  border-b border-b-neutral-500">
									<td colSpan={2} className="px-4 py-2 text-left">
										Total
									</td>
									<td className="px-4 py-2 text-right">
										{purchaseOrdersByVendorData.totals.amount}
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</CardContent>
			</Card>
		</div>
	);
};

export default PurchaseOrdersByVendorReport;
