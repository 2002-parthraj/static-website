"use client";
import React, { useState, useRef, useEffect } from "react";
import {
  BookOpen,
  Building2,
  Eye,
  FileChartColumn,
  Folder,
  ListFilter,
  Package2,
  Percent,
  PercentCircle,
  PieChart,
  Receipt,
  ShoppingBag,
  ShoppingCart,
  Star,
  StarIcon,
  UserCheck,
  Users,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import reportsByCategory from "./reportsByCategory.json";
import Link from "next/link";
import { getReportRoute } from "./reportRoutes";
import { useRouter } from "next/navigation";

const CategoryIcons = {
  "Business Overview": PieChart,
  GST: Receipt,
  Sales: ShoppingCart,
  "Purchases and Expenses": ShoppingBag,
  Accountant: BookOpen,
  Bank: Building2,
  TDS: Percent,
  TCS: PercentCircle,
  Inventory: Package2,
  Receivables: UserCheck,
  Payables: Users,
};

const ReportsCenter = () => {
  const [selectedCategory, setSelectedCategory] = useState("Business Overview");
  const sectionRefs = useRef({});
  const scrollAreaRef = useRef(null);
  const [isScrolling, setIsScrolling] = useState(false); // Scroll lock state
  const router = useRouter();

  // Handle category click in sidebar
  const handleCategoryClick = (category) => {
    setSelectedCategory(category);

    const section = sectionRefs.current[category];
    const scrollArea = scrollAreaRef.current;

    if (section && scrollArea) {
      // Disable scroll handler temporarily
      setIsScrolling(true);

      // Calculate the offset position to scroll smoothly without jumping to the top
      const sectionTop = section.offsetTop;
      scrollArea.scrollTo({
        top: sectionTop - scrollArea.clientHeight / 4, // Add some offset for better visibility
        behavior: "smooth",
      });

      // Re-enable the scroll handler after the scrolling animation is done
      setTimeout(() => {
        setIsScrolling(false);
      }, 800); // Adjust the timeout based on your scroll behavior
    }
  };

  // Handle scroll and update selected category in sidebar
  const handleScroll = () => {
    if (isScrolling) return; // Skip the scroll handler if scrolling via handleCategoryClick

    const scrollPosition = scrollAreaRef.current.scrollTop;
    let currentCategory = selectedCategory;

    Object.entries(sectionRefs.current).forEach(([category, ref]) => {
      const sectionTop = ref.offsetTop;
      if (
        ref &&
        sectionTop <= scrollPosition + scrollAreaRef.current.clientHeight / 3
      ) {
        currentCategory = category;
      }
    });

    if (currentCategory !== selectedCategory) {
      setSelectedCategory(currentCategory);
    }
  };

  // Add the handleViewReport function
  const handleViewReport = (reportName) => {
    const reportRoute = getReportRoute(reportName);
    router.push(reportRoute);
  };

  const handleReportClick = (reportName) => {
    router.push(getReportRoute(reportName));
  };

  useEffect(() => {
    const scrollElement = scrollAreaRef.current;
    if (scrollElement) {
      scrollElement.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (scrollElement) {
        scrollElement.removeEventListener("scroll", handleScroll);
      }
    };
  }, [selectedCategory, isScrolling]);

  return (
    <div className="flex -m-4 min-h-[calc(100vh-56px)] bg-gray-50">
      {/* Sidebar */}
      <div className="w-56 bg-[#FFFFFF] border-r border-gray-200">
        <div className="">
          <div>
            <h3 className="text-sm font-semibold px-2 pt-2  mb-2">Report Categories</h3>
            <div className="h-[calc(100vh-210px)] overflow-y-auto">
              {Object.entries(reportsByCategory).map(([category]) => {
                const IconComponent = CategoryIcons[category] || Folder;
                return (
                  <div
                    key={category}
                    className={`p-2 text-sm rounded cursor-pointer transition-colors flex items-center space-x-2 ${
                      category === selectedCategory
                        ? "bg-[#EFF6FF] text-[ ]"
                        : "hover:bg-gray-100 text-[#40566D]"
                    }`}
                    onClick={() => handleCategoryClick(category)}
                  >
                    <IconComponent size={18} />
                    <span>{category}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-hidden bg-[#FFFFFF]">
        <div className="border-b "></div>

        <div className="h-[calc(100vh-57px)] bg-slate-100 overflow-hidden  ">
          <CardContent className="p-0 h-full">
            <div
              className="h-full relative overflow-y-auto"
              ref={scrollAreaRef}
            >
              {Object.entries(reportsByCategory).map(([category, reports]) => (
                <div key={category} className="mb-6">
                  <div className="border-b "></div>
                  <div
                    className=" px-6 pb-3 pt-4 text-[#192839] font-semibold "
                    ref={(el) => (sectionRefs.current[category] = el)}
                  >
                    {category}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 px-4">
                    {reports.map((report, index) => (
                      <div
                        key={`report-${index}`}
                        onClick={() => handleReportClick(report.name)}
                        className="bg-white rounded-lg shadow p-4 cursor-pointer transition-all hover:shadow-lg"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-base font-semibold text-[#212121]">
                              {report.name}
                            </span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-[#768EA7] text-sm font-medium">
                            View Report
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </div>
      </div>
    </div>
  );
};

export default ReportsCenter;
