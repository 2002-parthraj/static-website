import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import invoiceInterestCalculatorData from "./invoiceInterestCalculatorData.json";

const InvoiceInterestCalculatorReport = () => {
	return (
		<div className="container mx-auto p-4 ">
			<Card className="rounded-none shadow-lg mx-auto w-[100%] lg:w-[72%]">
				<CardHeader className="p-3">
					<CardTitle className="text-xl font-bold">
						Invoice Interest Calculator
					</CardTitle>
				</CardHeader>
				<hr className="mb-6" />
				<CardContent>
					<div className="text-center py-4">
						<h2 className="text-xl pb-2">
							{invoiceInterestCalculatorData.company}
						</h2>
						<h3 className="text-2xl pb-2">
							{invoiceInterestCalculatorData.reportTitle}
						</h3>
						<p className="text-sm">
							Form {invoiceInterestCalculatorData.period.start} To{" "}
							{invoiceInterestCalculatorData.period.end}
						</p>
					</div>

					<div className="overflow-x-auto">
						<table className="min-w-full bg-white border-collapse ">
							<thead>
								<tr className="bg-gradient-to-b from-white to-gray-50 border border-gray-200">
									{invoiceInterestCalculatorData.columns.map((col, idx) => (
										<th
											key={idx}
											// className="text-left px-4 py-2 text-sm  text-blue-700 whitespace-nowrap border-r border-gray-300"
											className={`px-4 py-2 text-sm whitespace-nowrap border-r border-gray-200 text-blue-700 ${
												idx === 0 || idx === 1 || idx === 4
													? "text-left"
													: "text-right"
											}`}
										>
											{col}
										</th>
									))}
								</tr>
							</thead>
							<tbody>
								{/* Data Rows */}
								{invoiceInterestCalculatorData.data.map((row, idx) => (
									<tr
										key={idx}
										className={`border-b text-sm text-gray-800 ${
											idx === invoiceInterestCalculatorData.data.length - 1
												? "border-neutral-500"
												: ""
										}`}
									>
										<td className="px-4 py-2  text-left">{row.invoiceDate}</td>
										<td className="px-4 py-2  text-left ">{row.dueDate}</td>
										<td className="px-4 py-2  text-right ">{row.invoice}</td>
										<td className="px-4 py-2  text-right ">{row.order}</td>
										<td className="px-4 py-2  text-left ">
											{row.customerName}
										</td>
										<td className="px-4 py-2  text-right ">
											{row.invoiceAmount}
										</td>
										<td className="px-4 py-2  text-right ">{row.interest}</td>
										<td className="px-4 py-2  text-right ">{row.total}</td>
									</tr>
								))}

								<tr className="bg-stone-50 text-sm  border-b border-b-neutral-500">
									<td colSpan={5} className="px-4 py-2 text-left">
										Total
									</td>
									<td className="px-4 py-2 text-right">
										{invoiceInterestCalculatorData.totals.invoiceAmount}
									</td>
									<td className="px-4 py-2 text-right">
										{invoiceInterestCalculatorData.totals.interest}
									</td>
									<td className="px-4 py-2 text-right">
										{invoiceInterestCalculatorData.totals.total}
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</CardContent>
			</Card>
		</div>
	);
};

export default InvoiceInterestCalculatorReport;
