"use client";
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import agingDetailsByBillData from "./agingDetailsByBillData.json";
import { format } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { getPayableAgingDetailsReport } from "@/actions/reports/get-payable-aging-details-report";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import { handleDataExport } from "@/lib/exportUtils";
import { Button } from "@/components/ui/button";
import { ChevronLeft, LoaderCircle, Printer, Upload } from "lucide-react";
import { toast } from "sonner";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useRouter } from "next/navigation";

const AgingDetailsByBillReport = () => {
  const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [generatePDF, setGeneratePDF] = useState(false);
  const [chunkedlineItems, setChunkedLineItems] = useState([]);
  const [lineItemData, setLineItemData] = useState(null);
  const { data, isLoading, error } = useQuery({
    queryKey: ["InventorySummary", startDate, endDate],
    queryFn: () => getPayableAgingDetailsReport(startDate, endDate),
  });
  const router = useRouter();
  const { data: organization } = useQuery({
    queryKey: ["organization"],
    queryFn: getCommonInitData,
    onError: (error) => {
      toast.error(error || "Failed to load state list. Please try again.");
    },
  });
  const organizationName = organization?.data?.organization?.info?.name;

  const handleAsOfDateChange = (date) => {
    const startDate = format(date.from, "yyyy-MM-dd");
    const endDate = format(date.to, "yyyy-MM-dd");

    setStartDate(startDate);
    setEndDate(endDate);
  };
  const agingData = data?.data?.data || [];
  const inventorySummaryTotal = data?.data?.meta?.total;

  const handleExport = () => {
    if (agingData) {
      const result = handleDataExport(agingData, "ap-aging-details-report");
      if (!result.success) {
        // Handle error - maybe show a toast notification
        toast.error(result.error);
      }
    }
  };

  const ITEMS_PER_PAGE = 40;

  const chunkArray = (array, size) => {
    const chunked = [];
    for (let i = 0; i < array.length; i += size) {
      chunked.push(array.slice(i, i + size));
    }
    return chunked;
  };

  useEffect(() => {
    if (lineItemData && lineItemData.length > 0) {
      // Create chunks of line items, with 5 items per chunk
      const chunks = chunkArray(lineItemData, ITEMS_PER_PAGE);
      setChunkedLineItems(chunks);
    }
  }, [lineItemData]);

  const TableData = data?.data?.data;

  useEffect(() => {
    if (TableData?.length > 0) {
      setLineItemData(TableData);
    }
  }, [TableData]);

  const maxLengthPartyName = (TableData, maxLength = 30) => {
    return TableData?.length > maxLength
      ? TableData.slice(0, maxLength) + "..."
      : TableData;
  };

  const renderStatement = (TableData, index) => {
    const pageCount = index;
    const currentPageCount = pageCount + 1;
    return (
      <>
        <div
          style={{
            width: "210mm", // A4 width
            minHeight: "297mm", // A4 height
            // padding: "10mm", // Add some padding
            boxSizing: "border-box",
            backgroundColor: "#ffffff",
          }}
          className="p-4"
        >
          <div className="">
            <div className=" text-center mb-4">
              <h1 className="text-xl font-bold">{organizationName}</h1>
              <p className="font-bold mt-2">AP Aging Details</p>
              <div className="">
                {/* <p>
                          <b>From</b>:{data?.data?.data?.period?.fromDate}
                        </p>
                        <p>
                          <b>to</b>:{data?.data?.data?.period?.toDate}
                        </p> */}
                <span className="mr-1">From:</span>
                <span className="mr-2">{startDate}</span>
                <span className="mr-1">to:</span>
                <span>{endDate}</span>
              </div>
            </div>

            {/* After compelition of code use print-only hidden in div classname*/}
            <div className=" ">
              <table className="w-[100%] border-collapse">
                <thead>
                  <tr className="border-t-2 border-b-2 border-black ">
                    <th className="text-left">
                      <div className="mb-4 text-[15px]">Date</div>
                    </th>
                    <th className="text-left">
                      <div className="mb-4 text-[15px] ">Bill Number</div>
                    </th>
                    <th className="text-left">
                      <div className="mb-4 text-[15px] ">Type</div>
                    </th>
                    <th className="text-left">
                      <div className="mb-4 text-[15px] ">Status</div>
                    </th>
                    <th className="text-left">
                      <div className="mb-4 text-[15px] ">Vendor Name</div>
                    </th>
                    <th className="text-left">
                      <div className="mb-4 text-[15px] ">Age</div>
                    </th>
                    <th className="text-right">
                      <div className="mb-4 text-[15px] ">Amount</div>
                    </th>
                    <th className="text-right">
                      <div className="mb-4 text-[15px] ">Due Amount</div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {agingData?.map((bucket, bucketIndex) => (
                    <React.Fragment key={bucketIndex}>
                      <tr>
                        <td className="font-bold text-left">
                          {bucket?.agingBucket}
                        </td>
                      </tr>
                      {bucket?.items?.map((data, index) => (
                        <tr key={`${bucketIndex}-${index}`}>
                          <td className=" text-left">{data?.date}</td>
                          <td className=" text-left">{data?.billNumber}</td>
                          <td className=" text-left">{data?.type}</td>
                          <td className=" text-left">{data?.status}</td>

                          <td className=" text-left ">
                            {maxLengthPartyName(data?.vendorName)}
                          </td>
                          <td className=" text-left">{data?.age}</td>
                          <td className="text-right">
                            {data?.amount?.toFixed(2)}
                          </td>
                          <td className="text-right">
                            {data?.balanceDue?.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </React.Fragment>
                  ))}

                  <div className="pb-2"></div>
                  {chunkedlineItems?.length === index + 1 ? (
                    <>
                      <tr className="text-left   border-t-2 border-black">
                        {/* <td></td> */}
                        <td className="text-left">
                          <div className="mb-3">Total</div>
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td className=" text-right ">
                          <div className="mb-3 ">
                            {inventorySummaryTotal?.amount.toFixed(2)}
                          </div>
                        </td>
                        <td className="text-right  ">
                          <div className=" mb-3">
                            {inventorySummaryTotal?.balanceDue.toFixed(2)}
                          </div>
                        </td>
                      </tr>
                    </>
                  ) : (
                    ""
                  )}
                </tbody>
              </table>
            </div>
          </div>
          <div className="text-right">
            <span className="ml-[5px] text-xs">
              Page {currentPageCount} of {chunkedlineItems.length}
            </span>
          </div>
        </div>
      </>
    );
  };

  const handlePrint = async () => {
    if (generatePDF) return;
    try {
      setGeneratePDF(true);

      const renderTemplate = (lineItems, i) => (
        <div
          style={{
            width: "210mm",
            minHeight: "297mm",
            backgroundColor: "#ffffff",
          }}
        >
          {renderStatement(lineItems, i)}
        </div>
      );

      // Create container for rendering
      const templateId = "statement-template";
      const container = document.createElement("div");
      container.id = templateId;
      container.style.position = "absolute";
      container.style.left = "-9999px";
      container.style.top = "0";
      container.style.width = "210mm"; // A4 width
      container.style.backgroundColor = "#ffffff";
      document.body.appendChild(container);

      // Initialize PDF with A4 size
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
        compress: true,
      });

      // PDF dimensions
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      // Render template using React
      const { createRoot } = await import("react-dom/client");
      const root = createRoot(container);

      // Process each chunk/page
      for (let i = 0; i < chunkedlineItems.length; i++) {
        // Render current page
        await new Promise((resolve) => {
          root.render(
            <div id={templateId}>{renderTemplate(chunkedlineItems[i], i)}</div>
          );
          setTimeout(resolve, 500); // Wait for rendering
        });

        // HTML2Canvas options
        const options = {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
          width: 793, // A4 width in pixels (210mm at 96 DPI)
          height: 1122, // A4 height in pixels (297mm at 96 DPI)
          onclone: (clonedDoc) => {
            const notifications =
              clonedDoc.getElementsByClassName("notification");
            Array.from(notifications).forEach((notification) =>
              notification.remove()
            );
          },
        };

        try {
          // Generate canvas for current page
          const canvas = await html2canvas(container.firstChild, options);
          const imgData = canvas.toDataURL("image/jpeg", 1.0);

          // Calculate scaling to fit A4
          const imgWidth = canvas.width;
          const imgHeight = canvas.height;
          const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);

          // Center image on page
          const xOffset = (pdfWidth - imgWidth * ratio) / 2;
          const yOffset = 0;

          // Add new page if not first page
          if (i > 0) {
            pdf.addPage();
          }

          // Add image to PDF
          pdf.addImage(
            imgData,
            "JPEG",
            xOffset,
            yOffset,
            imgWidth * ratio,
            imgHeight * ratio,
            undefined,
            "FAST"
          );

          canvas.remove();
        } catch (error) {
          console.error(`Error generating page ${i + 1}:`, error);
          throw error;
        }
      }

      // Save the complete PDF
      await pdf.save("AP Aging Details.pdf", { returnPromise: true });

      // Cleanup
      root.unmount();
      document.body.removeChild(container);
    } catch (error) {
      console.error("PDF generation error:", error);
      toast.error("Failed to generate PDF. Please try again.");
    } finally {
      setGeneratePDF(false);
    }
  };

  return (
    <div className="bg-[#FFFFFF]">
      <div className="flex items-center justify-between border-b px-2 py-2 border-gray-300 h-16">
        <div className="flex items-center space-x-2 pl-1 pr-4">
          <Button
            size="icon"
            className="bg-white hover:bg-inherit  shadow-none border text-black"
            onClick={() => router.push(`/reports`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-left font-medium text-[16px] leading-6 text-[#212121] font-poppins">
            AP Aging Details
          </div>
        </div>
        <div>
          <div className="flex  items-center">
            <div className="">
              <ReportDateSelector
                mode="range"
                onDateChange={handleAsOfDateChange}
                className="w-[200px]"
              />
            </div>
            <div className="w-[16px] flex justify-center h-full ">
              <div className="w-[1px] bg-[#D2D6DB] h-[38px]"></div>
            </div>
            <div className="mr-[8px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={() => handlePrint()}
              >
                {generatePDF ? (
                  <div className="animate-spin">
                    <LoaderCircle />
                  </div>
                ) : (
                  <>
                    <Printer className="h-4 w-4" />
                    <span className="ml-1">Print</span>
                  </>
                )}
              </Button>
            </div>
            <div className="mr-[10px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={handleExport}
              >
                <Upload className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div>
        <div className="mt-[10px]">
          <div className="mr-[16px] ml-[16px] ">
            <div className="rounded-md border w-full overflow-y-auto ">
              <Table>
                <TableHeader className="bg-[#F2F5F8]">
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                font-semibold text-[#192839]`}
                      >
                        Date
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                font-semibold text-[#192839]`}
                      >
                        Bill Number
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                font-semibold text-[#192839]`}
                      >
                        Type
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                font-semibold text-[#192839]`}
                      >
                        Status
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                font-semibold text-[#192839]`}
                      >
                        Vendor Name
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                font-semibold text-[#192839]`}
                      >
                        Age
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-right
                                font-semibold text-[#192839]`}
                      >
                        Amount
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-right
                                font-semibold text-[#192839]`}
                      >
                        Due Amount
                      </div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {agingData && agingData.length > 0 ? (
                    <>
                      {agingData.map((bucket, bucketIndex) => (
                        <React.Fragment key={bucketIndex}>
                          <TableRow className="bg-gray-100">
                            <TableCell className=" p-2 text-left  text-[12px]  text-[#192839] font-semibold	" >
                              {bucket?.agingBucket}
                            </TableCell>
                            <TableCell colSpan={7} />
                          </TableRow>

                          {bucket?.items?.map((row, rowIndex) => (
                            <TableRow
                              key={`${bucketIndex}-${rowIndex}`}
                              className="text-gray-800"
                            >
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left" >{row.date}</TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">{row.billNumber}</TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">{row.type}</TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">{row.status}</TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">{row.vendorName}</TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">{row.age}</TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                                {row.amount}
                              </TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                                {row.balanceDue}
                              </TableCell>
                            </TableRow>
                          ))}
                        </React.Fragment>
                      ))}

                      <TableRow className="bg-stone-50 font-medium">
                        <TableCell colSpan={6}>
                          <div className=" text-left">
                          Total
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          {inventorySummaryTotal?.amount}
                        </TableCell>
                        <TableCell className="text-right">
                          {inventorySummaryTotal?.balanceDue}
                        </TableCell>
                      </TableRow>
                    </>
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={8}
                        className="text-center text-gray-500 h-24"
                      >
                        {isLoading ? "Loading..." : "No Data Available"}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgingDetailsByBillReport;
