// import React from "react";
// import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
// import gstr2Data from "./gstr2Data.json";

// const Gstr2Report = () => {
// 	return (
// 		<div className="container mx-auto p-4 ">
// 			<Card className="rounded-none shadow-lg mx-auto w-[100%] lg:w-[80%]">
// 				<CardHeader className="p-3">
// 					<CardTitle className="text-xl font-bold">GSTR-2 Report</CardTitle>
// 				</CardHeader>
// 				<hr className="mb-6" />
// 				<CardContent>
// 					<div className="text-center py-4">
// 						<h2 className="text-xl pb-2">{gstr2Data.company}</h2>
// 						<h3 className="text-2xl pb-2">{gstr2Data.reportTitle}</h3>
// 						<p className="text-sm">
// 							Form {gstr2Data.period.start} To {gstr2Data.period.end}
// 						</p>
// 					</div>

// 					<div className="overflow-x-auto">
// 						<table className="w-full border-collapse border border-gray-300">
// 							<thead>
// 								<tr className="bg-blue-100">
// 									{gstr2Data.columns.map((column, index) => (
// 										<td
// 											key={index}
// 											className="border border-gray-300 p-2 text-sm"
// 										>
// 											{column}
// 										</td>
// 									))}
// 								</tr>
// 								<tr className="bg-blue-200">
// 									<td className="border border-gray-300 p-2 text-center text-sm">
// 										1
// 									</td>
// 									<td className="border border-gray-300 p-2 text-center text-sm">
// 										2
// 									</td>
// 									<td className="border border-gray-300 p-2 text-center text-sm">
// 										3
// 									</td>
// 									<td className="border border-gray-300 p-2 text-center text-sm">
// 										4
// 									</td>
// 									<td className="border border-gray-300 p-2 text-center text-sm">
// 										5
// 									</td>
// 									<td className="border border-gray-300 p-2 text-center text-sm">
// 										6
// 									</td>
// 									<td className="border border-gray-300 p-2 text-center text-sm">
// 										7
// 									</td>
// 								</tr>
// 							</thead>
// 							<tbody>
// 								{gstr2Data.data.map((row, rowIndex) => (
// 									<tr key={rowIndex} className="bg-white ">
// 										<td className="border border-gray-300 p-2 text-sm text-center">
// 											{row.sr}
// 										</td>
// 										<td className="border border-gray-300 p-2 text-sm">
// 											{row.particulars}
// 										</td>
// 										<td className="border border-gray-300 p-2 text-sm text-right">
// 											{row.taxableValue}
// 										</td>
// 										<td className="border border-gray-300 p-2 text-sm text-right">
// 											{row.integratedTax}
// 										</td>
// 										<td className="border border-gray-300 p-2 text-sm text-right">
// 											{row.centralTax}
// 										</td>
// 										<td className="border border-gray-300 p-2 text-sm text-right">
// 											{row.stateUTTax}
// 										</td>
// 										<td className="border border-gray-300 p-2 text-sm text-right">
// 											{row.cessTax}
// 										</td>
// 									</tr>
// 								))}
// 							</tbody>
// 						</table>

// 						<div className="mt-4">
// 							{/* <h3 className="text-lg mb-2">HSN wise Summary</h3> */}
// 							<div className="text-center pb-4">
// 								<p className="text-sm">HSN wise Summary</p>
// 							</div>
// 							<table className="w-full border-collapse border border-gray-300">
// 								<thead>
// 									<tr className="bg-blue-100">
// 										{gstr2Data.columns.map((column, index) => (
// 											<td
// 												key={index}
// 												className="border border-gray-300 p-2 text-sm"
// 											>
// 												{column}
// 											</td>
// 										))}
// 									</tr>
// 									<tr className="bg-blue-200">
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											1
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											2
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											3
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											4
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											5
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											6
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											7
// 										</td>
// 									</tr>
// 								</thead>
// 								<tbody>
// 									<tr>
// 										<td
// 											colSpan={7}
// 											className="border border-gray-300 p-2 text-sm text-center"
// 										>
// 											No records found
// 										</td>
// 									</tr>
// 								</tbody>
// 							</table>
// 						</div>

// 						<div className="mt-4">
// 							<div className="text-center pb-4">
// 								<p className="text-sm">SAC wise Summary</p>
// 							</div>
// 							<table className="w-full border-collapse border border-gray-300">
// 								<thead>
// 									<tr className="bg-blue-100">
// 										{gstr2Data.columns.map((column, index) => (
// 											<td
// 												key={index}
// 												className="border border-gray-300 p-2 text-sm"
// 											>
// 												{column}
// 											</td>
// 										))}
// 									</tr>
// 									<tr className="bg-blue-200">
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											1
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											2
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											3
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											4
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											5
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											6
// 										</td>
// 										<td className="border border-gray-300 p-2 text-center text-sm">
// 											7
// 										</td>
// 									</tr>
// 								</thead>
// 								<tbody>
// 									<tr>
// 										<td
// 											colSpan={7}
// 											className="border border-gray-300 p-2 text-sm text-center"
// 										>
// 											No records found
// 										</td>
// 									</tr>
// 								</tbody>
// 							</table>
// 						</div>
// 					</div>
// 				</CardContent>
// 			</Card>
// 		</div>
// 	);
// };

// export default Gstr2Report;

"use client";
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import { Button } from "@/components/ui/button";
import { ChevronLeft, LoaderCircle, Printer, Upload } from "lucide-react";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useRouter } from "next/navigation";
import gstr2Data from "./gstr2Data.json";

const Gstr2Report = () => {
  const generatePDF = false;
  const router = useRouter();

  return (
    <div className="bg-[#FFFFFF]">
      <div className="flex items-center justify-between border-b px-2 py-2 border-gray-300 h-16">
        <div className="flex items-center space-x-2 pl-1 pr-4">
          <Button
            size="icon"
            className="bg-white hover:bg-inherit  shadow-none border text-black"
            onClick={() => router.push(`/reports`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-left font-medium text-[16px] leading-6 text-[#212121] font-poppins">
            GSTR-2 Summary
          </div>
        </div>
        <div>
          <div className="flex  items-center">
            <div className="">
              <ReportDateSelector
                mode="range"
                //   onDateChange={handleAsOfDateChange}
                className="w-[200px]"
              />
            </div>
            <div className="w-[16px] flex justify-center h-full ">
              <div className="w-[1px] bg-[#D2D6DB] h-[38px]"></div>
            </div>
            <div className="mr-[8px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={() => handlePrint()}
              >
                {generatePDF ? (
                  <div className="animate-spin">
                    <LoaderCircle />
                  </div>
                ) : (
                  <>
                    <Printer className="h-4 w-4" />
                    <span className="ml-1">Print</span>
                  </>
                )}
              </Button>
            </div>
            <div className="mr-[8px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"

                //onClick={handleExport}
              >
                <Upload className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className="rounded-md border w-full overflow-y-auto ">
                <Table className="border-collapse	">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {gstr2Data.columns.map((column, index) => (
                        <TableHead key={index} className="border-r p-2 text-sm">
                          <div
                            className={`text-[12px] text-${
                              column === "Particulars" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gstr2Data.data.map((row, rowIndex) => (
                      <TableRow key={rowIndex} className="bg-white ">
                        <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                          {row.particulars || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.taxableValue || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.integratedTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.centralTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.stateUTTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.cessTax || "00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* HSN wise Summary  component  */}
      <div>
        <div className="mt-[12px] bg-[#ECF4FF]">
          <div className="flex items-center">
            <div
              style={{
                backgroundColor: "#2E5391",
                border: "1px solid #2d518f",
                borderBottomRightRadius: "2px",
                borderTopRightRadius: "2px",
                width: "12px",
                height: "32px",
              }}
            ></div>
            <div className="ml-[10px]">
              <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                HSN wise Summary
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className="rounded-md border w-full overflow-y-auto ">
                <Table className="border-collapse">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {gstr2Data.columns.map((column, index) => (
                        <TableHead key={index} className="border-r p-2 text-sm">
                          <div
                            className={`text-[12px] text-${
                              column === "Particulars" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gstr2Data.data.map((row, rowIndex) => (
                      <TableRow key={rowIndex} className="bg-white ">
                        <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                          {row.particulars || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.taxableValue || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.integratedTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.centralTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.stateUTTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.cessTax || "00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* HSN wise Summary  component  */}
      <div>
        <div className="mt-[12px] bg-[#ECF4FF]">
          <div className="flex items-center">
            <div
              style={{
                backgroundColor: "#2E5391",
                border: "1px solid #2d518f",
                borderBottomRightRadius: "2px",
                borderTopRightRadius: "2px",
                width: "12px",
                height: "32px",
              }}
            ></div>
            <div className="ml-[10px]">
              <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                SAC wise Summary
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className="rounded-md border w-full overflow-y-auto ">
                <Table className="border-collapse	">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {gstr2Data.columns.map((column, index) => (
                        <TableHead key={index} className="border-r p-2 text-sm">
                          <div
                            className={`text-[12px] text-${
                              column === "Particulars" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gstr2Data.data.map((row, rowIndex) => (
                      <TableRow key={rowIndex} className="bg-white ">
                        <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                          {row.particulars || "00"}
                        </TableCell>
                        <TableCell className=" border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.taxableValue || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.integratedTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.centralTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.stateUTTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.cessTax || "00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-5 h-[30px]"></div>
    </div>
  );
};

export default Gstr2Report;
