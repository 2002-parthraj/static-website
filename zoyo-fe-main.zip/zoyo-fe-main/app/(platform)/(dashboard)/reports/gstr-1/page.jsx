"use client";
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import Gstr1Data from "./Gstr1Data.json";
import { Button } from "@/components/ui/button";
import { ChevronLeft, LoaderCircle, Printer, Upload } from "lucide-react";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useRouter } from "next/navigation";

const Gstr1Report = () => {
  const generatePDF = false;
  const router = useRouter();

  return (
    <div className="bg-[#FFFFFF]">
      <div className="flex items-center justify-between border-b px-2 py-2 border-gray-300 h-16">
        <div className="flex items-center space-x-2 pl-1 pr-4">
          <Button
            size="icon"
            className="bg-white hover:bg-inherit  shadow-none border text-black"
            onClick={() => router.push(`/reports`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-left font-medium text-[16px] leading-6 text-[#212121] font-poppins">
            GSTR-1 Summary
          </div>
        </div>
        <div>
          <div className="flex  items-center">
            <div className="">
              <ReportDateSelector
                mode="range"
                //   onDateChange={handleAsOfDateChange}
                className="w-[200px]"
              />
            </div>
            <div className="w-[16px] flex justify-center h-full ">
              <div className="w-[1px] bg-[#D2D6DB] h-[38px]"></div>
            </div>
            <div className="mr-[8px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={() => handlePrint()}
              >
                {generatePDF ? (
                  <div className="animate-spin">
                    <LoaderCircle />
                  </div>
                ) : (
                  <>
                    <Printer className="h-4 w-4" />
                    <span className="ml-1">Print</span>
                  </>
                )}
              </Button>
            </div>
            <div className="mr-[10px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"

                //onClick={handleExport}
              >
                <Upload className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className="rounded-md border w-full overflow-y-auto ">
                <Table
                  className="border-collapse
									"
                >
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {Gstr1Data.columns.map((column, index) => (
                        <TableHead
                          key={index}
                          className=" border-r p-2 text-sm"
                        >
                          <div
                            className={`text-[12px] text-${
                              column === "Particulars" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Gstr1Data.data.map((row, rowIndex) => (
                      <TableRow key={rowIndex} className="bg-white ">
                        <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                          {row.particulars || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.taxableValue || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.integratedTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.centralTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.stateUTTax || "00"}
                        </TableCell>
                        <TableCell className=" border-gray-300 p-2 w-[149px]  text-[12px] font-normal text-[#192839]  text-right">
                          {row.cessTax || "00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* HSN wise Summary  component  */}
      <div>
        <div className="mt-[12px] bg-[#ECF4FF]">
          <div className="flex items-center">
            <div
              style={{
                backgroundColor: "#2E5391",
                border: "1px solid #2d518f",
                borderBottomRightRadius: "2px",
                borderTopRightRadius: "2px",
                width: "12px",
                height: "32px",
              }}
            ></div>
            <div className="ml-[10px]">
              <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                HSN wise Summary
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className="rounded-md border w-full overflow-y-auto ">
                <Table className="	">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {Gstr1Data.columns.map((column, index) => (
                        <TableHead key={index} className="border-r p-2 text-sm">
                          <div
                            className={`text-[12px] text-${
                              column === "Particulars" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Gstr1Data.data.map((row, rowIndex) => (
                      <TableRow key={rowIndex} className="bg-white ">
                        <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                          {row.particulars || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.taxableValue || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.integratedTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.centralTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.stateUTTax || "00"}
                        </TableCell>
                        <TableCell className=" border-gray-300 w-[149px] p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.cessTax || "00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* HSN wise Summary  component  */}
      <div>
        <div className="mt-[12px] bg-[#ECF4FF] ">
          <div className="flex items-center">
            <div
              style={{
                backgroundColor: "#2E5391",
                borderBottomRightRadius: "2px",
                borderTopRightRadius: "2px",
                width: "10.62px",
                height: "32px",
              }}
            ></div>
            <div className="ml-[10px]">
              <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                SAC wise Summary
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[10px]">
          <div className="">
            <div className="mr-[16px] ml-[16px] ">
              <div className="rounded-md border w-full overflow-y-auto ">
                <Table className="border-collapse	">
                  <TableHeader className="bg-[#F2F5F8]">
                    <TableRow>
                      {Gstr1Data.columns.map((column, index) => (
                        <TableHead key={index} className="border-r p-2 text-sm">
                          <div
                            className={`text-[12px] text-${
                              column === "Particulars" ? "left" : "right"
                            } font-semibold text-[#192839]`}
                          >
                            {column}
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Gstr1Data.data.map((row, rowIndex) => (
                      <TableRow key={rowIndex} className="bg-white ">
                        <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                          {row.particulars || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.taxableValue || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.integratedTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                          {row.centralTax || "00"}
                        </TableCell>
                        <TableCell className="border-r w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.stateUTTax || "00"}
                        </TableCell>
                        <TableCell className="border w-[149px] border-gray-300 p-2  text-[12px] font-normal text-[#192839]  text-right">
                          {row.cessTax || "00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-5 h-[30px]"></div>
    </div>
  );
};

export default Gstr1Report;
