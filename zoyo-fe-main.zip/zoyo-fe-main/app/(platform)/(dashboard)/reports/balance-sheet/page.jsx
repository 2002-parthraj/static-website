"use client";
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import { useQuery } from "@tanstack/react-query";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import { getBusinessBalanceSheetReport } from "@/actions/reports/get-business-balance-sheet-report";
import { handleDataExport } from "@/lib/exportUtils";
import { Button } from "@/components/ui/button";
import { ChevronLeft, LoaderCircle, Printer, Upload } from "lucide-react";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useRouter } from "next/navigation";

const BalanceSheet = () => {
  const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const router = useRouter();

  const { data, isLoading } = useQuery({
    queryKey: ["InventorySummary", startDate, endDate],
    queryFn: () => getBusinessBalanceSheetReport(startDate, endDate),
  });

  const { data: organization } = useQuery({
    queryKey: ["organization"],
    queryFn: getCommonInitData,
  });

  const organizationName = organization?.data?.organization?.info?.name;
  const inventorySummary = data?.data?.data;

  const handleExport = () => {
    if (inventorySummary) {
      const result = handleDataExport(inventorySummary, "balance-sheet-report");
      if (!result.success) {
        toast.error(result.error);
      }
    }
  };

  const handleAsOfDateChange = (date) => {
    const startDate = format(date.from, "yyyy-MM-dd");
    const endDate = format(date.to, "yyyy-MM-dd");
    setStartDate(startDate);
    setEndDate(endDate);
  };

  const renderSectionItems = (items = [], indent = false) => {
    return items.map((item, index) => (
      <TableRow
        key={`${item.accountCode}-${index}`}
        className="border-t"
      >
        <TableCell
          className={`py-2 ${
            indent ? "pl-10" : "pl-4"
          } text-left pr-4 w-3/4 text-[12px] font-normal text-[#192839] `}
        >
          {item.accountName}
        </TableCell>
        <TableCell className="text-right py-2 px-4 w-1/4 text-[12px] font-normal text-[#192839] ">
          {item.amount?.toFixed(2)}
        </TableCell>
      </TableRow>
    ));
  };

  const renderSubSection = (sectionData, indent = true) => {
    if (!sectionData) return null;

    return (
      <>
        {sectionData.title && (
          <TableRow className="bg-[#F2F5F8] border-t border-b">
            <TableCell
              colSpan={2}
              className=" px-6 text-center text-[12px] 
                                font-semibold text-[#192839]"
            >
              {sectionData.title}
            </TableCell>
          </TableRow>
        )}
        {renderSectionItems(sectionData.items, indent)}
        {sectionData.total !== undefined && (
          <TableRow className="border-t border-b   bg-gray-50">
            <TableCell
              className="py-2 text-left pl-4 pr-4 w-3/4 text-[12px] 
                                font-semibold text-[#192839]"
            >
              Total {sectionData.title}
            </TableCell>
            <TableCell
              className="text-right py-2 px-4 w-1/4 text-[12px] 
                                font-semibold text-[#192839]"
            >
              {sectionData.total?.toFixed(2)}
            </TableCell>
          </TableRow>
        )}
      </>
    );
  };

  const renderSection = (
    title,
    sectionData,
    totalAmount,
    totalLabel = "Total"
  ) => {
    if (!sectionData) return null;

    return (
      <>
        <div className="mr-[16px] ml-[16px] mt-[10px]">
          <div className="mt-[12px] bg-[#ECF4FF] ">
            <div className="flex items-center">
              <div
                style={{
                  backgroundColor: "#2E5391",
                  borderBottomRightRadius: "2px",
                  borderTopRightRadius: "2px",
                  width: "10.62px",
                  height: "32px",
                }}
              ></div>
              <div className="ml-[10px] w-full">
                <div className="flex w-full  items-center justify-between">
                  <div className="text-[14px] text-[#2E5391] font-semibold	font-inter">
                    {title}
                  </div>
                  <div className="text-[14px] mr-4 text-[#2E5391] font-semibold	font-inter">
                    {startDate}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-3 rounded-md border w-full overflow-y-auto ">
            <Table>
              <TableHeader>
                <TableRow className=" bg-gradient-to-b from-white to-gray-50 border-gray-300"></TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(sectionData).map(([key, subSection]) => (
                  <React.Fragment key={key}>
                    {renderSubSection(subSection)}
                  </React.Fragment>
                ))}
                <TableRow className="border-t border-black bg-stone-50">
                  <TableCell
                    className="py-2 text-left pl-4 pr-4 w-3/4 text-[12px] 
                                font-semibold text-[#192839]"
                  >
                    {totalLabel}
                  </TableCell>
                  <TableCell
                    className="text-right py-2 px-4 w-1/4 text-[12px] 
                                font-semibold text-[#192839]"
                  >
                    {totalAmount?.toFixed(2)}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </div>
      </>
    );
  };

  const renderBalanceSheet = () => {
    if (!inventorySummary?.sections) return null;

    return Object.entries(inventorySummary?.sections).map(
      ([sectionKey, sectionData], index) => {
        const title = sectionKey.charAt(0).toUpperCase() + sectionKey.slice(1);
        const totalKey = `total${title}`;
        const total = inventorySummary[totalKey];

        return (
          <React.Fragment key={sectionKey}>
            {renderSection(title, sectionData, total, `Total ${title}`)}
            {index < Object.keys(inventorySummary?.sections).length - 1 && (
              <div className="py-4"></div>
            )}
          </React.Fragment>
        );
      }
    );
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }
  const generatePDF = false;
  return (
    <div className="bg-[#FFFFFF]">
      <div className="flex items-center justify-between border-b px-2 py-2 border-gray-300 h-16">
        <div className="flex items-center space-x-2 pl-1 pr-4">
          <Button
            size="icon"
            className="bg-white hover:bg-inherit  shadow-none border text-black"
            onClick={() => router.push(`/reports`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-left font-medium text-[16px] leading-6 text-[#212121] font-poppins">
            Balance Sheet
          </div>
        </div>
        <div>
          <div className="flex  items-center">
            <div className="">
              <ReportDateSelector
                mode="range"
                onDateChange={handleAsOfDateChange}
                className="w-[200px]"
              />
            </div>
            <div className="w-[16px] flex justify-center h-full ">
              <div className="w-[1px] bg-[#D2D6DB] h-[38px]"></div>
            </div>
            <div className="mr-[8px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={() => handlePrint()}
              >
                {generatePDF ? (
                  <div className="animate-spin">
                    <LoaderCircle />
                  </div>
                ) : (
                  <>
                    <Printer className="h-4 w-4" />
                    <span className="ml-1">Print</span>
                  </>
                )}
              </Button>
            </div>
            <div className="mr-[10px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={handleExport}
              >
                <Upload className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div>
        <div className="">{renderBalanceSheet()}</div>
      </div>
    </div>
  );
};

export default BalanceSheet;
