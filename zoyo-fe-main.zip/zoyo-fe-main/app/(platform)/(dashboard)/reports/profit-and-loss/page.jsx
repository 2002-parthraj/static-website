import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import profitAndLossData from "./profitAndLossData.json";

const ProfitAndLossReport = () => {
	const renderSection = (sectionData, indent = 0, isTotal = false) => {
		return sectionData.subcategories.map((item, index) => (
			<tr
				key={index}
				className={`border-t text-zinc-700 ${isTotal ? "border-black border-b bg-gray-100" : "border-gray-200"} ${isTotal ? "bg-stone-50" : ""}`}
			>
				<td className={`py-2 ${indent ? "pl-10" : "pl-4"} pr-4 w-3/4 text-sm`}>
					{item?.label}
				</td>
				<td className="text-right py-2 px-4 w-1/4 text-sm">
					{item?.value?.toFixed(2)}
				</td>
			</tr>
		));
	};

	const renderTableSection = (sectionData, title) => (
		<>
			<thead className="">
				<tr className="border-t border-b bg-gradient-to-b from-white to-gray-50 border-gray-300">
					<td className="text-left py-2 px-4 w-3/4 text-sm border-r text-blue-500">
						{title}
					</td>
					<td className="text-right py-2 px-4 w-1/4 text-sm text-blue-500">
						{profitAndLossData.date}
					</td>
				</tr>
			</thead>
			<tbody>
				{sectionData.map((section, index) => (
					<React.Fragment key={index}>
						{section.category !== "Totals" && (
							<tr>
								<td
									colSpan="2"
									className="py-2 px-6 border-t border-gray-200 text-sm"
								>
									{section.category}
								</td>
							</tr>
						)}
						{renderSection(
							section,
							section.category !== "Totals",
							section.category === "Totals",
						)}
					</React.Fragment>
				))}
			</tbody>
		</>
	);

	const renderTables = () => {
		const sections = Object.keys(profitAndLossData).filter(
			(key) =>
				key !== "company" &&
				key !== "reportTitle" &&
				key !== "period" &&
				key !== "date",
		);

		return sections.map((sectionKey, index) => (
			<React.Fragment key={index}>
				{renderTableSection(profitAndLossData[sectionKey], sectionKey)}
				<tbody>
					<tr>
						<td colSpan="2" className="py-4"></td>
					</tr>
				</tbody>
			</React.Fragment>
		));
	};

	return (
		<div className="container mx-auto p-4">
			<Card className="rounded-none shadow-lg mx-auto w-[100%] md:w-[70%]">
				<CardHeader className="p-3">
					<CardTitle className="text-xl font-bold">Profit and Loss</CardTitle>
				</CardHeader>
				<hr className="mb-6" />
				<CardContent>
					<div className="text-center py-4">
						<h2 className="text-xl pb-2">{profitAndLossData.company}</h2>
						<h3 className="text-2xl pb-2">{profitAndLossData.reportTitle}</h3>
						<p className="text-sm">
							From {profitAndLossData.period.start} To{" "}
							{profitAndLossData.period.end}
						</p>
					</div>
					<div className="overflow-x-auto">
						{/* {renderTables()} */}
						<table className="w-full">{renderTables()}</table>
					</div>
				</CardContent>
			</Card>
		</div>
	);
};

export default ProfitAndLossReport;
