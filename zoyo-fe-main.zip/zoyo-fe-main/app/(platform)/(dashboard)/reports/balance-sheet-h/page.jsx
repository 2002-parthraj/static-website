import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import balanceSheetData from "./balanceSheetData.json";

const BalanceSheetH = () => {
	const renderSection = (section, indent = 4) => {
		return Object.entries(section).map(([key, value]) => {
			if (
				key === "label" ||
				key === "value" ||
				key === "sectionTitle" ||
				key === "totalLiabilities" ||
				key === "totalAssets"
			)
				return null;

			if (
				typeof value === "object" &&
				value !== null &&
				!Array.isArray(value)
			) {
				return (
					<React.Fragment key={key}>
						<tr>
							<td colSpan="2" className={`pt-2 pb-2 pl-${indent} pr-4 w-[65%]`}>
								{value.label || key}
							</td>
							{value.value && (
								<td
									className={`text-right pt-2 pb-2 pl-4 pr-${indent} w-[35%]`}
								>
									{value.value}
								</td>
							)}
						</tr>
						{/* {renderSection(value, indent + 4)} */}
						{Object.entries(value).map(
							([nestedKey, nestedValue], nestedIndex, nestedArray) => {
								const isLastNestedRow = nestedIndex === nestedArray.length - 1;
								// Skip specific keys in nested objects
								if (nestedKey === "label" || nestedKey === "value") return null;

								return (
									<tr key={nestedKey}>
										<td className={`pl-${indent + 4} pt-2 pb-2 pr-4 w-[65%]`}>
											{" "}
											{typeof nestedValue === "object" && nestedValue !== null
												? nestedValue.label
												: nestedValue}
										</td>
										{/* <td className={`pl-${indent + 4} pt-2 pr-4`}>{nestedKey.label || nestedKey}</td> */}
										<td
											className={`text-right pt-2 pb-2 pr-4 w-[35%] ${isLastNestedRow ? "shadow-[0_1px_0_0_black]" : ""}`}
										>
											{/* <td className="text-right pt-2 pr-4 "> */}
											{
												typeof nestedValue === "object" && nestedValue !== null
													? nestedValue.value // Render value if nestedValue is an object
													: nestedValue // Render the value directly if it's not an object
											}
										</td>
									</tr>
								);
							},
						)}
					</React.Fragment>
				);
			} else {
				return (
					<tr key={key}>
						<td className={`pl-${indent + 4} pt-2 pb-2 pr-4 w-[65%]`}>{key}</td>
						<td className="w-[35%]"></td>
						<td className="text-right pt-2 pb-2 pr-4 w-[35%]">{value}</td>
					</tr>
				);
			}
		});
	};

	const renderTable = (sectionData, title, isAssetTable = false, maxRows) => {
		const totalRowKey = isAssetTable ? "totalAssets" : "totalLiabilities";
		const totalRowData = sectionData[totalRowKey];

		return (
			<>
				<table className="w-full text-sm min-w-[500px]">
					<thead>
						<tr className="border-t border-b border-black bg-stone-100">
							<td colSpan="2" className="text-left pb-2 pt-2 pl-4 pr-4 w-[65%]">
								{title}
							</td>
							<td className="text-right pb-2 pt-2 pl-4 pr-4 w-[35%]">
								{balanceSheetData.balanceSheetDate}
							</td>
						</tr>
					</thead>
				</table>
				<table className="w-full text-sm min-w-[500px]">
					<tbody>
						{renderSection(sectionData)}
						{/* Add empty rows to pad the table to maxRows */}
						{padTable(sectionData, maxRows)}
					</tbody>
				</table>
				<table className="w-full text-sm min-w-[500px]">
					<tfoot>
						<tr className="border-t border-b border-black bg-stone-100">
							<td colSpan="2" className="text-left pl-4 pr-4 pt-2 pb-2 w-[65%]">
								{totalRowData.label}
							</td>
							<td className="text-right pl-4 pr-4  pt-2 pb-2 w-[35%]">
								{totalRowData.value}
							</td>
						</tr>
					</tfoot>
				</table>
			</>
		);
	};

	const getMaxRowCount = () => {
		// Helper to determine the max number of rows between the two tables
		const liabilitiesRows = countRows(balanceSheetData.liabilities);
		const assetsRows = countRows(balanceSheetData.assets);
		return Math.max(liabilitiesRows, assetsRows);
	};

	const countRows = (section) => {
		let rowCount = 0;

		const countSectionRows = (sec) => {
			Object.values(sec).forEach((value) => {
				if (
					typeof value === "object" &&
					value !== null &&
					!Array.isArray(value)
				) {
					rowCount += 1; // Count the current row
					countSectionRows(value); // Recursively count nested rows
				}
			});
		};

		countSectionRows(section);
		return rowCount;
	};

	const padTable = (sectionData, maxRows) => {
		const currentRows = countRows(sectionData);
		const emptyRows = maxRows - currentRows;

		return Array.from({ length: emptyRows }, (_, i) => (
			<tr key={`empty-${i}`}>
				<td className="pt-2 pb-2 pl-4 pr-4 w-[65%]">&nbsp;</td>
				<td className="text-right pt-2 pb-2 pl-4 pr-4 w-[35%]">&nbsp;</td>
			</tr>
		));
	};

	return (
		<div className="container mx-auto p-4">
			<Card className="rounded-none shadow-lg">
				<CardHeader className="p-3">
					<CardTitle className="text-xl font-bold">Balance Sheet</CardTitle>
				</CardHeader>
				<hr className="mb-6" />
				<CardContent>
					<div className="text-center py-4">
						<h2 className="text-xl pb-2">{balanceSheetData.companyName}</h2>
						<h3 className="text-2xl pb-2">Balance Sheet</h3>
						<p className="text-sm">As of {balanceSheetData.balanceSheetDate}</p>
					</div>
					<div className="w-full overflow-x-auto">
						<div className="flex flex-col md:flex-row min-w-[500px] md:min-w-[1000px] ">
							<div className="flex-1 flex flex-col md:w-1/2">
								{renderTable(
									balanceSheetData.liabilities,
									"Liabilities",
									false,
									getMaxRowCount(),
								)}
							</div>
							<div className="flex-1 flex flex-col md:w-1/2 md:border-l border-black">
								{renderTable(
									balanceSheetData.assets,
									"Assets",
									true,
									getMaxRowCount(),
								)}
							</div>
						</div>
					</div>
				</CardContent>
			</Card>
		</div>
	);
};

export default BalanceSheetH;
