import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import invoicePaymentsData from "./invoicePaymentsData.json";

const InvoicePaymentsReport = () => {
	return (
		<div className="container mx-auto p-4">
			<Card className="rounded-none shadow-lg mx-auto w-[100%] lg:w-[72%]">
				<CardHeader className="p-3">
					<CardTitle className="text-xl font-bold">
						Invoice Payments (Payments Method Wise)
					</CardTitle>
				</CardHeader>
				<hr className="mb-6" />
				<CardContent>
					<div className="text-center py-4">
						<h2 className="text-xl pb-2">{invoicePaymentsData.company}</h2>
						<h3 className="text-2xl pb-2">{invoicePaymentsData.reportTitle}</h3>
						<p className="text-sm">As of {invoicePaymentsData.period.start}</p>
					</div>

					<div className="overflow-x-auto">
						<table className="min-w-full bg-white border-collapse">
							<thead>
								<tr className="bg-gradient-to-b from-white to-gray-50 border border-gray-200">
									{invoicePaymentsData.columns.map((col, idx) => (
										<th
											key={idx}
											className={`px-4 py-2 text-sm whitespace-nowrap border-r border-gray-200 text-blue-700 ${
												idx === 0 ? "text-left" : "text-right"
											}`}
										>
											{col}
										</th>
									))}
								</tr>
							</thead>
							<tbody>
								{invoicePaymentsData.data.map((row, rowIdx) => (
									<React.Fragment key={rowIdx}>
										<tr className="border-b">
											<td className="p-3 text-sm text-left">{row.date}</td>
											<td className="p-3 text-sm text-right">
												{row.invoiceNo}
											</td>
											<td className="p-3 text-sm text-right">
												{row.customerName}
											</td>
											<td className="p-3 text-sm text-right">{row.amount}</td>
											<td className="p-3 text-sm text-right">
												{/* Nested Table for Payments */}
												<table className="min-w-full">
													<tbody>
														{row.payments.map((payment, idx) => (
															<tr key={idx}>
																<td className="p-2 text-left">
																	{payment.name}
																</td>
																<td className="p-2 text-right">
																	{payment.amount}
																</td>
															</tr>
														))}
														{/* Adding Total and Pending Amount rows inside the nested table */}
														<tr className="border-b border-black bg-gray-50">
															<td colSpan="1" className="p-2 text-left ">
																Total
															</td>
															<td className="p-2 text-right 0">
																{row.totals.total}
															</td>
														</tr>
														<tr className="border-b border-black bg-gray-50">
															<td colSpan="1" className="p-2 text-left ">
																Pending Amount
															</td>
															<td className="p-2 text-right ">
																{row.pendingAmount}
															</td>
														</tr>
													</tbody>
												</table>
											</td>
										</tr>
									</React.Fragment>
								))}
							</tbody>
						</table>
					</div>
				</CardContent>
			</Card>
		</div>
	);
};

export default InvoicePaymentsReport;
