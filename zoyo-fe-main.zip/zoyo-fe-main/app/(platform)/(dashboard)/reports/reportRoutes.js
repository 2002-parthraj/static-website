const reportRoutes = {
	"Profit and Loss(T Format)": "/reports/profit-and-loss-h",
	"Cash Flow Statement": "/reports/cash-flow-Statement",
	// "Balance Sheet(T Format)": "/reports/balance-sheet-h",
	"Balance Sheet": "/reports/balance-sheet",
	// "Profit and Loss": "/reports/profit-and-loss",

	"GSTR-3B": "/reports/gstr-3b",
	"GSTR-1": "/reports/gstr-1",
	"GSTR-2": "/reports/gstr-2",

	"Sales Register": "/reports/sales-register",
	"Sales by Customer": "/reports/sales-by-customer",
	"Sales by Item": "/reports/sales-by-item",
	"Sales by Sales Person": "/reports/sales-by-salesperson",

	"Purchase Register": "/reports/purchase-register",
	"Purchases by Vendor": "/reports/purchases-by-vendor",
	"Purchases by Item": "/reports/purchases-by-item",
	"Expense Register": "/reports/expenses-details",
	"Expenses by Account": "/reports/expenses-by-account",
	"Expenses by Party": "/reports/expenses-by-category",

	"Account Transactions": "/reports/account-transactions",
	"General Ledger": "/reports/general-ledger",
	"Journal Entries": "/reports/journal-report",
	"Trial Balance": "/reports/trial-balance",
	"Day Book": "/reports/day-book",


	"Bank Transactions": "/reports/bank-transactions",
	"Receipts Transactions": "/reports/receipts-transactions",
	"Payments Transactions": "/reports/payments-transactions",
	"Bank Summary": "/reports/bank-summary",

	"TDS Receivables": "/reports/tds-receivables",
	"TDS Payables": "/reports/tds-payables",


	"TCS Receivables": "/reports/tcs-receivables",
	"TCS Payables": "/reports/tcs-payables",

	// "Tax Summary": "/reports/tax-summary",

	// "Payments Received": "/reports/payments-received",
	// "Credit Note Details": "/reports/credit-note-details",
	// "Refund History": "/reports/refund-history",
	// "Time to Get Paid": "/reports/time-to-get-paid",

	"Inventory Summary": "/reports/inventory-summary",
	"Inventory Valuation Summary": "/reports/inventory-valuation-summary",
	// "Contactwise Summary": "/reports/contactwise-summary",
	"Godown Summary": "/reports/godown-summary",
	// "Batch Summary": "/reports/batch-summary",
	"Categorywise Summary": "/reports/categorywise-summary",
	"Groupwise Summary": "/reports/groupwise-summary",
	// "Stock Journal Summary": "/reports/stock-journal-summary",
	// "Inventory Item List": "/reports/inventory-item-list",
	"Inventory Negative Stock Detail": "/reports/inventory-negative-stock-detail",
	"FIFO Cost Lot Tracking": "/reports/fifo-cost-lot-tracking",
	"In/Out Group-wise Detail": "/reports/inOut-group-wise-detail",
	"Highest Selling Items": "/reports/highest-selling-items",
	// "Item Wise Godown Details": "/reports/item-wise-godown-details",
	"Low Stock Items": "/reports/low-stock-items",

	"Account Receivable Summary": "/reports/account-receivable-summary",
	"Customer Balances": "/reports/customer-balances",
	"Aging Summary ": "/reports/aging-summary-by-invoice",
	"Aging Details ": "/reports/aging-details-by-invoice",
	"Invoice Details": "/reports/invoice-details",
	// "Estimate Details": "/reports/estimate-details",
	"Most Valuable Customers": "/reports/most-valuable-customers",
	// "Invoice Payments (Payments Method Wise)": "/reports/invoice-payments",
	// "Invoice Payment Reminder": "/reports/invoice-payment-reminder",
	// "Invoice Interest Calculator": "/reports/invoice-interest-calculator",

	"Account Payable Summary": "/reports/account-payable-summary",
	"Vendor Balances": "/reports/vendor-balances",
	"Aging Summary": "/reports/aging-summary-by-bill",
	"Aging Details": "/reports/aging-details-by-bill",
	"Bills Details": "/reports/bills-details",
	// "Payments Made": "/reports/payments-made",
	// "Refund History": "/reports/refund-history-by-bill",
	// "Purchase Order Details": "/reports/purchase-order-details",
	// "Purchase Orders by Vendor": "/reports/purchase-orders-by-vendor",
	"Most Valuable Vendors": "/reports/most-valuable-vendors",
	// "Bill Payments (Payments Method Wise)": "/reports/bill-payments",
};

export function getReportRoute(reportName) {
	return reportRoutes[reportName] || "/reports/not-found";
}
