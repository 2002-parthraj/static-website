"use client";
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import { getAccountantTrialBalanceReport } from "@/actions/reports/get-accountant-trialbalance-report";
import { handleDataExport } from "@/lib/exportUtils";
import { Button } from "@/components/ui/button";
import { ChevronLeft, LoaderCircle, Printer, Upload, Users } from "lucide-react";
import { toast } from "sonner";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/components/ui/table";
import { useRouter } from "next/navigation";
const TrialBalanceReport = () => {
	const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
	const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
	const router = useRouter();

	const { data, isPending, error } = useQuery({
		queryKey: ["InventorySummary", startDate, endDate],
		queryFn: () => getAccountantTrialBalanceReport(startDate, endDate),
	});

	const { data: organization } = useQuery({
		queryKey: ["organization"],
		queryFn: getCommonInitData,
		onError: (error) => {
			toast.error(error || "Failed to load state list. Please try again.");
		},
	});
	const organizationName = organization?.data?.organization?.info?.name;

	const handleAsOfDateChange = (date) => {
		const startDate = format(date.from, "yyyy-MM-dd");
		const endDate = format(date.to, "yyyy-MM-dd");

		setStartDate(startDate);
		setEndDate(endDate);
	};
	const agingData = data?.data?.data || [];
	const inventorySummaryTotal = data?.data?.meta?.totals;

	const handleExport = () => {
		if (agingData) {
			const result = handleDataExport(agingData, "trial-balance-report");
			if (!result.success) {
				// Handle error - maybe show a toast notification
				toast.error(result.error);
			}
		}
	};
	const generatePDF = false
	const renderSection = (section) => {
		if (!section) return null;
		return (
			<>
				<div>
					<div className="mt-[12px] bg-[#ECF4FF]">
						<div className="flex items-center">
							<div
								style={{
									backgroundColor: "#2E5391",
									border: "1px solid #2d518f",
									borderBottomRightRadius: "2px",
									borderTopRightRadius: "2px",
									width: "12px",
									height: "32px",
								}}
							></div>
							<div className="ml-[10px] w-full">
								<div className="w-full flex justify-between">
									<div className="text-[14px] capitalize text-[#2E5391] font-semibold	font-inter">
										{section?.type}
									</div>
									<div className="flex w-[30%] justify-between items-center">

										<div >
											<div className="text-[14px] capitalize text-[#192839] font-semibold	font-inter">
												Debit :	{section?.totalDebit}
											</div>
										</div>
										<div>
											<div className="text-[14px] capitalize text-[#192839] font-semibold	font-inter">
												Credit :	{section?.totalCredit}
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="mt-[10px]">
						<div className="">
							<div className="mr-[16px] ml-[16px] ">
								<div className="rounded-md border w-full overflow-y-auto ">
									<Table className="	">
										<TableHeader className="bg-[#F2F5F8]">
											<TableRow>

												<TableHead className="border-r p-2 text-sm">
													<div
														className={`text-[12px] text-"left"
									} font-semibold text-[#192839]`}
													>
														Account Name
													</div>

												</TableHead>
												<TableHead className="border-r w-[200px] p-2 text-sm">
													<div
														className={`text-[12px] text-left
									} font-semibold text-[#192839]`}
													>
														Account Code
													</div>

												</TableHead>
												<TableHead className="border-r w-[200px] p-2 text-sm">
													<div
														className={`text-[12px] text-left
									} font-semibold text-[#192839]`}
													>
														Group Name
													</div>

												</TableHead>
												<TableHead className="w-[200px] border-r p-2 text-sm">
													<div
														className={`text-[12px] text-right
									} font-semibold text-[#192839]`}
													>
														Closing Debit
													</div>

												</TableHead>
												<TableHead className="w-[200px] border-r p-2 text-sm">
													<div
														className={`text-[12px] text-right
									} font-semibold text-[#192839]`}
													>
														Closing Credit
													</div>

												</TableHead>
											</TableRow>
										</TableHeader>
										<TableBody>





											{section?.accounts?.map((row, rowIndex) => (
												<TableRow key={rowIndex} className="bg-white ">
													<TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
														{row.accountName || " - "}
													</TableCell>

													<TableCell className="border-r w-[200px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
														{row?.accountCode || "-"}

													</TableCell>
													<TableCell className="border-r w-[200px] border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
														{row?.groupName || "-"}

													</TableCell>
													<TableCell className="border-r w-[200px] border-gray-300 p-2   text-[12px] font-normal text-[#192839] text-right">
														{row.closingDebit || "00"}
													</TableCell>
													<TableCell className="border-r w-[200px] border-gray-300 p-2   text-[12px] font-normal text-[#192839] text-right">
														{row.closingCredit || "00"}
													</TableCell>

												</TableRow>
											))}
										</TableBody>
									</Table>
									<div style={{ display: section?.accounts?.length > 0 ? "none " : "flex" }}>
										<div className="flex flex-col w-full items-center justify-center p-4">
											{" "}
											<div className="rounded-full h-16  w-full bg-slate-50 text-center flex items-center justify-center">
												<Users className="text-blue-800 font-bold" />
											</div>
											<p className="text-gray-500 text-sm">No Data Added Yet</p>
										</div>
									</div>
									{/* <div className="flex border-t justify-between">
										<div
											className={`text-[12px] 
									 font-semibold p-2 text-[#192839]`}
										>
											Total
										</div>
										<div
											className={`text-[12px] p-2
							font-semibold text-[#192839]`}
										>
											{section.total?.toFixed(2)}
										</div>
									</div> */}

								</div>
							</div>
						</div>
					</div>
				</div>

			</>
		)
	}
	console.log(agingData, 'agingData  < ---------------')
	return (
		<>

			<div className="bg-[#FFFFFF]" >

				<div className="flex items-center justify-between border-b px-2 py-2 border-gray-300 h-16">
					<div className="flex items-center space-x-2 pl-1 pr-4">
						<Button
							size="icon"
							className="bg-white hover:bg-inherit  shadow-none border text-black"
							onClick={() => router.push(`/reports`)}
						>
							<ChevronLeft className="h-4 w-4" />
						</Button>
						<div className="text-left font-medium text-[16px] leading-6 text-[#212121] font-poppins">
							Trial Balance Report
						</div>
					</div>
					<div>
						<div className="flex  items-center">
							<div className="">
								<ReportDateSelector
									mode="range"
									//   onDateChange={handleAsOfDateChange}
									className="w-[200px]"
								/>
							</div>
							<div className="w-[16px] flex justify-center h-full ">
								<div className="w-[1px] bg-[#D2D6DB] h-[38px]"></div>
							</div>
							<div className="mr-[8px]">
								<Button
									style={{ border: "1px solid #d3d6db" }}
									variant="outline"
								//onClick={() => handlePrint()}
								>
									{generatePDF ? (
										<div className="animate-spin">
											<LoaderCircle />
										</div>
									) : (
										<>
											<Printer className="h-4 w-4" />
											<span className="ml-1">Print</span>
										</>
									)}
								</Button>
							</div>
							<div className="mr-[10px]">
								<Button
									style={{ border: "1px solid #d3d6db" }}
									variant="outline"

									onClick={handleExport}
								>
									<Upload className="mr-2 h-4 w-4" />
									Export
								</Button>
							</div>
						</div>
					</div>
				</div>
				<div>
					{
						agingData?.map((val, ind) => (
							<>
								{
									renderSection(val)
								}
							</>
						))
					}
				</div>

				<div className="p-2" >
					<div className="flex w-full justify-between ">
						<div className="text-[14px] capitalize text-[#192839] font-semibold	font-inter">
							Total
						</div>
						<div className="flex w-[30%] justify-between">
							<div className="text-[14px] capitalize text-[#192839] font-semibold	font-inter">
								{inventorySummaryTotal?.totalDebit}
							</div>
							<div className="text-[14px] capitalize text-[#192839] font-semibold	font-inter">
								{inventorySummaryTotal?.totalCredit}
							</div>
						</div>
					</div>
				</div>
			</div>


		</>

	);
};

export default TrialBalanceReport;
