"use client";
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import agingDetailsByInvoiceData from "./agingDetailsByInvoiceData.json";
import { format } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { getReceivableAgingDetailsReport } from "@/actions/reports/get-receivable-aging-details-report";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import ReportDateSelector from "@/components/custom-report-dateselector/report-date-selector";
import { handleDataExport } from "@/lib/exportUtils";
import { Button } from "@/components/ui/button";
import { ChevronLeft, LoaderCircle, Printer, Upload } from "lucide-react";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useRouter } from "next/navigation";
const AgingDetailsByInvoiceReport = () => {
  const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const router = useRouter();

  const { data, isPending, error } = useQuery({
    queryKey: ["InventorySummary", startDate, endDate],
    queryFn: () => getReceivableAgingDetailsReport(startDate, endDate),
  });

  const { data: organization } = useQuery({
    queryKey: ["organization"],
    queryFn: getCommonInitData,
    onError: (error) => {
      toast.error(error || "Failed to load state list. Please try again.");
    },
  });
  const organizationName = organization?.data?.organization?.info?.name;

  const handleAsOfDateChange = (date) => {
    const startDate = format(date.from, "yyyy-MM-dd");
    const endDate = format(date.to, "yyyy-MM-dd");

    setStartDate(startDate);
    setEndDate(endDate);
  };
  const agingData = data?.data?.data || [];
  const inventorySummaryTotal = data?.data?.meta?.total;

  const handleExport = () => {
    if (agingData) {
      const result = handleDataExport(agingData, "ar-aging-details-report");
      if (!result.success) {
        // Handle error - maybe show a toast notification
        toast.error(result.error);
      }
    }
  };
  const generatePDF = false;

  return (
    <div className="bg-[#FFFFFF]">
      <div className="flex items-center justify-between border-b px-2 py-2 border-gray-300 h-16">
        <div className="flex items-center space-x-2 pl-1 pr-4">
          <Button
            size="icon"
            className="bg-white hover:bg-inherit  shadow-none border text-black"
            onClick={() => router.push(`/reports`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-left font-medium text-[16px] leading-6 text-[#212121] font-poppins">
            AR Aging Details
          </div>
        </div>
        <div>
          <div className="flex  items-center">
            <div className="">
              <ReportDateSelector
                mode="range"
                onDateChange={handleAsOfDateChange}
                className="w-[200px]"
              />
            </div>
            <div className="w-[16px] flex justify-center h-full ">
              <div className="w-[1px] bg-[#D2D6DB] h-[38px]"></div>
            </div>
            <div className="mr-[8px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={() => handlePrint()}
              >
                {generatePDF ? (
                  <div className="animate-spin">
                    <LoaderCircle />
                  </div>
                ) : (
                  <>
                    <Printer className="h-4 w-4" />
                    <span className="ml-1">Print</span>
                  </>
                )}
              </Button>
            </div>
            <div className="mr-[10px]">
              <Button
                style={{ border: "1px solid #d3d6db" }}
                variant="outline"
                onClick={handleExport}
              >
                <Upload className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div>
        <div className="mt-[10px]">
          <div className="mr-[16px] ml-[16px] ">
            <div className="rounded-md border w-full overflow-y-auto ">
              <Table>
                <TableHeader className="bg-[#F2F5F8]">
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                      font-semibold text-[#192839]`}
                      >
                        Date
                      </div>
                    </TableHead>

                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                      font-semibold text-[#192839]`}
                      >
                        Customer Name
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                      font-semibold text-[#192839]`}
                      >
                        Transaction
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                      font-semibold text-[#192839]`}
                      >
                        Type
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                      font-semibold text-[#192839]`}
                      >
                        Status
                      </div>
                    </TableHead>

                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-left
                                      font-semibold text-[#192839]`}
                      >
                        Age
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-right
                                      font-semibold text-[#192839]`}
                      >
                        Amount
                      </div>
                    </TableHead>
                    <TableHead className="border-r p-2 text-sm">
                      <div
                        className={`text-[12px] text-right
                                      font-semibold text-[#192839]`}
                      >
                        Due Amount
                      </div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {agingData && agingData.length > 0 ? (
                    <>
                      {agingData.map((bucket, bucketIndex) => (
                        <React.Fragment key={bucketIndex}>
                          <TableRow className="bg-gray-100">
                            <TableCell className=" p-2 text-left  text-[12px]  text-[#192839] font-semibold	">
                              {bucket?.agingBucket}
                            </TableCell>
                            <TableCell colSpan={7} />
                          </TableRow>

                          {bucket?.items?.map((row, rowIndex) => (
                            <TableRow
                              key={`${bucketIndex}-${rowIndex}`}
                              className="text-gray-800"
                            >
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                                {row.date}
                              </TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  w-[200px] text-[12px] font-normal text-[#192839] text-left">
                                {row.customerName}
                              </TableCell>

                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                                {row.transactionNumber}
                              </TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                                {row.type}
                              </TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                                {row.status}
                              </TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-left">
                                {row.age}
                              </TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                                {row.amount}
                              </TableCell>
                              <TableCell className="border-r  border-gray-300 p-2  text-[12px] font-normal text-[#192839] text-right">
                                {row.balanceDue}
                              </TableCell>
                            </TableRow>
                          ))}
                        </React.Fragment>
                      ))}

                      <TableRow className="bg-stone-50 font-medium">
                        <TableCell colSpan={6}>
                          <div className=" text-left">Total</div>
                        </TableCell>
                        <TableCell className="text-right">
                          {inventorySummaryTotal?.amount}
                        </TableCell>
                        <TableCell className="text-right">
                          {inventorySummaryTotal?.balanceDue}
                        </TableCell>
                      </TableRow>
                    </>
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={8}
                        className="text-center text-gray-500 h-24"
                      >
                        {isLoading ? "Loading..." : "No Data Available"}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
      </div>
      
    </div>
  );
};

export default AgingDetailsByInvoiceReport;
