"use client";
import React, { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import CustomTable from "@/components/custom-table/custom-table";
import { toast } from "sonner";
import axios from "@/lib/axios";
import { getAllBankTransctions } from "@/actions/bank-transctions/get-bank-transctions";
import { useParams } from "next/navigation";
import useDebounce from "@/hooks/use-debounce";
import {
	ChevronDown,
	ChevronDownIcon,
	ChevronsUpDown,
	ChevronUp,
	ListFilter,
	Pencil,
	Trash2,
} from "lucide-react";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { deleteReceipts } from "@/actions/receipts/delete-receipts";
import { deletePayments } from "@/actions/payments/delete-payment";
import { Card } from "@/components/ui/card";

const BankTransactionsPage = () => {
	const params = useParams();
	const transactionId = params.accountId;
	const [sortBy, setSortBy] = useState("date");
	const [sortOrder, setSortOrder] = useState("desc");
	const [changePageCount, setChangePageCount] = useState(1);
	const [totalRowCount, setTotalRowCount] = useState(10);
	const [searchValue, setSearchValue] = useState("");
	const [filterType, setFilterType] = useState({
		key: "all",
		heading: "All",
	});

	const [isSheetOpen, setIsSheetOpen] = useState(false);
	const [editTransactionData, setEditTransactionData] = useState(null);
	const [activeSheetType, setActiveSheetType] = useState(null);

	const queryClient = useQueryClient();
	const { confirmDelete } = useDeleteConfirmation();

	const debouncedSearchValue = useDebounce(searchValue, 500);

	const {
		data: transactions,
		isLoading,
		error,
	} = useQuery({
		queryKey: [
			"bankTransactions",
			transactionId,
			changePageCount,
			sortBy,
			sortOrder,
			totalRowCount,
			debouncedSearchValue,
			filterType,
		],
		queryFn: () =>
			getAllBankTransctions(
				transactionId,
				changePageCount,
				sortBy,
				sortOrder,
				totalRowCount,
				debouncedSearchValue,
				filterType,
			),
		onError: (error) => {
			toast.error(
				error || "Failed to load bank transactions. Please try again.",
			);
		},
	});

	useEffect(() => {
		setTotalRowCount(totalRowCount);
		setChangePageCount(1);
	}, [totalRowCount]);

	const tableData = transactions?.data?.data;
	const pagination_data = transactions?.data?.pagination;

	const deleteMutation = useMutation({
		mutationFn: ({ id, type }) =>
			type === "receipt" ? deleteReceipts(id) : deletePayments(id),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["bankTransactions"] });
			toast.success(data?.message || "Transaction deleted successfully");
		},
		onError: (error) => {
			toast.error(
				`Failed to delete the transaction. Error: ${
					error?.message || error || "Something went wrong"
				}`,
			);
		},
	});

	const handleDelete = (transaction) => {
		try {
			confirmDelete(
				`Are you sure you want to delete this ${transaction.type}?`,
				() => {
					deleteMutation.mutate({ id: transaction.id, type: transaction.type });
				},
			);
		} catch (error) {
			console.error("Failed to delete transaction:", error);
		}
	};

	const handleEdit = (data) => {
		setEditTransactionData(data);
		setActiveSheetType(data.type);
		setIsSheetOpen(true);
	};

	const handleAddReceipt = () => {
		setEditTransactionData(null);
		setActiveSheetType("receipt");
		setIsSheetOpen(true);
	};

	const handleAddPayment = () => {
		setEditTransactionData(null);
		setActiveSheetType("payment");
		setIsSheetOpen(true);
	};

	const onSortChange = (sortedBy) => {
		if (sortBy === sortedBy) {
			setSortOrder(sortOrder === "asc" ? "desc" : "asc");
		} else {
			setSortBy(sortedBy);
			setSortOrder("asc");
		}
	};

	const renderSortIcon = (columnId) => {
		if (sortBy === columnId) {
			return sortOrder === "asc" ? (
				<ListFilter className="ml-2 h-4 w-4" />
			) : (
				<ListFilter className="ml-2 h-4 w-4" />
			);
		}
		return <ListFilter className="ml-2 h-4 w-4" />;
	};

	const myColumns = [
		{
			id: "date",
			accessorKey: "date",
			lable: "Date",
			width: 200,
			header: ({ column }) => (
				<div className="flex   justify-center">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						onClick={() => onSortChange("date")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("date");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span style={{ display: "flex", alignItems: "center" }}>
							Date
							{renderSortIcon("date")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => {
				const rawDate = row?.getValue("date");
				const formattedDate = new Date(rawDate).toLocaleDateString("en-GB", {
					day: "2-digit",
					month: "short",
					year: "numeric",
				});

				return (
					<div className="text-center text-wrap">
						<div className="overflow-hidden text-ellipsis whitespace-nowrap">
							{formattedDate}
						</div>
					</div>
				);
			},
		},
		{
			id: "amount",
			accessorKey: "amount",
			lable: "Amount",
			width: 200,
			header: ({ column }) => (
				<div className="flex   justify-center">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						onClick={() => onSortChange("amount")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("amount");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span style={{ display: "flex", alignItems: "center" }}>
							Amount
							{renderSortIcon("amount")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-center  text-wrap">
					<div className="overflow-hidden text-ellipsis whitespace-nowrap">
						{row?.getValue("amount")}
					</div>
				</div>
			),
		},
		{
			id: "payment_mode",
			accessorKey: "payment_mode",
			lable: "Payment Mode",
			width: 200,
			header: ({ column }) => (
				<div className="flex   justify-center">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						onClick={() => onSortChange("payment_mode")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("payment_mode");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span style={{ display: "flex", alignItems: "center" }}>
							Payment Mode
							{renderSortIcon("payment_mode")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-center  text-wrap">
					<div className="overflow-hidden text-ellipsis whitespace-nowrap">
						{row?.getValue("payment_mode")}
					</div>
				</div>
			),
		},

		{
			id: "opposite_account_name",
			accessorKey: "opposite_account_name",
			lable: "Opposite Account Name",
			width: 200,
			header: ({ column }) => (
				<div className="flex   justify-center">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						onClick={() => onSortChange("opposite_account_name")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("opposite_account_name");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span style={{ display: "flex", alignItems: "center" }}>
							Opposite Account Name
							{renderSortIcon("opposite_account_name")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-center  text-wrap">
					<div className="overflow-hidden text-ellipsis whitespace-nowrap">
						{row?.getValue("opposite_account_name")}
					</div>
				</div>
			),
		},
		{
			id: "account_name",
			accessorKey: "account_name",
			lable: "Account Name",
			width: 200,
			header: ({ column }) => (
				<div className="flex   justify-center">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						onClick={() => onSortChange("account_name")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("account_name");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span style={{ display: "flex", alignItems: "center" }}>
							Account Name
							{renderSortIcon("account_name")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-center  text-wrap">
					<div className="overflow-hidden text-ellipsis whitespace-nowrap">
						{row?.getValue("account_name")}
					</div>
				</div>
			),
		},
		{
			id: "actions",
			enableHiding: false,
			header: ({ column }) => (
				<div className="flex justify-end">
					<div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
						<span style={{ display: "flex", alignItems: "center" }}>
							Action
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => {
				const transaction = row?.original;
				return (
					<div className="text-end space-x-2 capitalize">
						<Button
							size="icon"
							className="bg-inherit hover:bg-inherit text-black "
							onClick={() => handleDelete(transaction)}
						>
							<Trash2 className="h-4 w-4" />
						</Button>
						<Button
							size="icon"
							className="bg-inherit hover:bg-inherit text-black"
							onClick={() => handleEdit(transaction)}
						>
							<Pencil className="h-4 w-4" />
						</Button>
					</div>
				);
			},
		},
	];
	const handleFilterByChange = (params) => {
		setFilterType(params);
	};
	const otherFilterFields = () => {
		return (
			<div className="flex justify-between ">
				<div className="flex space-x-3">
					<div className="flex space-x-2">
						<DropdownMenu>
							<DropdownMenuTrigger asChild>
								<Button variant="outline" className="ml-auto">
									Add Transaction
									<ChevronDownIcon className="ml-2 h-4 w-4" />
								</Button>
							</DropdownMenuTrigger>
							<DropdownMenuContent align="end">
								<DropdownMenuItem
									className="ml-auto"
									onClick={handleAddPayment}
								>
									Add Payment
								</DropdownMenuItem>
								<DropdownMenuItem
									className="ml-auto"
									onClick={handleAddReceipt}
								>
									Add Receipt
								</DropdownMenuItem>
							</DropdownMenuContent>
						</DropdownMenu>
					</div>
				</div>
			</div>
		);
	};

	return (
		<Card className="rounded-md ">
			<CustomTable
				data={tableData}
				columns={myColumns}
				isLoading={isLoading}
				error={error}
				tableHeader="Bank Transactions"
				tableWidth="100%"
				paginationData={pagination_data}
				pageChangeCount={setChangePageCount}
				totalRowCount={setTotalRowCount}
				getSerchValue={setSearchValue}
				serchPlaceholder={"Search"}
				filterFields={otherFilterFields()}
			/>

			<Custom_Sheet
				isOpen={isSheetOpen}
				onClose={() => setIsSheetOpen(false)}
				activeKey={activeSheetType}
				editId={editTransactionData}
				isWideSheet="50%"
			/>
		</Card>
	);
};

export default BankTransactionsPage;
