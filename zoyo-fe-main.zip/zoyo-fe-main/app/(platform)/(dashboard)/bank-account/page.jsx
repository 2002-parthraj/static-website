"use client";
import React, { useState } from "react";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Pencil, PencilLine, Trash2 } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import CustomTable from "@/components/custom-table/custom-table";
import { toast } from "sonner";
import { getAllBankAccountData } from "@/actions/bank-account/get-all-bankAccount";
import { deleteBankAccount } from "@/actions/bank-account/delete-bankAccount";
import { useRouter } from "next/navigation";

const BankAccountPage = () => {
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editBankAccountData, setEditBankAccountData] = useState(null);
  const router = useRouter();

  const queryClient = useQueryClient();

  const { confirmDelete } = useDeleteConfirmation();

  const {
    data: bankAccounts,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: getAllBankAccountData,
    onError: (error) => {
      toast.error(error || "Failed to load state list. Please try again.");
    },
  });

  const tableData = bankAccounts?.data?.data;

  const deleteMutation = useMutation({
    mutationFn: (id) => deleteBankAccount(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["bankAccounts"] });

      if (!data?.message) {
        toast.error(data || data?.message || "Something Went Wrong");
      } else {
        toast.success(data?.message || "Bank Account deleted successfully");
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to delete the Bank Account. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (bankAccount) => {
    try {
      confirmDelete(
        `Are you sure you want to delete Bank Account ${bankAccount?.name}?`,
        () => {
          deleteMutation.mutate(bankAccount.id);
        }
      );
    } catch (error) {
      console.error("Failed to delete tax group:", error);
    }
  };

  const handleEdit = (data) => {
    setIsSheetOpen(true);
    setEditBankAccountData(data);
  };

  const handleAddAccount = () => {
    setEditBankAccountData(null); // Reset edit data when adding a new account
    setIsSheetOpen(true); // Open sheet for adding
  };

  const handleAccountNameClick = (accountId) => {
    router.push(`bank-account/bank-transactions/${accountId}`);
  };

  const myColumns = [
    {
      id: "bankName",
      accessorKey: "bankName",
      lable: "Bank Name",
      width: 200,
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">Bank Name</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div
            className="overflow-hidden text-ellipsis whitespace-nowrap cursor-pointer hover:text-blue-500"
            onClick={() => handleAccountNameClick(row.original.id)}
          >
            {row?.getValue("bankName")}
          </div>
        </div>
      ),
    },
    {
      id: "name",
      accessorKey: "name",
      lable: "Account Name",
      width: 200,
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">Account Name</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div
            className="overflow-hidden text-ellipsis whitespace-nowrap cursor-pointer hover:text-blue-500"
            onClick={() => handleAccountNameClick(row.original.id)}
          >
            {row?.getValue("name")}
          </div>
        </div>
      ),
    },
    {
      id: "accountNumber",
      accessorKey: "accountNumber",
      lable: " Account No.",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">Account No.</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("accountNumber")}
          </div>
        </div>
      ),
    },
    {
      id: "ifscCode",
      accessorKey: "ifscCode",
      lable: "IFSC Code",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">IFSC Code</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("ifscCode")}
          </div>
        </div>
      ),
    },
    {
      id: "balance",
      accessorKey: "balance",
      lable: "Balance",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">Balance</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {Number(row?.getValue("balance") || 0).toFixed(2)}
          </div>
        </div>
      ),
    },

    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                onClick={() => handleDelete(userdata)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      },
    },
  ];

  const otherFilterFields = () => {
    return <div className=" pt-4 pb-4 flex justify-between "></div>;
  };

  return (
    <Card className="rounded-md ">
      <CustomTable
        data={tableData}
        columns={myColumns}
        isLoading={isLoading}
        error={error}
        tableHeader="Accounts"
        tableWidth="100%"
        addbuttonLable={"Add Account"}
        onClickAddbutton={handleAddAccount}
        filterFields={otherFilterFields()}
        module="bank-accounts"
      />

      <Custom_Sheet
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        activeKey={"bankAccount"}
        editId={editBankAccountData}
      />
    </Card>
  );
};

export default BankAccountPage;
