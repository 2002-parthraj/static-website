import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  GlobalCheckbox,
  GlobalSwitch,
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { toast } from "sonner";
import { addBankAccount } from "@/actions/bank-account/add-bankAccount";
import { editBankAccount } from "@/actions/bank-account/edit-bankAccount";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ReloadIcon } from "@radix-ui/react-icons";

const formSchema = z.object({
  name: z
    .string()
    .min(1, "Name must be at least 1 character long")
    .max(100, "Name can't be longer than 100 characters")
    .nonempty("Name is required"),

  accountNumber: z
    .string({ message: "Please enter a account number" })
    .trim()
    .nonempty("Please enter a account number.")
    .refine((value) => !value || /^\d+$/.test(value), {
      message: "Account number must contain only digits.",
    })
    .refine((value) => !value || (value.length >= 9 && value.length <= 18), {
      message: "Account number must be between 9 and 18 digits long.",
    }),
  bankName: z
    .string()
    .max(100, "Bank name can't be longer than 100 characters")
    .optional(),
  ifscCode: z
    .string()
    .trim()
    .nonempty("Please enter a IFSC code.")
    .optional()
    .nullable()
    .refine((value) => !value || /^[A-Z]{4}0[A-Z0-9]{6}$/.test(value), {
      message:
        "IFSC code must be in the format: 4 uppercase letters, followed by a '0', and then 6 alphanumeric characters (e.g., ABCD0123456).",
    }),
  branch: z
    .string()
    .max(100, "Branch can't be longer than 100 characters")
    .optional(),
  description: z.string().optional(),
  isDefault: z.boolean().default(false),
});
export const AddEditBankAccountForm = ({ bankAccount = null, onClose }) => {
  const queryClient = useQueryClient();
  const isEditing = !!bankAccount;

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: bankAccount?.name || "",
      accountNumber: bankAccount?.accountNumber || "",
      bankName: bankAccount?.bankName || "",
      ifscCode: bankAccount?.ifscCode || "",
      branch: bankAccount?.branch || "",
      description: bankAccount?.description || "",
      isDefault: bankAccount?.isDefault || false,
    },
  });

  useEffect(() => {
    if (bankAccount) {
      form.reset({
        name: bankAccount?.name || "",
        accountNumber: bankAccount?.accountNumber || "",
        bankName: bankAccount?.bankName || "",
        ifscCode: bankAccount?.ifscCode || "",
        branch: bankAccount?.branch || "",
        description: bankAccount?.description || "",
        isDefault: bankAccount?.isDefault || false,
      });
    }
  }, [bankAccount, form]);

  const addBankAccountsMutation = useMutation({
    mutationFn: addBankAccount,
    onSuccess: handleMutationSuccess,
    onError: handleMutationError,
  });

  const editBankAccountMutation = useMutation({
    mutationFn: (data) => editBankAccount(data, bankAccount.id),
    onSuccess: handleMutationSuccess,
    onError: handleMutationError,
  });

  function handleMutationSuccess(data) {
    queryClient.invalidateQueries({ queryKey: ["bankAccounts"] });
    if (data?.status === 200 || data?.status === 201) {
      form.reset();
      onClose?.();
      toast.success(
        `Bank Account ${isEditing ? "updated" : "added"} successfully`
      );
    } else if (data?.status === 409) {
      toast.warning(data?.data?.error[0]?.message || "A conflict occurred");
    } else {
      toast.error(
        data?.response?.data?.error[0]?.message ||
          "An unexpected error occurred"
      );
    }
  }

  function handleMutationError(error) {
    toast.error(error || "Something went wrong, try again");
  }

  function onSubmit(values) {
    const filteredValues = Object.fromEntries(
      Object.entries(values).filter(
        ([key, value]) => value !== "" || key === "isDefault"
      )
    );
    if (isEditing) {
      editBankAccountMutation.mutate(filteredValues);
    } else {
      addBankAccountsMutation.mutate(filteredValues);
    }
  }
  return (
    <>
      <div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
        <h2 className="text-lg font-semibold">
          {isEditing ? "Edit Bank Account" : "Add Bank Account"}
        </h2>
      </div>

      <Form {...form} className="p-4">
        <form
          id="bankAccountForm"
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-4 "
        >
          <main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto">
            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form="form"
                name="name"
                label="Account Name"
                type="text"
                placeholder="Enter Account Name Here"
                className="flex flex-col space-y-1.5"
                required
              />
            </div>
            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form="form"
                name="accountNumber"
                label="Account No"
                type="text"
                placeholder="Enter Account No. Here"
                className="flex flex-col space-y-1.5"
              />
            </div>
            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form="form"
                name="bankName"
                label="Bank Name"
                type="text"
                placeholder="Enter Bank Name Here"
                className="flex flex-col space-y-1.5"
              />
            </div>
            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form="form"
                name="ifscCode"
                label="IFSC Code"
                type="text"
                placeholder="Enter IFSC Code Here"
                className="flex flex-col space-y-1.5"
              />
            </div>

            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form="form"
                name="branch"
                label="Branch"
                type="text"
                placeholder="Enter Branch Name Here"
                className="flex flex-col space-y-1.5"
              />
            </div>

            <div className="w-[90%] pt-4 mx-auto">
              <TextareaInputField
                form="form"
                name="description"
                label="Remarks"
                placeholder="Write Your Remarks Here"
                className="flex flex-col space-y-1.5"
              />
            </div>

            <div className="w-[90%] pt-4 mx-auto">
              <GlobalSwitch
                form={form}
                name="isDefault"
                label="This Is Default Bank Account"
                className="p-0"
                switchClassName="data-[state=checked]: "
              />
            </div>
          </main>
          <div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0 h-[76px] left-0 w-full p-4 shadow-lg">
            <Button
              type="submit"
              form="bankAccountForm"
              className="  mr-3 mt-1 text-white  "
              disabled={
                addBankAccountsMutation.isPending ||
                editBankAccountMutation.isPending
              }
            >
              {editBankAccountMutation.isPending ||
              addBankAccountsMutation.isPending ? (
                <>
                  <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                  {editBankAccountMutation.isPending
                    ? "Updating..."
                    : "Adding..."}
                </>
              ) : isEditing ? (
                "Update"
              ) : (
                "Add"
              )}
            </Button>
          </div>
        </form>
      </Form>
    </>
  );
};
