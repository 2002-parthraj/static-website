"use client";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";

import { ReloadIcon } from "@radix-ui/react-icons";

import { getItemsMasterData } from "@/actions/items/get-master-data";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

import {
	FormSelectField,
	RadioGroupField,
	TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";

import { GlobalAutoCompleteCombobox } from "@/components/custom-multiselect-dropdown/custom-multi-select-autocomplate";
import { addPriceList } from "@/actions/pricelist/add-price-list";
import { getPriceListById } from "@/actions/pricelist/get-single-price-list";
import { editPriceList } from "@/actions/pricelist/edit-price-list";

import { markUpOption } from "@/components/enums/enums";
import { itemOption } from "@/components/enums/enums";

const formSchema = z.object({
	allItems: z
		.boolean()
		.refine((val) => val === true || val === false, "All Items is required"),
	name: z
		.string()
		.min(1, "Name is required")
		.max(255, "Maximum length is 255 characters"),
	categoryId: z.array(z.string()).optional(),
	locationId: z.array(z.string()).optional(),
	groupId: z.array(z.string()).optional(),
	markUPtype: z.string().min(1, "Markup is required"),
	percentage: z
		.preprocess(
			(value) => (value === "" ? undefined : Number(value)),
			z.number().optional(),
		)
		.refine((value) => value === undefined || !Number.isNaN(value), {
			message: "Percentage must be a valid number",
		})
		.refine(
			(value) =>
				value === undefined || /^\d{1,10}(\.\d{1,4})?$/.test(value.toString()),
			{
				message: "Sales rate must have up to 10 digits and 4 decimal places",
			},
		),
});

const AddEditPriceList = ({ onClose, editId }) => {
	const queryClient = useQueryClient();

	const { data: masterData, error } = useQuery({
		queryKey: ["master-data"],
		queryFn: () => getItemsMasterData(),
	});

	const { data: initialData } = useQuery({
		queryKey: ["pricelist", editId],
		queryFn: () => getPriceListById(editId.id),
		enabled: !!editId, // only run this query if editId is present
	});

	const [isFormSubmitting, setIsFormSubmitting] = useState(false);

	const [locationData, setLocationData] = useState([]);

	const [initialGroupData, setInitialGroupData] = useState([]);
	const [initialCategoriesData, setInitialCategoriesData] = useState([]);

	function convertToNumber(array) {
		return array?.map((val) => {
			return Number(val);
		});
	}

	function convertToString(array) {
		if (Array.isArray(array)) {
			return array.map((val) => String(val));
		}
		return [];
	}

	useEffect(() => {
		if (masterData) {
			setLocationData(masterData?.data?.locations);

			setInitialGroupData(masterData?.data?.groups);
			setInitialCategoriesData(masterData?.data?.categories);
		}
	}, [masterData]);

	const form = useForm({
		resolver: zodResolver(formSchema),
		defaultValues: {
			allItems: true,
			name: "",
			categoryId: [],
			locationId: [],
			groupId: [],
			markUPtype: "markup",
			percentage: "",
		},
	});

	useEffect(() => {
		if (initialData) {
			form.setValue("allItems", initialData?.allItems);
			form.setValue("name", initialData?.name || "");
			form.setValue("percentage", initialData?.percentage || "");
			form.setValue("markUPtype", initialData?.markup ? "markup" : "markdown");

			form.setValue(
				"categoryId",
				convertToString(initialData?.categoryId || []),
			);
			form.setValue(
				"organizationId",
				convertToString(initialData?.organizationId || []),
			);
			form.setValue(
				"locationId",
				convertToString(initialData?.locationId) || [],
			);
			form.setValue("groupId", convertToString(initialData?.groupId) || []);
		}
	}, [initialData, form]);

	const { mutate: addPriceListMutation, isLoading } = useMutation({
		mutationFn: (payload) => addPriceList(payload),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["pricelist"] });

			if (data?.status === 201) {
				toast.success("Price list added successfully");
				setIsFormSubmitting(false);
				form.reset();
				onClose(false);
			} else {
				toast.error(data?.data?.error?.[0]?.message || "Something went wrong");
				setIsFormSubmitting(false);
			}
		},
		onError: (error) => {
			toast.error(
				`Failed to add price list. Error: ${
					error?.message || "Something went wrong"
				}`,
			);
			setIsFormSubmitting(false);
		},
	});

	const { mutate: editPriceListMutation } = useMutation({
		mutationFn: (payload) => editPriceList(payload, editId?.id),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["pricelist"] });

			if (data?.status === 200) {
				toast.success("Price list edited successfully");
				setIsFormSubmitting(false);
				form.reset();
				onClose(false);
			} else {
				toast.error(data?.data?.error?.[0]?.message || "Something went wrong");
				setIsFormSubmitting(false);
			}
		},
		onError: (error) => {
			toast.error(
				`Failed to edit price list. Error: ${
					error?.message || "Something went wrong"
				}`,
			);
			setIsFormSubmitting(false);
		},
	});

	const onSubmit = (values) => {
		setIsFormSubmitting(true);

		const categotiesValues = values?.categoryId;
		const locationValues = values?.locationId;
		const groupValues = values?.groupId;

		const finalPayload = {};

		finalPayload.allItems = values.allItems;
		if (values?.name) finalPayload.name = values.name;
		if (categotiesValues.length !== 0)
			finalPayload.categoryId = convertToNumber(categotiesValues);
		if (locationValues.length !== 0)
			finalPayload.locationId = convertToNumber(locationValues);
		if (groupValues.length !== 0)
			finalPayload.groupId = convertToNumber(groupValues);
		if (values?.markUPtype)
			finalPayload.markup = values?.markUPtype === "markup";
		if (values?.percentage) finalPayload.percentage = values?.percentage;

		if (editId) {
			editPriceListMutation(finalPayload);
		} else {
			addPriceListMutation(finalPayload);
		}
	};

	const categoryOption = initialCategoriesData?.map((val, ind) => ({
		value: `${val?.id}`,
		label: val?.name,
		isActive: val?.isActive 
	}));

	const locationOption = locationData?.map((val, ind) => ({
		value: `${val?.id}`,
		label: val?.name,
		isActive: val?.isActive 
	}));


	const groupOption = initialGroupData?.map((val, ind) => ({
		value: `${val?.id}`,
		label: val?.name,
		isActive: val?.isActive 
	}));

	return (
		<>
			<div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
				<h2 className="text-lg font-semibold">
					{editId ? "Edit Price List" : "Add Price List"}
				</h2>
			</div>
			<Form {...form}>
				<form onSubmit={form.handleSubmit(onSubmit)}>
					<main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto  ">
						<div className="mx-auto w-[90%] gap-4 pt-4">
							<RadioGroupField
								control={form.control}
								name="allItems"
								label="Items"
								options={itemOption}
							/>
						</div>

						<div className="w-[90%] pt-4 mx-auto">
							{/* <FormSelectField */}
							<RadioGroupField
								control={form.control}
								name={"markUPtype"}
								label={"Markup Type"}
								options={markUpOption}
							/>
						</div>

						<div className="w-[90%] pt-4 mx-auto">
							<TextInputField
								form={form}
								name="name"
								placeholder="Enter Price List Name Here"
								label="Price List Name"
								type="text"
								required
							/>
						</div>

						<div className="w-[90%] pt-4 pb-4 mx-auto">
							<TextInputField
								form={form}
								name="percentage"
								placeholder="Enter Percentage Amount"
								label="Percentage(%)"
								type="text"
							/>
						</div>

						{!form.watch("allItems") ? (
							<div className="border-t-4 border-gray-100 ">
								<div className="w-[90%] pt-4 mx-auto">
									<Controller
										name="categoryId"
										control={form.control}
										render={({ field }) => (
											<GlobalAutoCompleteCombobox
												label="Categories"
												placeholder="Choose Categories"
												options={categoryOption}
												field={field}
												onSelect={(values) => field.onChange(values)}
												error={form?.errors?.categories}
												disableKey="isActive"  // Specify which key to check
                                                disableValue={false}   // Disable when isActive is false
											/>
										)}
									/>
								</div>

								<div className="w-[90%] pt-4 mx-auto">
									<Controller
										name="locationId"
										control={form.control}
										render={({ field }) => (
											<GlobalAutoCompleteCombobox
												label="Locations"
												placeholder="Choose Locations"
												options={locationOption}
												field={field}
												onSelect={(values) => field.onChange(values)}
												error={form?.errors?.locationId}
												disableKey="isActive"  // Specify which key to check
                                                disableValue={false}   // Disable when isActive is false
											/>
										)}
									/>
								</div>
								<div className="w-[90%] pt-4 mx-auto">
									<Controller
										name="groupId"
										control={form.control}
										render={({ field }) => (
											<GlobalAutoCompleteCombobox
												label="Groups"
												placeholder="Choose Groups"
												options={groupOption}
												field={field}
												onSelect={(values) => field.onChange(values)}
												error={form?.errors?.locationId}
												disableKey="isActive"  // Specify which key to check
                                                disableValue={false}   // Disable when isActive is false
											/>
										)}
									/>
								</div>
							</div>
						) : null}
					</main>

					<div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0  h-[76px] left-0 w-full p-4 shadow-lg">
						<Button
							type="submit"
							className="  mr-3 mt-1 text-white  "
							disabled={isFormSubmitting}
						>
							{isFormSubmitting ? (
								<>
									<ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
									{editId ? "Updating..." : "Saving..."}
								</>
							) : editId ? (
								"Update Price List"
							) : (
								"Add Price List"
							)}
						</Button>
					</div>
				</form>
			</Form>
		</>
	);
};

export default AddEditPriceList;
