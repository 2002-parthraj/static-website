"use client";
import React, { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowDownLeft,
  ArrowUpRight,
  ChevronDown,
  ChevronsUpDown,
  ChevronUp,
  ListFilter,
  MoveDownLeft,
  Pencil,
  PencilLine,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import CustomTable from "@/components/custom-table/custom-table";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { format } from "date-fns";
import { getAllGroups } from "@/actions/groups/get-all-groups";
import { deleteGroup } from "@/actions/groups/delete-group";
import { getAllpriceList } from "@/actions/pricelist/get-all-pricelist";
import { deletePriceList } from "@/actions/pricelist/delete-price-list";
import useDebounce from "@/hooks/use-debounce";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { patchtogglePriceListsStatus } from "@/actions/pricelist/toggle-pricelist-status";
import { useStatusToggleStore } from "@/hooks/stores/use-status-toggle-store";

const PriceList = () => {
  const queryClient = useQueryClient();

  const { confirmDelete } = useDeleteConfirmation();
  const openConfirmDialog = useStatusToggleStore(
    (state) => state.openConfirmDialog
  );

  const [changePageCount, setChangePageCount] = useState(1);
  const [sortBy, setSortBy] = useState("createdAt");
  const [sortOrder, setSortOrder] = useState("desc");
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");

  const [selectedItemId, setSelectedItemId] = useState(null);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editUserData, setEditUserData] = useState(null);

  const debouncedSearchValue = useDebounce(searchValue, 500);

  const { data, isLoading, error } = useQuery({
    queryKey: [
      "pricelist",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
    ],
    queryFn: () =>
      getAllpriceList(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue
      ),
  });

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const formatDateToISO = (date) => {
    if (!date) return null;
    return format(date, "yyyy-MM-dd");
  };

  const deleteMutation = useMutation({
    mutationFn: (id) => deletePriceList(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["pricelist"] });

      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(data?.data?.message || "Price list deleted successfully");
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to delete the party. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (userId) => {
    confirmDelete(`Price : ${userId?.name}`, () => {
      deleteMutation.mutate(userId?.id);
    });
  };

  const handleEdit = (userdata) => {
    setIsSheetOpen(true);
    setEditUserData(userdata);
  };

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const toggleStatusMutation = useMutation({
    mutationFn: (id) => patchtogglePriceListsStatus(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["pricelist"] });

      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(data?.data?.message);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed . Error: ${error?.message || error || "Something went wrong"}`
      );
    },
  });

  const handleStatusToggle = (id, currentStatus) => {
    openConfirmDialog({
      itemId: id,
      currentStatus: currentStatus,
      entityType: "Price List",
      onConfirmCallback: (itemId) => {
        toggleStatusMutation.mutate(itemId);
      },
    });
  };

  const myColumns = [
    {
      id: "select",
      header: ({ table }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedItemId !== null}
            onCheckedChange={(value) => {
              if (!value) {
                setSelectedItemId(null);
                table?.toggleAllPageRowsSelected(false);
              }
            }}
            aria-label="Select item"
          />
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedItemId === row.original.id}
            onCheckedChange={(value) => {
              if (value) {
                setSelectedItemId(row.original.id);
              } else {
                setSelectedItemId(null);
              }
            }}
            aria-label="Select row"
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
    },

    {
      id: "name",
      accessorKey: "name",
      lable: "List Name",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("name")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("name");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              List Name
              {renderSortIcon("name")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("name")}
          </div>
        </div>
      ),
    },
    {
      id: "percentage",
      accessorKey: "percentage",
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("percentage")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("percentage");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Percentage
              {renderSortIcon("percentage")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("percentage") || 0}%
          </div>
        </div>
      ),
    },

    {
      id: "markup",
      accessorKey: "markup",
      lable: "Markup type",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-nowrap text-gray-900"
            onClick={() => onSortChange("markup")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("markup");
              }
            }}
          >
            <span className="flex items-center gap-1">
              Markup type
              {renderSortIcon("markup")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">
          {row?.getValue("markup") ? (
            <Badge className="text-emerald-700 bg-emerald-50">
              UP <ArrowUpRight size={15} />
            </Badge>
          ) : (
            <Badge className="text-rose-700 bg-rose-50">
              DOWN <ArrowDownLeft size={15} />{" "}
            </Badge>
          )}
        </div>
      ),
    },
    {
      id: "isActive",
      accessorKey: "isActive",
      lable: "Status",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-nowrap text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Status
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex items-center justify-left">
          <Switch
            checked={row.getValue("isActive")}
            onCheckedChange={() => {
              handleStatusToggle(row.original.id, row.getValue("isActive"));
            }}
            className="data-[state=checked]: "
            aria-label="Toggle status"
          />
          <span className="text-sm font-medium pl-2 text-black w-16 text-left">
            {row.getValue("isActive") ? "Active" : "Inactive"}
          </span>
        </div>
      ),
    },
    {
      id: "createdAt",
      accessorKey: "createdAt",
      lable: "Created On",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("createdAt")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("createdAt");
              }
            }}
          >
            <span className="flex items-center gap-1">
              Created On
              {renderSortIcon("createdAt")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const date = new Date(row?.original.createdAt);
        const formattedDate = date
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          })
          .split("/")
          .join("-");

        return <div className="text-left">{formattedDate}</div>;
      },
    },

    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                onClick={() => handleDelete(userdata)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      },
    },
  ];

  const otherFilterFields = () => {
    return <div className=" pt-4 pb-4 flex justify-between "></div>;
  };

  const handleAddPriceList = () => {
    setEditUserData(null);
    setIsSheetOpen(true); // Open sheet for adding
  };

  const otherFields = () => {
    return (
      <>
        <div className="p-4 flex justify-between">
          <div className="flex space-x-3">tt</div>
        </div>
      </>
    );
  };

  const tableData = data?.data?.data;
  const pagination_data = data?.data?.pagination;

  return (
    <Card className="rounded-md">
      <CustomTable
        data={tableData || []}
        columns={myColumns || []}
        isLoading={isLoading}
        error={error}
        tableHeader="Price List"
        tableWidth={"100%"}
        paginationData={pagination_data}
        pageChangeCount={setChangePageCount}
        totalRowCount={setTotalRowCount}
        getSerchValue={setSearchValue}
        serchPlaceholder={"Search"}
        addbuttonLable={"Add Price List"}
        onClickAddbutton={handleAddPriceList}
        filterFields={otherFilterFields()}
      />

      <Custom_Sheet
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        activeKey={"pricelist"}
        editId={editUserData}
      />
    </Card>
  );
};

export default PriceList;
