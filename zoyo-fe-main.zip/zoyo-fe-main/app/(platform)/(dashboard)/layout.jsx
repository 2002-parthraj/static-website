"use client";
import React, { useState } from "react";
import { Sidebar } from "./_components/sidebar";
import { Navbar } from "./_components/navbar";
import { cn } from "@/lib/utils";
import { ProtectedRoute } from "@/components/ProtectedRoute";
const SIDEBAR_WIDTH = {
  open: "w-64",
  closed: "w-16",
};
const DashboardLayout = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  // Remove the useEffect since we don't need to manually set axios headers anymore
  // Cookies will be automatically sent with requests
  return (
    <ProtectedRoute>
      <div className="h-screen flex relative overflow-hidden">
        <div
          className={cn(
            "absolute top-0 left-0 h-full z-50 transition-all duration-300",
            isSidebarOpen ? SIDEBAR_WIDTH.open : SIDEBAR_WIDTH.closed
          )}
        >
          <Sidebar
            isSidebarOpen={isSidebarOpen}
            setIsSidebarOpen={setIsSidebarOpen}
          />
        </div>
        <div className="flex-1 overflow-auto bg-slate-100 flex-col pl-16">
          <Navbar isSidebarOpen={isSidebarOpen} />
          <main className="p-4 h-vh-minus-50 bg-slate-100">{children}</main>
        </div>
      </div>
    </ProtectedRoute>
  );
};
export default DashboardLayout;
