"use client";

import React, { useEffect, useState } from "react";
import CustomTable from "@/components/custom-table/custom-table";
import { Checkbox } from "@/components/ui/checkbox";
import {
  ChevronDown,
  ChevronUp,
  Copy,
  EllipsisVertical,
  PencilLine,
  Send,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import useDebounce from "@/hooks/use-debounce";
import { Badge } from "@/components/ui/badge";
import { getAllVendorCredit } from "@/actions/vendor-credit/get-all-vendorCredit";
import { deleteVendoreCredit } from "@/actions/vendor-credit/delete-vendorCredit";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Card } from "@/components/ui/card";
import { DropdownMenuSeparator } from "@radix-ui/react-dropdown-menu";
import CustomGlobalPDFdownloader from "@/components/custom-global-pdf-download/custom-global-pdf-download";
import CustomPdfViewer from "@/components/custom-global-pdf-download/custom-preview-template";
import CustomGlobalBulkPDFdownloader from "@/components/custom-global-pdf-download/custom-bulk-pdf";

const VandorCreditpage = () => {
  const queryClient = useQueryClient();

  const router = useRouter();

  const { confirmDelete } = useDeleteConfirmation();

  const [sortBy, setSortBy] = useState("date");
  const [selectedPartyId, setSelectedPartyId] = useState(null);
  const [sortOrder, setSortOrder] = useState("desc");
  const [changePageCount, setChangePageCount] = useState(1);
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");
  const [status, setStatus] = useState({
    key: "all",
    heading: "All",
  });
  const [filterBy, setFilterBy] = useState({
    key: "goods",
    heading: "Goods",
  });
  const [selectedPartyIds, setSelectedPartyIds] = useState([]);

  const debouncedSearchValue = useDebounce(searchValue, 500);

  const {
    data: PurchaseOrderListing,
    isLoading,
    error,
  } = useQuery({
    queryKey: [
      "VandorCredit-listing",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
      status,
      filterBy,
    ],
    queryFn: () =>
      getAllVendorCredit(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue,
        status,
        filterBy
      ),
  });

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const deleteMutation = useMutation({
    mutationFn: (id) => deleteVendoreCredit(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["VandorCredit-listing"] });

      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(
          data?.data?.message || "Debit Notes  deleted successfully"
        );
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to delete the Debit Notes Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (userId) => {
    confirmDelete(`Vendor credit ${userId?.partyName}`, () => {
      deleteMutation.mutate(userId?.id);
    });
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderStatusBadge = (status) => {
    if (status === "sent") {
      return (
        <Badge
          variant="outline"
          className={"text-yellow-500  bg-amber-50 rounded-3xl"}
        >
          Sent
        </Badge>
      );
    }

    if (status === "open") {
      return (
        <Badge
          variant="outline"
          className={"text-yellow-500  bg-amber-50 rounded-3xl"}
        >
          Open
        </Badge>
      );
    }

    if (status === "draft") {
      return (
        <Badge
          variant="outline"
          className={"text-slate-900 bg-slate-100 rounded-3xl"}
        >
          Draft
        </Badge>
      );
    }

    if (status === "unpaid") {
      return (
        <Badge
          variant="outline"
          className={"text-red-600 bg-red-50 rounded-3xl"}
        >
          Unpaid
        </Badge>
      );
    }

    if (status === "partial") {
      return (
        <Badge
          variant="outline"
          className={"text-orange-800 bg-orange-50 rounded-3xl"}
        >
          Partial
        </Badge>
      );
    }

    if (status === "paid") {
      return (
        <Badge
          variant="outline"
          className={"text-green-600 bg-green-50 rounded-3xl"}
        >
          Paid
        </Badge>
      );
    }

    if (status === "closed") {
      return (
        <Badge
          variant="outline"
          className={"text-gray-600 bg-gray-50 rounded-3xl"}
        >
          Closed
        </Badge>
      );
    }

    if (status === "invoiced") {
      return (
        <Badge
          variant="outline"
          className={"text-gray-600 bg-gray-50 rounded-3xl"}
        >
          Invoiced
        </Badge>
      );
    }

    return null;
  };

  const myEstimatesColumns = [
    {
      id: "select",
      header: ({ table }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={
              selectedPartyIds.length === table.getRowModel().rows.length
            }
            onCheckedChange={(value) => {
              if (value) {
                const allIds = table
                  .getRowModel()
                  .rows.map((row) => ({ id: row.original.id }));
                setSelectedPartyIds(allIds);
                table.toggleAllPageRowsSelected(true);
              } else {
                setSelectedPartyIds([]);
                table.toggleAllPageRowsSelected(false);
              }
            }}
            aria-label="Select all rows"
          />
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedPartyIds.some(
              (item) => item.id === row.original.id
            )}
            onCheckedChange={(value) => {
              if (value) {
                setSelectedPartyIds((prev) => [
                  ...prev,
                  { id: row.original.id },
                ]);
              } else {
                setSelectedPartyIds((prev) =>
                  prev.filter((item) => item.id !== row.original.id)
                );
              }
            }}
            aria-label="Select row"
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
    },
    {
      id: "voucherNumber",
      accessorKey: "voucherNumber",
      lable: "Debit Note No.",

      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("voucherNumber")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("voucherNumber");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Debit Note No.
              {renderSortIcon("voucherNumber")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left ">{row?.getValue("voucherNumber")}</div>
      ),
    },
    {
      id: "date",
      accessorKey: "date",
      lable: "Date",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("date")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("date");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span style={{ display: "flex", alignItems: "center" }}>
              Date
              {renderSortIcon("date")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const date = new Date(row?.original.date);
        const formattedDate = date
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          })
          .split("/")
          .join("-");

        return <div className="text-left">{formattedDate}</div>;
      },
    },

    {
      id: "partyName",
      accessorKey: "partyName",
      lable: " Party Name",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("partyName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("partyName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Party Name
              {renderSortIcon("partyName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left ">{row?.getValue("partyName")}</div>
      ),
    },

    {
      id: "status",
      accessorKey: "status",
      lable: "Status",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("status")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("status");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Status
              {renderSortIcon("status")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left capitalize">
          {renderStatusBadge(row?.getValue("status"))}
        </div>
      ),
    },

    {
      id: "total",
      accessorKey: "total",
      lable: "Amount",
      header: ({ column }) => (
        <div className="flex justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("total")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("total");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Amount
              {renderSortIcon("total")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right ">
          {" "}
          {Number(row?.getValue("total") || 0).toFixed(2)}
        </div>
      ),
    },

    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className=" flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit  shadow-none border text-black"
                onClick={() => handleEstimatesEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className=" flex items-center">
              <CustomPdfViewer
                userdata={userdata}
                voucherType={"vendorCredit"}
              />
            </div>
            <div className="border-r border-gray-300 flex items-center">
              <div className="flex items-center mr-2">
                <CustomGlobalPDFdownloader
                  userdata={userdata}
                  voucherType={"vendorCredit"}
                />
              </div>
            </div>
            <div className=" flex items-center">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    size="icon"
                    className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                  >
                    <EllipsisVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem
                    className="cursor-pointer"
                    onClick={() => {
                      router.push(`/debit-note/add?clone=${userdata?.id}`);
                    }}
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Voucher
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <Send className="mr-2 h-4 w-4" />
                    Share
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => handleDelete(userdata)}
                    className="cursor-pointer text-red-600"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        );
      },
    },
  ];

  const handleEstimatesEdit = (userdata) => {
    router.push(`/debit-note/${userdata.id}`);
  };

  const ChangeStatus = (param) => {
    setStatus(param);
  };

  const statusOptions = [
    {
      key: "all",
      heading: "All",
    },
    {
      key: "open",
      heading: "Open",
    },
    {
      key: "draft",
      heading: "Draft",
    },
    {
      key: "closed",
      heading: "Closed",
    },
    {
      key: "cancelled",
      heading: "Cancelled",
    },
  ];

  const otherFields = () => {
    return (
      <>
        <div className="pt-4 pb-4 flex justify-between ">
          {selectedPartyIds?.length > 0 ? (
            <div className="flex-shrink-0 pr-4">
              <CustomGlobalBulkPDFdownloader
                userDataArray={selectedPartyIds || []}
                voucherType="vendorCredit"
                setUserArray={setSelectedPartyIds}
              />
            </div>
          ) : null}
          <div className="mr-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center gap-2">
                  {status.heading}
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {statusOptions.map((option) => (
                  <DropdownMenuItem
                    key={option.key}
                    onClick={() => ChangeStatus(option)}
                    className="cursor-pointer"
                  >
                    {option.heading}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </>
    );
  };

  return (
    <main>
      <Card>
        <CustomTable
          data={PurchaseOrderListing?.data?.data || []}
          columns={myEstimatesColumns || []}
          isLoading={isLoading}
          error={error}
          tableHeader="Debit Notes"
          tableWidth={"100%"}
          paginationData={PurchaseOrderListing?.data?.pagination}
          pageChangeCount={setChangePageCount}
          totalRowCount={setTotalRowCount}
          getSerchValue={setSearchValue}
          filterFields={otherFields()}
          serchPlaceholder={"Search"}
          addbuttonLable={"Add Debit Note"}
          onClickAddbutton={() => router.push("/debit-note/add")}
        />
      </Card>
    </main>
  );
};

export default VandorCreditpage;
