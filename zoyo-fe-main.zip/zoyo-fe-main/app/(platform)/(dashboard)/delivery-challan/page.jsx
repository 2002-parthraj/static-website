"use client";
import React, { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ChevronDown,
  ChevronDownIcon,
  ChevronsUpDown,
  ChevronUp,
  Copy,
  EllipsisVertical,
  FileText,
  ListFilter,
  Pencil,
  PencilLine,
  Send,
  Trash2,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { patchtoggleItemStatus } from "@/actions/items/toggle-item-status";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { getAllDeliveryChallan } from "@/actions/delivery_challan/get-all-delivery-challan";
import { Badge } from "@/components/ui/badge";
import { useRouter } from "next/navigation";
import { deleteIDeliveryChallan } from "@/actions/delivery_challan/delete-delivery-challan";
import { Card } from "@/components/ui/card";
import CustomTable from "@/components/custom-table/custom-table";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import useDebounce from "@/hooks/use-debounce";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import CustomGlobalPDFdownloader from "@/components/custom-global-pdf-download/custom-global-pdf-download";
import CustomPdfViewer from "@/components/custom-global-pdf-download/custom-preview-template";
import CustomGlobalBulkPDFdownloader from "@/components/custom-global-pdf-download/custom-bulk-pdf";

const DeliveryChalan = () => {
  const queryClient = useQueryClient();
  const router = useRouter();
  const { confirmDelete } = useDeleteConfirmation();

  const [changePageCount, setChangePageCount] = useState(1);
  const [sortBy, setSortBy] = useState("date");
  const [sortOrder, setSortOrder] = useState("desc");
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [status, setStatus] = useState({
    key: "all",
    heading: "All",
  });

  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editUserData, setEditUserData] = useState(null);
  const [selectedPartyIds, setSelectedPartyIds] = useState([]);

  const debouncedSearchValue = useDebounce(searchValue, 500);

  const { data, isLoading, error } = useQuery({
    queryKey: [
      "delivery-challans",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
      status,
    ],
    queryFn: () =>
      getAllDeliveryChallan(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue,
        status
      ),
  });

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const deleteMutation = useMutation({
    mutationFn: (id) => deleteIDeliveryChallan(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["delivery-challans"] });

      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(
          data?.data?.message || "Delivery challan  deleted successfully"
        );
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to delete the Delivery challan . Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (userId) => {
    confirmDelete(`Item ${userId?.partyName}`, () => {
      deleteMutation.mutate(userId?.id);
    });
  };

  const handleEdit = (userdata) => {
    setEditUserData(userdata?.id);

    router.push(`/delivery-challan/${userdata?.id}`);
  };

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const renderStatusBadge = (status) => {
    if (status === "sent") {
      return (
        <Badge
          variant="outline"
          className={"text-yellow-500  bg-amber-50 rounded-3xl"}
        >
          Sent
        </Badge>
      );
    }

    if (status === "open") {
      return (
        <Badge
          variant="outline"
          className={"text-yellow-500  bg-amber-50 rounded-3xl"}
        >
          Open
        </Badge>
      );
    }

    if (status === "draft") {
      return (
        <Badge
          variant="outline"
          className={"text-slate-900 bg-slate-100 rounded-3xl"}
        >
          Draft
        </Badge>
      );
    }

    if (status === "unpaid") {
      return (
        <Badge
          variant="outline"
          className={"text-red-600 bg-red-50 rounded-3xl"}
        >
          Unpaid
        </Badge>
      );
    }

    if (status === "partial") {
      return (
        <Badge
          variant="outline"
          className={"text-orange-800 bg-orange-50 rounded-3xl"}
        >
          Partial
        </Badge>
      );
    }

    if (status === "paid") {
      return (
        <Badge
          variant="outline"
          className={"text-green-600 bg-green-50 rounded-3xl"}
        >
          Paid
        </Badge>
      );
    }

    if (status === "closed") {
      return (
        <Badge
          variant="outline"
          className={"text-gray-600 bg-gray-50 rounded-3xl"}
        >
          Closed
        </Badge>
      );
    }

    if (status === "invoiced") {
      return (
        <Badge
          variant="outline"
          className={"text-gray-600 bg-gray-50 rounded-3xl"}
        >
          Invoiced
        </Badge>
      );
    }

    return null;
  };

  const myColumns = [
    {
      id: "select",
      header: ({ table }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={
              selectedPartyIds.length === table.getRowModel().rows.length
            }
            onCheckedChange={(value) => {
              if (value) {
                const allIds = table
                  .getRowModel()
                  .rows.map((row) => ({ id: row.original.id }));
                setSelectedPartyIds(allIds);
                table.toggleAllPageRowsSelected(true);
              } else {
                setSelectedPartyIds([]);
                table.toggleAllPageRowsSelected(false);
              }
            }}
            aria-label="Select all rows"
          />
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedPartyIds.some(
              (item) => item.id === row.original.id
            )}
            onCheckedChange={(value) => {
              if (value) {
                setSelectedPartyIds((prev) => [
                  ...prev,
                  { id: row.original.id },
                ]);
              } else {
                setSelectedPartyIds((prev) =>
                  prev.filter((item) => item.id !== row.original.id)
                );
              }
            }}
            aria-label="Select row"
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
    },

    {
      id: "voucherNumber",
      accessorKey: "voucherNumber",
      lable: "Challan No.",

      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("partyName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("voucherNumber");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Challan No.
              {renderSortIcon("voucherNumber")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">
          {row?.getValue("voucherNumber")}
        </div>
      ),
    },

    {
      id: "date",
      accessorKey: "date",
      lable: "Date",

      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("date")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("date");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Date
              {renderSortIcon("date")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const date = new Date(row?.original.date);
        const formattedDate = date
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          })
          .split("/")
          .join("-");

        return <div className="text-left">{formattedDate}</div>;
      },
    },

    {
      id: "partyName",
      accessorKey: "partyName",
      lable: "Party Name",

      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("partyName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("partyName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Party Name
              {renderSortIcon("partyName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">
          {row?.getValue("partyName")}
        </div>
      ),
    },

    {
      id: "status",
      accessorKey: "status",
      lable: "Status",

      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("status")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("status");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Status
              {renderSortIcon("status")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left capitalize">
          {renderStatusBadge(row?.getValue("status"))}
        </div>
      ),
    },

    {
      id: "total",
      accessorKey: "total",
      lable: "Amount",

      header: ({ column }) => (
        <div className="flex justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("total")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("total");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Amount
              {renderSortIcon("total")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right">
          {" "}
          {Number(row?.getValue("total") || 0).toFixed(2)}
        </div>
      ),
    },

    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;

        return (
          <div className="flex justify-end capitalize">
            <div className=" flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit  shadow-none border text-black"
                onClick={() => handleEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className=" flex items-center">
              <CustomPdfViewer
                userdata={userdata}
                voucherType={"deliveryChallan"}
              />
            </div>
            <div className="border-r border-gray-300 flex items-center">
              <div className="flex items-center mr-2">
                <CustomGlobalPDFdownloader
                  userdata={userdata}
                  voucherType={"deliveryChallan"}
                />
              </div>
            </div>
            <div className=" flex items-center">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    size="icon"
                    className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                  >
                    <EllipsisVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {userdata.status === "sent" && (
                    <DropdownMenuItem
                      onClick={() => {
                        router.push(
                          `/invoice/add?voucher=delivery-challans&voucharNumber=${userdata?.id}`
                        );
                      }}
                      className="cursor-pointer"
                    >
                      <Copy className="mr-2 h-4 w-4" />
                      Convert to Invoice
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem
                    className="cursor-pointer"
                    onClick={() => {
                      router.push(
                        `/delivery-challan/add?clone=${userdata?.id}`
                      );
                    }}
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Voucher
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <Send className="mr-2 h-4 w-4" />
                    Share
                  </DropdownMenuItem>

                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => handleDelete(userdata)}
                    className="cursor-pointer text-red-600"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        );
      },
    },
  ];

  const ChangeStatus = (param) => {
    setStatus(param);
    setSelectedItemId(null);
  };

  const toggleItemStatusMutation = useMutation({
    mutationFn: (id) => patchtoggleItemStatus(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["items"] });

      if (!data?.data?.message) {
        toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
      } else {
        toast.success(
          data?.data?.message || "Item activate or inactivate successfully"
        );
        setSelectedItemId(null);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed . Error: ${error?.message || error || "Something went wrong"}`
      );
    },
  });

  const handleActiveInactiveItem = (id) => {
    toggleItemStatusMutation.mutate(id);
  };

  const challanTypeOptions = [
    {
      key: "supplyOfLiquidGas",
      heading: "Supply Of Liquid Gas",
    },
    {
      key: "jobWork",
      heading: "Job Work",
    },
    {
      key: "supplyOnApproval",
      heading: "Supply On Approval",
    },
    {
      key: "others",
      heading: "others",
    },
    {
      key: "all",
      heading: "All",
    },
  ];

  const statusOptions = [
    {
      key: "all",
      heading: "All",
    },
    {
      key: "draft",
      heading: "Draft",
    },
    {
      key: "sent",
      heading: "Sent",
    },
    {
      key: "closed",
      heading: "Closed",
    },
    {
      key: "cancelled",
      heading: "Cancelled",
    },
  ];

  const otherFields = () => {
    return (
      <>
        <div className="pt-4 pb-4 flex justify-between ">
          {selectedPartyIds?.length > 0 ? (
            <div className="flex-shrink-0 pr-4">
              <CustomGlobalBulkPDFdownloader
                userDataArray={selectedPartyIds || []}
                voucherType="deliveryChallan"
                setUserArray={setSelectedPartyIds}
              />
            </div>
          ) : null}
          <div className="mr-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center gap-2">
                  {status.heading}
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {statusOptions.map((option) => (
                  <DropdownMenuItem
                    key={option.key}
                    onClick={() => ChangeStatus(option)}
                    className="cursor-pointer"
                  >
                    {option.heading}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </>
    );
  };

  const tableData = data?.data?.data;
  const pagination_data = data?.data?.pagination;

  const onClickAddbutton = () => {
    router.push("/delivery-challan/add");
  };
  return (
    <main>
      <Card className="rounded-md">
        <CustomTable
          data={tableData || []}
          columns={myColumns || []}
          isLoading={isLoading}
          error={error}
          tableHeader="Delivery challan"
          tableWidth={"100%"}
          paginationData={pagination_data}
          pageChangeCount={setChangePageCount}
          totalRowCount={setTotalRowCount}
          getSerchValue={setSearchValue}
          serchPlaceholder={"Search"}
          filterFields={otherFields()}
          addbuttonLable={"Add Challan "}
          onClickAddbutton={() => onClickAddbutton()}
          module="delivery-challans"
        />
      </Card>

      <Custom_Sheet
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        activeKey={"items"}
        editId={editUserData}
      />
    </main>
  );
};

export default DeliveryChalan;
