"use client";

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useParams, useRouter } from "next/navigation";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import {
  CommonCalendarInput,
  FormSelectField,
  GlobalCheckbox,
  RadioGroupField,
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { Controller, useFieldArray, useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { uploadFile } from "@/actions/items/file-upload";
import {
  fetchInitialPartiesforDeleiveryChalan,
  getSuggestionOfPartiesforDeleiveryChalan,
} from "@/actions/delivery_challan/search-customer-suggestion";
import {
  fetchInitialItemsforComboBox,
  getSuggestionOfItemsforComboBox,
} from "@/actions/estimate/search-items-suggestion";
import useDebounce from "@/hooks/use-debounce";
import { getPartyById } from "@/actions/parties/get-single-party";
import { getItemById } from "@/actions/items/get-single-item";
import { getStatesData } from "@/actions/comman/get-state-data";
import { getVoucherInit } from "@/actions/comman/voucher-init";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import Decimal from "decimal.js";
import {
  Barcode,
  ChevronDown,
  ChevronLeft,
  ChevronUp,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { ReloadIcon } from "@radix-ui/react-icons";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import { Label } from "@/components/ui/label";
import { tdstcsOption } from "@/components/enums/enums";
import { getDeliveryChallanById } from "@/actions/delivery_challan/get-single-dilivary-challan";
import { EditDeliveryChallan } from "@/actions/delivery_challan/edit-delivery-challan";
import { ScrollArea } from "@/components/ui/scroll-area";
import { getAllItemsByBarcode } from "@/actions/items/get-all-items";
import AutoCompletePartySelector from "@/components/custom-party-selections-model/AutoCompletePartySelector";
import AutoCompleteItemSelector from "@/components/custom-party-selections-model/AutoCompleteItemSelector";
import { useBarcodeModalStore } from "@/hooks/stores/use-barcode-modal-store";
import { deleteSalesPerson } from "@/actions/sales-person/delete-sales-person";
import { deletePartyAddress } from "@/actions/comman/delete-address";
import { Switch } from "@/components/ui/switch";
import BarcodeScanner from "../../_components/barcodeComponets/barcode-scanner";
import BarcodeModal from "../../_components/barcodeComponets/BarcodeModal";
import Spinner from "@/components/custom-spinner/spinner";

const STATIC_TAX_OPTIONS = [
  { value: "nonTaxable", label: "Non Taxable" },
  { value: "outOfScope", label: "Out of Scope" },
  { value: "nonGstSupply", label: "Non GST Supply" },
];

const deliveryChallanSchema = z.object({
  isAutoNumber: z.boolean().optional(),
  challanType: z.string().optional(),
  voucherAutoSeriesId: z.number().optional(),
  partyId: z
    .string({ required_error: "Please select a party" })
    .min(1, "Please select a party"),
  partyGstNumber: z.string().optional(),
  placeOfSupplyId: z.string().nullable().optional(),
  billingAddressId: z.string({ message: "Please Select billing address" }),
  shippingAddressId: z
    .string({ message: "Please Select shipping address" })
    .optional(),
  salespersonId: z.string().optional().nullable(),
  templateId: z.string({ message: "Please select template" }),
  priceListId: z.string({ message: "Please select price list" }).optional(),
  voucherNumber: z.string().nullable().optional(),
  referenceNumber: z.string().optional(),
  date: z.date({ message: "Please select delivery challan date " }),
  deliveryDate: z
    .date({ message: "Please select due challan date " })
    .optional(),
  gstTreatment: z.string().optional().nullable(),
  taxableAmount: z.string().optional(),
  taxTotal: z.string().optional(),
  adjustment: z.string().optional(),
  total: z.string().optional(),
  isInclusiveTax: z.boolean(),
  isItemLevelDiscount: z.boolean(),
  isDiscountPercentage: z.boolean().nullable(),
  discountAmount: z.string().nullable(),
  discountRate: z.string().nullable(),
  notes: z.string().optional(),
  terms: z.string().optional(),
  attachment: z.array(z.string()).nullable().default([]),
  status: z.enum(["draft", "sent", "paid"]),
  customFields: z
    .array(
      z.object({
        id: z.number(),
        value: z.string().nullable(),
      })
    )
    .optional()
    .default([])
    .transform((fields) =>
      fields.filter((field) => field.value !== null && field.value !== "")
    ),
  customCharges: z.string().optional(), // Keep as string for form input
  customChargesTaxGroup: z.string().optional(),
  customChargesTaxId: z.string().optional(),
  tdsTcsType: z.enum(["tds", "tcs"]),
  tdsTcsId: z.string().optional(),
  tdsTcsAmount: z.string().optional(),
  lineItems: z.array(
    z.object({
      itemId: z
        .union([z.number({ message: "Please select item " }), z.null()])
        .superRefine((val, ctx) => {
          // Get array path from context
          const arrayPath = ctx.path.slice(0, -1);
          const index = arrayPath[arrayPath.length - 1];

          // Get parent array from data
          let data = ctx.parent;
          while (data && !Array.isArray(data)) {
            data = data.parent;
          }
          if (!data) return true; // Fallback if we can't get the array
          const isLastRow = Number(index) === data.length - 1;
          // Skip validation for empty last row
          if (isLastRow) {
            return true;
          }
          // Validate other rows
          if (!val || val === "") {
            ctx.addIssue({
              code: z.ZodIssueCode.custom,
              message: "Please select item first",
            });
          }
        }),
      description: z.string().nullable().default(""),
      productType: z.enum(["goods", "service"]).optional(),
      hsn: z.string().nullable().optional(),
      quantity: z.string(),
      unitId: z.number().optional(),
      unitName: z.string().optional(),
      unitCode: z.string().optional(),
      unitOptions: z
        .array(
          z.object({
            id: z.number(),
            name: z.string(),
            code: z.string(),
            qty: z.string().optional(), // For alternate units conversion
          })
        )
        .optional(),
      rate: z
        .string({ message: "Please select rate " })
        .superRefine((val, ctx) => {
          // Get array path from context
          const arrayPath = ctx?.path.slice(0, -1);
          const index = arrayPath[arrayPath?.length - 1];

          // Get parent array from data
          let data = ctx?.parent;
          while (data && !Array.isArray(data)) {
            data = data.parent;
          }

          if (!data) return true; // Fallback if we can't get the array

          const isLastRow = Number(index) === data?.length - 1;

          // Skip validation for empty last row
          if (
            isLastRow &&
            (!data[index]?.itemId || data[index]?.itemId === "")
          ) {
            return true;
          }

          // Validate rate for other rows
          const numValue = Number.parseFloat(val);
          if (!Number.isNaN(numValue) && numValue > "0") {
            ctx.addIssue({
              code: z.ZodIssueCode.custom,
              message: "Rate must be greater than 0",
            });
          }
        }),
      isDiscountPercentage: z.boolean(),
      discountRate: z.string().transform((val) => Number(val)),
      discountAmount: z.string().transform((val) => Number(val)),
      taxableAmount: z.string().optional(),
      taxTreatment: z
        .enum(["taxable", "nonTaxable", "outOfScope", "nonGstSupply"])
        .optional()
        .nullable(),
      taxGroup: z
        .union([
          z.object({
            id: z.number(),
            name: z.string(),
            taxSpecification: z.string(),
            taxes: z.array(
              z.object({
                id: z.number(),
                name: z.string(),
                rate: z.number(),
                taxType: z.string(),
                taxAmount: z.number(),
              })
            ),
          }),
          z.string(),
          z.null(), // Allow string for initial form state
        ])
        .nullable(),
    })
  ),
});

const EditDeliveryChallanpage = () => {
  const openModal = useBarcodeModalStore((state) => state.openModal);

  const { id } = useParams();
  const [partyValues, setPartyValues] = useState([]);
  const [itemsValues, setItemsValues] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [selectedItemIndex, setSelectedItemIndex] = useState(null);
  const [taxData, setTaxData] = useState();
  const [isAddPartySheetOpen, setAddPartyIsSheetOpen] = useState(false);
  const [isAddItemSheetOpen, setAddItemIsSheetOpen] = useState(false);
  const [isAddressSheetOpen, setEditAddressIsSheetOpen] = useState(false);
  const [uploadedImageUrls, setUploadedImageUrls] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);
  const [totals, setTotals] = useState({
    taxableAmount: 0,
    taxTotal: 0,
    total: 0,
    totalDiscount: 0,
  });
  const [newlyAddedParty, setNewlyAddedParty] = useState(null);
  const [newlyAddedItem, setNewlyAddedItem] = useState(null);
  const [isPageLoading, setIsPageLoading] = useState(true);
  const [estimateStatus, setEstimateStatus] = useState(null);
  const [customFields, setCustomFields] = useState([]);
  const [processingButton, setProcessingButton] = useState(null);
  const [isTdsTcsManuallyEdited, setIsTdsTcsManuallyEdited] = useState(false);
  const [isPreferenceFiled, setisPreferenceFiled] = useState();
  const [globalDiscountType, setGlobalDiscountType] = useState("percentage");
  const [itemInputValues, setItemInputValues] = useState({});
  const [partyInputValues, setPartyInputValues] = useState({});
  const [addressToEdit, setAddressToEdit] = useState(null);
  const [showExtraFields, setShowExtraFields] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [showDiscount, setShowDiscount] = useState(false);
  const [discountType, setDiscountType] = useState("percentage");
  const [discountValue, setDiscountValue] = useState("");
  const [activeTab, setActiveTab] = useState();
  const [showExtraCharges, setShowExtraCharges] = useState(false);
  const [isBarcodeModalOpen, setIsBarcodeModalOpen] = useState(false);

  const router = useRouter();
  const autoAdjustmentRef = useRef(0);

  const form = useForm({
    resolver: zodResolver(deliveryChallanSchema),
    defaultValues: useMemo(() => {
      return {
        challanType: "others",
        isAutoNumber: false,
        partyGstNumber: "",
        placeOfSupplyId: "",
        date: new Date(),
        gstTreatment: "",
        taxableAmount: 0,
        taxTotal: 0,
        total: 0,
        adjustment: "0",
        isInclusiveTax: false,
        isItemLevelDiscount: false,
        isDiscountPercentage: false,
        discountAmount: null,
        discountRate: null,
        customChargesTaxGroup: "",
        customCharges: "0",
        customChargesTaxId: "",
        attachment: [],
        lineItems: [],
      };
    }, []),
    // Add mode to preserve form state between renders
    shouldUnregister: false,
  });

  const {
    control,
    handleSubmit,
    setValue,
    getValues,
    watch,
    reset,
    formState: { errors },
  } = form;

  const { fields, append, remove } = useFieldArray({
    control,
    name: "lineItems",
  });

  const safeRemove = (index) => {
    if (fields.length > 1) {
      remove(index);
      setItemInputValues((prevValues) => {
        const newValues = { ...prevValues };
        delete newValues[index];
        // Shift the remaining values to fill the gap
        for (let i = index + 1; i < fields.length; i++) {
          newValues[i - 1] = newValues[i];
          delete newValues[i];
        }
        return newValues;
      });
    } else {
      // Optionally, show a message that at least one item is required
      toast.warning("At least one item is required.");
    }
  };

  const watchedFields = useWatch({
    control,
    name: [
      "lineItems",
      "isItemLevelDiscount",
      "isInclusiveTax",
      "discountAmount",
      "discountRate",
      "adjustment",
      "isDiscountPercentage",
      "total",
      "customCharges",
      "customChargesTaxGroup",
    ],
  });

  const challanDate = watch("date");

  const {
    data: getdeliveryChallanDataByID,
    isLoading: isDeliveryChallanLoading,
  } = useQuery({
    queryKey: ["deliveryChallanData", id],
    queryFn: () => getDeliveryChallanById(id),
    enabled: !!id,
  });

  const { data: stateData, isLoading: isStateDataLoading } = useQuery({
    queryKey: ["state"],
    queryFn: () => getStatesData(),
  });

  const {
    data: voucherData,
    isLoading: isVoucherDataLoading,
    refetch: refetchVoucherData,
  } = useQuery({
    queryKey: ["voucher-init-deliveryChallan"],
    queryFn: () => getVoucherInit("deliveryChallan"),
  });

  const { data: commonInitData, isLoading: iscommonInitDataLoading } = useQuery(
    {
      queryKey: ["getCommonInitData"],
      queryFn: () => getCommonInitData(),
    }
  );

  const idOfParty = watch("partyId");
  const { data: partyData, refetch: refatchpartData } = useQuery({
    queryKey: ["party", idOfParty],
    queryFn: () => getPartyById(idOfParty),
    enabled: !!idOfParty,
  });

  const fetchItemByBarcodeMutation = useMutation({
    mutationFn: (barcode) => getAllItemsByBarcode(barcode),
  });

  const updateDeliveryChallanMutation = useMutation({
    mutationKey: ["edit-deliveryChallan", id],
    mutationFn: (data) => EditDeliveryChallan(id, data),
    onSuccess: (response) => {
      if (response.status === 200 || response.status === 201) {
        router.push("/delivery-challan");
        toast.success("Your Delivery Challan is updated successfully!");
      } else if (response.status === 409) {
        toast.warning(
          response.data?.error?.[0]?.message || "A conflict occurred"
        );
      } else {
        toast.error(
          response.data?.error?.[0]?.message || "An unexpected error occurred"
        );
      }
    },
    onError: (error) => {
      console.error("Error updating Delivery Challan:", error);
      toast.error(error.message || "Something went wrong, please try again");
    },
  });

  const deleteSalesPersonMutation = useMutation({
    mutationKey: ["delete-sales-person"],
    mutationFn: deleteSalesPerson,
    onSuccess: () => {
      toast.success("Sales person deleted successfully");
      refetchVoucherData();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete sales person");
    },
  });

  const deletePartyAddressMutation = useMutation({
    mutationKey: ["delete-party-address"],
    mutationFn: ({ partyAddressID, idOfParty }) =>
      deletePartyAddress({ partyAddressID, idOfParty }),
    onSuccess: (data) => {
      if (data.status === 200) {
        toast.success("Party address deleted successfully");
      } else {
        toast.error(data.message || "Failed to delete party address");
      }
      refatchpartData();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete party address");
    },
  });

  const uploadFileMutation = useMutation({
    mutationFn: (payload) => uploadFile(payload),
  });

  const formatDateToISO = (date) => {
    if (!date) return null;
    return format(date, "yyyy-MM-dd");
  };

  const calculateLineItemTotal = (index) => {
    const quantity = new Decimal(getValues(`lineItems.${index}.quantity`) || 0);
    const rate = new Decimal(getValues(`lineItems.${index}.rate`) || 0);
    let lineTotal = quantity.times(rate);

    if (getValues("isItemLevelDiscount")) {
      let discount;
      if (getValues(`lineItems.${index}.discountRate`)) {
        const discountRate = new Decimal(
          getValues(`lineItems.${index}.discountRate`) || 0
        );

        discount = lineTotal.times(discountRate).dividedBy(100);
      } else {
        discount = new Decimal(
          getValues(`lineItems.${index}.discountAmount`) || 0
        );
      }
      lineTotal = lineTotal.minus(discount);
    }

    return lineTotal.toDecimalPlaces(2).toNumber();
  };

  const redioTypeOfTdsTcs = watch("tdsTcsType");

  const tdsTcsOptions = useMemo(() => {
    if (!commonInitData?.data?.preferences?.tds) return [];

    const options =
      redioTypeOfTdsTcs === "tds"
        ? commonInitData?.data?.preferences?.tds?.tdsMasters
        : commonInitData?.data?.preferences?.tds?.tcsMasters;

    return (
      options?.map((item) => ({
        value: item.id.toString(),
        label:
          redioTypeOfTdsTcs === "tds"
            ? `${item.tdsName} (${item.tdsRate}%)`
            : `${item.tcsName} (${item.tcsRate}%) - ${item.sectionDisplay}`,
      })) || []
    );
  }, [redioTypeOfTdsTcs, commonInitData]);

  const tdsTcsId = watch("tdsTcsId");

  useEffect(() => {
    const taxableAmount = totals.taxableAmount;

    if (tdsTcsId && taxableAmount && !isTdsTcsManuallyEdited) {
      const selectedOption = tdsTcsOptions.find(
        (option) => option.value === tdsTcsId
      );
      if (selectedOption) {
        const rateMatch = selectedOption.label.match(/\((\d+(?:\.\d+)?)%\)/);
        if (rateMatch) {
          const rate = Number.parseFloat(rateMatch[1]);
          const calculatedAmount = (taxableAmount * rate) / 100;
          setValue("tdsTcsAmount", calculatedAmount.toFixed(2));
        }
      }
    } else if (!tdsTcsId) {
      setValue("tdsTcsAmount", "0");
      setIsTdsTcsManuallyEdited(false);
    }
  }, [
    redioTypeOfTdsTcs,
    tdsTcsId,
    totals.taxableAmount,
    tdsTcsOptions,
    setValue,
    isTdsTcsManuallyEdited,
  ]);

  useEffect(() => {
    setIsTdsTcsManuallyEdited(false);
  }, [redioTypeOfTdsTcs, tdsTcsId]);
  // end tds tcs

  const prepareFinalData = (
    preparedData,
    voucherData,
    partyData,
    commonInitData
  ) => {
    let subtotal = new Decimal(0);
    let totalDiscount = new Decimal(0);
    let totalTaxableAmount = new Decimal(0);
    let totalTaxAmount = new Decimal(0);
    let totalCustomChargeAmount = new Decimal(0);
    let totalCustomChargeTaxAmount = new Decimal(0);
    let allTaxes = {};

    const adjustment = new Decimal(preparedData.adjustment || 0);
    const isItemLevelDiscount = preparedData.isItemLevelDiscount;
    const isInclusiveTax = preparedData.isInclusiveTax;
    const discountAmount = new Decimal(preparedData.discountAmount || 0);
    const discountRate = new Decimal(preparedData.discountRate || 0);

    // Calculate subtotal before any discounts
    // biome-ignore lint/complexity/noForEach: <explanation>
    preparedData.lineItems.forEach((item) => {
      const quantity = new Decimal(item.quantity || 0);
      const rate = new Decimal(item.rate || 0);
      subtotal = subtotal.plus(quantity.times(rate));
    });

    // Process line items
    let lineItems = preparedData.lineItems.map((item) => {
      const quantity = new Decimal(item.quantity || 0);
      const rate = new Decimal(item.rate || 0);
      let lineTotal = quantity.times(rate);

      let itemDiscountAmount = new Decimal(0);
      if (isItemLevelDiscount) {
        if (item.isDiscountPercentage) {
          itemDiscountAmount = lineTotal
            .times(new Decimal(item.discountRate || 0))
            .dividedBy(100);
        } else {
          itemDiscountAmount = new Decimal(item.discountAmount || 0);
        }
        lineTotal = lineTotal.minus(itemDiscountAmount);
      }
      totalDiscount = totalDiscount.plus(itemDiscountAmount);

      let taxableAmountForLine = lineTotal;
      let itemTaxAmount = new Decimal(0);
      let taxGroup = null;

      if (item.taxGroup) {
        const selectedTaxGroup =
          typeof item.taxGroup === "string"
            ? voucherData?.data?.taxes?.groups.find(
                (group) => group.id === Number(item.taxGroup)
              )
            : item.taxGroup;

        if (selectedTaxGroup) {
          let totalTaxRate = selectedTaxGroup.taxes.reduce(
            (sum, tax) => sum.plus(new Decimal(tax.rate || 0)),
            new Decimal(0)
          );

          if (isInclusiveTax) {
            // Inclusive Tax Calculations
            const totalTaxRatePercent = totalTaxRate.dividedBy(100);
            taxableAmountForLine = lineTotal.dividedBy(
              new Decimal(1).plus(totalTaxRatePercent)
            );
          }

          taxGroup = {
            id: selectedTaxGroup.id,
            name: selectedTaxGroup.name,
            taxSpecification: selectedTaxGroup.taxSpecification,
            taxes: selectedTaxGroup.taxes.map((tax) => {
              let taxAmount;
              if (isInclusiveTax) {
                taxAmount = taxableAmountForLine
                  .times(new Decimal(tax.rate))
                  .dividedBy(100);
              } else {
                taxAmount = lineTotal
                  .times(new Decimal(tax.rate))
                  .dividedBy(100);
              }
              itemTaxAmount = itemTaxAmount.plus(taxAmount);
              allTaxes[tax.name] = (allTaxes[tax.name] || new Decimal(0)).plus(
                taxAmount
              );
              return {
                ...tax,
                taxAmount: taxAmount.toDecimalPlaces(4).toNumber(),
              };
            }),
          };
        }
      }

      totalTaxAmount = totalTaxAmount.plus(itemTaxAmount);
      totalTaxableAmount = totalTaxableAmount.plus(taxableAmountForLine);

      return {
        itemId: Number(item.itemId),
        unitId: item.unitId,
        description: item.description || "",
        productType: item.productType || "service",
        hsn: item.hsn || "",
        quantity: quantity.toNumber(),
        rate: rate.toNumber(),
        isDiscountPercentage: item.isDiscountPercentage,
        discountRate: new Decimal(item.discountRate || 0).toNumber(),
        discountAmount: itemDiscountAmount.toDecimalPlaces(2).toNumber(),
        taxableAmount: taxableAmountForLine.toDecimalPlaces(2).toNumber(),
        taxTreatment:
          commonInitData?.data?.organization?.gst?.isGstRegistered === false
            ? "outOfScope"
            : item.taxTreatment,
        taxGroup: taxGroup,
      };
    });

    const tds =
      preparedData.tdsTcsType === "tds" && preparedData.tdsTcsId
        ? [
            {
              id: Number(preparedData.tdsTcsId),
              amount: Number(preparedData.tdsTcsAmount || 0),
            },
          ]
        : undefined;

    const tcs =
      preparedData.tdsTcsType === "tcs" && preparedData.tdsTcsId
        ? [
            {
              id: Number(preparedData.tdsTcsId),
              amount: Number(preparedData.tdsTcsAmount || 0),
            },
          ]
        : undefined;

    // Calculate voucher-level discount if not item-level
    if (!isItemLevelDiscount) {
      if (preparedData.isDiscountPercentage) {
        totalDiscount = subtotal.times(discountRate).dividedBy(100);
      } else {
        totalDiscount = discountAmount;
      }

      // Recalculate taxable amount and taxes for voucher-level discount
      totalTaxableAmount = new Decimal(0);
      totalTaxAmount = new Decimal(0);
      allTaxes = {};

      lineItems = lineItems.map((item) => {
        const itemSubtotal = new Decimal(item.quantity).times(item.rate);
        const proportion = itemSubtotal.dividedBy(subtotal);
        const itemDiscount = totalDiscount.times(proportion);
        let taxableAmountForLine = itemSubtotal.minus(itemDiscount);

        if (item.taxGroup) {
          if (isInclusiveTax) {
            const totalTaxRate = item.taxGroup.taxes.reduce(
              (sum, tax) => sum.plus(new Decimal(tax.rate)),
              new Decimal(0)
            );
            const totalTaxRatePercent = totalTaxRate.dividedBy(100);
            taxableAmountForLine = taxableAmountForLine.dividedBy(
              new Decimal(1).plus(totalTaxRatePercent)
            );
          }

          item.taxGroup.taxes = item.taxGroup.taxes.map((tax) => {
            const taxAmount = taxableAmountForLine
              .times(new Decimal(tax.rate))
              .dividedBy(100);
            totalTaxAmount = totalTaxAmount.plus(taxAmount);
            allTaxes[tax.name] = (allTaxes[tax.name] || new Decimal(0)).plus(
              taxAmount
            );
            return {
              ...tax,
              taxAmount: taxAmount.toDecimalPlaces(2).toNumber(),
            };
          });
        }

        totalTaxableAmount = totalTaxableAmount.plus(taxableAmountForLine);
        return {
          ...item,
          discountAmount: itemDiscount.toDecimalPlaces(2).toNumber(),
          taxableAmount: taxableAmountForLine.toDecimalPlaces(2).toNumber(),
        };
      });
    }

    // Custom Charges Processing
    let formattedCustomCharges = [];
    let totalCustomChargesTaxableAmount = new Decimal(0);
    let totalCustomChargesTaxAmount = new Decimal(0);

    if (preparedData.customChargesTaxGroup && preparedData.customCharges) {
      const selectedCustomCharge =
        commonInitData?.data?.preferences?.sales?.customCharges?.find(
          (charge) =>
            charge.id.toString() === preparedData.customChargesTaxGroup
        );

      if (selectedCustomCharge) {
        const customChargeAmount = new Decimal(preparedData.customCharges || 0);
        let customChargeTaxGroup = null;
        let calculatedTaxableAmount = customChargeAmount;
        let calculatedTotalTaxAmount = new Decimal(0);

        // Handle case when GST is off
        if (!commonInitData?.data?.organization?.gst?.isGstRegistered) {
          formattedCustomCharges = [
            {
              id: selectedCustomCharge.id,
              name: selectedCustomCharge.name,
              amount: customChargeAmount.toDecimalPlaces(2).toNumber(),
              taxableAmount: customChargeAmount.toDecimalPlaces(2).toNumber(),
              finalAmount: customChargeAmount.toDecimalPlaces(2).toNumber(),
              taxTreatment: "outOfScope",
              taxGroup: null,
            },
          ];

          totalCustomChargesTaxableAmount =
            totalCustomChargesTaxableAmount.plus(customChargeAmount);
          totalTaxableAmount = totalTaxableAmount.plus(customChargeAmount);

          // Handle tax treatment
        } else if (preparedData.customChargesTaxId) {
          // Check if it's a static tax option
          if (
            ["nonTaxable", "outOfScope", "nonGstSupply"].includes(
              preparedData.customChargesTaxId
            )
          ) {
            formattedCustomCharges = [
              {
                id: selectedCustomCharge.id,
                name: selectedCustomCharge.name,
                amount: customChargeAmount.toDecimalPlaces(2).toNumber(),
                taxableAmount: customChargeAmount.toDecimalPlaces(2).toNumber(),
                finalAmount: customChargeAmount.toDecimalPlaces(2).toNumber(),
                taxTreatment: preparedData.customChargesTaxId,
                taxGroup: null,
              },
            ];

            totalCustomChargesTaxableAmount =
              totalCustomChargesTaxableAmount.plus(customChargeAmount);
            totalTaxableAmount = totalTaxableAmount.plus(customChargeAmount);
          } else {
            // Handle regular tax group
            const selectedTaxGroup = voucherData?.data?.taxes?.groups?.find(
              (group) => group.id === Number(preparedData.customChargesTaxId)
            );

            if (selectedTaxGroup) {
              // Calculate total tax rate for the group
              const totalTaxRate = selectedTaxGroup.taxes.reduce(
                (sum, tax) => sum + Number(tax.rate),
                0
              );

              // Adjust taxable amount if tax is inclusive
              if (isInclusiveTax) {
                calculatedTaxableAmount = customChargeAmount.dividedBy(
                  new Decimal(1).plus(new Decimal(totalTaxRate).dividedBy(100))
                );
              }

              // Calculate taxes
              const taxes = selectedTaxGroup.taxes.map((tax) => {
                const taxAmount = calculatedTaxableAmount
                  .times(new Decimal(tax.rate))
                  .dividedBy(100);
                calculatedTotalTaxAmount =
                  calculatedTotalTaxAmount.plus(taxAmount);

                return {
                  id: tax.id,
                  name: tax.name,
                  rate: tax.rate,
                  taxType: tax.taxType,
                  taxAmount: taxAmount.toDecimalPlaces(2).toNumber(),
                };
              });

              customChargeTaxGroup = {
                id: selectedTaxGroup.id,
                name: selectedTaxGroup.name,
                taxSpecification: selectedTaxGroup.taxSpecification,
                taxes: taxes,
              };

              // Calculate final amounts
              const finalAmount = isInclusiveTax
                ? customChargeAmount
                : calculatedTaxableAmount.plus(calculatedTotalTaxAmount);

              formattedCustomCharges = [
                {
                  id: selectedCustomCharge.id,
                  name: selectedCustomCharge.name,
                  amount: calculatedTaxableAmount.toDecimalPlaces(2).toNumber(),
                  taxableAmount: calculatedTaxableAmount
                    .toDecimalPlaces(2)
                    .toNumber(),
                  finalAmount: finalAmount.toDecimalPlaces(2).toNumber(),
                  taxTreatment: "taxable",
                  taxGroup: customChargeTaxGroup,
                },
              ];

              // Update totals
              totalCustomChargesTaxableAmount =
                totalCustomChargesTaxableAmount.plus(calculatedTaxableAmount);
              totalCustomChargesTaxAmount = totalCustomChargesTaxAmount.plus(
                calculatedTotalTaxAmount
              );
              totalTaxableAmount = totalTaxableAmount.plus(
                calculatedTaxableAmount
              );
              totalTaxAmount = totalTaxAmount.plus(calculatedTotalTaxAmount);
            }
          }
        }
      }
    }

    const total = totalTaxableAmount.plus(totalTaxAmount).plus(adjustment);

    return {
      isAutoNumber: false,
      partyId: Number(preparedData.partyId),
      partyGstNumber: preparedData.partyGstNumber || "",
      placeOfSupplyId: Number(preparedData.placeOfSupplyId) || undefined,
      billingAddressId: Number(preparedData.billingAddressId),
      shippingAddressId: Number(preparedData.shippingAddressId),
      salespersonId: Number(preparedData.salespersonId) || undefined,
      templateId: Number(preparedData.templateId),
      priceListId: Number(preparedData.priceListId) || undefined,
      voucherNumber: preparedData.voucherNumber,
      referenceNumber: preparedData.referenceNumber || "",
      date: formatDateToISO(preparedData.date),
      deliveryDate: formatDateToISO(preparedData.deliveryDate),
      challanType: preparedData.challanType || "others",
      taxableAmount: Number(totalTaxableAmount.toDecimalPlaces(2)),
      taxTotal: Number(totalTaxAmount.toDecimalPlaces(2)),
      adjustment: Number(adjustment.toDecimalPlaces(2)),
      total: Number(total.toDecimalPlaces(2)),
      isInclusiveTax: isInclusiveTax,
      isItemLevelDiscount: isItemLevelDiscount,
      isDiscountPercentage: preparedData.isDiscountPercentage,
      discountAmount: Number(totalDiscount.toDecimalPlaces(2)),
      discountRate: preparedData.isDiscountPercentage
        ? Number(preparedData.discountRate)
        : 0,
      notes: preparedData.notes || voucherData?.data?.notes || "",
      terms: preparedData.terms || voucherData?.data?.termsAndConditions || "",
      status: preparedData.status,
      customCharges: formattedCustomCharges,
      tds: tds,
      tcs: tcs,
      lineItems: lineItems.map((item) => ({
        ...item,
        quantity: Number(item.quantity),
        rate: Number(item.rate),
        discountRate: Number(item.discountRate),
        discountAmount: Number(item.discountAmount),
        taxableAmount: Number(item.taxableAmount),
      })),
      gstTreatment: partyData?.gstType || "composition",
      allTaxes: Object.fromEntries(
        Object.entries(allTaxes).map(([key, value]) => [
          key,
          value.toDecimalPlaces(2).toNumber(),
        ])
      ),
    };
  };

  // Simplified price list adjustment calculation

  const calculatePriceListAdjustment = useCallback(
    (baseRate, priceListId) => {
      if (!priceListId || !baseRate) return baseRate;

      const selectedPriceList = voucherData?.data?.priceLists?.find(
        (list) => list.id.toString() === priceListId
      );

      if (!selectedPriceList) return baseRate;

      const percentage = Number.parseFloat(selectedPriceList.percentage);
      const isMarkup = selectedPriceList.markup;

      if (isMarkup) {
        return baseRate * (1 + percentage / 100);
        // biome-ignore lint/style/noUselessElse: <explanation>
      } else {
        return baseRate * (1 - percentage / 100);
      }
    },
    [voucherData?.data?.priceLists]
  );

  const watchPriceList = watch("priceListId");

  const placeOfSupplyIdData = watch("placeOfSupplyId");

  const TaxDataOptions = useMemo(() => {
    const isIntraTax =
      placeOfSupplyIdData ===
      commonInitData?.data?.organization?.gst?.gstNumber?.slice(0, 2);
    return isIntraTax
      ? voucherData?.data?.taxes?.groups
          ?.filter((val) => val?.taxSpecification === "intra")
          ?.map((val) => ({
            value: `${val?.id}`,
            label: val?.name,
          }))
      : voucherData?.data?.taxes?.groups
          ?.filter((val) => val?.taxSpecification === "inter")
          ?.map((val) => ({
            value: `${val?.id}`,
            label: val?.name,
          }));
  }, [
    commonInitData?.data?.organization?.gst?.gstNumber,
    placeOfSupplyIdData,
    voucherData?.data?.taxes?.groups,
  ]);

  // Add effect to update tax groups when place of supply changes
  useEffect(() => {
    if (!placeOfSupplyIdData) return;

    const lineItems = getValues("lineItems");
    const organizationGstState =
      commonInitData?.data?.organization?.gst?.gstNumber?.slice(0, 2);
    const isIntraState = placeOfSupplyIdData === organizationGstState;

    lineItems.forEach(async (item, index) => {
      if (item.itemId) {
        const itemDetails = await getItemById(item.itemId);
        if (itemDetails) {
          const taxGroupId = isIntraState
            ? itemDetails.intraGstTaxId
            : itemDetails.interGstTaxId;
          if (taxGroupId) {
            const matchingTaxGroup = TaxDataOptions?.find(
              (option) => option.value === taxGroupId.toString()
            );
            if (matchingTaxGroup) {
              setValue(`lineItems.${index}.taxGroup`, matchingTaxGroup.value);
            }
          }
        }
      }
    });
  }, [
    TaxDataOptions,
    commonInitData?.data?.organization?.gst?.gstNumber,
    getValues,
    placeOfSupplyIdData,
    setValue,
  ]);

  const handleItemSelect = useCallback(
    async (itemId, index) => {
      const itemIdString = Number(itemId);

      const selectedItemString = itemsValues?.find(
        (item) => Number(item.value) === itemIdString
      );

      if (selectedItemString) {
        const selectedDataId = Number(selectedItemString.value);

        try {
          const itemDetails = await getItemById(selectedDataId);
          if (itemDetails) {
            setValue(`lineItems.${index}.itemId`, selectedDataId);
            setValue(
              `lineItems.${index}.description`,
              itemDetails.description || ""
            );
            setValue(`lineItems.${index}.hsn`, itemDetails.hsn || "");
            const originalRate = Number(itemDetails.salesRate).toFixed(2) || 0;
            setValue(
              `lineItems.${index}.originalRate`,
              originalRate.toString()
            );
            setValue(`lineItems.${index}.originalQuantity`, "1"); // Store original quantity

            const currentPriceList = getValues("priceListId");
            if (currentPriceList) {
              const adjustedRate = calculatePriceListAdjustment(
                originalRate,
                currentPriceList
              );
              setValue(`lineItems.${index}.rate`, adjustedRate.toString());
            } else {
              // Set original rate first
              setValue(`lineItems.${index}.rate`, originalRate);

              // 2. Check for item-level discounts
              if (
                itemDetails.discountPercentage &&
                Number(itemDetails.discountPercentage) > 0
              ) {
                setValue(`lineItems.${index}.isDiscountPercentage`, true);
                const discountRate = Number(
                  itemDetails.discountPercentage
                ).toFixed(2);
                setValue(`lineItems.${index}.discountRate`, discountRate);
                const discountAmount =
                  (Number(originalRate) * Number(discountRate)) / 100;
                setValue(
                  `lineItems.${index}.discountAmount`,
                  discountAmount.toFixed(2)
                );
              } else if (
                itemDetails.discountAmount &&
                Number(itemDetails.discountAmount) > 0
              ) {
                setValue(`lineItems.${index}.isDiscountPercentage`, false);
                const discountAmount = Number(
                  itemDetails.discountAmount
                ).toFixed(2);
                setValue(`lineItems.${index}.discountAmount`, discountAmount);
                const discountRate =
                  (Number(discountAmount) / Number(originalRate)) * 100;
                setValue(
                  `lineItems.${index}.discountRate`,
                  discountRate.toFixed(2)
                );
              } else {
                // 3. Check for party discount
                const partyId = getValues("partyId");
                if (
                  partyId &&
                  partyData?.discountPercentage &&
                  Number(partyData.discountPercentage) > 0
                ) {
                  setValue(`lineItems.${index}.isDiscountPercentage`, true);
                  const discountRate = Number(
                    partyData.discountPercentage
                  ).toFixed(2);
                  setValue(`lineItems.${index}.discountRate`, discountRate);
                  const discountAmount =
                    (Number(originalRate) * Number(discountRate)) / 100;
                  setValue(
                    `lineItems.${index}.discountAmount`,
                    discountAmount.toFixed(2)
                  );
                } else {
                  // No discounts apply
                  setValue(`lineItems.${index}.isDiscountPercentage`, false);
                  setValue(`lineItems.${index}.discountRate`, "0.00");
                  setValue(`lineItems.${index}.discountAmount`, "0.00");
                }
              }
            }

            // Handle units
            const unitOptions = [];

            // Add primary unit
            if (itemDetails.unit) {
              unitOptions.push({
                id: itemDetails.unit.id,
                name: itemDetails.unit.name,
                code: itemDetails.unit.code,
                qty: "1", // Base unit conversion
              });
            }

            // Add alternate units
            if (
              itemDetails.alternateUnits &&
              itemDetails.alternateUnits.length > 0
            ) {
              itemDetails.alternateUnits.forEach((altUnit) => {
                unitOptions.push({
                  id: altUnit.unitId,
                  name: altUnit.unitName,
                  code: altUnit.unitCode,
                  qty: altUnit.qty, // Conversion ratio from base unit
                });
              });
            }

            // Set unit options and default unit
            setValue(`lineItems.${index}.unitOptions`, unitOptions);
            if (itemDetails.unit) {
              setValue(`lineItems.${index}.unitId`, itemDetails.unit.id);
              setValue(`lineItems.${index}.unitName`, itemDetails.unit.name);
              setValue(`lineItems.${index}.unitCode`, itemDetails.unit.code);
            }

            if (
              commonInitData?.data?.organization?.gst?.isGstRegistered === true
            ) {
              // Add tax group handling
              const organizationGstState =
                commonInitData?.data?.organization?.gst?.gstNumber?.slice(0, 2);
              const isIntraState = placeOfSupplyIdData === organizationGstState;

              const taxGroupId = isIntraState
                ? itemDetails.intraGstTaxId
                : itemDetails.interGstTaxId;

              if (taxGroupId) {
                const matchingTaxGroup = TaxDataOptions?.find(
                  (option) => option.value === taxGroupId.toString()
                );
                if (matchingTaxGroup) {
                  setValue(
                    `lineItems.${index}.taxGroup`,
                    matchingTaxGroup.value
                  );
                }
              } else if (itemDetails.gstType) {
                // If no specific tax group ID but gstType exists, use that
                // Find the corresponding static tax option
                const matchingStaticOption = STATIC_TAX_OPTIONS.find(
                  (option) => option.value === itemDetails.gstType
                );

                if (matchingStaticOption) {
                  setValue(
                    `lineItems.${index}.taxGroup`,
                    matchingStaticOption.value
                  );
                  setValue(
                    `lineItems.${index}.taxTreatment`,
                    itemDetails.gstType
                  );
                }
              }
            }
            setItemInputValues((prev) => ({
              ...prev,
              [index]: selectedItemString.label,
            }));
            setTimeout(() => {
              const descriptionInput = document.querySelector(
                `input[name="lineItems.${index}.description"]`
              );
              if (descriptionInput) {
                descriptionInput.focus();
                descriptionInput.select(); // Optional: selects all text in the input
              }
            }, 0);
          }
        } catch (error) {
          console.error("Error fetching item details:", error);
        }

        // Check if this is the last row and add a new empty row if needed
        if (index === fields.length - 1) {
          append(
            {
              itemId: null,
              description: "",
              productType: "goods",
              hsn: "",
              quantity: "1",
              rate: "0",
              originalRate: "0", // Added originalRate field
              isDiscountPercentage: false,
              discountRate: "0",
              discountAmount: "0",
              taxableAmount: "0",
              taxTreatment:
                commonInitData?.data?.organization?.gst?.isGstRegistered ===
                false
                  ? "outOfScope"
                  : "taxable",
              taxGroup: null,
            },
            { shouldFocus: false }
          );
        }
      } else {
        console.log("No matching item found");
      }
    },
    [
      itemsValues,
      fields.length,
      setValue,
      getValues,
      commonInitData?.data?.organization?.gst?.gstNumber,
      commonInitData?.data?.organization?.gst?.isGstRegistered,
      placeOfSupplyIdData,
      calculatePriceListAdjustment,
      TaxDataOptions,
      append,
    ]
  );

  const handleFileChange = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length + uploadedImageUrls.length > 3) {
      toast.error("You can only upload a maximum of 3 images");
      return;
    }

    setIsUploading(true);

    const uploadPromises = files.map((file) => {
      const formData = new FormData();
      formData.append("image", file);
      return uploadFileMutation.mutateAsync(formData);
    });

    try {
      const results = await Promise.all(uploadPromises);
      setUploadedImageUrls((prevUrls) => {
        const newUrls = results.reduce(
          (acc, result) => {
            if (result?.status === 200 && result?.data?.url) {
              if (!acc.includes(result.data.url)) {
                acc.push(result.data.url);
              }
            }
            return acc;
          },
          [...prevUrls]
        );

        return newUrls.slice(0, 3); // Ensure we don't exceed 3 images
      });

      toast.success("Images uploaded successfully");
    } catch (error) {
      toast.error("Failed to upload one or more images");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleRemoveImage = (indexToRemove) => {
    setUploadedImageUrls((prevUrls) => {
      const newUrls = prevUrls.filter((_, index) => index !== indexToRemove);
      return newUrls;
    });
  };

  const prepareFormData = (data) => {
    return {
      ...data,
      id: Number(id),
      attachment: Array.isArray(data?.attachment) ? data?.attachment : [],
      taxableAmount: Number(totals.taxableAmount),
      taxTotal: Number(totals.taxTotal),
      total: Number(totals.total),
      status: data.status,
      lineItems: data.lineItems.map((item) => ({
        ...item,
        taxableAmount: Number(item.taxableAmount),
      })),
    };
  };

  const onSubmit = (data, action) => {
    // Filter out empty last row from lineItems
    const lineItems = data.lineItems || [];
    const lastIndex = lineItems.length - 1;
    const isLastRowEmpty =
      lastIndex >= 0 &&
      (!lineItems[lastIndex].itemId || lineItems[lastIndex].itemId === "") &&
      (!lineItems[lastIndex].rate || lineItems[lastIndex].rate === "0");

    // Create filtered data with empty last row removed
    const filteredData = {
      ...data,
      lineItems: isLastRowEmpty ? lineItems.slice(0, -1) : lineItems,
    };

    const status = action === "draft" ? "draft" : "sent";
    const preparedData = prepareFormData(filteredData, status);
    const finalData = {
      ...preparedData,
      attachment: Array.isArray(uploadedImageUrls) ? uploadedImageUrls : [],
      ...prepareFinalData(preparedData, voucherData, partyData, commonInitData),
    };
    setProcessingButton(action);
    updateDeliveryChallanMutation.mutate(finalData);
  };

  useEffect(() => {
    if (voucherData) {
      setTaxData(voucherData.data?.taxes?.groups);
    }
  }, [voucherData]);

  const formatAddress = (address) => {
    const parts = [
      address?.street,
      address?.city,
      address?.state,
      address?.pincode,
      address?.country,
    ].filter(Boolean);
    return parts.length > 0
      ? parts.join(", ")
      : "Address details not available";
  };

  const toggleDiscountType = () => {
    const newType =
      globalDiscountType === "percentage" ? "amount" : "percentage";
    setGlobalDiscountType(newType);

    // Update all line items
    fields.forEach((_, index) => {
      const currentValue = form.getValues(
        `lineItems.${index}.${
          newType === "percentage" ? "discountRate" : "discountAmount"
        }`
      );
      form.setValue(
        `lineItems.${index}.${
          newType === "percentage" ? "discountRate" : "discountAmount"
        }`,
        currentValue || "0"
      );
      form.setValue(
        `lineItems.${index}.${
          newType === "percentage" ? "discountAmount" : "discountRate"
        }`,
        "0"
      );
    });
  };

  useEffect(() => {
    if (partyData) {
      setValue("partyGstNumber", partyData.gstn || "");

      if (partyData.gstn && partyData.gstn.length >= 2) {
        const stateCode = partyData.gstn.substring(0, 2);
        const stateId = stateData?.data?.find(
          (state) => state.id === Number(stateCode)
        );
        if (stateId) {
          setValue("placeOfSupplyId", stateId?.id?.toString());
        }
      } else {
        // Fallback to organization GST number if stateId is not found
        const orgStateCode =
          commonInitData?.data?.organization?.gst?.gstNumber?.substring(0, 2);
        const orgStateId = stateData?.data?.find(
          (state) => state.id === Number(orgStateCode)
        );

        if (orgStateId) {
          setValue("placeOfSupplyId", orgStateId.id.toString());
        }
      }
    }
  }, [commonInitData, partyData, setValue, stateData]);

  // set initial data here
  useEffect(() => {
    if (
      // !isFormInitialized &&
      getdeliveryChallanDataByID &&
      stateData &&
      voucherData &&
      commonInitData &&
      !isDeliveryChallanLoading &&
      !isStateDataLoading &&
      !iscommonInitDataLoading &&
      !isVoucherDataLoading
    ) {
      const customFieldsWithValues =
        commonInitData.data?.preferences?.voucherPreferences?.deliveryChallan?.customFields?.map(
          (field) => {
            const existingValue =
              getdeliveryChallanDataByID.customFields?.find(
                (f) => f.id === field.id
              )?.value || "";
            return {
              id: field.id,
              value: existingValue,
            };
          }
        ) || [];

      setCustomFields(
        commonInitData.data?.preferences?.voucherPreferences?.deliveryChallan
          ?.customFields || []
      );
      setisPreferenceFiled(commonInitData?.data?.preferences?.sales);

      // Calculate custom charge amount
      const customCharge = getdeliveryChallanDataByID?.customCharges?.[0];
      let customChargeAmount = "0";
      if (customCharge) {
        const taxableAmount = new Decimal(customCharge?.taxableAmount || 0);
        const taxAmount =
          customCharge?.taxGroup?.taxes?.reduce(
            (sum, tax) => sum.plus(new Decimal(tax.taxAmount || 0)),
            new Decimal(0)
          ) || new Decimal(0);

        customChargeAmount = getdeliveryChallanDataByID?.isInclusiveTax
          ? taxableAmount?.plus(taxAmount).toString()
          : taxableAmount?.toString();

        setShowExtraCharges(true);
      }

      const tdsTcsType =
        getdeliveryChallanDataByID?.tds?.length > 0 ? "tds" : "tcs";
      const tdsTcsData =
        getdeliveryChallanDataByID?.tds?.length > 0
          ? getdeliveryChallanDataByID?.tds[0]
          : getdeliveryChallanDataByID?.tcs[0];

      const initialLineItems = getdeliveryChallanDataByID?.lineItems.map(
        (item) => {
          // Determine the tax group value based on taxTreatment and taxGroup
          let taxGroupValue = null;
          if (item.taxTreatment === "taxable" && item.taxGroup) {
            // If taxable and has tax group, use the tax group ID
            taxGroupValue = item.taxGroup.id.toString();
          } else if (
            ["nonTaxable", "outOfScope", "nonGstSupply"].includes(
              item.taxTreatment
            )
          ) {
            // If it's one of the static tax treatments, use that value
            taxGroupValue = item.taxTreatment;
          }
          // Create unit options array from item data
          let unitOptions = [];
          if (item.unit) {
            unitOptions.push({
              id: item.unit.id,
              name: item.unit.name,
              code: item.unit?.code || item.unit.name, // Fallback to name if code is not available
              qty: "1", // Base unit conversion
            });
          }

          // Add alternate units if available from item.item
          if (item.item?.alternateUnits?.length > 0) {
            unitOptions = [
              ...unitOptions,
              ...item.item.alternateUnits.map((altUnit) => ({
                id: altUnit.unitId,
                name: altUnit.unitName,
                code: altUnit.unitCode,
                qty: altUnit.qty,
              })),
            ];
          }
          return {
            ...item,
            itemId: item?.itemId ? Number(item.itemId) : null,
            unitId: item?.unit?.id || null,
            unitName: item?.unit?.name || "",
            unitCode: item?.unit?.code || item?.unit?.name || "", // Fallback to name if code is not available
            unitOptions: unitOptions,
            taxGroup: taxGroupValue,
            originalRate: item.rate,
            rate: item?.rate ? Number(item.rate).toFixed(2) : null,
            quantity: item?.quantity ? Number(item.quantity).toFixed(2) : null,
            discountAmount: item?.discountAmount
              ? Number(item.discountAmount).toFixed(2)
              : null,
            discountRate: item?.discountRate
              ? Number(item.discountRate).toFixed(2)
              : null,
            taxTreatment: item.taxTreatment || "taxable",
          };
        }
      );
      if (getdeliveryChallanDataByID.isDiscountPercentage) {
        setDiscountType("percentage");
        setDiscountValue(getdeliveryChallanDataByID.discountRate || "");
      } else {
        setDiscountType("fixed");
        setDiscountValue(getdeliveryChallanDataByID.discountAmount || "");
      }
      setShowDiscount(
        !!(
          getdeliveryChallanDataByID.discountRate ||
          getdeliveryChallanDataByID.discountAmount
        )
      );

      // Set initial TDS/TCS tab based on existing data
      if (getdeliveryChallanDataByID.tds?.length > 0) {
        setActiveTab("tds");
        setValue("tdsTcsType", "tds");
        setValue("tdsTcsId", getdeliveryChallanDataByID.tds[0].id.toString());
        setValue(
          "tdsTcsAmount",
          getdeliveryChallanDataByID.tds[0].amount.toString()
        );
      } else if (getdeliveryChallanDataByID.tcs?.length > 0) {
        setActiveTab("tcs");
        setValue("tdsTcsType", "tcs");
        setValue("tdsTcsId", getdeliveryChallanDataByID.tcs[0].id.toString());
        setValue(
          "tdsTcsAmount",
          getdeliveryChallanDataByID.tcs[0].amount.toString()
        );
      } else {
        // If neither TDS nor TCS exists, don't activate any tab
        setActiveTab(null);
        setValue("tdsTcsType", "tds"); // Default to TDS type but with no selection
        setValue("tdsTcsId", "");
        setValue("tdsTcsAmount", "0");
      }

      reset({
        ...getdeliveryChallanDataByID,
        partyId: getdeliveryChallanDataByID?.partyId?.toString(),
        date: new Date(getdeliveryChallanDataByID.date),
        deliveryDate: getdeliveryChallanDataByID.deliveryDate,
        billingAddressId:
          getdeliveryChallanDataByID.billingAddressId ===
          getdeliveryChallanDataByID.billingAddress?.id
            ? getdeliveryChallanDataByID.billingAddressId?.toString()
            : "dont have billing address",
        shippingAddressId:
          getdeliveryChallanDataByID.shippingAddressId ===
          getdeliveryChallanDataByID.shippingAddress?.id
            ? getdeliveryChallanDataByID.shippingAddressId?.toString()
            : "dont have shipping address",
        placeOfSupplyId: getdeliveryChallanDataByID.placeOfSupplyId?.toString(),
        salespersonId: getdeliveryChallanDataByID.salespersonId?.toString(),
        templateId: getdeliveryChallanDataByID.templateId?.toString(),
        priceListId: getdeliveryChallanDataByID.priceListId?.toString(),
        referenceNumber: getdeliveryChallanDataByID?.referenceNumber || "",
        notes:
          getdeliveryChallanDataByID?.notes ||
          commonInitData?.data?.preferences?.voucherPreferences?.deliveryChallan
            ?.notes ||
          "",
        terms:
          getdeliveryChallanDataByID?.terms ||
          commonInitData?.data?.preferences?.voucherPreferences?.deliveryChallan
            ?.terms ||
          "",
        customChargesTaxGroup:
          getdeliveryChallanDataByID.customCharges?.[0]?.chargeId?.toString() ||
          "",
        customChargesTaxId:
          getdeliveryChallanDataByID.customCharges?.[0]?.taxGroup?.id?.toString() ||
          "",
        customCharges: customChargeAmount,
        tdsTcsType: tdsTcsType,
        tdsTcsId: tdsTcsData?.id?.toString() || "",
        tdsTcsAmount: tdsTcsData?.amount?.toString() || "0",
        lineItems: initialLineItems,
      });

      const initialItemInputValues = {};
      initialLineItems.forEach((item, index) => {
        initialItemInputValues[index] = item.item?.itemName || "";
      });
      setItemInputValues(initialItemInputValues);
      setPartyInputValues({
        partyId: getdeliveryChallanDataByID?.party?.name || "",
      });

      setUploadedImageUrls(
        Array.isArray(getdeliveryChallanDataByID?.attachment)
          ? getdeliveryChallanDataByID.attachment
          : []
      );
      customFields: customFieldsWithValues;
      setEstimateStatus(getdeliveryChallanDataByID?.status);
      setIsPageLoading(false);
      // setIsFormInitialized(true);
    }
  }, [
    getdeliveryChallanDataByID,
    stateData,
    voucherData,
    isDeliveryChallanLoading,
    isStateDataLoading,
    isVoucherDataLoading,
    commonInitData,
    iscommonInitDataLoading,
    reset,
    setValue,
  ]);

  const handlePartySearch = useCallback(async (query) => {
    if (query) {
      const partySuggestions = await getSuggestionOfPartiesforDeleiveryChalan(
        query
      );
      setPartyValues(partySuggestions);
    }
  }, []);

  const fetchSuggestionsforParty = useCallback(async () => {
    const initialParties = await fetchInitialPartiesforDeleiveryChalan();
    setPartyValues(initialParties);
  }, []);

  // Use this query to fetch suggestions
  useQuery({
    queryKey: ["suggestionsforparty"],
    queryFn: fetchSuggestionsforParty,
    enabled: true,
  });

  useEffect(() => {
    if (partyData) {
      // Helper function to set place of supply
      const setPlaceOfSupply = (stateId) => {
        if (stateId) {
          setValue("placeOfSupplyId", stateId.toString(), {
            shouldValidate: true,
            shouldDirty: true,
            shouldTouch: true,
          });
          return true;
        }
        return false;
      };

      // Set GST Number
      setValue("partyGstNumber", partyData.gstn || "");

      // Set shipping and billing addresses regardless of their stateId
      const shippingAddress = partyData.addresses?.find(
        (address) => address.type === "shipping"
      );
      const billingAddress = partyData.addresses?.find(
        (address) => address.type === "billing"
      );

      // Set shipping address if exists
      if (shippingAddress) {
        setValue("shippingAddressId", shippingAddress.id.toString(), {
          shouldValidate: true,
          shouldDirty: true,
          shouldTouch: true,
        });
      }

      // Set billing address if exists
      if (billingAddress) {
        setValue("billingAddressId", billingAddress.id.toString(), {
          shouldValidate: true,
          shouldDirty: true,
          shouldTouch: true,
        });
      }

      let placeOfSupplySet = false;

      // First try shipping address state if it exists AND has a valid stateId
      if (shippingAddress?.stateId) {
        placeOfSupplySet = setPlaceOfSupply(shippingAddress.stateId);
      }

      // If no shipping address OR shipping address has no stateId, try billing address
      if (!placeOfSupplySet && billingAddress?.stateId) {
        placeOfSupplySet = setPlaceOfSupply(billingAddress.stateId);
      }

      // If no valid address states, try party's GST number
      if (!placeOfSupplySet && partyData.gstn?.length >= 2) {
        const stateCode = partyData.gstn.substring(0, 2);
        const stateId = stateData?.data?.find(
          (state) => state.id === Number(stateCode)
        )?.id;
        if (stateId) {
          placeOfSupplySet = setPlaceOfSupply(stateId);
        }
      }

      // Finally, if nothing else worked, use organization's GST number
      if (
        !placeOfSupplySet &&
        commonInitData?.data?.organization?.gst?.gstNumber
      ) {
        const orgStateCode =
          commonInitData.data.organization.gst.gstNumber.substring(0, 2);
        const stateId = stateData?.data?.find(
          (state) => state.id === Number(orgStateCode)
        )?.id;
        if (stateId) {
          setPlaceOfSupply(stateId);
        }
      }
    }
  }, [partyData, setValue, stateData, commonInitData]);

  useEffect(() => {
    if (newlyAddedParty) {
      setValue("partyId", Number(newlyAddedParty.value));
      setPartyInputValues((prevValues) => ({
        ...prevValues,
        partyId: newlyAddedParty.label,
      }));
      setNewlyAddedParty(null); // Reset after setting the value
    }
  }, [newlyAddedParty, setValue]);

  const fetchInitialItems = useCallback(async () => {
    const initialItems = await fetchInitialItemsforComboBox();
    setItemsValues(initialItems);
  }, []);

  const handleItemSearch = useCallback(async (query) => {
    if (query) {
      const itemSuggestion = await getSuggestionOfItemsforComboBox(query);
      setItemsValues(itemSuggestion);
    }
  }, []);

  // Use this query to fetch initial items
  useQuery({
    queryKey: ["initialItems"],
    queryFn: fetchInitialItems,
    enabled: true,
  });

  // Add this function to handle input changes
  const handleItemInputChange = useCallback((value, index) => {
    setItemInputValues((prev) => ({ ...prev, [index]: value }));
  }, []);

  const handlePartyInputChange = useCallback((value, fieldName) => {
    setPartyInputValues((prev) => ({ ...prev, [fieldName]: value }));
  }, []);

  // useEffect for New Added ITem
  useEffect(() => {
    if (newlyAddedItem) {
      const fetchItemDetails = async () => {
        const currentItemIndex = selectedItemIndex;
        if (currentItemIndex !== -1) {
          const addedItemId = Number(newlyAddedItem.value);
          setValue(`lineItems.${currentItemIndex}.itemId`, addedItemId);

          try {
            const itemDetails = await getItemById(addedItemId);
            if (itemDetails) {
              setValue(
                `lineItems.${currentItemIndex}.description`,
                itemDetails.description || ""
              );
              setValue(
                `lineItems.${currentItemIndex}.rate`,
                Number(itemDetails.salesRate).toFixed(2) || 0
              );
              setValue(
                `lineItems.${currentItemIndex}.hsn`,
                itemDetails.hsn || ""
              );
              // Add more fields as needed

              setItemInputValues((prev) => ({
                ...prev,
                [currentItemIndex]: itemDetails.itemName,
              }));
            }
          } catch (error) {
            console.error("Error fetching item details:", error);
          }
          handleItemSelect(newlyAddedItem.value, currentItemIndex);
        }
        setItemsValues((prevItems) => [...prevItems, newlyAddedItem]);
        setNewlyAddedItem(null);
      };

      fetchItemDetails();
    }
  }, [newlyAddedItem, selectedItemIndex, handleItemSelect, setValue]);

  const idOfCustomerNameString = watch("customerName");
  const idOfCustomer = Number(idOfCustomerNameString);

  const addItem = () => {
    append(
      {
        itemId: null,
        description: "",
        productType: "goods",
        hsn: "",
        quantity: "1",
        rate: "0",
        isDiscountPercentage: false, // Set default to false
        discountRate: "0", // Set default to 0
        discountAmount: "0",
        taxableAmount: "0",
        taxTreatment:
          commonInitData?.data?.organization?.gst?.isGstRegistered === false
            ? "outOfScope"
            : "taxable",
        taxGroup: null,
      },
      { shouldFocus: false }
    );
  };

  const tdsTcsAmount = watch("tdsTcsAmount");
  useEffect(() => {
    const data = getValues();
    const updatedData = prepareFinalData(
      data,
      voucherData,
      partyData,
      commonInitData
    );

    let adjustedTotal = updatedData?.total || 0;
    const numericTdsTcsAmount = Number(tdsTcsAmount) || 0;
    // Adjust total based on the type of TDS/TCS received
    if (redioTypeOfTdsTcs === "tcs") {
      adjustedTotal += numericTdsTcsAmount; // Subtract tcs amount if type is "tcs"
    } else if (redioTypeOfTdsTcs === "tds") {
      adjustedTotal -= numericTdsTcsAmount; // Add tds amount if type is "tds"
    }

    const roundedTotal = Math.round(adjustedTotal);
    const autoAdjustment = roundedTotal - adjustedTotal;

    // Store auto-adjustment in ref
    autoAdjustmentRef.current = autoAdjustment;

    // Get the current manual adjustment
    const currentAdjustment = Number(data.adjustment) || 0;

    // Use manual adjustment if present, otherwise use auto-adjustment
    const finalAdjustment =
      currentAdjustment !== 0 ? currentAdjustment : autoAdjustment;

    // Calculate subtotal based on discount type
    let subtotal = new Decimal(0);

    // First calculate raw total from line items
    // biome-ignore lint/complexity/noForEach: <explanation>
    data.lineItems?.forEach((item) => {
      const quantity = new Decimal(item.quantity || 0);
      const rate = new Decimal(item.rate || 0);
      const lineTotal = quantity.times(rate);
      subtotal = subtotal.plus(lineTotal);
    });

    // If using item-level discount, subtract individual discounts from line items
    let totalItemDiscount = new Decimal(0);

    if (data.isItemLevelDiscount) {
      // biome-ignore lint/complexity/noForEach: <explanation>
      data.lineItems?.forEach((item) => {
        const quantity = new Decimal(item.quantity || 0);
        const rate = new Decimal(item.rate || 0);
        const lineTotal = quantity.times(rate);

        if (item.isDiscountPercentage) {
          const discountAmount = lineTotal
            .times(new Decimal(item.discountRate || 0))
            .dividedBy(100);
          totalItemDiscount = totalItemDiscount.plus(discountAmount);
        } else {
          totalItemDiscount = totalItemDiscount.plus(
            new Decimal(item.discountAmount || 0)
          );
        }
      });
      subtotal = subtotal.minus(totalItemDiscount);
    }
    // For voucher-level discount, keep the original subtotal
    // Don't subtract the voucher discount from subtotal display

    setTotals((prevTotals) => ({
      ...prevTotals,
      subtotal: subtotal.toNumber(), // This will be the final subtotal based on discount type
      taxableAmount: updatedData.taxableAmount,
      taxTotal: updatedData.taxTotal,
      total: adjustedTotal + finalAdjustment,
      allTaxes: updatedData.allTaxes,
      adjustment: finalAdjustment,
      totalDiscount: totalItemDiscount.toFixed(0), // Add the total discount to the state
    }));
  }, [
    watchedFields,
    voucherData,
    partyData,
    getValues,
    tdsTcsAmount,
    redioTypeOfTdsTcs,
    commonInitData,
  ]);

  const getTaxData = form.watch("lineItems");

  const calculateTaxData = () => {
    // Get line item tax data
    const lineItemTaxes = getTaxData
      .map((val, ind) => {
        const rawTotal = calculateLineItemTotal(ind);
        const isInclusiveTax = form.watch("isInclusiveTax");
        const taxGroup =
          typeof val?.taxGroup === "string"
            ? taxData?.find((group) => group.id === Number(val?.taxGroup))
            : null;

        // Calculate total tax rate for the group
        const totalTaxRate =
          taxGroup?.taxes?.reduce(
            (sum, tax) => sum + (Number(tax.rate) || 0),
            0
          ) || 0;

        // Adjust taxable amount for inclusive tax
        let taxableAmount = rawTotal;
        if (isInclusiveTax && totalTaxRate > 0) {
          taxableAmount = new Decimal(rawTotal)
            .dividedBy(
              new Decimal(1).plus(new Decimal(totalTaxRate).dividedBy(100))
            )
            .toNumber();
        }

        return {
          taxGroupId: Number(val?.taxGroup),
          taxableAmount,
          isInclusive: isInclusiveTax,
          isFromCustomCharge: false,
        };
      })
      .filter((item) => item.taxGroupId && !isNaN(item.taxGroupId));

    // Get custom charge tax data
    const customChargesTaxId = form.watch("customChargesTaxId");
    const customChargesAmount = new Decimal(form.watch("customCharges") || 0);
    const customChargesTaxGroup =
      typeof customChargesTaxId === "string" &&
      !["nonTaxable", "outOfScope", "nonGstSupply"].includes(customChargesTaxId)
        ? taxData?.find((group) => group.id === Number(customChargesTaxId))
        : null;

    if (customChargesTaxGroup && customChargesAmount.greaterThan(0)) {
      const totalTaxRate = customChargesTaxGroup.taxes.reduce(
        (sum, tax) => sum + (Number(tax.rate) || 0),
        0
      );
      let taxableAmount = customChargesAmount;

      if (form.watch("isInclusiveTax") && totalTaxRate > 0) {
        taxableAmount = customChargesAmount.dividedBy(
          new Decimal(1).plus(new Decimal(totalTaxRate).dividedBy(100))
        );
      }

      lineItemTaxes.push({
        taxGroupId: customChargesTaxGroup.id,
        taxableAmount: taxableAmount.toNumber(),
        isInclusive: form.watch("isInclusiveTax"),
        isFromCustomCharge: true,
      });
    }

    return lineItemTaxes;
  };

  const gsttaxIdAndAmount = calculateTaxData();

  const gstTaxGrouped = gsttaxIdAndAmount?.reduce((acc, gstItem) => {
    const { taxGroupId, taxableAmount, isInclusive, isFromCustomCharge } =
      gstItem;

    if (acc[taxGroupId]) {
      acc[taxGroupId].taxableAmount = new Decimal(acc[taxGroupId].taxableAmount)
        .plus(taxableAmount)
        .toDecimalPlaces(2);
    } else {
      acc[taxGroupId] = {
        ...gstItem,
        taxableAmount: new Decimal(taxableAmount),
      };
    }

    return acc;
  }, {});

  const taxDatta = taxData || [];

  const matchedTaxData = taxDatta
    .map((taxItem) => {
      const matchingGstItem = gstTaxGrouped[taxItem.id];

      if (matchingGstItem) {
        const taxableAmount = matchingGstItem.taxableAmount;
        const isInclusive = matchingGstItem.isInclusive;

        const updatedTaxes = taxItem.taxes.map((tax) => {
          const rate = new Decimal(tax.rate);
          let taxAmount;

          if (isInclusive) {
            // For inclusive tax, calculate tax amount from the taxable amount
            taxAmount = new Decimal(taxableAmount).times(rate).dividedBy(100);
          } else {
            // For exclusive tax, calculate tax on top of the taxable amount
            taxAmount = new Decimal(taxableAmount).times(rate).dividedBy(100);
          }

          return {
            ...tax,
            taxAmount: taxAmount.toDecimalPlaces(2).toString(),
            isFromCustomCharge: matchingGstItem.isFromCustomCharge,
          };
        });

        return {
          ...taxItem,
          taxableAmount,
          isInclusive,
          taxes: updatedTaxes,
          isFromCustomCharge: matchingGstItem.isFromCustomCharge,
        };
      }

      return null;
    })
    .filter(Boolean); // Remove null values

  const sumAllTaxAmounts = (data) => {
    const taxMap = {};

    for (const item of data) {
      for (const tax of item.taxes) {
        if (taxMap[tax.name]) {
          taxMap[tax.name] = new Decimal(taxMap[tax.name])
            .plus(tax.taxAmount)
            .toDecimalPlaces(2);
        } else {
          taxMap[tax.name] = new Decimal(tax.taxAmount);
        }
      }
    }

    return Object.entries(taxMap).map(([name, totalAmount]) => ({
      taxName: name,
      totalAmount,
    }));
  };

  const finalArray = sumAllTaxAmounts(matchedTaxData);

  if (isPageLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spinner className="w-10 h-10" />
      </div>
    );
  }

  const handleBarcodeScanned = async (barcode) => {
    try {
      // First fetch item by barcode
      const { data: barcodeResponse } =
        await fetchItemByBarcodeMutation.mutateAsync(barcode);
      const barcodeItem = barcodeResponse.data[0];

      if (!barcodeItem) {
        toast.error("No item found for this barcode");
        return;
      }

      // Find first empty row or existing item
      const existingItemIndex = fields.findIndex(
        (field) => field.itemId === barcodeItem.id.toString()
      );

      // If item exists, just update quantity
      if (existingItemIndex !== -1) {
        const currentQuantity =
          Number.parseFloat(
            getValues(`lineItems.${existingItemIndex}.quantity`)
          ) || 0;
        const newQuantity = (currentQuantity + 1).toString();
        setValue(`lineItems.${existingItemIndex}.quantity`, newQuantity);
        form.trigger(`lineItems.${existingItemIndex}.quantity`);
        toast.success("Item quantity increased");
        return;
      }

      // Get detailed item information
      const itemDetails = await getItemById(barcodeItem.id);
      if (!itemDetails) {
        toast.error("Could not fetch item details");
        return;
      }

      // Find or create target row
      const emptyRowIndex = fields.findIndex((field) => !field.itemId);
      const targetIndex = emptyRowIndex !== -1 ? emptyRowIndex : fields.length;

      if (emptyRowIndex === -1) {
        append(
          {
            itemId: null,
            description: "",
            productType: "goods",
            hsn: "",
            quantity: "1",
            rate: "0",
            originalRate: "0",
            isDiscountPercentage: false,
            discountRate: "0",
            discountAmount: "0",
            taxableAmount: 0,
            taxTreatment:
              commonInitData?.data?.organization?.gst?.isGstRegistered === false
                ? "outOfScope"
                : "taxable",
            taxGroup: null,
          },
          { shouldFocus: false }
        );
      }

      // Set basic item details
      const originalRate = Number(itemDetails.salesRate).toFixed(2) || "0";
      setValue(`lineItems.${targetIndex}.originalRate`, originalRate);
      setValue(`lineItems.${targetIndex}.originalQuantity`, "1");

      // Handle price list adjustments
      const currentPriceList = getValues("priceListId");
      if (currentPriceList) {
        const adjustedRate = calculatePriceListAdjustment(
          originalRate,
          currentPriceList
        );
        setValue(`lineItems.${targetIndex}.rate`, adjustedRate.toString());
      } else {
        setValue(`lineItems.${targetIndex}.rate`, originalRate);

        // Handle discounts
        if (
          itemDetails.discountPercentage &&
          Number(itemDetails.discountPercentage) > 0
        ) {
          setValue(`lineItems.${targetIndex}.isDiscountPercentage`, true);
          const discountRate = Number(itemDetails.discountPercentage).toFixed(
            2
          );
          setValue(`lineItems.${targetIndex}.discountRate`, discountRate);
          const discountAmount =
            (Number(originalRate) * Number(discountRate)) / 100;
          setValue(
            `lineItems.${targetIndex}.discountAmount`,
            discountAmount.toFixed(2)
          );
        } else if (
          itemDetails.discountAmount &&
          Number(itemDetails.discountAmount) > 0
        ) {
          setValue(`lineItems.${targetIndex}.isDiscountPercentage`, false);
          const discountAmount = Number(itemDetails.discountAmount).toFixed(2);
          setValue(`lineItems.${targetIndex}.discountAmount`, discountAmount);
          const discountRate =
            (Number(discountAmount) / Number(originalRate)) * 100;
          setValue(
            `lineItems.${targetIndex}.discountRate`,
            discountRate.toFixed(2)
          );
        } else {
          // Check for party discount
          const partyId = getValues("partyId");
          if (
            partyId &&
            partyData?.discountPercentage &&
            Number(partyData.discountPercentage) > 0
          ) {
            setValue(`lineItems.${targetIndex}.isDiscountPercentage`, true);
            const discountRate = Number(partyData.discountPercentage).toFixed(
              2
            );
            setValue(`lineItems.${targetIndex}.discountRate`, discountRate);
            const discountAmount =
              (Number(originalRate) * Number(discountRate)) / 100;
            setValue(
              `lineItems.${targetIndex}.discountAmount`,
              discountAmount.toFixed(2)
            );
          } else {
            setValue(`lineItems.${targetIndex}.isDiscountPercentage`, false);
            setValue(`lineItems.${targetIndex}.discountRate`, "0.00");
            setValue(`lineItems.${targetIndex}.discountAmount`, "0.00");
          }
        }
      }

      // Set other item details
      setValue(`lineItems.${targetIndex}.itemId`, itemDetails.id.toString());
      setValue(
        `lineItems.${targetIndex}.description`,
        itemDetails.description || ""
      );
      setValue(
        `lineItems.${targetIndex}.productType`,
        itemDetails.productType || "goods"
      );
      setValue(`lineItems.${targetIndex}.hsn`, itemDetails.hsn || "");
      setValue(`lineItems.${targetIndex}.quantity`, "1");

      // Handle units
      const unitOptions = [];
      if (itemDetails.unit) {
        unitOptions.push({
          id: itemDetails.unit.id,
          name: itemDetails.unit.name,
          code: itemDetails.unit.code,
          qty: "1",
        });
      }

      if (itemDetails.alternateUnits?.length > 0) {
        itemDetails.alternateUnits.forEach((altUnit) => {
          unitOptions.push({
            id: altUnit.unitId,
            name: altUnit.unitName,
            code: altUnit.unitCode,
            qty: altUnit.qty,
          });
        });
      }

      setValue(`lineItems.${targetIndex}.unitOptions`, unitOptions);
      if (itemDetails.unit) {
        setValue(`lineItems.${targetIndex}.unitId`, itemDetails.unit.id);
        setValue(`lineItems.${targetIndex}.unitName`, itemDetails.unit.name);
        setValue(`lineItems.${targetIndex}.unitCode`, itemDetails.unit.code);
      }

      if (commonInitData?.data?.organization?.gst?.isGstRegistered === true) {
        // Handle tax groups
        const organizationGstState =
          commonInitData?.data?.organization?.gst?.gstNumber?.slice(0, 2);
        let taxGroupId = !placeOfSupplyIdData
          ? itemDetails.intraGstTaxId
          : placeOfSupplyIdData === organizationGstState
          ? itemDetails.intraGstTaxId
          : itemDetails.interGstTaxId;

        if (taxGroupId) {
          const matchingTaxGroup = TaxDataOptions?.find(
            (option) => option.value === taxGroupId.toString()
          );
          if (matchingTaxGroup) {
            setValue(
              `lineItems.${targetIndex}.taxGroup`,
              matchingTaxGroup.value
            );
            setValue(`lineItems.${targetIndex}.taxTreatment`, "taxable");
          }
        } else if (itemDetails.gstType) {
          // If no specific tax group ID but gstType exists, use that
          // Find the corresponding static tax option
          const matchingStaticOption = STATIC_TAX_OPTIONS.find(
            (option) => option.value === itemDetails.gstType
          );

          if (matchingStaticOption) {
            setValue(`lineItems.${index}.taxGroup`, matchingStaticOption.value);
            setValue(`lineItems.${index}.taxTreatment`, itemDetails.gstType);
          }
        }
      }
      setItemInputValues((prev) => ({
        ...prev,
        [targetIndex]: itemDetails.itemName,
      }));

      toast.success("Item added via barcode");

      // Add new empty row
      append(
        {
          itemId: null,
          description: "",
          productType: "goods",
          hsn: "",
          quantity: "1",
          rate: "0",
          originalRate: "0",
          isDiscountPercentage: false,
          discountRate: "0",
          discountAmount: "0",
          taxableAmount: 0,
          taxTreatment:
            commonInitData?.data?.organization?.gst?.isGstRegistered === false
              ? "outOfScope"
              : "taxable",
          taxGroup: null,
        },
        { shouldFocus: false }
      );
    } catch (error) {
      console.error("Error processing barcode:", error);
      toast.error("Failed to process barcode scan");
    }
  };

  // Add new handlers from add estimate page
  const handleDiscountToggle = () => {
    setShowDiscount(!showDiscount);
    if (!showDiscount) {
      setDiscountValue("");
      setValue("discountRate", "0");
      setValue("discountAmount", "0");
      setValue("isDiscountPercentage", true);
    }
  };

  const handleDiscountTypeChange = (type) => {
    setDiscountType(type);
    const subtotal = new Decimal(totals.subtotal || 0);
    const currentRate = new Decimal(getValues("discountRate") || 0);
    const currentAmount = new Decimal(getValues("discountAmount") || 0);

    if (type === "percentage") {
      // Converting from amount to percentage
      setValue("isDiscountPercentage", true);
      if (!subtotal.isZero() && !currentAmount.isZero()) {
        const newRate = currentAmount.dividedBy(subtotal).times(100);
        setValue("discountRate", newRate.toFixed(2));
        setDiscountValue(newRate.toFixed(2));
      } else {
        setValue("discountRate", "0");
        setDiscountValue("0");
      }
    } else {
      // Converting from percentage to amount
      setValue("isDiscountPercentage", false);
      if (!currentRate.isZero()) {
        const newAmount = subtotal.times(currentRate).dividedBy(100);
        setValue("discountAmount", newAmount.toFixed(2));
        setDiscountValue(newAmount.toFixed(2));
      } else {
        setValue("discountAmount", "0");
        setDiscountValue("0");
      }
    }
  };

  const handleDiscountValueChange = (value) => {
    setDiscountValue(value);
    const numericValue = new Decimal(value || 0);
    const subtotal = new Decimal(totals.subtotal || 0);

    if (discountType === "percentage") {
      // For percentage discount
      setValue("isDiscountPercentage", true);
      setValue("discountRate", value);

      // Calculate discount amount based on percentage
      const discountAmount = subtotal.times(numericValue).dividedBy(100);
      setValue("discountAmount", discountAmount.toFixed(2));
    } else {
      // For fixed amount discount
      setValue("isDiscountPercentage", false);
      setValue("discountAmount", value);

      // Calculate percentage for reference (avoid division by zero)
      if (!subtotal.isZero()) {
        const discountRate = numericValue.dividedBy(subtotal).times(100);
        setValue("discountRate", discountRate.toFixed(2));
      } else {
        setValue("discountRate", "0");
      }
    }
  };

  const getDisplayValue = () => {
    if (!showDiscount) return "0";

    if (discountType === "percentage") {
      const rate = getValues("discountRate");
      const amount = getValues("discountAmount");
      return ` ${Number(amount).toFixed(2)}`;
    }

    return getValues("discountAmount");
  };

  const handleRemoveDiscount = () => {
    setShowDiscount(false);
    setDiscountValue("");
    setValue("discountRate", "0");
    setValue("discountAmount", "0");
    setValue("isDiscountPercentage", true);
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setValue("tdsTcsType", tab);
    // Reset the ID and amount when switching tabs
    setValue("tdsTcsId", "");
    setValue("tdsTcsAmount", "0");
    setIsTdsTcsManuallyEdited(false);
  };

  // Utility functions for calculations
  const calculateLineTotal = (quantity, rate) => {
    return new Decimal(quantity || 0).times(new Decimal(rate || 0));
  };

  const calculateDiscountAmount = (lineTotal, discountRate) => {
    return lineTotal.times(new Decimal(discountRate || 0)).dividedBy(100);
  };

  const calculateDiscountRate = (lineTotal, discountAmount) => {
    return lineTotal.isZero()
      ? new Decimal(0)
      : new Decimal(discountAmount || 0).dividedBy(lineTotal).times(100);
  };

  const calculateTaxableAmount = (lineTotal, discountAmount) => {
    return lineTotal.minus(new Decimal(discountAmount || 0));
  };

  // Main callback function for line item updates
  const handleLineItemUpdate = ({
    index,
    field,
    value,
    form,
    setValue,
    getValues,
    updateTotals = true,
  }) => {
    // Get current values
    const currentValues = {
      quantity: Number(getValues(`lineItems.${index}.quantity`)) || 0,
      rate: Number(getValues(`lineItems.${index}.rate`)) || 0,
      isDiscountPercentage: getValues(
        `lineItems.${index}.isDiscountPercentage`
      ),
      discountRate: Number(getValues(`lineItems.${index}.discountRate`)) || 0,
      discountAmount:
        Number(getValues(`lineItems.${index}.discountAmount`)) || 0,
    };

    // Update the changed field
    if (field && value !== undefined) {
      currentValues[field] = Number(value) || 0;
      setValue(`lineItems.${index}.${field}`, value.toString());
    }

    // Calculate line total
    const lineTotal = calculateLineTotal(
      currentValues.quantity,
      currentValues.rate
    );

    // Update discounts based on type
    if (currentValues.isDiscountPercentage) {
      const discountAmount = calculateDiscountAmount(
        lineTotal,
        currentValues.discountRate
      );
      setValue(`lineItems.${index}.discountAmount`, discountAmount.toFixed(2));
    } else {
      const discountRate = calculateDiscountRate(
        lineTotal,
        currentValues.discountAmount
      );
      setValue(`lineItems.${index}.discountRate`, discountRate.toFixed(2));
    }

    // Update taxable amount
    const taxableAmount = calculateTaxableAmount(
      lineTotal,
      currentValues.isDiscountPercentage
        ? calculateDiscountAmount(lineTotal, currentValues.discountRate)
        : currentValues.discountAmount
    );
    setValue(
      `lineItems.${index}.taxableAmount`,
      Number(taxableAmount.toFixed(2)) // Explicitly convert to number
    );

    // Trigger form updates
    form.trigger(`lineItems.${index}`);
    if (updateTotals) {
      form.trigger("lineItems");
    }

    return {
      lineTotal: lineTotal.toFixed(2),
      taxableAmount: Number(taxableAmount.toFixed(2)),
    };
  };

  // Handler for quantity changes
  const handleQuantityChange = (e, index, form, setValue, getValues) => {
    handleLineItemUpdate({
      index,
      field: "quantity",
      value: e.target.value,
      form,
      setValue,
      getValues,
    });
  };

  // Handler for rate changes
  const handleRateChange = (e, index, form, setValue, getValues) => {
    handleLineItemUpdate({
      index,
      field: "rate",
      value: e.target.value,
      form,
      setValue,
      getValues,
    });
  };

  // Handler for discount rate changes
  const handleDiscountRateChange = (e, index, form, setValue, getValues) => {
    setValue(`lineItems.${index}.isDiscountPercentage`, true);
    handleLineItemUpdate({
      index,
      field: "discountRate",
      value: e.target.value,
      form,
      setValue,
      getValues,
    });
  };

  // Handler for discount amount changes
  const handleDiscountAmountChange = (e, index, form, setValue, getValues) => {
    setValue(`lineItems.${index}.isDiscountPercentage`, false);
    handleLineItemUpdate({
      index,
      field: "discountAmount",
      value: e.target.value,
      form,
      setValue,
      getValues,
    });
  };

  console.log(errors, "ERRORS");

  return (
    <>
      <div className="flex flex-col -m-4">
        <div className="flex-1  ">
          <div className=" mx-auto  bg-white">
            <Form {...form}>
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="sticky top-[54px] left-0 right-0 z-10 h-[41px] bg-white border-b border-[#D2D6DB] pt-2">
                  <div className="px-4 mx-auto flex justify-start items-center ">
                    <span>
                      {" "}
                      <ChevronLeft
                        onClick={() => router.push("/delivery-challan")}
                      />
                    </span>
                    <h2 className="text-lg pl-0 font-semibold">
                      Edit Delivery Challan
                    </h2>
                  </div>
                </div>
                <div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6 p-6 ">
                    {/* Party Selection */}
                    <div>
                      <FormField
                        control={form.control}
                        name="partyId"
                        render={({ field }) => (
                          <FormItem className={cn("space-y-1")}>
                            <FormLabel className="text-[#40566D] mb-1">
                              Select party{" "}
                              <span className="text-red-500 ml-1">*</span>
                            </FormLabel>
                            <FormControl>
                              <AutoCompletePartySelector
                                value={field.value}
                                inputValue={partyInputValues[field.name] || ""}
                                onInputChange={(value) =>
                                  handlePartyInputChange(value, field.name)
                                }
                                onSelect={(selectPartyID) => {
                                  field.onChange(
                                    selectPartyID ? selectPartyID : null
                                  );
                                  setValue(
                                    "partyId",
                                    selectPartyID?.toString()
                                  );
                                }}
                                options={partyValues}
                                onSearch={handlePartySearch}
                                placeholder="Choose a party"
                                emptyMessage="No parties found"
                                onAddNewParty={() =>
                                  setAddPartyIsSheetOpen(true)
                                }
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* voucherNumber No */}
                    <div className="-mt-1">
                      <TextInputField
                        form={form}
                        name="voucherNumber"
                        label="Challan No."
                        placeholder="Delivery Challan Number"
                      />
                    </div>

                    {/* Delivery Challan  Date */}
                    <div>
                      <CommonCalendarInput
                        form={form}
                        name="date"
                        label="Challan Date"
                        placeholder="Choose Challan date"
                        labelClassName="pt-0"
                      />
                    </div>

                    {/* Expiry Date */}
                    <div>
                      <CommonCalendarInput
                        form={form}
                        name="deliveryDate"
                        label="Due Date"
                        placeholder="Choose Due Date"
                        labelClassName="pt-0"
                        className=" pt-0"
                        minDate={challanDate}
                      />
                    </div>

                    {/* Billing Address*/}
                    <div>
                      <FormSelectField
                        form={form}
                        name={"billingAddressId"}
                        label={"Billing Address "}
                        required
                        placeholder={"Billing address"}
                        options={[
                          {
                            value:
                              getdeliveryChallanDataByID?.billingAddressId?.toString(),
                            label: formatAddress(
                              getdeliveryChallanDataByID?.billingAddress
                            ),
                          },
                          ...(partyData?.addresses
                            ?.filter((val) => val?.type === "billing")
                            ?.map((data) => ({
                              value: data?.id.toString(),
                              label: formatAddress(data),
                            })) || []),
                        ].filter(
                          (option, index, self) =>
                            option.value &&
                            index ===
                              self.findIndex((t) => t.value === option.value)
                        )}
                        customButtonLabel="Add Billing Address"
                        onCustomButtonClick={() => {
                          setEditAddressIsSheetOpen(true);
                        }}
                        showActions={true}
                        onDelete={(partyAddressID) => {
                          useConfirmationModalStore
                            .getState()
                            .setModalData(
                              "Delete Billing Address",
                              "Are you sure you want to delete this billing address ? This action cannot be undone.",
                              () =>
                                deletePartyAddressMutation.mutate({
                                  partyAddressID,
                                  idOfParty,
                                })
                            );
                        }}
                        onEdit={(addressData) => {
                          const addressToEdit = partyData?.addresses?.find(
                            (address) =>
                              address.id === Number(addressData.value)
                          );
                          setAddressToEdit(addressToEdit);
                          setEditAddressIsSheetOpen(true);
                        }}
                      />
                    </div>

                    {/* Shipping Address*/}
                    <div>
                      <FormSelectField
                        form={form}
                        name={"shippingAddressId"}
                        label={"Shipping Address "}
                        required
                        placeholder={"Shipping address"}
                        options={[
                          {
                            value:
                              getdeliveryChallanDataByID?.shippingAddressId?.toString(),
                            label: formatAddress(
                              getdeliveryChallanDataByID?.shippingAddress
                            ),
                          },
                          ...(partyData?.addresses
                            ?.filter((val) => val?.type === "shipping")
                            ?.map((data) => ({
                              value: data?.id.toString(),
                              label: formatAddress(data),
                            })) || []),
                        ].filter(
                          (option, index, self) =>
                            option.value &&
                            index ===
                              self.findIndex((t) => t.value === option.value)
                        )}
                        customButtonLabel="Add Shipping Address"
                        onCustomButtonClick={() => {
                          setEditAddressIsSheetOpen(true);
                        }}
                        showActions={true}
                        onDelete={(partyAddressID) => {
                          useConfirmationModalStore
                            .getState()
                            .setModalData(
                              "Delete Shipping Address",
                              "Are you sure you want to delete this shipping address ? This action cannot be undone.",
                              () =>
                                deletePartyAddressMutation.mutate({
                                  partyAddressID,
                                  idOfParty,
                                })
                            );
                        }}
                        onEdit={(addressData) => {
                          const addressToEdit = partyData?.addresses?.find(
                            (address) =>
                              address.id === Number(addressData.value)
                          );
                          setAddressToEdit(addressToEdit);
                          setEditAddressIsSheetOpen(true);
                        }}
                      />
                    </div>

                    {/* placeOfSupplyId*/}
                    {commonInitData?.data?.organization?.gst
                      ?.isGstRegistered === true && (
                      <div>
                        <FormSelectField
                          form={form}
                          label="Place of Supply"
                          name={"placeOfSupplyId"}
                          required
                          placeholder="Choose State"
                          options={
                            stateData?.data?.map((val) => ({
                              value: `${val?.id}`,
                              label: val?.name,
                            })) || []
                          }
                          className="bg-white"
                        />
                      </div>
                    )}

                    {/* hide filed  */}
                    <div className="mt-8 sm:mt-0 md:mt-8 lg:mt-8">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowExtraFields(!showExtraFields)}
                        className="flex items-center gap-2 bg-transparent border w-full shadow-none hover:bg-transparent"
                      >
                        {showExtraFields ? "Hide" : "Show More"}
                        {showExtraFields ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>

                    {showExtraFields && (
                      <>
                        {/* Salesperson */}
                        {commonInitData?.data?.preferences?.sales
                          ?.salesPerson === true && (
                          <div>
                            <FormSelectField
                              form={form}
                              name={"salespersonId"}
                              label={"Sales Person"}
                              placeholder={"Choose Sales Person"}
                              options={voucherData?.data?.salesPersons?.map(
                                (val) => ({
                                  value: `${val?.id}`,
                                  label: val?.name,
                                })
                              )}
                              customButtonLabel="Add Sales Person"
                              onCustomButtonClick={() => {
                                useSalesPersonModalStore
                                  .getState()
                                  .openModal(null, "deliveryChallan");
                              }}
                              showActions={true}
                              onDelete={(salesPersonId) => {
                                useConfirmationModalStore
                                  .getState()
                                  .setModalData(
                                    "Delete Sales Person",
                                    "Are you sure you want to delete this sales person? This action cannot be undone.",
                                    () =>
                                      deleteSalesPersonMutation.mutate(
                                        salesPersonId
                                      )
                                  );
                              }}
                              onEdit={(salesPerson) => {
                                useSalesPersonModalStore
                                  .getState()
                                  .openModal(salesPerson, "deliveryChallan");
                              }}
                            />
                          </div>
                        )}

                        {/* price list */}
                        {commonInitData?.data?.preferences?.inventory
                          ?.priceList && (
                          <div>
                            <FormSelectField
                              form={form}
                              label={"Price List"}
                              name={"priceListId"}
                              placeholder={"Choose Price List"}
                              options={voucherData?.data?.priceLists?.map(
                                (val) => ({
                                  value: `${val?.id}`,
                                  label: val?.name,
                                })
                              )}
                            />
                          </div>
                        )}

                        {/* Reference Number */}
                        <div>
                          <TextInputField
                            form={form}
                            name="referenceNumber"
                            label="Reference Number"
                            placeholder="Reference Number"
                          />
                        </div>

                        {/* Template */}
                        <div>
                          <FormSelectField
                            form={form}
                            name={"templateId"}
                            label={"Template"}
                            placeholder={"Choose Template"}
                            options={voucherData?.data?.templates?.map(
                              (val) => ({
                                value: `${val?.id}`,
                                label: val?.name,
                              })
                            )}
                          />
                        </div>

                        {/* Custom Fields */}
                        {customFields.map((field, index) => (
                          <div key={field.id} className="mb-2">
                            <TextInputField
                              form={form}
                              name={`customFields.${index}.value`}
                              label={field.name}
                              placeholder={"Enter Value"}
                            />
                          </div>
                        ))}

                        {/* Is Item Level Discount */}
                        {commonInitData?.data?.preferences?.sales
                          ?.isItemLevelDiscount === true && (
                          <div className="my-auto">
                            <GlobalCheckbox
                              form={form}
                              label=" Is Item Level Discount"
                              name="isItemLevelDiscount"
                            />
                          </div>
                        )}
                      </>
                    )}
                  </div>
                  <div className="border-b mx-6"></div>
                  <div className="flex justify-end items-center p-6 space-x-2">
                    <Label
                      htmlFor="is-inclusive-tax"
                      className="font-normal text-sm text-[#192839]"
                    >
                      Tax Inclusive Items?
                    </Label>
                    <Switch
                      id="is-inclusive-tax"
                      checked={form.watch("isInclusiveTax")}
                      onCheckedChange={(checked) => {
                        form.setValue("isInclusiveTax", checked);
                      }}
                      className="data-[state=checked]: "
                    />
                  </div>

                  <div className="px-6">
                    <Table className=" border-collapse">
                      <TableHeader>
                        <TableRow className="border rounded-lg border-[#D2D6DB]  bg-[#F5F8FF] hover:bg-[#F5F8FF] h-[60px]">
                          <TableHead className="border font-semibold text-left text-xs text-[#192839] w-[10%] ">
                            <span className="flex  text-xs justify-between items-center">
                              Items
                              <Button
                                variant="ghost"
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  setIsBarcodeModalOpen(true);
                                }}
                              >
                                <Barcode />
                              </Button>
                            </span>
                          </TableHead>
                          <TableHead className="border font-semibold text-left text-xs text-[#192839] w-[8%]">
                            Description
                          </TableHead>
                          <TableHead className="border font-semibold text-right text-xs text-[#192839] w-[6%]">
                            HSN
                          </TableHead>
                          <TableHead className="border font-semibold text-right text-xs text-[#192839] w-[6%]">
                            Qty
                          </TableHead>
                          <TableHead className="border font-semibold text-right text-xs text-[#192839] w-[6%]">
                            Unit
                          </TableHead>
                          <TableHead className="border font-semibold text-center text-xs text-[#192839] w-[8%]">
                            Price Per Unit
                          </TableHead>
                          {getValues("isItemLevelDiscount") && (
                            <>
                              <TableHead
                                className="border p-0 font-semibold text-xs text-[#192839] w-[8%]"
                                colSpan={2}
                              >
                                <span className="flex  text-xs justify-center pb-1 items-center border-b ">
                                  Discount
                                </span>
                                <div className="flex pt-1 justify-around items-end ">
                                  <span className=" text-xs">%</span>
                                  <span className=" text-xs">Value</span>
                                </div>
                              </TableHead>
                            </>
                          )}

                          {commonInitData?.data?.organization?.gst
                            ?.isGstRegistered === true &&
                            commonInitData?.data?.organization?.gst
                              ?.gstRegistrationType === "regular" && (
                              <TableHead className="border font-semibold text-center text-xs text-[#192839] w-[8%] ">
                                Tax
                              </TableHead>
                            )}

                          <TableHead className="border font-semibold text-right text-xs text-[#192839] w-[6%]">
                            Total
                          </TableHead>
                          <TableHead className="border font-semibold text-left text-xs text-[#192839] w-[2%]">
                            Action
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {fields.map((item, index) => (
                          <TableRow key={item.id} className="border ">
                            <TableCell className="border p-[10px] pt-5">
                              <FormField
                                control={form.control}
                                name={`lineItems.${index}.itemId`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <AutoCompleteItemSelector
                                        value={field.value}
                                        inputValue={
                                          itemInputValues[index] || ""
                                        }
                                        onInputChange={(value) =>
                                          handleItemInputChange(value, index)
                                        }
                                        onSelect={(value) => {
                                          field.onChange(value ? value : null);
                                          handleItemSelect(value, index);
                                        }}
                                        options={itemsValues}
                                        onSearch={handleItemSearch}
                                        placeholder="Choose Item"
                                        emptyMessage="No items found"
                                        onAddNewItem={() => {
                                          setSelectedItemIndex(index);
                                          setAddItemIsSheetOpen(true);
                                        }}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </TableCell>
                            <TableCell className="border p-[10px]">
                              {/* <Input className="border-0 focus-visible:ring-0" /> */}
                              <TextInputField
                                form={form}
                                name={`lineItems.${index}.description`}
                                placeholder="Description"
                                className={"min-w-28 "}
                              />
                            </TableCell>
                            <TableCell className="border p-[10px]">
                              <TextInputField
                                form={form}
                                name={`lineItems.${index}.hsn`}
                                // disabled={true}
                                className={"min-w-24 "}
                              />{" "}
                            </TableCell>
                            <TableCell className="border p-[10px]">
                              <TextInputField
                                form={form}
                                name={`lineItems.${index}.quantity`}
                                type="number"
                                min="0"
                                step="1"
                                className={"min-w-24 "}
                                onChange={(e) => {
                                  const value = Math.max(
                                    0,
                                    Number(e.target.value)
                                  );
                                  e.target.value = value;
                                  handleQuantityChange(
                                    e,
                                    index,
                                    form,
                                    setValue,
                                    getValues
                                  );
                                }}
                              />
                            </TableCell>
                            <TableCell className="border p-[10px]">
                              <Controller
                                control={form.control}
                                name={`lineItems.${index}.unitCode`}
                                render={({ field }) => (
                                  <Select
                                    value={field.value}
                                    onValueChange={(value) => {
                                      const unitOptions = watch(
                                        `lineItems.${index}.unitOptions`
                                      );
                                      const selectedOption = unitOptions?.find(
                                        (opt) => opt.code === value
                                      );
                                      const baseUnit = unitOptions?.[0]; // First unit is always the base unit

                                      if (selectedOption) {
                                        // Store the selected unit details
                                        field.onChange(selectedOption.code);
                                        setValue(
                                          `lineItems.${index}.unitName`,
                                          selectedOption.name
                                        );
                                        setValue(
                                          `lineItems.${index}.unitCode`,
                                          selectedOption.code
                                        );

                                        // Get the original values
                                        const originalRate = Number(
                                          getValues(
                                            `lineItems.${index}.originalRate`
                                          )
                                        );
                                        const originalQuantity = Number(
                                          getValues(
                                            `lineItems.${index}.originalQuantity`
                                          )
                                        );
                                        const conversionRatio =
                                          Number(selectedOption.qty) || 1;

                                        if (
                                          selectedOption.code !== baseUnit.code
                                        ) {
                                          // Converting to alternate unit
                                          const newRate =
                                            originalRate / conversionRatio;
                                          const newQuantity =
                                            originalQuantity * conversionRatio;

                                          setValue(
                                            `lineItems.${index}.rate`,
                                            newRate.toFixed(2)
                                          );
                                          setValue(
                                            `lineItems.${index}.quantity`,
                                            newQuantity.toString()
                                          );
                                        } else {
                                          // Converting back to base unit
                                          setValue(
                                            `lineItems.${index}.rate`,
                                            originalRate.toFixed(2)
                                          );
                                          setValue(
                                            `lineItems.${index}.quantity`,
                                            originalQuantity.toString()
                                          );
                                        }

                                        // Trigger calculations
                                        form.trigger(`lineItems.${index}.rate`);
                                        form.trigger(
                                          `lineItems.${index}.quantity`
                                        );
                                      }
                                    }}
                                  >
                                    <SelectTrigger className="border focus:ring-0 min-w-34">
                                      <SelectValue placeholder="Select Unit">
                                        {watch(`lineItems.${index}.unitName`) ||
                                          "Select Unit"}
                                      </SelectValue>
                                    </SelectTrigger>
                                    <SelectContent>
                                      {watch(
                                        `lineItems.${index}.unitOptions`
                                      )?.map((option) => (
                                        <SelectItem
                                          key={option.code}
                                          value={option.code}
                                        >
                                          {`${option.name} (${option.code})`}
                                        </SelectItem>
                                      )) || []}
                                    </SelectContent>
                                  </Select>
                                )}
                              />
                            </TableCell>
                            <TableCell className="borderp-[10px]">
                              <TextInputField
                                form={form}
                                name={`lineItems.${index}.rate`}
                                type="number"
                                step="0.0001"
                                className="min-w-28 "
                                onChange={(e) =>
                                  handleRateChange(
                                    e,
                                    index,
                                    form,
                                    setValue,
                                    getValues
                                  )
                                }
                              />
                            </TableCell>
                            {getValues("isItemLevelDiscount") && (
                              <>
                                <TableCell className="border p-[10px]">
                                  <TextInputField
                                    form={form}
                                    name={`lineItems.${index}.discountRate`}
                                    type="number"
                                    step="0.0001"
                                    className="min-w-[74px] "
                                    onChange={(e) =>
                                      handleDiscountRateChange(
                                        e,
                                        index,
                                        form,
                                        setValue,
                                        getValues
                                      )
                                    }
                                  />
                                </TableCell>
                                <TableCell className="border p-[10px]">
                                  <TextInputField
                                    form={form}
                                    name={`lineItems.${index}.discountAmount`}
                                    type="number"
                                    step="0.0001"
                                    className="min-w-[74px] "
                                    onChange={(e) =>
                                      handleDiscountAmountChange(
                                        e,
                                        index,
                                        form,
                                        setValue,
                                        getValues
                                      )
                                    }
                                  />
                                </TableCell>
                              </>
                            )}

                            {commonInitData?.data?.organization?.gst
                              ?.isGstRegistered === true &&
                              commonInitData?.data?.organization?.gst
                                ?.gstRegistrationType === "regular" && (
                                <TableCell className="border p-[10px]">
                                  <FormSelectField
                                    control={form.control}
                                    name={`lineItems.${index}.taxGroup`}
                                    placeholder="Choose Tax"
                                    options={[
                                      ...STATIC_TAX_OPTIONS,
                                      ...(TaxDataOptions || []),
                                    ]}
                                    onChange={(selectedValue) => {
                                      if (!selectedValue) return; // Prevent empty selections

                                      const isStaticOption =
                                        STATIC_TAX_OPTIONS.some(
                                          (option) =>
                                            option.value === selectedValue
                                        );

                                      if (isStaticOption) {
                                        setValue(
                                          `lineItems.${index}.taxTreatment`,
                                          selectedValue
                                        );
                                        setValue(
                                          `lineItems.${index}.taxGroup`,
                                          selectedValue
                                        );
                                      } else {
                                        const selectedTaxGroup =
                                          TaxDataOptions?.find(
                                            (group) =>
                                              group.value === selectedValue
                                          );
                                        if (selectedTaxGroup) {
                                          setValue(
                                            `lineItems.${index}.taxTreatment`,
                                            "taxable"
                                          );
                                          setValue(
                                            `lineItems.${index}.taxGroup`,
                                            selectedValue
                                          );
                                        }
                                      }
                                    }}
                                    className="min-w-24 "
                                  />
                                </TableCell>
                              )}
                            <TableCell className="border min-w-24 text-right p-[10px]">
                              {calculateLineItemTotal(index).toFixed(2)}
                            </TableCell>
                            <TableCell className="border p-3">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => safeRemove(index)}
                                className="h-8 w-8 border p-[6px] gap-[10px] rounded-[8px]"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                        <TableRow className="border border-[#D2D6DB]  bg-[#F5F8FF] hover:bg-[#F5F8FF] h-11">
                          <TableCell colSpan={3} className="border p-0">
                            <span className="flex justify-between items-center py-[13px] px-[12px] w-[316px] ">
                              <span>
                                <Button
                                  type="button"
                                  variant="outline"
                                  onClick={addItem}
                                  className="text-[ ] hover:text-[ ] border border-[ ]"
                                >
                                  + Add Row
                                </Button>
                              </span>
                              <span className=" font-medium">TOTAL</span>
                            </span>
                          </TableCell>
                          <TableCell className="border text-right">
                            {" "}
                            {fields
                              .reduce((sum, item) => {
                                if (!item.itemId) return sum;
                                return sum + (Number(item.quantity) || 0);
                              }, 0)
                              .toFixed(0)}
                          </TableCell>
                          <TableCell className="border font-medium" />
                          <TableCell className="border font-medium" />

                          {getValues("isItemLevelDiscount") && (
                            <>
                              <TableCell className="border"></TableCell>
                              <TableCell className="border text-right">
                                {totals.totalDiscount || "0"}
                              </TableCell>
                            </>
                          )}
                          {commonInitData?.data?.organization?.gst
                            ?.isGstRegistered === true &&
                            commonInitData?.data?.organization?.gst
                              ?.gstRegistrationType === "regular" && (
                              <TableCell className="border font-medium" />
                            )}

                          <TableCell className="border text-right">
                            {" "}
                            {totals.subtotal?.toFixed(0) || "0"}
                          </TableCell>
                          <TableCell className="border font-medium" />
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex flex-col lg:flex-row p-6 lg:p-6 lg:justify-between">
                    <div className="w-full lg:w-[472px] lg:min-w-[472px] ">
                      <div className="w-full border rounded-[8px]">
                        <div
                          className="flex items-center justify-between p-2 cursor-pointer "
                          onClick={() => setIsExpanded(!isExpanded)}
                        >
                          <h3 className="text-xs font-normal ">
                            Payment Terms & Notes For Client
                          </h3>
                          {isExpanded ? (
                            <ChevronUp className="h-5 w-5" />
                          ) : (
                            <ChevronDown className="h-5 w-5" />
                          )}
                        </div>

                        {isExpanded && (
                          <div className="grid grid-cols-2 gap-4 p-4">
                            <div className="space-y-2">
                              <TextareaInputField
                                form={form}
                                name="notes"
                                label="Notes For Client"
                                placeholder="Enter any notes"
                                defaultValue={
                                  commonInitData?.data?.preferences
                                    ?.voucherPreferences?.deliveryChallan?.notes
                                }
                                rows={4}
                              />
                            </div>
                            <div className="space-y-2">
                              <TextareaInputField
                                form={form}
                                name="terms"
                                label="Payement Terms"
                                placeholder="Enter terms"
                                defaultValue={
                                  commonInitData?.data?.preferences
                                    ?.voucherPreferences?.deliveryChallan?.terms
                                }
                                rows={4}
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Image Upload Section */}
                      <div className="w-full">
                        <div className="py-4 space-y-4">
                          <div
                            className="flex justify-start border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors h-[29px]"
                            onClick={() => fileInputRef.current?.click()}
                          >
                            <input
                              ref={fileInputRef}
                              type="file"
                              multiple
                              accept="image/*"
                              className="hidden"
                              onChange={handleFileChange}
                              disabled={
                                isUploading || uploadedImageUrls.length >= 3
                              }
                            />
                            <span className="flex justify-center items-center gap-[13px]">
                              <Upload className="h-[21px] w-[21px] mx-auto  text-[ ] " />
                              <p className="text-xs text-gray-600">
                                Drag & drop files or browse files
                              </p>
                            </span>
                          </div>

                          {isUploading && (
                            <p className="text-sm text-primary">Uploading...</p>
                          )}

                          <div className="grid grid-cols-3 gap-4">
                            {uploadedImageUrls.map((url, index) => (
                              <div key={index} className="relative group">
                                <div className="relative w-full border rounded-sm border-[#D2D6DB] h-[146px] mt-2">
                                  <div className="absolute inset-0 overflow-hidden rounded-lg">
                                    <img
                                      src={url}
                                      alt={`Uploaded ${index + 1}`}
                                      className="w-full h-full object-contain rounded-lg"
                                    />
                                  </div>
                                  <Button
                                    variant="destructive"
                                    size="icon"
                                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                                    onClick={() => handleRemoveImage(index)}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                      {/* End upload Attechment */}
                    </div>

                    <div className="w-full lg:w-[450px] lg:min-w-[450px] mt-6 lg:mt-0">
                      <div className="w-full border border-[#D2D6DB] rounded-[8px]">
                        <div className="flex flex-col">
                          <div className="flex justify-between items-center border-b  border-[#D2D6DB] px-6 py-3 text-sm">
                            <span className="text-[#40566D]">Subtotal</span>
                            <span>{totals.subtotal?.toFixed(2) || "0.00"}</span>
                          </div>

                          {getValues("isItemLevelDiscount") === false && (
                            <div className="border-b border-[#D2D6DB] max-h-[92px] py-3 px-6 pb-1">
                              <div className="flex justify-between items-center pb-2 ">
                                <div className="flex items-center gap-2 text-sm">
                                  <span className="text-[#40566D]">
                                    Discount
                                  </span>
                                  <Button
                                    variant="outline"
                                    className="text-primary px-1 h-6 py-1"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      handleDiscountToggle();
                                    }}
                                  >
                                    <Plus size={16} />
                                  </Button>
                                </div>
                                <span className="font-medium text-sm">
                                  {getDisplayValue()}
                                </span>
                              </div>
                              {showDiscount && (
                                <div className="flex items-center min-w-[318px] gap-2 text-sm">
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      handleRemoveDiscount();
                                    }}
                                  >
                                    <Trash2 size={16} />
                                  </Button>

                                  <div className="flex gap-1 flex-1 text-sm">
                                    <div className="flex rounded-md overflow-hidden gap-1 border border-slate-600">
                                      <Button
                                        className={`px-3 py-1 text-sm ${
                                          discountType === "percentage"
                                            ? "bg-slate-600 text-white hover:bg-slate-600"
                                            : "bg-white text-slate-600"
                                        }`}
                                        onClick={(e) => {
                                          e.preventDefault();
                                          e.stopPropagation();
                                          handleDiscountTypeChange(
                                            "percentage"
                                          );
                                        }}
                                      >
                                        Percentage
                                      </Button>
                                      <Button
                                        className={`px-3 py-1 text-sm ${
                                          discountType === "fixed"
                                            ? "bg-slate-600 text-white hover:bg-slate-600"
                                            : "bg-white text-slate-600"
                                        }`}
                                        onClick={(e) => {
                                          e.preventDefault();
                                          e.stopPropagation();
                                          handleDiscountTypeChange("fixed");
                                        }}
                                      >
                                        Fixed
                                      </Button>
                                    </div>
                                    <Controller
                                      name={
                                        discountType === "percentage"
                                          ? "discountRate"
                                          : "discountAmount"
                                      }
                                      control={control}
                                      render={({ field }) => (
                                        <input
                                          type="number"
                                          className="flex-1 px-3 py-1 border rounded-md w-16"
                                          placeholder={`Enter ${
                                            discountType === "percentage"
                                              ? "%"
                                              : ""
                                          } Value`}
                                          value={discountValue}
                                          onChange={(e) => {
                                            field.onChange(e.target.value);
                                            handleDiscountValueChange(
                                              e.target.value
                                            );
                                          }}
                                          onFocus={(e) => {
                                            e.target.select();
                                          }}
                                        />
                                      )}
                                    />
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                          {commonInitData?.data?.preferences?.sales
                            ?.customCharges.length > 0 && (
                            <div className=" border-b border-[#D2D6DB] py-3 pb-2 px-6">
                              <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2">
                                  <span className="text-[#40566D]">
                                    Extra Charges
                                  </span>
                                  <Button
                                    variant="outline"
                                    className="text-primary px-1 h-6 py-1"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      setShowExtraCharges(true);
                                    }}
                                  >
                                    <Plus size={16} />
                                  </Button>
                                </div>
                                <span>{getValues("customCharges")}</span>
                              </div>

                              {showExtraCharges && (
                                <div className="flex  items-center gap-2">
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    className="p-2 mt-2 text-black hover:text-gray-600"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      setValue("customCharges", "0");
                                      setValue("customChargesTaxGroup", "");
                                      setValue("customChargesTaxId", "");
                                      setShowExtraCharges(false);
                                    }}
                                  >
                                    <Trash2 size={16} />
                                  </Button>
                                  <div className="flex justify-center items-center gap-1">
                                    <div className="min-w-[154px]">
                                      <FormSelectField
                                        form={form}
                                        name="customChargesTaxGroup"
                                        placeholder="Select Charge"
                                        options={commonInitData?.data?.preferences?.sales?.customCharges?.map(
                                          (val) => ({
                                            value: `${val?.id}`,
                                            label: val?.name,
                                          })
                                        )}
                                      />
                                    </div>

                                    {commonInitData?.data?.organization?.gst
                                      ?.isGstRegistered === true && (
                                      <div className="max-w-[150px]">
                                        <FormSelectField
                                          form={form}
                                          name="customChargesTaxId"
                                          placeholder="Tax"
                                          options={[
                                            ...STATIC_TAX_OPTIONS,
                                            ...(TaxDataOptions || []),
                                          ]}
                                          className="w-[100px]"
                                        />
                                      </div>
                                    )}

                                    <TextInputField
                                      form={form}
                                      name="customCharges"
                                      type="number"
                                      step="0.01"
                                      placeholder="Enter custom charges"
                                      className="min-w-116px"
                                    />
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                          {commonInitData?.data?.organization?.gst
                            ?.isGstRegistered && (
                            <div className="space-y-2 border-b border-[#D2D6DB] py-3 px-6">
                              <div className="flex justify-between items-center">
                                <span className="text-[#40566D]">Tax</span>
                                <span>{totals.taxTotal}</span>
                              </div>
                              <div className="text-xs space-y-1">
                                {finalArray?.map((tax, index) => (
                                  <div
                                    key={tax?.totalAmount + tax.taxName}
                                    className="flex justify-between text-xs text-gray-500"
                                  >
                                    <span>{tax.taxName}</span>
                                    <span>{tax.totalAmount.toFixed(2)}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          {/* TDS/TCS section */}

                          {commonInitData?.data?.preferences?.tds?.tds && (
                            <div className="space-y-2 border-b border-[#D2D6DB] py-3  px-6">
                              <div className="flex items-center justify-between">
                                <div className="flex border rounded-md overflow-hidden">
                                  <Button
                                    type="button"
                                    variant={
                                      activeTab === "tds" ? "default" : "ghost"
                                    }
                                    className={`flex-1 rounded-none px-6 ${
                                      activeTab === "tds"
                                        ? "bg-slate-600 text-white hover:bg-slate-700"
                                        : ""
                                    }`}
                                    onClick={() => handleTabChange("tds")}
                                  >
                                    TDS
                                  </Button>
                                  <Button
                                    type="button"
                                    variant={
                                      activeTab === "tcs" ? "default" : "ghost"
                                    }
                                    className={`flex-1 rounded-none px-6 ${
                                      activeTab === "tcs"
                                        ? "bg-slate-600 text-white hover:bg-slate-700"
                                        : ""
                                    }`}
                                    onClick={() => handleTabChange("tcs")}
                                  >
                                    TCS
                                  </Button>
                                </div>
                                <span className="text-sm font-medium">
                                  {activeTab === "tds" || activeTab === "tcs"
                                    ? getValues("tdsTcsAmount")
                                    : "-"}
                                </span>
                              </div>

                              {(activeTab === "tds" || activeTab === "tcs") && (
                                <div className="grid grid-col-1 ">
                                  <FormSelectField
                                    form={form}
                                    name="tdsTcsId"
                                    placeholder={`Select ${activeTab.toUpperCase()}`}
                                    options={tdsTcsOptions}
                                    className="w-[314px]"
                                  />
                                </div>
                              )}
                            </div>
                          )}

                          <div className="flex justify-between items-center border-[#D2D6DB] py-3  px-6">
                            <span className="text-gray-700">Round Off</span>
                            <TextInputField
                              form={form}
                              name="adjustment"
                              type="number"
                              step="0.0001"
                              placeholder={`Auto: ${autoAdjustmentRef.current.toFixed(
                                2
                              )}`}
                              defaultValue={Number(
                                getValues("adjustedTotal")
                              ).toFixed(2)}
                            />
                          </div>

                          <div className="flex justify-between items-center px-6 py-3 rounded-b-[8px] border-[#D2D6DB] bg-primary  text-white">
                            <span className="font-medium">Payable Amount</span>
                            <span className="font-medium">
                              {totals.total.toFixed(2) || "0.00"}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Submit Button */}

                <div className="sticky bottom-0 left-0 right-0 bg-[#F5F8FF] border-t py-4">
                  <div className="px-6 mx-auto flex justify-end gap-4">
                    <div className="flex space-x-4">
                      <Button
                        type="button"
                        onClick={() => router.push("/delivery-challan")} // Adjust the route as needed
                        variant="outline"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setValue("status", "draft");
                          handleSubmit((data) => onSubmit(data, "draft"))();
                        }}
                        disabled={
                          processingButton === "draft" &&
                          updateDeliveryChallanMutation.isPending
                        }
                      >
                        {processingButton === "draft" &&
                        updateDeliveryChallanMutation.isPending ? (
                          <div className="flex items-center">
                            <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                            <span>Saving...</span>
                          </div>
                        ) : (
                          <span>Save Draft</span>
                        )}
                      </Button>

                      <Button
                        type="button"
                        onClick={() => {
                          setValue("status", "sent");
                          handleSubmit((data) => onSubmit(data, "sent"))();
                        }}
                        disabled={
                          processingButton === "sent" &&
                          updateDeliveryChallanMutation.isPending
                        }
                        className="  hover: "
                      >
                        {processingButton === "sent" &&
                        updateDeliveryChallanMutation.isPending ? (
                          <div className="flex items-center">
                            <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                            <span>Saving...</span>
                          </div>
                        ) : (
                          <span>Save</span>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
                {/* </Button> */}
              </form>
            </Form>
          </div>
        </div>
      </div>

      <BarcodeScanner
        onBarcodeScanned={handleBarcodeScanned}
        isModalOpen={isBarcodeModalOpen}
      />

      <BarcodeModal
        isOpen={isBarcodeModalOpen}
        onClose={() => setIsBarcodeModalOpen(false)}
        onBarcodeScanned={handleBarcodeScanned}
      />

      <Custom_Sheet
        isOpen={isAddPartySheetOpen}
        onClose={() => setAddPartyIsSheetOpen(false)}
        activeKey={"Parties"}
        onPartyAdded={(newParty) => {
          setNewlyAddedParty(newParty);
          setAddPartyIsSheetOpen(false);
        }}
      />

      <Custom_Sheet
        isOpen={isAddItemSheetOpen}
        onClose={() => setAddItemIsSheetOpen(false)}
        activeKey={"items"}
        onItemAdded={(newItem) => {
          setNewlyAddedItem(newItem);
          setAddItemIsSheetOpen(false);
        }}
      />

      <Custom_Sheet
        isOpen={isAddressSheetOpen}
        onClose={() => {
          setEditAddressIsSheetOpen(false);
          setAddressToEdit(null); // Reset edit data when closing
        }}
        activeKey={"address"}
        partyIdforAddress={idOfParty}
        editData={addressToEdit} // Pass the address data to edit
      />
    </>
  );
};

export default EditDeliveryChallanpage;
