import React, { useCallback, useEffect, useRef, useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CommonCalendarInput,
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { toast } from "sonner";
import { Upload, X } from "lucide-react";
import { formatDate } from "date-fns";
import { addExpense } from "@/actions/expense/add-expense";
import { editExpense } from "@/actions/expense/edit-expense";
import { getAllBankAccountData } from "@/actions/bank-account/get-all-bankAccount";
import { ComboboxForm } from "@/components/custom-compobox-select/custom-global-compobox-select";
import {
  fetchInitialPartiesforDeleiveryChalan,
  getSuggestionOfPartiesforDeleiveryChalan,
} from "@/actions/delivery_challan/search-customer-suggestion";
import useDebounce from "@/hooks/use-debounce";
import {
  fetchInitialAccounts,
  getSuggestionOfAccounts,
} from "@/actions/expense/get-all-expense";
import { getExpenseById } from "@/actions/expense/get-single-expense";
import { ReloadIcon } from "@radix-ui/react-icons";
import { uploadFile } from "@/actions/items/file-upload";

const formSchema = z.object({
  date: z.date({
    required_error: "Please select date.",
    invalid_type_error: "Date must be a valid date.",
  }),
  expenseAccountId: z
    .string({ message: "Please enter expense account name." })
    .min(1, { message: "Please enter expense account name." })
    .transform((val) => Number.parseFloat(val)),
  amount: z
    .string({
      required_error: "Please enter amount.",
    })
    .regex(
      /^\d+(\.\d{1,2})?$/,
      "Amount must be a number with up to 2 decimal places."
    )
    .transform((val) => Number.parseFloat(val))
    .refine((val) => val > 0, "Amount must be greater than 0."),
  paidFromAccountId: z
    .string({ message: "Please enter bank account name." })
    .min(1, { message: "Please enter bank account name." })
    .transform((val) => Number.parseFloat(val)),
  partyId: z.string().optional(),
  voucherNumber: z.string().max(50).optional(),
  note: z.string().max(500).optional(),
  attachment: z.array(z.string()).optional(),
});
export const AddEditExpenseForm = ({ expense, onClose }) => {
  const queryClient = useQueryClient();
  const isEditing = !!expense;
  const fileInputRef = useRef(null);

  const [expenseAccountSearchQuery, setExpenseAccountSearchQuery] =
    useState("");
  const [paidFromAccountSearchQuery, setPaidFromAccountSearchQuery] =
    useState("");
  const [partySearchQuery, setPartySearchQuery] = useState("");
  const [expenseAccountValues, setExpenseAccountValues] = useState([]);
  const [partyValues, setPartyValues] = useState([]);
  const [uploadedImageUrls, setUploadedImageUrls] = useState([]);
  const [isUploading, setIsUploading] = useState(false);

  const debouncedExpenseAccountSearchQuery = useDebounce(
    expenseAccountSearchQuery,
    300
  );
  const debouncedPaidFromAccountSearchQuery = useDebounce(
    paidFromAccountSearchQuery,
    300
  );
  const debouncedPartySearchQuery = useDebounce(partySearchQuery, 300);

  const { data: getexpenseDataByID, isSuccess: isExpenseLoaded } = useQuery({
    queryKey: ["expanse", expense],
    queryFn: () => getExpenseById(expense),
    enabled: !!expense,
  });

  const fetchExpenseAccountSuggestions = useCallback(async () => {
    if (debouncedExpenseAccountSearchQuery) {
      const suggestions = await getSuggestionOfAccounts(
        debouncedExpenseAccountSearchQuery
      );
      setExpenseAccountValues(suggestions);
    } else {
      const initialAccounts = await fetchInitialAccounts();
      setExpenseAccountValues(initialAccounts);
    }
  }, [debouncedExpenseAccountSearchQuery]);

  const fetchPartySuggestions = useCallback(async () => {
    if (debouncedPartySearchQuery) {
      const suggestions = await getSuggestionOfPartiesforDeleiveryChalan(
        debouncedPartySearchQuery
      );
      setPartyValues(suggestions);
    } else {
      const initialParties = await fetchInitialPartiesforDeleiveryChalan();
      setPartyValues(initialParties);
    }
  }, [debouncedPartySearchQuery]);

  useQuery({
    queryKey: ["expenseAccountSuggestions", debouncedExpenseAccountSearchQuery],
    queryFn: fetchExpenseAccountSuggestions,
    enabled: true,
  });

  useQuery({
    queryKey: ["partySuggestions", debouncedPartySearchQuery],
    queryFn: fetchPartySuggestions,
    enabled: true,
  });

  const { data: accountname, isSuccess: isAccountLoaded } = useQuery({
    queryKey: ["accountname"],
    queryFn: getAllBankAccountData,
    refetchOnWindowFocus: false,
    onError: (error) => {
      toast.error(error || "Failed to load account groups. Please try again.");
    },
  });

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      date: new Date(),
      voucherNumber: "",
      note: "",
      paidFromAccountId: null,
    },
  });

  const amount = useWatch({ control: form.control, name: "amount" });
  const totalAmount = amount ? Number.parseFloat(amount) || 0 : 0;

  // 3. Update useEffect to properly handle data synchronization
  useEffect(() => {
    if (isEditing && getexpenseDataByID && accountname?.data?.data) {
      const bankAccount = accountname.data.data.find(
        (account) => account.id === getexpenseDataByID?.bankAccount?.id
      );

      console.log("Found bank account:", bankAccount); // Debug log

      if (bankAccount) {
        // First set the bank account individually to ensure it updates
        form.setValue("paidFromAccountId", bankAccount.id.toString(), {
          shouldValidate: true,
          shouldDirty: true,
          shouldTouch: true,
        });

        // Then reset the full form
        form.reset({
          date: getexpenseDataByID.date
            ? new Date(getexpenseDataByID.date)
            : new Date(),
          expenseAccountId:
            getexpenseDataByID.expenseAccount?.id?.toString() || "",
          amount: getexpenseDataByID.amount
            ? Number.parseFloat(getexpenseDataByID.amount).toFixed(2)
            : "",
          paidFromAccountId: bankAccount.id.toString(),
          partyId: getexpenseDataByID.party?.id?.toString() || undefined,
          voucherNumber: getexpenseDataByID.voucherNumber || "",
          note: getexpenseDataByID.note || "",
        });
      }
    }
  }, [getexpenseDataByID, accountname?.data?.data, form, isEditing]);

  // Format the bank account options with proper display
  const formatBankAccountOptions = useCallback(() => {
    if (!accountname?.data?.data) return [];

    return accountname.data.data.map((account) => ({
      value: account.id.toString(),
      label: ` ${account.bankName} `, // Combined display
      bankName: account.bankName,
      accountNumber: account.accountNumber,
    }));
  }, [accountname?.data?.data]);

  const addExpenseMutation = useMutation({
    mutationFn: addExpense,
    onSuccess: handleMutationSuccess,
    onError: handleMutationError,
  });

  const editExpenseMutation = useMutation({
    mutationFn: (data) => editExpense(data, expense),
    onSuccess: handleMutationSuccess,
    onError: handleMutationError,
  });

  function handleMutationSuccess(data) {
    queryClient.invalidateQueries({ queryKey: ["expense"] });
    if (data?.status === 200 || data?.status === 201) {
      form.reset();
      onClose?.();
      toast.success(`Expense ${isEditing ? "updated" : "added"} successfully`);
    } else if (data?.status === 409) {
      toast.warning(data?.data?.error[0]?.message || "A conflict occurred");
    } else {
      toast.error(
        data?.response?.data?.error[0]?.message ||
          "An unexpected error occurred"
      );
    }
  }

  function handleMutationError(error) {
    toast.error(error || "Something went wrong, try again");
  }

  const uploadFileMutation = useMutation({
    mutationFn: (payload) => uploadFile(payload),
  });

  const handleFileChange = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length + uploadedImageUrls.length > 3) {
      toast.error("You can only upload a maximum of 3 images");
      return;
    }

    setIsUploading(true);

    const uploadPromises = files.map((file) => {
      const formData = new FormData();
      formData.append("image", file);
      return uploadFileMutation.mutateAsync(formData);
    });

    try {
      const results = await Promise.all(uploadPromises);
      setUploadedImageUrls((prevUrls) => {
        const newUrls = results.reduce(
          (acc, result) => {
            if (result?.status === 200 && result?.data?.url) {
              if (!acc.includes(result.data.url)) {
                acc.push(result.data.url);
              }
            }
            return acc;
          },
          [...prevUrls]
        );

        return newUrls.slice(0, 3); // Ensure we don't exceed 3 images
      });

      toast.success("Images uploaded successfully");
    } catch (error) {
      toast.error("Failed to upload one or more images");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleRemoveImage = (indexToRemove) => {
    setUploadedImageUrls((prevUrls) => {
      const newUrls = prevUrls.filter((_, index) => index !== indexToRemove);
      return newUrls;
    });
  };

  function onSubmit(values) {
    const formattedValues = {
      ...values,
      partyId: Number(values.partyId),
      date: values.date ? formatDate(values.date, "yyyy-MM-dd") : undefined,
      attachment: uploadedImageUrls,
    };

    const filteredValues = Object.fromEntries(
      Object.entries(formattedValues).filter(([, value]) => value !== "")
    );

    if (isEditing) {
      editExpenseMutation.mutate(filteredValues);
    } else {
      addExpenseMutation.mutate(filteredValues);
    }
  }

  return (
    <>
      <div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
        <h2 className="text-lg font-semibold">
          {isEditing ? "Edit Expense" : "Add Expense"}
        </h2>
      </div>

      <Form {...form} className="p-4">
        <form id="expenseForm" onSubmit={form.handleSubmit(onSubmit)}>
          <main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto  ">
            <div className="mx-auto w-[90%] gap-4 pt-3">
              <CommonCalendarInput
                form={form}
                name="date"
                label="Date"
                placeholder="Select date"
                required
              />
            </div>

            <div className="flex justify-between flex-col sm:flex-row w-[90%] pb-4 gap-4 mx-auto">
              <div className="w-full pt-4 mx-auto">
                <ComboboxForm
                  form={form}
                  name="expenseAccountId"
                  label="Expense Account"
                  placeholder="Choose Account"
                  options={expenseAccountValues}
                  onSearch={setExpenseAccountSearchQuery}
                  required
                />
              </div>

              <div className="w-full pt-0 sm:pt-4 mx-auto">
                <ComboboxForm
                  form={form}
                  name="paidFromAccountId"
                  label="Paid Through"
                  placeholder="Choose Account"
                  options={formatBankAccountOptions()}
                  onSearch={setPaidFromAccountSearchQuery}
                  required
                  key={`paid-from-${getexpenseDataByID?.bankAccount?.id}-${accountname?.data?.data?.length}`}
                />
              </div>
            </div>

            <div className="border-t-4  border-gray-200" />

            <div className="w-[90%] pt-4 mx-auto">
              <ComboboxForm
                form={form}
                name="partyId"
                label="Party Name"
                placeholder="Choose Party"
                options={partyValues}
                onSearch={setPartySearchQuery}
                initialData={getexpenseDataByID}
              />
            </div>

            <div className="flex justify-between flex-col sm:flex-row w-[90%] gap-4 pb-4 mx-auto">
              <div className="w-full pt-4 mx-auto">
                <TextInputField
                  form="form"
                  name="voucherNumber"
                  label="Expense Voucher No."
                  type="text"
                  placeholder="Enter Expense Voucher No."
                  className="flex flex-col space-y-1.5"
                />
              </div>

              <div className="w-full pt-0 sm:pt-4 mx-auto">
                <TextInputField
                  form="form"
                  name="amount"
                  label="Amount"
                  type="text"
                  placeholder="Enter Amount Here"
                  className="flex flex-col space-y-1.5"
                  required
                />
              </div>
            </div>

            <div className="border-t-4 border-gray-200" />

            <div className="w-[90%] pt-4 mx-auto">
              <TextareaInputField
                form="form"
                name="note"
                label="Notes"
                placeholder="Enter Note Here..."
                rows="3"
                className="flex flex-col space-y-1.5"
              />
            </div>

            <div className="pt-3 w-[90%] mx-auto">
              {/* Image Upload Section */}
              <div className="w-full">
                <div className="py-4 space-y-4">
                  <h3 className="text-xs font-medium text-[#40566D]">
                    Upload Image/Photos (Max 3 Photos)
                  </h3>

                  {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
                  <div
                    className="flex justify-start border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors h-[59px]"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      accept="image/*"
                      className="hidden"
                      onChange={handleFileChange}
                      disabled={isUploading || uploadedImageUrls.length >= 3}
                    />
                    <span className="flex justify-center items-center gap-[13px]">
                      <Upload className="h-[21px] w-[21px] mx-auto  text-[ ] " />
                      <p className="text-xs text-gray-600">
                        Drag & drop files or browse files
                      </p>
                    </span>
                  </div>

                  {isUploading && (
                    <p className="text-sm text-primary">Uploading...</p>
                  )}

                  {uploadedImageUrls.length > 0 && (
                    <div className="grid grid-cols-3 gap-4">
                      {uploadedImageUrls.map((url, index) => (
                        // biome-ignore lint/suspicious/noArrayIndexKey: <explanation>
                        <div key={index} className="relative group">
                          <img
                            src={url}
                            alt={`Uploaded ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg"
                          />
                          <Button
                            variant="destructive"
                            size="icon"
                            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleRemoveImage(index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}

                  {uploadedImageUrls.length < 3 && (
                    <p className="text-sm text-gray-500">
                      {3 - uploadedImageUrls.length} image(s) can be uploaded
                    </p>
                  )}
                </div>
              </div>
            </div>
          </main>

          <div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0 h-[76px] left-0 w-full p-4 shadow-lg">
            <Button
              type="submit"
              className="  mr-3 mt-1 text-white  "
              disabled={
                addExpenseMutation.isPending || editExpenseMutation.isPending
              }
            >
              {editExpenseMutation.isPending || addExpenseMutation.isPending ? (
                <>
                  <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                  {editExpenseMutation.isPending ? "Updating..." : "Adding..."}
                </>
              ) : isEditing ? (
                "Update"
              ) : (
                "Add"
              )}
            </Button>
          </div>
        </form>
      </Form>
    </>
  );
};
