"use client";
import React, { useEffect, useState } from "react";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ChevronDown,
  ChevronsUpDown,
  ChevronUp,
  ListFilter,
  Pencil,
  PencilLine,
  Trash2,
} from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import CustomTable from "@/components/custom-table/custom-table";
import { toast } from "sonner";
import { getAllExpense } from "@/actions/expense/get-all-expense";
import { deleteExpense } from "@/actions/expense/delete-expense";
import useDebounce from "@/hooks/use-debounce";

const ExpensePage = () => {
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editExpenseData, setEditExpenseData] = useState(null);

  const queryClient = useQueryClient();

  const { confirmDelete } = useDeleteConfirmation();

  const [changePageCount, setChangePageCount] = useState(1);
  const [sortBy, setSortBy] = useState("date");
  const [sortOrder, setSortOrder] = useState("desc");
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");

  const debouncedSearchValue = useDebounce(searchValue, 500);

  const { data, isLoading, error } = useQuery({
    queryKey: [
      "expense",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
    ],
    queryFn: () =>
      getAllExpense(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue
      ),
  });

  useEffect(() => {
    setTotalRowCount(totalRowCount);
    setChangePageCount(1);
  }, [totalRowCount]);

  const tableData = data?.data?.data;
  const pagination_data = data?.data?.pagination;

  const deleteMutation = useMutation({
    mutationFn: (id) => deleteExpense(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["expense"] });

      if (!data?.message) {
        toast.error(data || data?.message || "Something Went Wrong");
      } else {
        toast.success(data?.message || "Expense deleted successfully");
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to delete the Expense. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
    },
  });

  const handleDelete = (expense) => {
    try {
      confirmDelete(
        `Are you sure you want to delete Expense ${expense?.voucherNumber}?`,
        () => {
          deleteMutation.mutate(expense.id);
        }
      );
    } catch (error) {
      console.error("Failed to delete Expense:", error);
    }
  };

  const handleEdit = (data) => {
    setIsSheetOpen(true);
    setEditExpenseData(data?.id);
  };

  const handleAddExpense = () => {
    setEditExpenseData(null); // Reset edit data when adding a new account
    setIsSheetOpen(true); // Open sheet for adding
  };

  const onSortChange = (sortedBy) => {
    if (sortBy === sortedBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(sortedBy);
      setSortOrder("asc");
    }
  };

  const renderSortIcon = (columnId) => {
    if (sortBy === columnId) {
      return sortOrder === "asc" ? (
        <ChevronDown className="ml-2 h-4 w-4" />
      ) : (
        <ChevronUp className="ml-2 h-4 w-4" />
      );
    }
    return <ChevronDown className="ml-2 h-4 w-4" />;
  };

  const myColumns = [
    {
      id: "voucherNumber",
      accessorKey: "voucherNumber",
      lable: "Expense Voucher No.",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("voucherNumber")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("voucherNumber");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Expense Voucher No.
              {renderSortIcon("voucherNumber")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("voucherNumber")}
          </div>
        </div>
      ),
    },
    {
      id: "date",
      accessorKey: "date",
      lable: "Date",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("date")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("date");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Date
              {renderSortIcon("date")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const date = new Date(row?.original.date);
        const formattedDate = date
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          })
          .split("/")
          .join("-");

        return <div className="text-left">{formattedDate}</div>;
      },
    },
    {
      id: "expenseAccountName",
      accessorKey: "expenseAccount.name",
      lable: "Expense Account",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("expenseAccountName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("expenseAccountName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Expense Account
              {renderSortIcon("expenseAccountName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.original?.expenseAccount?.name}
          </div>
        </div>
      ),
    },

    {
      id: "partyName",
      accessorKey: "partyName",
      lable: "Party Name",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("partyName")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("partyName");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Party Name
              {renderSortIcon("partyName")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("partyName")}
          </div>
        </div>
      ),
    },

    {
      id: "note",
      accessorKey: "note",
      lable: "Notes",
      width: 200,
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            // onClick={() => onSortChange("note")}
            // onKeyDown={(e) => {
            //   if (e.key === "Enter" || e.key === " ") {
            //     onSortChange("note");
            //   }
            // }}
            // tabIndex={0}
            // role="button"
          >
            <span className="flex items-center gap-1">
              Notes
              {/* {renderSortIcon("note")} */}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {row?.getValue("note")}
          </div>
        </div>
      ),
    },

    {
      id: "amount",
      accessorKey: "amount",
      lable: "Amount",
      width: 200,
      header: ({ column }) => (
        <div className="flex   justify-end">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("amount")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                onSortChange("amount");
              }
            }}
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">
              Amount
              {renderSortIcon("amount")}
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right  text-wrap">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap">
            {Number(row?.getValue("amount") || 0).toFixed(2)}
          </div>
        </div>
      ),
    },
    {
      id: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        return (
          <div className="flex justify-end capitalize">
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                onClick={() => handleDelete(userdata)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      },
    },
  ];

  const otherFilterFields = () => {
    return <div className=" pt-4 pb-4 flex justify-between "></div>;
  };

  return (
    <div>
      <Card>
        <CustomTable
          tableHeader="Expenses"
          data={tableData}
          columns={myColumns}
          isLoading={isLoading}
          error={error}
          addbuttonLable={" Add Expense"}
          onClickAddbutton={handleAddExpense}
          tableWidth="100%"
          paginationData={pagination_data}
          pageChangeCount={setChangePageCount}
          totalRowCount={setTotalRowCount}
          getSerchValue={setSearchValue}
          serchPlaceholder={"Search "}
          filterFields={otherFilterFields()}
          module="expenses"
        />
      </Card>

      <Custom_Sheet
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
        activeKey={"expenses"}
        editId={editExpenseData}
      />
    </div>
  );
};

export default ExpensePage;
