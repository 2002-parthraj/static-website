"use client";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
	Form,
	FormControl,
	FormField,
	FormItem,
	FormLabel,
	FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
	Card,
	CardHeader,
	CardTitle,
	CardContent,
	CardFooter,
} from "@/components/ui/card";
import { ReloadIcon } from "@radix-ui/react-icons";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { toast } from "sonner";

import { addGroup } from "@/actions/groups/add-group";
import { editGroup } from "@/actions/groups/edit-group";
import { addCategorie } from "@/actions/categories/add-categorie";
import { editCategorie } from "@/actions/categories/edit-categorie";
import { TextInputField } from "@/components/custom-form-fields/custom-form-fields";

const formSchema = z.object({
	name: z
		.string()
		.min(1, "Category name is required")
		.max(20, "Maximum length is 20 characters"),
});

const AddEditCategoriesForm = ({ onClose, editId }) => {
	const queryClient = useQueryClient();

	const [isFormSubmitting, setIsFormSubmitting] = useState(false);

	const form = useForm({
		resolver: zodResolver(formSchema),
		defaultValues: {
			name: "",
		},
	});

	useEffect(() => {
		if (editId) {
			form.reset({
				name: editId?.name || "",
			});
		}
	}, [editId, form]);

	const { mutate: addCategoriesMutation, isLoading } = useMutation({
		mutationFn: (payload) => addCategorie(payload),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["categories"] });

			if (data?.status === 201) {
				setIsFormSubmitting(false);
				toast.success("Categories added successfully");
				form.reset();
				onClose(false);
			} else {
				toast.error(data?.data?.error?.[0]?.message || "Something went wrong");
				setIsFormSubmitting(false);
			}
		},
		onError: (error) => {
			toast.error(
				`Failed to Add Categories. Error: ${
					error?.message || error || "Something went wrong"
				}`,
			);
			setIsFormSubmitting(false);
		},
	});

	const { mutate: editCategoriesMutation } = useMutation({
		mutationFn: (payload) => editCategorie(payload, editId?.id),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["categories"] });

			if (data?.status === 200) {
				setIsFormSubmitting(false);
				toast.success("Edit Categories successfully");
				form.reset();
				onClose(false);
			} else {
				toast.error(data?.data?.error?.[0]?.message || "Something went wrong");
				setIsFormSubmitting(false);
			}
		},
		onError: (error) => {
			toast.error(
				`Failed to edit Categories. Error: ${
					error?.message || error || "Something went wrong"
				}`,
			);
			setIsFormSubmitting(false);
		},
	});

	const onSubmit = (values) => {
		setIsFormSubmitting(true);
		const finalPayload = {};

		if (values?.name) finalPayload.name = values.name;

		editId
			? editCategoriesMutation(finalPayload)
			: addCategoriesMutation(finalPayload);
	};

	return (
		<>
			<div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
				<h2 className="text-lg font-semibold">
					{editId ? "Edit Category" : "Add Category"}
				</h2>
			</div>
			<Form {...form}>
				<form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
					<main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto">
						<div className="w-[90%] pt-4 mx-auto">
							<TextInputField
								form={form}
								name="name"
								placeholder="Enter Category Name Here"
								label="Category Name"
								type="text"
								required
							/>
						</div>
					</main>

					<div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0  h-[76px] left-0 w-full p-4 shadow-lg">
						<Button
							type="submit"
							className="  mr-3 mt-1 text-white  "
							disabled={isFormSubmitting}
						>
							{isFormSubmitting ? (
								<>
									<ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
									{editId ? "Updating..." : "Saving..."}
								</>
							) : editId ? (
								"Update Category"
							) : (
								"Add Category"
							)}
						</Button>
					</div>
				</form>
			</Form>
		</>
	);
};

export default AddEditCategoriesForm;
