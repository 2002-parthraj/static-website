"use client";

import React, { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  creditPeriodOption,
  gstTypeEnum,
  PartyTypeEnum,
} from "@/components/enums/enums";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Card, CardContent } from "../../../../../../components/ui/card";
import { Label } from "../../../../../../components/ui/label";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../../../../../../components/ui/tabs";
import { Button } from "../../../../../../components/ui/button";
import { Form } from "../../../../../../components/ui/form";
import { addParties } from "@/actions/parties/add-parties";
import { stateList } from "@/actions/comman/state-list";
import MultiSelect from "@/components/custom-multiselect-dropdown/custom-multiselect-dropdown";
import { getPartyById } from "@/actions/parties/get-single-party";
import { editparty } from "@/actions/parties/edit-party";
import { ReloadIcon } from "@radix-ui/react-icons";
import { getAllTagsData } from "@/actions/parties/get-all-tags";
import {
  FormSelectField,
  RadioGroupField,
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { GlobalAutoCompleteCombobox } from "@/components/custom-multiselect-dropdown/custom-multi-select-autocomplate";
import MultipleSelector from "@/components/custom-multiselect-dropdown/custom-multiple-Selector";
import { Switch } from "@/components/ui/switch";
import { Copy } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { getGSTDetails } from "@/actions/gst-details/get-gst-details";

const isEmptyValue = (value) => {
  return value === undefined || value === null || value === "" || value === 0;
};

const addressSchema = z
  .object({
    street: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
    pincode: z.coerce
      .number({ message: "Please enter valid pincode" })
      .nullable()
      .optional()
      .refine(
        (val) =>
          !val ||
          (val.toString().length === 6 && val >= 100000 && val <= 999999),
        { message: "Pincode must be exactly 6 digits" }
      ),
  })
  .superRefine((data, ctx) => {
    const hasAnyData = Object.values(data).some(
      (value) => !isEmptyValue(value)
    );

    if (hasAnyData) {
      if (!data.city) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "City is required when any field is provided",
          path: ["city"],
        });
      }
      if (!data.state) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "State is required when any field is provided",
          path: ["state"],
        });
      }
    }
  });

const billingaddressSchema = z
  .object({
    street: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
    pincode: z.coerce
      .number({ message: "Please enter valid pincode" })
      .nullable()
      .optional()
      .refine(
        (val) =>
          !val ||
          (val.toString().length === 6 && val >= 100000 && val <= 999999),
        { message: "Pincode must be exactly 6 digits" }
      ),
  })
  .superRefine((data, ctx) => {
    const hasAnyData = Object.values(data).some(
      (value) => !isEmptyValue(value)
    );

    if (hasAnyData) {
      if (!data.city) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "City is required when any field is provided",
          path: ["city"],
        });
      }
      if (!data.state) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "State is required when any field is provided",
          path: ["state"],
        });
      }
    }
  });

const addPartiesSchema = z
  .object({
    name: z
      .string({ message: "Please enter party name" })
      .trim()
      .min(2, "Name will be atleast more then 2 character"),
    companyName: z.string().optional(),

    mobile: z
      .string()
      .trim()
      .nullish() // allows null or undefined
      .transform((val) => val || null) // transforms empty strings to undefined
      .refine((value) => !value || /^[0-9]{10}$/.test(value), {
        message: "Please enter a valid 10-digit mobile number.",
      }),
    email: z
      .string()
      .trim()
      .nullish() // allows null or undefined
      .transform((val) => val || null) // transforms empty strings to undefined
      .refine((value) => !value || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), {
        message: "Please enter a valid email.",
      }),
    gstn: z
      .string()
      .trim()
      .nullish() // allows null or undefined
      .transform((val) => val || null)
      .refine(
        (value) =>
          !value ||
          (value.length === 15 &&
            /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(
              value
            )),
        {
          message:
            "GSTN must be exactly 15 characters long and follow the standard format (e.g., 22AAAAA0000A1Z5).",
        }
      ),
    gstType: z.enum(["regular", "composition", "unregistered"]).optional(),
    pan: z
      .string()
      .trim()
      .nullish() // allows null or undefined
      .transform((val) => val || null)
      .refine(
        (value) =>
          !value ||
          (value.length === 10 && /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(value)),
        {
          message:
            "PAN must be exactly 10 characters long and follow the standard format (e.g., ABCDE1234F).",
        }
      ),
    partyType: z.enum(["customer", "supplier", "both"], {
      message: "Please select your party type",
    }),

    openingBalance: z.coerce.number().optional().nullable().default(),
    creditPeriod: z.coerce.number().nonnegative().nullable().optional(),
    creditLimit: z.coerce.number().nonnegative().nullable().optional(),
    discountPercentage: z.coerce.number().nonnegative().nullable().optional(),
    isActive: z.boolean().optional().default(true),
    billingAddress: billingaddressSchema,
    shippingAddress: addressSchema,
    tags: z.array(z.string()).optional(),
    bankDetails: z
      .object({
        bankName: z.string().optional(),
        branchName: z.string().optional(),
        ifscCode: z
          .string()
          .trim()
          .optional()
          .nullable()
          .refine((value) => !value || /^[A-Z]{4}0[A-Z0-9]{6}$/.test(value), {
            message:
              "IFSC code must be in the format: 4 uppercase letters, followed by a '0', and then 6 alphanumeric characters (e.g., ABCD0123456).",
          }),
        accountNumber: z
          .string()
          .trim()
          .optional()
          .refine((value) => !value || /^\d+$/.test(value), {
            message: "Account number must contain only digits.",
          })
          .refine(
            (value) => !value || (value.length >= 9 && value.length <= 18),
            {
              message: "Account number must be between 9 and 18 digits long.",
            }
          ),
      })
      .optional(),
  })
  .refine(
    (data) => {
      if (
        (data.gstType === "regular" || data.gstType === "composition") &&
        !data.gstn
      ) {
        return false;
      }
      return true;
    },
    {
      message: "GSTN is required if GST Type is 'Regular' or 'Composition'.",
      path: ["gstn"],
    }
  );

export const AddPartiesForm = ({ onclose, editId, onPartyAdded }) => {
  const queryClient = useQueryClient();
  const [shippingAddtessInitialadata, setShippingAddtessInitialadata] =
    useState(null);
  const [billingAddtessInitialadata, setBillingAddtessInitialadata] =
    useState(null);
  const [hasGST, setHasGST] = useState(false);
  const [fetchedGSTNumber, setFetchedGSTNumber] = useState("");
  const [initialGSTNumber, setInitialGSTNumber] = useState("");

  const form = useForm({
    resolver: zodResolver(addPartiesSchema),
    defaultValues: {
      partyType: "customer",
      isActive: true,
      billingAddress: {},
      shippingAddress: {},
      tags: [],
      bankDetails: {},
    },
  });

  const { data: initialpartyData } = useQuery({
    queryKey: ["party", editId],
    queryFn: () => getPartyById(editId),
    enabled: !!editId,
  });

  const initialBillingStateId = initialpartyData?.addresses?.find(
    (val) => val.type === "billing"
  )?.stateId;

  const initialShippingStateId = initialpartyData?.addresses?.find(
    (val) => val.type === "shipping"
  )?.stateId;

  useEffect(() => {
    if (initialpartyData) {
      const billingAddress =
        initialpartyData?.addresses?.find(
          (address) => address.type === "billing"
        ) || {};

      const shippingAddress =
        initialpartyData?.addresses?.find(
          (address) => address.type === "shipping"
        ) || {};

      const hasGSTDetails = !!(
        initialpartyData?.gstType || initialpartyData?.gstn
      );
      setHasGST(hasGSTDetails);

      setShippingAddtessInitialadata(shippingAddress);
      setBillingAddtessInitialadata(billingAddress);

      // Basic fields that should be set only if they have values
      const conditionalFields = {
        mobile: initialpartyData?.mobile,
        email: initialpartyData?.email,
        gstn: initialpartyData?.gstn,
        gstType: initialpartyData?.gstType,
        pan: initialpartyData?.pan,
      };

      // Only set values for fields that are not empty or undefined
      Object.entries(conditionalFields).forEach(([field, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          form.setValue(field, value);
        }
      });

      form.setValue("name", initialpartyData?.name || "");
      form.setValue("companyName", initialpartyData?.companyName || "");
      // form.setValue("mobile", initialpartyData?.mobile || "");
      // form.setValue("email", initialpartyData?.email || "");
      // form.setValue("gstn", initialpartyData?.gstn || "");
      // form.setValue("gstType", initialpartyData?.gstType || undefined);
      // form.setValue("pan", initialpartyData?.pan || "");

      form.setValue("partyType", initialpartyData?.partyType || "");
      form.setValue(
        "openingBalance",
        initialpartyData?.openingBalance != null &&
          !isNaN(Number(initialpartyData.openingBalance))
          ? Number(initialpartyData.openingBalance).toFixed(2)
          : "0.00"
      );
      form.setValue(
        "discountPercentage",
        initialpartyData?.discountPercentage != null &&
          !isNaN(Number(initialpartyData.discountPercentage))
          ? Number(initialpartyData.discountPercentage).toFixed(2)
          : "0.00"
      );
      // form.setValue("creditPeriod", initialpartyData?.creditPeriod.toString() || "");
      form.setValue(
        "creditPeriod",
        initialpartyData?.creditPeriod != null
          ? initialpartyData.creditPeriod.toString()
          : ""
      );
      form.setValue(
        "creditLimit",
        initialpartyData?.creditLimit != null &&
          !isNaN(Number(initialpartyData.creditLimit))
          ? Number(initialpartyData.creditLimit).toFixed(2)
          : "0.00"
      );
      form.setValue("isActive", initialpartyData?.isActive || false);

      form.setValue(
        "billingAddress.street",
        billingAddress?.street || undefined
      );
      form.setValue("billingAddress.city", billingAddress?.city || undefined);
      form.setValue(
        "billingAddress.state",
        billingAddress?.stateId ? billingAddress.stateId.toString() : ""
      );
      form.setValue("billingAddress.country", billingAddress?.country || "");
      form.setValue("billingAddress.pincode", billingAddress?.pincode || "");

      form.setValue(
        "shippingAddress.street",
        shippingAddress?.street || undefined
      );
      form.setValue("shippingAddress.city", shippingAddress?.city || undefined);
      form.setValue(
        "shippingAddress.state",
        shippingAddress?.stateId ? shippingAddress.stateId.toString() : ""
      );
      form.setValue("shippingAddress.country", shippingAddress?.country || "");
      form.setValue("shippingAddress.pincode", shippingAddress?.pincode || "");

      form.setValue("tags", initialpartyData?.tags || []);
      form.setValue(
        "bankDetails.bankName",
        initialpartyData?.bankDetails?.bankName || ""
      );
      form.setValue(
        "bankDetails.branchName",
        initialpartyData?.bankDetails?.branchName || ""
      );
      form.setValue(
        "bankDetails.ifscCode",
        initialpartyData?.bankDetails?.ifscCode || ""
      );
      form.setValue(
        "bankDetails.accountNumber",
        initialpartyData?.bankDetails?.accountNumber || ""
      );
    }
  }, [initialpartyData, form]);

  // Add effect to watch GST number changes
  const gstNumber = form.watch("gstn");

  // Set initial GST number when form loads in edit mode
  useEffect(() => {
    if (initialpartyData?.gstn) {
      setInitialGSTNumber(initialpartyData.gstn);
      setFetchedGSTNumber(initialpartyData.gstn);
    }
  }, [initialpartyData]);

  // Validate GST number format
  const isValidGSTFormat = (gst) => {
    return /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(
      gst
    );
  };

  // Function to fetch GST details
  const {
    mutate: fetchGSTDetails,
    isLoading: isLoadingGST,
    error,
  } = useMutation({
    mutationFn: getGSTDetails,
    onSuccess: (response) => {
      // If response is an error message string
      if (
        typeof response === "string" &&
        response.includes("status code 400")
      ) {
        toast.error("Failed to fetch GST details");
        return;
      }

      if (response?.data?.success && response?.data?.data) {
        const gstData = response?.data?.data;

        setFetchedGSTNumber(gstNumber); // Store the GST number we've fetched

        // Auto-fill form fields
        form.setValue("companyName", gstData.ownerName || "");
        form.setValue("name", gstData.name || "");

        // Set GST Type
        if (gstData.gstType?.toLowerCase() === "regular") {
          form.setValue("gstType", "regular");
        } else if (gstData.gstType?.toLowerCase() === "composition") {
          form.setValue("gstType", "composition");
        }

        // Auto-fill address
        if (gstData.address) {
          form.setValue("billingAddress.street", gstData.address.street || "");
          form.setValue("billingAddress.city", gstData.address.city || "");

          // Find state ID from state name
          const stateObj = stateOptions.find(
            (state) =>
              state.label.toLowerCase() === gstData.address.state.toLowerCase()
          );
          if (stateObj) {
            form.setValue("billingAddress.state", stateObj.value.toString());
          }

          form.setValue(
            "billingAddress.pincode",
            gstData.address.pincode || ""
          );
        }

        toast.success("GST details fetched successfully");
        if (gstData.status?.toLowerCase() === "cancelled") {
          toast.warning("GST number is cancelled");
        }
      }
    },
    onError: (error) => {
      toast.error(error?.[0]?.message || "Failed to fetch GST details");
    },
  });

  useEffect(() => {
    const handleGSTChange = () => {
      if (
        gstNumber &&
        gstNumber.length === 15 &&
        isValidGSTFormat(gstNumber) &&
        gstNumber !== fetchedGSTNumber &&
        gstNumber !== initialGSTNumber
      ) {
        fetchGSTDetails(gstNumber);
      }
    };

    // Add a small delay to avoid immediate API calls while typing
    const timeoutId = setTimeout(handleGSTChange, 1000);
    return () => clearTimeout(timeoutId);
  }, [gstNumber, fetchedGSTNumber, initialGSTNumber, fetchGSTDetails]);

  useEffect(() => {
    if (gstNumber && gstNumber.length === 15) {
      const panFromGst = gstNumber.slice(2, -3);
      const currentPan = form.getValues("pan");
      if (!currentPan || currentPan !== panFromGst) {
        form.setValue("pan", panFromGst);
      }
    }
  }, [form, gstNumber]);

  const { data: state } = useQuery({
    queryKey: ["states"],
    queryFn: stateList,
    onError: (error) => {
      toast.error(error || "Failed to load state list. Please try again.");
    },
  });

  const { data: tags } = useQuery({
    queryKey: ["tags"],
    queryFn: getAllTagsData,
    onError: (error) => {
      toast.error(error || "Failed to load tags list. Please try again.");
    },
  });
  const tagsOptions = tags?.data?.data?.map((val, ind) => ({
    value: val?.name,
    label: val?.name?.toUpperCase(),
  }));
  const errorsData = useMemo(() => form?.formState?.errors, [form.formState]);

  const mutation = useMutation({
    mutationFn: editId ? (data) => editparty(data, editId) : addParties,
    onSuccess: handleMutationSuccess,
    onError: handleMutationError,
  });

  function handleMutationSuccess(data) {
    queryClient.invalidateQueries({ queryKey: ["parties"] });

    if (data?.status === 200 || data?.status === 201) {
      onclose();
      form.reset();
      if (!editId) {
        if (data?.data?.id && data?.data?.name) {
          onPartyAdded === undefined
            ? null
            : onPartyAdded({
                value: data?.data?.id.toString(),
                label: data?.data?.name,
              });
        } else {
          console.error("Newly created party data is incomplete:", data);
        }
      }
      toast.success(`Party ${editId ? "Updated" : "Added"} successfully`);
    } else if (data?.status === 409) {
      toast.warning(data?.data?.error[0]?.message || "A conflict occurred");
    } else {
      toast.error(
        data?.response?.data?.error[0]?.message ||
          "An unexpected error occurred"
      );
    }
  }

  function handleMutationError(error) {
    toast.error(error || "Something went wrong, try again");
  }

  const stateOptions = useMemo(
    () =>
      state?.data?.map((state) => ({
        value: state.id, // Keep as number
        label: state.name,
      })) || [],
    [state]
  );

  const billingValues = form.watch("billingAddress");

  const onSubmit = (data) => {
    const transformedData = {
      ...data,
      // tags: data.tags,
      // gstn: data.gstn === "" ? undefined : data.gstn,
      // email: data.email === "" ? undefined : data.email,
      // mobile: data.mobile === "" ? undefined : data.mobile,
      // pan: data.pan || undefined,

      gstn: !hasGST ? null : data.gstn === "" ? undefined : data.gstn,
      gstType: !hasGST ? null : data.gstType,

      bankDetails: {
        ...data.bankDetails,
        ifscCode:
          data.bankDetails?.ifscCode === ""
            ? undefined
            : data.bankDetails.ifscCode,
        accountNumber:
          data.bankDetails?.accountNumber === ""
            ? undefined
            : data.bankDetails?.accountNumber,
      },
      addresses: [
        {
          ...data.billingAddress,
          type: "billing",
          id:
            billingAddtessInitialadata === null
              ? undefined
              : billingAddtessInitialadata?.id,
          street:
            data.billingAddress?.street === ""
              ? undefined
              : data.billingAddress?.street,
          city:
            data.billingAddress?.city === ""
              ? undefined
              : data.billingAddress?.city,
          stateId: data.billingAddress.state
            ? Number(data.billingAddress.state)
            : undefined,
          pincode:
            data.billingAddress?.pincode === 0
              ? undefined
              : data.billingAddress.pincode,
        },
        {
          ...data.shippingAddress,
          type: "shipping",
          id:
            shippingAddtessInitialadata === null
              ? undefined
              : shippingAddtessInitialadata?.id,

          city:
            data.shippingAddress?.city === ""
              ? undefined
              : data.shippingAddress?.city,
          street:
            data.shippingAddress?.street === ""
              ? undefined
              : data.shippingAddress?.street,
          stateId: data.shippingAddress.state
            ? Number(data.shippingAddress.state)
            : undefined,
          pincode:
            data.shippingAddress?.pincode === 0
              ? undefined
              : data.shippingAddress.pincode,
        },
      ],
    };

    delete transformedData.billingAddress;
    delete transformedData.shippingAddress;
    mutation.mutate(transformedData);
  };

  return (
    <>
      <div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-[#ECF1FF] p-6 border-b">
        <h2 className="text-lg text-[#192839] font-semibold">
          {editId ? "Edit Party" : "Add Party"}
        </h2>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <main className=" h-[calc(100vh-153px)] overflow-y-auto  ">
            <div className="mx-auto w-[90%] gap-4 py-4">
              <RadioGroupField
                control={form.control}
                name={"partyType"}
                options={PartyTypeEnum}
                label={"Party Type"}
              />
            </div>

            <div className="w-[90%] mx-auto">
              <TextInputField
                form={form}
                name={"name"}
                placeholder={"Enter Party Name Here"}
                label={"Party Name"}
                type={"text"}
                required
              />
            </div>
            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form={form}
                name={"companyName"}
                placeholder={"Enter Company Name Here"}
                label={"Company Name"}
                type={"text"}
              />
            </div>

            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form={form}
                name={"mobile"}
                placeholder={"Enter Contact Number Here"}
                label={"Contact Number"}
                type={"text"}
              />
            </div>
            <div className="w-[90%] pt-4 mx-auto">
              <TextInputField
                form={form}
                name={"email"}
                placeholder={"Enter Email Address Here"}
                label={"Email"}
                type={"text"}
              />
            </div>

            <div className=" w-[90%] pt-4 pb-4 mx-auto">
              <div className="flex items-center gap-2">
                <span className="text-sm">Have GST Number</span>
                <Switch
                  className="data-[state=checked]:  data-[state=unchecked]:bg-input"
                  checked={hasGST}
                  onCheckedChange={setHasGST}
                />
              </div>

              {hasGST && (
                <>
                  {/* {(form.watch("gstType") === "regular" ||
                    form.watch("gstType") === "composition") && ( */}
                  <div className=" pt-4">
                    <TextInputField
                      form={form}
                      name="gstn"
                      placeholder="Enter GST Number Here"
                      label="GST Number"
                      type="text"
                      required
                    />
                  </div>
                  {/* )} */}

                  <div className=" pt-4">
                    <FormSelectField
                      control={form.control}
                      name="gstType"
                      label="GST Type"
                      intialValue={
                        editId ? `${initialpartyData?.gstType || ""}` : ""
                      }
                      placeholder="Choose GST Type"
                      options={gstTypeEnum}
                    />
                  </div>
                </>
              )}
            </div>

            <div className="w-full h-10">
              <Tabs
                defaultValue="address"
                className="w-full  border-t-4 border-gray-200"
              >
                <div className="border-b pb-[2px] border-gray-300 text-center overflow-x-auto overflow-y-hidden">
                  <TabsList className="w-full mt-2 flex justify-start flex-row rounded-lg bg-white">
                    <TabsTrigger
                      value="address"
                      className={
                        errorsData?.billingAddress?.pincode ||
                        errorsData?.shippingAddress?.pincode
                          ? "text-red-500 pb-4"
                          : "flex-1 rounded-none pb-4 text-sm font-medium text-gray-700 data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary  data-[state=active]:border-b-2 data-[state=active]:border-primary"
                      }
                    >
                      Address
                    </TabsTrigger>
                    <TabsTrigger
                      value="otherDetails"
                      className={
                        errorsData?.pan ||
                        errorsData?.openingBalance ||
                        errorsData?.creditPeriod ||
                        errorsData?.creditLimit ||
                        errorsData?.discountPercentage
                          ? "text-red-500 pb-4"
                          : "flex-1 rounded-none pb-4 text-sm font-medium text-gray-700   data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                      }
                    >
                      Other Details
                    </TabsTrigger>
                    <TabsTrigger
                      value="bankDetails"
                      className={
                        errorsData?.bankDetails?.bankName ||
                        errorsData?.bankDetails?.branchName ||
                        errorsData?.bankDetails?.ifscCode ||
                        errorsData?.bankDetails?.accountNumber
                          ? "text-red-500 pb-4"
                          : "flex-1 pb-4 rounded-none text-sm font-medium text-gray-700 data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary  data-[state=active]:border-b-2 data-[state=active]:border-primary"
                      }
                    >
                      Bank Details
                    </TabsTrigger>
                  </TabsList>
                </div>
                <TabsContent value="bankDetails">
                  <div className="">
                    <div className="w-[90%] pt-4 mx-auto">
                      <TextInputField
                        form={form}
                        name={"bankDetails.accountNumber"}
                        placeholder={"Enter Account Number Here"}
                        label={"Account Number"}
                        type={"text"}
                      />
                    </div>
                    <div className="w-[90%] pt-4 mx-auto">
                      <TextInputField
                        form={form}
                        name={"bankDetails.ifscCode"}
                        placeholder={"Enter IFSC Code Here"}
                        label={"IFSC Code"}
                        type={"text"}
                      />
                    </div>
                    <div className="w-[90%] pt-4 mx-auto">
                      <TextInputField
                        form={form}
                        name={"bankDetails.bankName"}
                        placeholder={"Enter Bank Name Here"}
                        label={"Bank Name"}
                        type={"text"}
                      />
                    </div>
                    <div className="w-[90%] pt-4 pb-4 mx-auto">
                      <TextInputField
                        form={form}
                        name={"bankDetails.branchName"}
                        placeholder={"Enter Branch Name Here"}
                        label={"Branch"}
                        type={"text"}
                      />
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="otherDetails">
                  <div>
                    <div className="w-[90%] pt-4 mx-auto">
                      <FormSelectField
                        control={form.control}
                        name={"creditPeriod"}
                        label={"Payment Terms"}
                        intialValue={
                          editId && initialpartyData?.creditPeriod != null
                            ? initialpartyData.creditPeriod.toString()
                            : ""
                        }
                        placeholder={"Choose Payment Term"}
                        options={creditPeriodOption}
                      />
                    </div>

                    <div className="w-[90%] pt-4 mx-auto">
                      <TextInputField
                        form={form}
                        name={"creditLimit"}
                        placeholder={"Define Credit Limit"}
                        label={"Credit Limit"}
                        type={"text"}
                      />
                    </div>
                    <div className="w-[90%] pt-4 mx-auto">
                      <TextInputField
                        form={form}
                        name={"discountPercentage"}
                        placeholder={"Enter Discount in Percentage Here"}
                        label={"Default Discount (%)"}
                        type={"text"}
                      />
                    </div>
                    <div className="w-[90%] pt-4 mx-auto">
                      <TextInputField
                        form={form}
                        name={"openingBalance"}
                        placeholder={"Enter Opening Balance If Any"}
                        label={"Opening Balance"}
                        type={"text"}
                      />
                    </div>
                    <div className="w-[90%] pt-4 mx-auto">
                      <Controller
                        name="tags"
                        control={form.control}
                        render={({ field }) => (
                          <MultipleSelector
                            value={
                              Array.isArray(field.value)
                                ? field.value.map((tag) =>
                                    typeof tag === "string"
                                      ? {
                                          value: tag,
                                          label: tag.toUpperCase(),
                                        }
                                      : tag
                                  )
                                : []
                            }
                            onChange={(newValue) =>
                              field.onChange(
                                newValue.map((option) => option.value || option)
                              )
                            }
                            options={tagsOptions}
                            creatable
                            label="Tags"
                            placeholder="Choose Tag"
                            //
                          />
                        )}
                      />
                    </div>
                    <div className="w-[90%] pt-4 pb-4 mx-auto">
                      <TextInputField
                        form={form}
                        name={"pan"}
                        placeholder={"Enter PAN Number Here"}
                        label={"PAN Number"}
                        type={"text"}
                      />
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="address">
                  <div className="flex flex-col sm:flex-row justify-between w-[90%] gap-4 pt-4 pb-4 mx-auto">
                    <div className="sm:w-[50%] w-full mx-auto sm:border-r border-gray-300 sm:pr-4">
                      <Label
                        htmlFor="billing"
                        className="font-medium text-[16px] text-[#40566D]"
                      >
                        Billing Address
                      </Label>
                      <div className="w-full pt-2 mx-auto">
                        <TextareaInputField
                          form={form}
                          name={"billingAddress.street"}
                          placeholder={"Area,Street,Sector"}
                          label={"Address Line"}
                          rows={3}
                        />
                      </div>

                      <div className="w-full pt-4 mx-auto">
                        <TextInputField
                          form={form}
                          name={"billingAddress.city"}
                          placeholder={"Enter Town/City"}
                          label={"Town/City"}
                          type={"text"}
                        />
                      </div>

                      <div className="w-full pt-4 mx-auto">
                        <FormSelectField
                          control={form.control}
                          name="billingAddress.state"
                          label="State"
                          intialValue={
                            initialBillingStateId
                              ? initialBillingStateId.toString()
                              : ""
                          }
                          placeholder="Choose State"
                          options={stateOptions.map((option) => ({
                            ...option,
                            value: option.value.toString(),
                          }))}
                        />
                      </div>

                      <div className="w-full pt-4 mx-auto">
                        <TextInputField
                          form={form}
                          name={"billingAddress.pincode"}
                          placeholder={"Enter Pincode"}
                          label={"Pincode"}
                          type={"text"}
                        />
                      </div>
                    </div>
                    <div className="sm:w-[50%] w-full mx-auto pl-2">
                      <div className="w-full">
                        <Label
                          htmlFor="shipping"
                          className="font-medium text-[16px] text-[#40566D]"
                        >
                          Shipping Address
                        </Label>

                        <div className="w-full pt-2 mx-auto">
                          <TextareaInputField
                            form={form}
                            name={"shippingAddress.street"}
                            placeholder={"Area,Street,Sector"}
                            label={"Address Line"}
                            rows={3}
                          />
                        </div>

                        <div className="w-full pt-4 mx-auto">
                          <TextInputField
                            form={form}
                            name={"shippingAddress.city"}
                            placeholder={"Enter Town/City"}
                            label={"Town/City"}
                            type={"text"}
                          />
                        </div>

                        <div className="w-full pt-4 mx-auto">
                          <FormSelectField
                            control={form.control}
                            name="shippingAddress.state"
                            label="State"
                            intialValue={
                              initialShippingStateId
                                ? initialShippingStateId.toString()
                                : ""
                            }
                            placeholder="Choose State"
                            options={stateOptions.map((option) => ({
                              ...option,
                              value: option.value.toString(),
                            }))}
                          />
                        </div>

                        <div className="w-full pt-4 mx-auto">
                          <TextInputField
                            form={form}
                            name={"shippingAddress.pincode"}
                            placeholder={"Enter Pincode"}
                            label={"Pincode"}
                            type={"text"}
                          />
                        </div>

                        {/* Same as Billing Checkbox */}
                        <div className="flex items-center space-x-2 mt-4">
                          <Checkbox
                            id="sameAsBilling"
                            onCheckedChange={(checked) => {
                              if (checked) {
                                // Copy billing address values to shipping address
                                form.setValue(
                                  "shippingAddress.street",
                                  form.getValues("billingAddress.street") || ""
                                );
                                form.setValue(
                                  "shippingAddress.city",
                                  form.getValues("billingAddress.city") || ""
                                );
                                form.setValue(
                                  "shippingAddress.state",
                                  form.getValues("billingAddress.state") || ""
                                );
                                form.setValue(
                                  "shippingAddress.pincode",
                                  form.getValues("billingAddress.pincode") || ""
                                );
                              } else {
                                // Clear shipping address fields and trigger form update
                                form.setValue(
                                  "shippingAddress",
                                  {
                                    street: "",
                                    city: "",
                                    state: "",
                                    pincode: "",
                                  },
                                  {
                                    shouldDirty: true,
                                    shouldTouch: true,
                                    shouldValidate: true,
                                  }
                                );
                              }
                            }}
                          />
                          <label
                            htmlFor="sameAsBilling"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            Same As Billing Address
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </main>

          <div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0  h-[76px] left-0 w-full p-4 shadow-lg">
            <Button
              type="submit"
              className="  mr-3 mt-1 text-white hover: "
              disabled={mutation.isPending}
            >
              {mutation.isPending ? (
                <>
                  <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                  {editId ? "Updating..." : "Saving..."}
                </>
              ) : editId ? (
                "Update Party"
              ) : (
                "Add Party"
              )}
            </Button>
          </div>
        </form>
      </Form>
      {/* </div> */}
    </>
  );
};
