"use client";
import React, { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ChevronDownIcon,
  CalendarIcon,
  Pencil,
  Trash2,
  PencilLine,
  Printer,
  LoaderCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";
import CustomTable from "@/components/custom-table/custom-table";
import { useParams, useRouter } from "next/navigation";
import { getPartyStatement } from "@/actions/parties/get-all-parties";
import { Card } from "@/components/ui/card";
import { TableBody, TableCell, TableRow } from "@/components/ui/table";
import CustomTableWithFooter from "@/components/custom-table-with-footer/custom-table-with-footer";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { deleteReceipts } from "@/actions/receipts/delete-receipts";
import { deletePayments } from "@/actions/payments/delete-payment";
import { deleteInvoice } from "@/actions/invoice/delete-invoice";
import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";
import { deleteBills } from "@/actions/bills/delete-bill";
import { deleteCreditNotes } from "@/actions/credit_notes/delete-credit-notes";
import { deleteVendoreCredit } from "@/actions/vendor-credit/delete-vendorCredit";
import { toast } from "sonner";

const printStyles = `
  @media print {
    .no-print {
      display: none !important;
    }

    // .print-only {
    //   display: block !important;
    // }

    @page {
      size: auto;
      margin: 0mm;
    }
  }

  .print-only {
    display: none; /* Hidden by default */
  }
`;

const PartyStatement = () => {
  const [generatePDF, setGeneratePDF] = useState(false);
  const queryClient = useQueryClient();
  const router = useRouter();
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [activeKey, setActiveKey] = useState("");
  const { confirmDelete } = useDeleteConfirmation();
  const params = useParams();
  const partyId = params.partyId;
  const [lineItemData, setLineItemData] = useState(null);
  const [chunkedlineItems, setChunkedLineItems] = useState([]);

  // Function to get the financial year dates
  const getFinancialYearDates = () => {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth(); // 0-based (0 = January)

    let fromDate, toDate;

    // If current month is January to March (0-2), we're in the previous financial year
    if (currentMonth < 3) {
      fromDate = new Date(currentYear - 1, 3, 1); // April 1st of previous year
      toDate = new Date(currentYear, 2, 31); // March 31st of current year
    } else {
      fromDate = new Date(currentYear, 3, 1); // April 1st of current year
      toDate = new Date(currentYear + 1, 2, 31); // March 31st of next year
    }

    return { from: fromDate, to: toDate };
  };

  // const [date, setDate] = useState({
  //   from: new Date(),
  //   to: new Date(new Date().setMonth(new Date().getMonth() + 1))
  // });

  const [date, setDate] = useState(getFinancialYearDates());

  // Convert date objects to formatted strings for the API
  const fromDate = format(date.from, "yyyy-MM-dd");
  const toDate = format(date.to, "yyyy-MM-dd");

  const { data, isLoading, error } = useQuery({
    queryKey: ["partyStatement", partyId, fromDate, toDate],
    queryFn: () => getPartyStatement(partyId, fromDate, toDate),
  });

  const calculateTotals = (transactions) => {
    if (!transactions) return { totalDebit: 0, totalCredit: 0 };
    return transactions.reduce(
      (acc, curr) => ({
        totalDebit: acc.totalDebit + (curr.debit || 0),
        totalCredit: acc.totalCredit + (curr.credit || 0),
      }),
      { totalDebit: 0, totalCredit: 0 }
    );
  };

  useEffect(() => {
    // Add print styles to document head
    const style = document.createElement("style");
    style.innerHTML = printStyles;
    document.head.appendChild(style);

    return () => {
      document.head.removeChild(style);
    };
  }, []);

  // const handlePrint = () => {
  //   // const printContents = document.getElementById("printable-card").innerHTML;
  //   // const originalContents = document.body.innerHTML;
  //   // document.body.innerHTML = printContents;
  //   // window.print();
  //   // document.body.innerHTML = originalContents;
  //   // window.location.reload(); // Reload to rehydrate the React app
  //   // -------------------PDF Download-------------

  //   const content = document.getElementById("printable-card");

  //   if (content) {
  //     html2canvas(content).then((canvas) => {
  //       const imgData = canvas.toDataURL("image/png");
  //       const doc = new jsPDF();

  //       // Get image properties
  //       const imgProps = doc.getImageProperties(imgData);
  //       const pdfWidth = doc.internal.pageSize.getWidth();
  //       const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

  //       // Add image to PDF
  //       doc.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
  //       doc.save("downloaded-document.pdf");
  //     });
  //   }

  //   //   const contents = document.querySelectorAll("#printable-card");

  //   //   contents.forEach((content, index) => {
  //   //     // Temporarily make the element visible for capturing
  //   //     const originalDisplay = content.style.display;
  //   //     content.style.display = "block";

  //   //     // Ensure the element is fully rendered before capturing
  //   //     // setTimeout(() => {
  //   //     html2canvas(content, {
  //   //       useCORS: true,
  //   //       scale: 2,
  //   //       logging: false,
  //   //       scrollX: 0,
  //   //       scrollY: -window.scrollY,
  //   //     })
  //   //       .then((canvas) => {
  //   //         // Restore original display
  //   //         content.style.display = originalDisplay;

  //   //         const imgData = canvas.toDataURL("image/png");
  //   //         const doc = new jsPDF({
  //   //           orientation: "portrait",
  //   //           unit: "px",
  //   //           format: "a4",
  //   //         });

  //   //         // Get image properties
  //   //         const imgProps = doc.getImageProperties(imgData);
  //   //         const pdfWidth = doc.internal.pageSize.getWidth();
  //   //         const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

  //   //         // Add image to PDF
  //   //         doc.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);

  //   //         // Save with a unique filename if multiple elements exist
  //   //         const filename =
  //   //           contents.length > 1
  //   //             ? `downloaded-document-${index + 1}.pdf`
  //   //             : "downloaded-document.pdf";

  //   //         doc.save(filename);
  //   //       })
  //   //       .catch((error) => {
  //   //         console.error("Error capturing content:", error);
  //   //         // Restore original display in case of error
  //   //         content.style.display = originalDisplay;
  //   //       });
  //   //   });
  // };

  // const handlePrint = async () => {
  //   if (generatePDF) return;
  //   try {
  //     setGeneratePDF(true);
  //     const content = document.getElementById("printable-card");

  //     if (content) {
  //       // Create canvas with custom settings to avoid UI rendering
  //       const options = {
  //         logging: false, // Disable logging
  //         useCORS: true,
  //         allowTaint: true,
  //         backgroundColor: null,
  //         scale: 2, // Higher quality
  //         onclone: (clonedDoc) => {
  //           // Remove any notification elements if they exist
  //           const notifications =
  //             clonedDoc.getElementsByClassName("notification");
  //           if (notifications.length > 0) {
  //             Array.from(notifications).forEach((notification) => {
  //               notification.remove();
  //             });
  //           }
  //         },
  //       };

  //       html2canvas(content, options).then((canvas) => {
  //         // Convert to PDF silently
  //         const imgData = canvas.toDataURL("image/png", 1.0);
  //         const pdf = new jsPDF({
  //           orientation: "portrait",
  //           unit: "mm",
  //           format: "a4",
  //           compress: true,
  //         });

  //         const pdfWidth = pdf.internal.pageSize.getWidth();
  //         const pdfHeight = pdf.internal.pageSize.getHeight();

  //         // Add image while maintaining aspect ratio
  //         const imgProps = pdf.getImageProperties(imgData);
  //         const aspectRatio = imgProps.height / imgProps.width;

  //         let renderHeight = pdfWidth * aspectRatio;
  //         let renderWidth = pdfWidth;

  //         // Check if height exceeds page height
  //         if (renderHeight > pdfHeight) {
  //           renderHeight = pdfHeight;
  //           renderWidth = renderHeight / aspectRatio;
  //         }

  //         // Center the image
  //         const xOffset = (pdfWidth - renderWidth) / 2;
  //         const yOffset = (pdfHeight - renderHeight) / 2;

  //         pdf.addImage(
  //           imgData,
  //           "PNG",
  //           xOffset,
  //           yOffset,
  //           renderWidth,
  //           renderHeight,
  //           undefined,
  //           "FAST"
  //         );

  //         // Save PDF without showing dialog
  //         pdf
  //           .save("downloaded-document.pdf", { returnPromise: true })
  //           .then(() => {
  //             // Clean up
  //             canvas.remove();
  //           })
  //           .catch((error) => {
  //             console.error("PDF generation failed:", error);
  //           });
  //       });
  //     }
  //   } catch (error) {
  //     console.error("PDF genration", error);
  //   } finally {
  //     setGeneratePDF(false);
  //   }
  // };

  // const handlePrint = async () => {
  //   if (generatePDF) return;
  //   try {
  //     setGeneratePDF(true);
  //     const content = document.getElementById("printable-card");

  //     if (content) {
  //       const options = {
  //         logging: false,
  //         useCORS: true,
  //         allowTaint: true,
  //         backgroundColor: null,
  //         scale: 2,
  //         onclone: (clonedDoc) => {
  //           const notifications =
  //             clonedDoc.getElementsByClassName("notification");
  //           if (notifications.length > 0) {
  //             Array.from(notifications).forEach((notification) => {
  //               notification.remove();
  //             });
  //           }
  //         },
  //       };

  //       html2canvas(content, options).then((canvas) => {
  //         const imgData = canvas.toDataURL("image/png", 1.0);
  //         const pdf = new jsPDF({
  //           orientation: "portrait",
  //           unit: "mm",
  //           format: "a4",
  //           compress: true,
  //         });

  //         const pdfWidth = pdf.internal.pageSize.getWidth();
  //         const pdfHeight = pdf.internal.pageSize.getHeight();

  //         // Get image properties
  //         const imgProps = pdf.getImageProperties(imgData);
  //         const aspectRatio = imgProps.height / imgProps.width;

  //         // Calculate dimensions for a full page
  //         let renderWidth = pdfWidth;
  //         let renderHeight = pdfWidth * aspectRatio;

  //         // If content height exceeds page height, split into multiple pages
  //         if (renderHeight > pdfHeight) {
  //           const totalPages = Math.ceil(renderHeight / pdfHeight);
  //           let remainingHeight = renderHeight;
  //           let sourceY = 0;
  //           const pageHeight = pdfHeight;
  //           const scaleFactor = canvas.width / renderWidth;

  //           for (let page = 0; page < totalPages; page++) {
  //             if (page > 0) {
  //               pdf.addPage();
  //             }

  //             // Calculate height for current page
  //             const currentHeight = Math.min(pageHeight, remainingHeight);
  //             const sourceHeight = currentHeight * scaleFactor;

  //             // Create temporary canvas for the page portion
  //             const tempCanvas = document.createElement("canvas");
  //             tempCanvas.width = canvas.width;
  //             tempCanvas.height = sourceHeight;
  //             const ctx = tempCanvas.getContext("2d");

  //             // Draw portion of original canvas
  //             ctx.drawImage(
  //               canvas,
  //               0,
  //               sourceY,
  //               canvas.width,
  //               sourceHeight,
  //               0,
  //               0,
  //               canvas.width,
  //               sourceHeight
  //             );

  //             // Convert to image data
  //             const pageImgData = tempCanvas.toDataURL("image/png", 1.0);

  //             // Add to PDF
  //             pdf.addImage(
  //               pageImgData,
  //               "PNG",
  //               0,
  //               0,
  //               pdfWidth,
  //               currentHeight,
  //               undefined,
  //               "FAST"
  //             );

  //             // Update remaining height and source position
  //             remainingHeight -= currentHeight;
  //             sourceY += sourceHeight;

  //             // Clean up
  //             tempCanvas.remove();
  //           }
  //         } else {
  //           // Single page case - center the image
  //           const xOffset = (pdfWidth - renderWidth) / 2;
  //           const yOffset = (pdfHeight - renderHeight) / 2;

  //           pdf.addImage(
  //             imgData,
  //             "PNG",
  //             xOffset,
  //             yOffset,
  //             renderWidth,
  //             renderHeight,
  //             undefined,
  //             "FAST"
  //           );
  //         }

  //         // Save PDF
  //         pdf
  //           .save("downloaded-document.pdf", { returnPromise: true })
  //           .then(() => {
  //             canvas.remove();
  //           })
  //           .catch((error) => {
  //             console.error("PDF generation failed:", error);
  //           });
  //       });
  //     }
  //   } catch (error) {
  //     console.error("PDF generation", error);
  //   } finally {
  //     setGeneratePDF(false);
  //   }
  // };

  // const handlePrint = async () => {
  //   if (generatePDF) return;
  //   try {
  //     setGeneratePDF(true);
  //     const content = document.getElementById("printable-card");

  //     if (content) {
  //       const options = {
  //         scale: 2,
  //         useCORS: true,
  //         allowTaint: true,
  //         logging: false,
  //         backgroundColor: "#ffffff", // Set white background
  //         onclone: (clonedDoc) => {
  //           const notifications =
  //             clonedDoc.getElementsByClassName("notification");
  //           if (notifications.length > 0) {
  //             Array.from(notifications).forEach((notification) => {
  //               notification.remove();
  //             });
  //           }
  //         },
  //       };

  //       try {
  //         const canvas = await html2canvas(content, options);
  //         const imgData = canvas.toDataURL("image/jpeg", 1.0); // Changed to JPEG format

  //         const pdf = new jsPDF({
  //           orientation: "portrait",
  //           unit: "mm",
  //           format: "a4",
  //           compress: true,
  //         });

  //         const pdfWidth = pdf.internal.pageSize.getWidth();
  //         const pdfHeight = pdf.internal.pageSize.getHeight();
  //         const imgWidth = canvas.width;
  //         const imgHeight = canvas.height;
  //         const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
  //         const imgX = (pdfWidth - imgWidth * ratio) / 2;
  //         const imgY = 30;

  //         const contentHeight = imgHeight * ratio;
  //         const maxHeight = pdfHeight - 40; // Leave some margin
  //         const totalPages = Math.ceil(contentHeight / maxHeight);

  //         let remainingHeight = imgHeight;
  //         let currentPosition = 0;

  //         for (let i = 0; i < totalPages; i++) {
  //           if (i > 0) {
  //             pdf.addPage();
  //           }

  //           const pageHeight = Math.min(remainingHeight, maxHeight / ratio);

  //           const tempCanvas = document.createElement("canvas");
  //           tempCanvas.width = imgWidth;
  //           tempCanvas.height = pageHeight;

  //           const ctx = tempCanvas.getContext("2d");
  //           ctx.drawImage(
  //             canvas,
  //             0,
  //             currentPosition,
  //             imgWidth,
  //             pageHeight,
  //             0,
  //             0,
  //             imgWidth,
  //             pageHeight
  //           );

  //           const pageImgData = tempCanvas.toDataURL("image/jpeg", 1.0);

  //           pdf.addImage(
  //             pageImgData,
  //             "JPEG",
  //             imgX,
  //             imgY,
  //             imgWidth * ratio,
  //             pageHeight * ratio
  //           );

  //           remainingHeight -= pageHeight;
  //           currentPosition += pageHeight;
  //           tempCanvas.remove();
  //         }

  //         await pdf.save("statement.pdf", { returnPromise: true });
  //         canvas.remove();
  //       } catch (error) {
  //         console.error("Error in PDF generation:", error);
  //         toast.error("Error generating PDF. Please try again.");
  //       }
  //     }
  //   } catch (error) {
  //     console.error("PDF generation error:", error);
  //     toast.error("Failed to generate PDF. Please try again.");
  //   } finally {
  //     setGeneratePDF(false);
  //   }
  // };

  const voucherTypeMapping = {
    bill: "bills",
    vendor_credit: "debit-note",
    credit_note: "credit-note",
    invoice: "invoice",
  };

  const handleEstimatesEdit = (userdata) => {
    if (
      userdata.voucherType === "payment" ||
      userdata.voucherType === "receipt"
    ) {
      setEditId(userdata.voucherId);
      setIsSheetOpen(true);
      setActiveKey(userdata.voucherType);
    } else {
      const pathType =
        voucherTypeMapping[userdata.voucherType] || userdata.voucherType;
      router.push(`/${pathType}/${userdata.voucherId}`);
    }
  };

  const deleteMutation = useMutation({
    mutationFn: async (userData) => {
      try {
        let response;

        switch (userData.voucherType) {
          case "payment":
            response = await deletePayments(userData.voucherId);
            break;
          case "receipt":
            response = await deleteReceipts(userData.voucherId);
            break;
          case "invoice":
            response = await deleteInvoice(userData.voucherId);
            break;
          case "bill":
            response = await deleteBills(userData.voucherId);
            break;
          case "vendor_credit":
            response = await deleteVendoreCredit(userData.voucherId);
            break;
          case "credit_note":
            response = await deleteCreditNotes(userData.voucherId);
            break;
          default:
            throw new Error(
              `Unsupported voucher type: ${userData.voucherType}`
            );
        }

        if (!response) {
          throw new Error("No response received from delete operation");
        }

        return response;
      } catch (error) {
        // Properly transform the error to ensure it's handled by onError
        throw new Error(error?.message || "Failed to delete the statement");
      }
    },
    onSuccess: (data) => {
      // Invalidate and refetch the party statement query
      queryClient.invalidateQueries(["partyStatement"]);

      // Show success message
      toast.success(data?.message || "Statement deleted successfully");
    },
    onError: (error) => {
      // Handle error case
      toast.error(error?.message || "Failed to delete the statement");
    },
  });

  // Updated handleDelete function
  const handleDelete = async (userdata) => {
    try {
      confirmDelete(
        `Are you sure you want to delete ${userdata.particulars}?`,
        () => {
          deleteMutation.mutate({
            voucherType: userdata.voucherType,
            voucherId: userdata.voucherId,
          });
        }
      );
    } catch (error) {
      console.error("Failed to delete statement:", error);
      toast.error("An unexpected error occurred while deleting");
    }
  };

  const myColumns = [
    {
      id: "date",
      accessorKey: "date",
      lable: "Date",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-nowrap text-gray-900">
            <span className="flex items-center gap-1">Date</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">
          {format(new Date(row?.getValue("date")), "dd-MM-yyyy")}
        </div>
      ),
    },
    {
      id: "particulars",
      accessorKey: "particulars",
      lable: "Voucher Type",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">Voucher Type</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">
          {row?.getValue("particulars")}
        </div>
      ),
    },
    {
      id: "voucherNo",
      accessorKey: "voucherNo",
      lable: "Voucher No.",
      header: ({ column }) => (
        <div className="flex justify-start">
          <div
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            tabIndex={0}
            role="button"
          >
            <span className="flex items-center gap-1">Voucher No.</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">
          {row?.getValue("voucherNo")}
        </div>
      ),
    },
    {
      id: "debit",
      accessorKey: "debit",
      lable: "Debit",
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span className="flex items-center gap-1">Debit</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right">
          {/* {row?.getValue("debit")} */}
          {row?.getValue("debit")
            ? Number(row?.getValue("debit")).toLocaleString("en-IN", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })
            : "-"}
        </div>
      ),
    },
    {
      id: "credit",
      accessorKey: "credit",
      lable: "Credit",
      header: ({ column }) => (
        <div className="flex justify-end">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span className="flex items-center gap-1">Credit</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-right">
          {/* {row?.getValue("credit")} */}
          {row?.getValue("credit")
            ? Number(row?.getValue("credit")).toLocaleString("en-IN", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })
            : "-"}
        </div>
      ),
    },

    // {
    //   id: "actions",
    //   accessorKey: "actions",
    //   enableHiding: false,
    //   header: ({ column }) => (
    //     <div className="flex justify-end no-print">
    //       <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
    //         <span style={{ display: "flex", alignItems: "center" }}>
    //           Actions
    //         </span>
    //       </div>
    //     </div>
    //   ),
    //   cell: ({ row }) => {
    //     const userdata = row?.original;

    //     return (
    //       <div className="flex justify-end capitalize no-print">
    //         <div className="border-r border-gray-300 flex items-center">
    //           <Button
    //             size="icon"
    //             className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
    //             onClick={() => handleEstimatesEdit(userdata)}
    //           >
    //             <PencilLine className="h-4 w-4" />
    //           </Button>
    //         </div>
    //         <div className="flex items-center">
    //           <Button
    //             size="icon"
    //             className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
    //             onClick={() => handleDelete(userdata)}
    //           >
    //             <Trash2 className="h-4 w-4" />
    //           </Button>
    //         </div>
    //       </div>
    //     );
    //   },
    // },
    {
      id: "actions",
      accessorKey: "actions",
      enableHiding: false,
      header: ({ column }) => (
        <div className="flex justify-end no-print">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span style={{ display: "flex", alignItems: "center" }}>
              Actions
            </span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const userdata = row?.original;
        const rowIndex = row.index; // Get the row index
        // Return empty div if it's the first row (index 0)
        if (rowIndex === 0) {
          return <div className="flex justify-end" />;
        }
        return (
          <div className="flex justify-end capitalize no-print">
            <div className="border-r border-gray-300 flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
                onClick={() => handleEstimatesEdit(userdata)}
              >
                <PencilLine className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center">
              <Button
                size="icon"
                className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
                onClick={() => handleDelete(userdata)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      },
    },
  ];

  // Header component with date range and ledger info
  const Header = () => (
    <div className="flex justify-between items-center p-4 border-b overflow-x-auto">
      <div className="flex items-center gap-2">
        <span className="font-medium">Ledger:</span>
        <span>{data?.data?.data?.party?.name}</span>
      </div>
      <div className="flex items-center gap-4 no-print">
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className="w-64 justify-start text-left font-normal"
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date?.from ? (
                date.to ? (
                  <>
                    {format(date.from, "dd MMM yyyy")} -{" "}
                    {format(date.to, "dd MMM yyyy")}
                  </>
                ) : (
                  format(date.from, "dd MMM yyyy")
                )
              ) : (
                <span>Pick a date range</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0 " align="end">
            <Calendar
              initialFocus
              mode="range"
              defaultMonth={date?.from}
              selected={{ from: date?.from, to: date?.to }}
              onSelect={setDate}
              numberOfMonths={2}
            />
          </PopoverContent>
        </Popover>
        <Button
          variant="outline"
          className="flex items-center gap-2 no-print"
          onClick={() => handlePrint()}
          // onClick={() => generatePDF("printable-card")}
        >
          {generatePDF ? (
            <div className="animate-spin">
              <LoaderCircle />
            </div>
          ) : (
            <>
              <Printer className="h-4 w-4" />
              <span>Print</span>
            </>
          )}
        </Button>
      </div>
    </div>
  );

  const { totalDebit, totalCredit } = calculateTotals(
    data?.data?.data?.transactions
  );

  const getBalanceFields = (value) => ({
    debit: value > 0 ? Math.abs(value) : null,
    credit: value < 0 ? Math.abs(value) : null,
  });

  const sumFields = (field1, field2) => {
    const sumDebit = (field1.debit || 0) + (field2.debit || 0);
    const sumCredit = (field1.credit || 0) + (field2.credit || 0);

    return { debit: sumDebit, credit: sumCredit };
  };

  const footerData = {
    openingBalance: getBalanceFields(data?.data?.data?.openingBalance || 0),
    currentBalance: {
      debit: totalDebit,
      credit: totalCredit,
    },
    closingBalance: {
      debit: data?.data?.data?.closingBalance?.debit,
      credit: data?.data?.data?.closingBalance?.credit,
    },
  };

  const ITEMS_PER_PAGE = 40;

  const chunkArray = (array, size) => {
    const chunked = [];
    for (let i = 0; i < array.length; i += size) {
      chunked.push(array.slice(i, i + size));
    }
    return chunked;
  };

  useEffect(() => {
    if (lineItemData && lineItemData.length > 0) {
      // Create chunks of line items, with 5 items per chunk
      const chunks = chunkArray(lineItemData, ITEMS_PER_PAGE);
      setChunkedLineItems(chunks);
    }
  }, [lineItemData]);

  const TableData = data?.data?.data?.transactions || [];

  useEffect(() => {
    if (TableData?.length > 0) {
      setLineItemData(TableData);
    }
  }, [TableData]);

  const renderStatement = (TableData, index) => {
    const pageCount = index;
    const currentPageCount = pageCount + 1;
    return (
      <>
        <div
          style={{
            width: "210mm", // A4 width
            minHeight: "297mm", // A4 height
            // padding: "10mm", // Add some padding
            boxSizing: "border-box",
            backgroundColor: "#ffffff",
          }}
          className="p-8"
        >
          <div className="">
            <div className=" text-center mb-4">
              <h1 className="text-xl font-bold">
                {data?.data?.data?.party?.name}
              </h1>
              <p className="">Party Statement</p>
              <div className="">
                {/* <p>
                  <b>From</b>:{data?.data?.data?.period?.fromDate}
                </p>
                <p>
                  <b>to</b>:{data?.data?.data?.period?.toDate}
                </p> */}
                <span className="mr-1">From:</span>
                <span className="mr-2">
                  {data?.data?.data?.period?.fromDate}
                </span>
                <span className="mr-1">to:</span>
                <span>{data?.data?.data?.period?.toDate}</span>
              </div>
            </div>

            {/* After compelition of code use print-only hidden in div classname*/}
            <div className=" ">
              <table className="w-[100%] border-collapse">
                <thead>
                  <tr className="border-t-2 border-b-2 border-black ">
                    <th className="text-left">
                      <div className="mb-4 text-[15px]">Date</div>
                    </th>
                    <th className="  text-left">
                      <div className="mb-4 text-[15px]">Particulars</div>
                    </th>
                    <th className="  text-left">
                      <div className="mb-4 text-[15px]">Voucher No.</div>
                    </th>
                    <th className="  text-right">
                      <div className="mb-4 text-[15px]">Debit</div>
                    </th>
                    <th className="  text-right">
                      <div className="mb-4 text-[15px]">Credit</div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {TableData?.map((data, index) => (
                    <tr key={index}>
                      <td className="text-left">
                        {format(new Date(data?.date), "dd-MM-yyyy")}
                      </td>
                      <td className="text-left">
                        <b>{data?.particulars}</b>
                      </td>
                      <td className="text-left">{data?.voucherNo}</td>
                      <td className="text-right">{data?.debit.toFixed(2)}</td>
                      <td className="text-right">{data?.credit.toFixed(2)}</td>
                    </tr>
                  ))}
                  <div className="pb-2"></div>
                  {chunkedlineItems?.length === index + 1 ? (
                    <>
                      <tr className="text-left   border-t-2 border-black">
                        <td></td>
                        <td className="text-left font-bold">
                          <div className="mb-3">Closing Balance</div>
                        </td>
                        <td></td>
                        <td className=" text-right ">
                          <div className="mb-3 ">
                            {data?.data?.data?.closingBalance?.debit.toFixed(2)}
                          </div>
                        </td>
                        <td className="text-right  ">
                          <div className=" mb-3">
                            {data?.data?.data?.closingBalance?.credit.toFixed(
                              2
                            )}
                          </div>
                        </td>
                      </tr>

                      <tr className="text-left border-b-2 border-t-2 border-black ">
                        <td></td>
                        <td className="text-left font-bold">
                          <div className="mb-3">Current Total</div>
                        </td>
                        <td></td>
                        <td className="text-center">
                          <div className=" text-right mb-3">
                            {footerData.currentBalance.debit.toFixed(2)}
                          </div>
                        </td>
                        <td className="text-center">
                          <div className="text-right mb-3">
                            {footerData.currentBalance.credit.toFixed(2)}
                          </div>
                        </td>
                      </tr>
                    </>
                  ) : (
                    ""
                  )}
                </tbody>
              </table>
            </div>
          </div>
          <div className="text-right">
            <span className="ml-[5px] text-xs">
              Page {currentPageCount} of {chunkedlineItems.length}
            </span>
          </div>
        </div>
      </>
    );
  };
  const handlePrint = async () => {
    if (generatePDF) return;
    try {
      setGeneratePDF(true);

      const renderTemplate = (lineItems, i) => (
        <div
          style={{
            width: "210mm",
            minHeight: "297mm",
            backgroundColor: "#ffffff",
          }}
        >
          {renderStatement(lineItems, i)}
        </div>
      );

      // Create container for rendering
      const templateId = "statement-template";
      const container = document.createElement("div");
      container.id = templateId;
      container.style.position = "absolute";
      container.style.left = "-9999px";
      container.style.top = "0";
      container.style.width = "210mm"; // A4 width
      container.style.backgroundColor = "#ffffff";
      document.body.appendChild(container);

      // Initialize PDF with A4 size
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
        compress: true,
      });

      // PDF dimensions
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      // Render template using React
      const { createRoot } = await import("react-dom/client");
      const root = createRoot(container);

      // Process each chunk/page
      for (let i = 0; i < chunkedlineItems.length; i++) {
        // Render current page
        await new Promise((resolve) => {
          root.render(
            <div id={templateId}>{renderTemplate(chunkedlineItems[i], i)}</div>
          );
          setTimeout(resolve, 500); // Wait for rendering
        });

        // HTML2Canvas options
        const options = {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
          width: 793, // A4 width in pixels (210mm at 96 DPI)
          height: 1122, // A4 height in pixels (297mm at 96 DPI)
          onclone: (clonedDoc) => {
            const notifications =
              clonedDoc.getElementsByClassName("notification");
            Array.from(notifications).forEach((notification) =>
              notification.remove()
            );
          },
        };

        try {
          // Generate canvas for current page
          const canvas = await html2canvas(container.firstChild, options);
          const imgData = canvas.toDataURL("image/jpeg", 1.0);

          // Calculate scaling to fit A4
          const imgWidth = canvas.width;
          const imgHeight = canvas.height;
          const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);

          // Center image on page
          const xOffset = (pdfWidth - imgWidth * ratio) / 2;
          const yOffset = 0;

          // Add new page if not first page
          if (i > 0) {
            pdf.addPage();
          }

          // Add image to PDF
          pdf.addImage(
            imgData,
            "JPEG",
            xOffset,
            yOffset,
            imgWidth * ratio,
            imgHeight * ratio,
            undefined,
            "FAST"
          );

          canvas.remove();
        } catch (error) {
          console.error(`Error generating page ${i + 1}:`, error);
          throw error;
        }
      }

      // Save the complete PDF
      await pdf.save("statement.pdf", { returnPromise: true });

      // Cleanup
      root.unmount();
      document.body.removeChild(container);
    } catch (error) {
      console.error("PDF generation error:", error);
      toast.error("Failed to generate PDF. Please try again.");
    } finally {
      setGeneratePDF(false);
    }
  };

  return (
    <>
      <div>
        <Card className="rounded-md ">
          <Header />
          <CustomTableWithFooter
            data={TableData}
            columns={myColumns}
            isLoading={isLoading}
            error={error}
            tableWidth="100%"
            footerData={footerData}
          />
          {/* <Footer /> */}
        </Card>
        {/* After compelition of code use print-only hidden in div classname*/}
        <Custom_Sheet
          isOpen={isSheetOpen}
          onClose={() => setIsSheetOpen(false)}
          activeKey={activeKey}
          editId={editId}
        />
      </div>
      <div className="">
        {/* <div
          style={{ border: "1px solid red" }}
          className="w[210mm]"
          id="printable-card"
        >
          {chunkedlineItems.map((lineItems, index) =>
            renderStatement(lineItems, index)
          )}
        </div> */}
        {/* Hidden print div */}
        {/* <div
          id="printable-card"
          style={{
            position: "absolute",
            left: "-9999px",
            top: "-9999px",
            width: "210mm",
            visibility: "hidden",
            overflow: "hidden",
            height: 0,
            opacity: 0,
            pointerEvents: "none",
            backgroundColor: "#ffffff",
          }}
          aria-hidden="true"
        >
          {chunkedlineItems.map((lineItems, index) =>
            renderStatement(lineItems, index)
          )}
        </div> */}
      </div>
    </>
  );
};

export default PartyStatement;
