"use client";
import React, { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getAllParties } from "@/actions/parties/get-all-parties";
import {
	ChevronDown,
	ChevronDownIcon,
	ChevronUp,
	ListFilter,
	PencilLine,
	Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

import CustomTable from "@/components/custom-table/custom-table";

import useDebounce from "@/hooks/use-debounce";

import { useDeleteConfirmation } from "@/hooks/use-delete-confirmation-modal";

import { deleteParty } from "@/actions/parties/delete-party";
import { patchtogglePartyStatus } from "@/actions/parties/toggle-party-status";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const PartyList = () => {
	const queryClient = useQueryClient();
	const router = useRouter();
	const { confirmDelete } = useDeleteConfirmation();

	const [changePageCount, setChangePageCount] = useState(1);
	const [sortBy, setSortBy] = useState("createdAt");
	const [sortOrder, setSortOrder] = useState("desc");
	const [totalRowCount, setTotalRowCount] = useState(10);
	const [searchValue, setSearchValue] = useState("");
	const [selectedPartyId, setSelectedPartyId] = useState(null);
	const [status, setStatus] = useState({
		key: "all",
		heading: "All",
	});
	const [filterBy, setFilterBy] = useState({
		key: "both",
		heading: "All",
	});
	const [isEditPartySheetOpen, setEditPartyIsSheetOpen] = useState(false);
	const [editPartyData, seteditPartyData] = useState(null);
	const debouncedSearchValue = useDebounce(searchValue, 500);

	const { data, isLoading, error } = useQuery({
		queryKey: [
			"parties",
			changePageCount,
			sortBy,
			sortOrder,
			totalRowCount,
			debouncedSearchValue,
			status,
			filterBy,
		],
		queryFn: () =>
			getAllParties(
				changePageCount,
				sortBy,
				sortOrder,
				totalRowCount,
				debouncedSearchValue,
				status,
				filterBy,
			),
	});

	useEffect(() => {
		setTotalRowCount(totalRowCount);
		setChangePageCount(1);
	}, [totalRowCount]);

	const deleteMutation = useMutation({
		mutationFn: (id) => deleteParty(id),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["parties"] });

			if (!data?.data?.message) {
				toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
			} else {
				toast.success(data?.data?.message || "Party deleted successfully");
			}
		},
		onError: (error) => {
			toast.error(
				`Failed to delete the party. Error: ${
					error?.message || error || "Something went wrong"
				}`,
			);
		},
	});

	const handleDelete = (userId) => {
		confirmDelete(`User ${userId?.name}`, () => {
			deleteMutation.mutate(userId?.id);
		});
	};

	const handleEdit = (userdata) => {
		setEditPartyIsSheetOpen(true);
		seteditPartyData(userdata?.id);
	};
	const onSortChange = (sortedBy) => {
		if (sortBy === sortedBy) {
			setSortOrder(sortOrder === "asc" ? "desc" : "asc");
		} else {
			setSortBy(sortedBy);
			setSortOrder("asc");
		}
	};

	const renderSortIcon = (columnId) => {
		if (sortBy === columnId) {
			return sortOrder === "asc" ? (
				<ChevronDown className="ml-2 h-4 w-4" />
			) : (
				<ChevronUp className="ml-2 h-4 w-4" />
			);
		}
		return <ChevronDown className="ml-2 h-4 w-4" />;
	};

	const handlePartiesNameClick = (partyId) => {
		router.push(`parties/statement/${partyId}`);
	};

	const myColumns = [
		{
			id: "select",
			header: ({ table }) => (
				<div className="flex justify-center">
					<Checkbox
						checked={selectedPartyId !== null}
						onCheckedChange={(value) => {
							if (!value) {
								setSelectedPartyId(null);
								table?.toggleAllPageRowsSelected(false);
							}
						}}
						aria-label="Select party"
					/>
				</div>
			),
			cell: ({ row }) => (
				<div className="flex justify-center">
					<Checkbox
						checked={selectedPartyId === row.original.id}
						onCheckedChange={(value) => {
							if (value) {
								setSelectedPartyId(row.original.id);
							} else {
								setSelectedPartyId(null);
							}
						}}
						aria-label="Select row"
					/>
				</div>
			),
			enableSorting: false,
			enableHiding: false,
		},

		{
			id: "name",
			accessorKey: "name",
			label: "Name",
			header: ({ column }) => (
				<div className="flex justify-start">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-left text-gray-900"
						onClick={() => onSortChange("name")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("name");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span className="flex items-center gap-1">
							Name
							{renderSortIcon("name")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div
					className="text-left cursor-pointer hover:text-blue-500"
					onClick={() => handlePartiesNameClick(row.original.id)}
				>
					{row?.getValue("name")}
				</div>
			),
		},
		{
			id: "companyName",
			accessorKey: "companyName",
			lable: "Company Name",
			header: ({ column }) => (
				<div className="flex justify-start">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center  text-gray-900"
						onClick={() => onSortChange("companyName")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("companyName");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span className="flex items-center gap-1">
							Company Name
							{renderSortIcon("companyName")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-left ">{row?.getValue("companyName")}</div>
			),
		},
		{
			id: "mobile",
			accessorKey: "mobile",
			lable: "Mobile Number",
			header: ({ column }) => (
				<div className="flex justify-start">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						onClick={() => onSortChange("mobile")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("mobile");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span className="flex items-center gap-1">
							Mobile Number
							{renderSortIcon("mobile")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-left">{row?.getValue("mobile")}</div>
			),
		},
		{
			id: "payable",
			accessorKey: "payable",
			lable: "To Pay",
			header: ({ column }) => (
				<div className="flex justify-end">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						onClick={() => onSortChange("payable")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("payable");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span className="flex items-center gap-1">
							To Pay
							{renderSortIcon("payable")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-right capitalize text-nowrap">
					{Number(row?.getValue("payable") || 0).toFixed(2)}
				</div>
			),
		},
		{
			id: "receivable",
			accessorKey: "receivable",
			lable: "To Receive",
			header: ({ column }) => (
				<div className="flex justify-end">
					<div
						className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
						onClick={() => onSortChange("receivable")}
						onKeyDown={(e) => {
							if (e.key === "Enter" || e.key === " ") {
								onSortChange("receivable");
							}
						}}
						tabIndex={0}
						role="button"
					>
						<span className="flex items-center gap-1">
							To Receive
							{renderSortIcon("receivable")}
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => (
				<div className="text-right capitalize text-nowrap">
					{Number(row?.getValue("receivable") || 0).toFixed(2)}
				</div>
			),
		},

		{
			id: "actions",
			enableHiding: false,
			header: ({ column }) => (
				<div className="flex justify-end">
					<div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
						<span style={{ display: "flex", alignItems: "center" }}>
							Actions
						</span>
					</div>
				</div>
			),
			cell: ({ row }) => {
				const userdata = row?.original;

				return (
					<div className="flex justify-end capitalize">
						<div className="border-r border-gray-300 flex items-center">
							<Button
								size="icon"
								className="bg-white hover:bg-inherit mr-2 shadow-none border text-black"
								onClick={() => handleEdit(userdata)}
							>
								<PencilLine className="h-4 w-4" />
							</Button>
						</div>
						<div className="flex items-center">
							<Button
								size="icon"
								className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
								onClick={() => handleDelete(userdata)}
							>
								<Trash2 className="h-4 w-4" />
							</Button>
						</div>
					</div>
				);
			},
		},
	];

	const ChangeStatus = (param) => {
		setStatus(param);
		setSelectedPartyId(null);
	};

	const handleFilterByChange = (params) => {
		setFilterBy(params);
		setSelectedPartyId(null);
	};

	const togglePartyStatusMutation = useMutation({
		mutationFn: (id) => patchtogglePartyStatus(id),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["parties"] });

			if (!data?.data?.message) {
				toast.error(data?.data || data?.[0]?.message || "Something Went Wrong");
			} else {
				toast.success(
					data?.data?.message || "Party activate or inactivate successfully",
				);
				setSelectedPartyId(null);
			}
		},
		onError: (error) => {
			toast.error(
				`Failed . Error: ${error?.message || error || "Something went wrong"}`,
			);
		},
	});

	const handleActiveInactiveParty = (id) => {
		togglePartyStatusMutation.mutate(id);
	};

	const handleAddParties = () => {
		seteditPartyData(null);
		setEditPartyIsSheetOpen(true); // Open sheet for adding
	};

	const otherFilterFields = () => {
		return (
			<div className=" pt-4 pb-4 flex justify-between ">
				{selectedPartyId && (
					<>
						<div className="pr-3">
							{status?.key !== "active" ? (
								<Button
									variant="outline"
									onClick={() => handleActiveInactiveParty(selectedPartyId)}
									className="ml-auto"
								>
									Mark as Active
								</Button>
							) : (
								<Button
									variant="outline"
									onClick={() => handleActiveInactiveParty(selectedPartyId)}
									className="ml-auto"
								>
									Mark as Inactive
								</Button>
							)}
						</div>
					</>
				)}
				<div className="mr-3">
					<DropdownMenu>
						<DropdownMenuTrigger asChild className="py-0">
							<Button variant="outline" className="ml-auto">
								{filterBy?.heading} <ChevronDownIcon className="ml-2 h-4 w-4" />
							</Button>
						</DropdownMenuTrigger>
						<DropdownMenuContent align="end">
							<DropdownMenuItem
								className="ml-auto"
								onClick={() =>
									handleFilterByChange({
										key: "both",
										heading: "All",
									})
								}
							>
								All
							</DropdownMenuItem>
							<DropdownMenuItem
								className="ml-auto"
								onClick={() =>
									handleFilterByChange({
										key: "customer",
										heading: "Customer",
									})
								}
							>
								Customer
							</DropdownMenuItem>
							<DropdownMenuItem
								className="ml-auto"
								onClick={() =>
									handleFilterByChange({
										key: "supplier",
										heading: "Supplier",
									})
								}
							>
								Supplier
							</DropdownMenuItem>
						</DropdownMenuContent>
					</DropdownMenu>
				</div>
			</div>
		);
	};

	const tableData = data?.data?.data;
	const pagination_data = data?.data?.pagination;

	return (
		<Card className="rounded-md">
			{/* <div> */}
			<CustomTable
				data={tableData || []}
				columns={myColumns || []}
				isLoading={isLoading}
				error={error}
				tableHeader="Parties"
				tableWidth={"100%"}
				paginationData={pagination_data}
				pageChangeCount={setChangePageCount}
				totalRowCount={setTotalRowCount}
				getSerchValue={setSearchValue}
				addbuttonLable={"Add Party"}
				onClickAddbutton={handleAddParties}
				serchPlaceholder={"Search"}
				filterFields={otherFilterFields()}
				module="parties"
			/>

			<Custom_Sheet
				isOpen={isEditPartySheetOpen}
				onClose={() => setEditPartyIsSheetOpen(false)}
				activeKey={"Parties"}
				editId={editPartyData}
			/>
			{/* </div> */}
		</Card>
	);
};

export default PartyList;
