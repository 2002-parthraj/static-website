/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { ReloadIcon } from "@radix-ui/react-icons";
import { getItemsMasterData } from "@/actions/items/get-master-data";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { addItem } from "@/actions/items/add-item";
import { getItemById } from "@/actions/items/get-single-item";
import { editItem } from "@/actions/items/edit-item";
import { uploadFile } from "@/actions/items/file-upload";
import { toast } from "sonner";
import { format } from "date-fns";

import SwitchFormField, {
  CommonCalendarInput,
  FormSelectField,
  FormSelectFieldForDisabledOption,
  GlobalCheckbox,
  RadioGroupField,
  SwitchField,
  TextareaInputField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";

import { itemtypeOption } from "@/components/enums/enums";
import { gsttaxTypeOption } from "@/components/enums/enums";
import { rateTypeOption } from "@/components/enums/enums";
import { isTrackableOption } from "@/components/enums/enums";
import { GlobalAutoCompleteCombobox } from "@/components/custom-multiselect-dropdown/custom-multi-select-autocomplate";
import MultipleSelector from "@/components/custom-multiselect-dropdown/custom-multiple-Selector";
import { getCommonInitData } from "@/actions/common-init/get-common-init-data";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import {
  ChevronsUpDown,
  CircleAlert,
  IndianRupee,
  Percent,
  X,
} from "lucide-react";
import { getOrganizationsGSTInfo } from "@/actions/organization-gst-info/get-organization-gst-info";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";

const formSchema = z
  .object({
    itemType: z.enum(["goods", "service"], "Item Type is required"),
    unit: z.string().min(1, "Unit is required"),
    itemName: z
      .string()
      .min(1, "item name is required")
      .max(255, "Maximum length is 255 characters"),

    // gstType: z.string().optional(),
    gstType: z
      .enum(["taxable", "nonTaxable", "outOfScope", "nonGstSupply"])
      .optional(),

    interGstTaxId: z.string().optional(),
    intraGstTaxId: z.string().optional(),
    hsn: z.string().max(20, "Maximum length is 20 characters"),
    sac: z.string().max(20, "Maximum length is 20 characters"),
    barcode: z.string().max(20, "Maximum length is 20 characters"),
    mrp: z
      .preprocess(
        (value) => (value === "" ? undefined : Number(value)),
        z.number().optional()
      )
      .refine((value) => value === undefined || !Number.isNaN(value), {
        message: "MRP must be a valid number",
      })
      .refine(
        (value) =>
          value === undefined ||
          /^\d{1,10}(\.\d{1,4})?$/.test(value.toString()),
        {
          message: "MRP must have up to 10 digits and 4 decimal places",
        }
      )
      .optional(),

    discountPercentage: z
      .preprocess(
        (value) => (value === "" ? undefined : Number(value)),
        z.number().optional()
      )
      .refine((value) => value === undefined || !Number.isNaN(value), {
        message: "Discount % must be a valid number",
      })
      .refine(
        (value) =>
          value === undefined ||
          /^\d{1,10}(\.\d{1,4})?$/.test(value.toString()),
        {
          message: "Discount % must have up to 10 digits and 4 decimal places",
        }
      )
      .optional(),
    discountAmount: z
      .preprocess(
        (value) => (value === "" ? undefined : Number(value)),
        z.number().optional()
      )
      .refine((value) => value === undefined || !Number.isNaN(value), {
        message: "Discount amount must be a valid number",
      })
      .refine(
        (value) =>
          value === undefined ||
          /^\d{1,10}(\.\d{1,4})?$/.test(value.toString()),
        {
          message:
            "Discount amount must have up to 10 digits and 4 decimal places",
        }
      )
      .optional(),

    salesRate: z
      .string()
      .nonempty("Sales rate is required")
      .transform((val) => (val === "" ? "0" : val))
      .pipe(
        z.coerce
          .number({ invalid_type_error: "Sales rate must be a number" })
          .min(0, "Sales rate must be 0 or greater")
          .refine(
            (val) => /^\d{1,10}(\.\d{1,4})?$/.test(val.toString()),
            "Sales rate must have up to 10 digits and 4 decimal places"
          )
      ),

    purchaseRate: z
      .string()
      .transform((val) => (val === "" ? "0" : val))
      .pipe(
        z.coerce
          .number({ invalid_type_error: "Purchase rate must be a number" })
          .min(0, "Purchase rate must be 0 or greater")
          .refine(
            (val) => /^\d{1,10}(\.\d{1,4})?$/.test(val.toString()),
            "Purchase rate must have up to 10 digits and 4 decimal places"
          )
      ),
    avgLandingCost: z
      .preprocess(
        (value) => (value === "" ? undefined : Number(value)),
        z.number().optional()
      )
      .refine((value) => value === undefined || !Number.isNaN(value), {
        message: "Avearge landing cost must be a valid number",
      })
      .refine(
        (value) =>
          value === undefined ||
          /^\d{1,10}(\.\d{1,4})?$/.test(value.toString()),
        {
          message:
            "Average landing cost must have up to 10 digits and 4 decimal places",
        }
      )
      .optional(),
    isTrackable: z
      .string()
      .optional()
      .refine(
        (value, ctx) => {
          const itemType = ctx?.parent?.itemType;
          if (itemType === "Goods" && !value) {
            return false;
          }
          return true;
        },
        {
          message: "isTrackable is required for Goods",
        }
      ),

    openingStockQty: z
      .string()
      .refine((value) => !Number.isNaN(Number(value)), {
        message: "Must be a valid number",
      })
      .transform((value) => Number(value))
      .refine((value) => value.toString().length <= 10, {
        message: "Maximum length is 10 digits",
      })
      .refine((value) => /^\d+(\.\d{1,4})?$/.test(value.toString()), {
        message: "Maximum of 4 decimal places allowed",
      }),

    openingStockRatePerUnit: z
      .string()
      .refine((value) => !Number.isNaN(Number(value)), {
        message: "Must be a valid number",
      })
      .transform((value) => Number(value))
      .refine((value) => value.toString().length <= 10, {
        message: "Maximum length is 10 digits",
      })
      .refine((value) => /^\d+(\.\d{1,4})?$/.test(value.toString()), {
        message: "Maximum of 4 decimal places allowed",
      }),
    openingStockDate: z.date({
      required_error: "Please select a date and time",
      invalid_type_error: "That's not a date!",
    }),
    locationId: z.string().optional(),
    serialNumber: z.string().max(100, "Maximum length is 100 characters"),
    groupId: z.string().optional(),
    categoryId: z.string().optional(),
    description: z.string().max(255, "Maximum length is 255 characters"),
    isActive: z.string().optional(),
    tags: z.array(z.string()).optional(),
    // qty: z
    //   .string()

    //   .refine((value) => !Number.isNaN(Number(value)), {
    //     message: "Must be a valid number",
    //   })
    //   .optional(),
    // unitId: z
    //   .string()

    //   .optional(),
    qty: z
      .string()
      .refine((value) => !Number.isNaN(Number(value)), {
        message: "Must be a valid number",
      })
      .optional(),
    unitId: z.string().optional(),
  })
  .refine(
    (data) => {
      // If unitId is selected, qty is required
      if (data.unitId && !data.qty) {
        return false;
      }
      return true;
    },
    {
      message: "Quantity is required",
      path: ["qty"],
    }
  );

const AddItem = ({ onClose, editId, onItemAdded }) => {
  const queryClient = useQueryClient();

  const {
    data: masterData,

    error,
  } = useQuery({
    queryKey: ["master-data"],
    queryFn: () => getItemsMasterData(),
  });

  const { data: gstInfo } = useQuery({
    queryKey: ["organizationsGSTInfo"],
    queryFn: getOrganizationsGSTInfo,
  });

  const Gst = gstInfo?.data?.data;

  const [isLocationSheetOpen, setIsLocationSheetOpen] = useState(false);
  const [isGroupSheetOpen, setIsGroupSheetOpen] = useState(false);
  const [isCategorieSheetOpen, setIsCategorieSheetOpen] = useState(false);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [defaultTab, setDefaultTab] = useState("pricingDetails");

  const { data: commonInitInventoryData, isLoading: isCommonDataLoading } =
    useQuery({
      queryKey: ["commonInitInventoryData"],
      queryFn: () => getCommonInitData(),
    });

  useEffect(() => {
    if (!isCommonDataLoading && commonInitInventoryData) {
      const commonInventoryData =
        commonInitInventoryData?.data?.preferences?.inventory;
      setDefaultTab(
        commonInventoryData?.alternateUnit
          ? "alternateUnitTab"
          : "pricingDetails"
      );
      setIsDataLoaded(true);
    }
  }, [isCommonDataLoading, commonInitInventoryData]);

  const commonInventoryData =
    commonInitInventoryData?.data?.preferences?.inventory;

  const { data: initialData } = useQuery({
    queryKey: ["item", editId],
    queryFn: () => getItemById(editId),
  });

  const [isFormSubmitting, setIsFormSubmitting] = useState(false);
  const [open, setOpen] = useState(false);
  const [unitData, setUnitData] = useState([]);
  const [locationData, setLocationData] = useState([]);
  const [initialTagData, setInitialTagData] = useState([]);
  const [initialGroupData, setInitialGroupData] = useState([]);
  const [initialCategoriesData, setInitialCategoriesData] = useState([]);
  const [gstTaxesData, setGstTaxesData] = useState([]);
  const [uploadedImageUrl, setUploadedImageUrl] = useState("");
  const [isImageDeleted, setIsImageDeleted] = useState(false);

  const [discountType, setDiscountType] = useState("");

  useEffect(() => {
    const intialDataMain = masterData?.data;
    const groupMainInitlaData = intialDataMain?.taxes?.groups;

    setUnitData(intialDataMain?.units);
    setLocationData(intialDataMain?.locations);
    setInitialTagData(intialDataMain?.productTags);
    setInitialGroupData(intialDataMain?.groups);
    setInitialCategoriesData(intialDataMain?.categories);

    setGstTaxesData(groupMainInitlaData);
  }, [masterData]);

  const form = useForm({
    resolver: zodResolver(formSchema),

    defaultValues: {
      itemType: initialData ? initialData?.itemType : "goods",
      itemName: "",
      unit: "",
      gstType: "taxable",
      interGstTaxId: "",
      intraGstTaxId: "",
      hsn: "",
      sac: "",
      barcode: "",
      discountAmount: "",
      salesRate: "",
      // purchaseRate: "",
      purchaseRate: initialData ? initialData?.purchaseRate?.toString() : "0",
      avgLandingCost: "",
      isTrackable: "NonTrackable",
      openingStockQty: 0,
      openingStockRatePerUnit: 0,
      openingStockDate: new Date(),
      locationId: "",
      serialNumber: "",
      groupId: "",
      categoryId: "",
      description: "",
      isActive: "true",
      tags: [],
      isAlternateUnits: false,
      imaageData: null,
    },
  });

  // const form = useForm({
  //   resolver: zodResolver(formSchema),
  //   defaultValues: async () => {
  //     if (editId) {
  //       return {
  //         itemType: initialData?.itemType || "goods",
  //         itemName: initialData?.itemName || "",
  //         unit: initialData?.unit?.name || "",
  //         gstType: initialData?.gstType || "taxable",
  //         interGstTaxId: initialData?.interGstTaxId?.toString() || "",
  //         intraGstTaxId: initialData?.intraGstTaxId?.toString() || "",
  //         hsn: initialData?.hsn || "",
  //         sac: initialData?.sac || "",
  //         barcode: initialData?.barcode || "",
  //         // mrp: initialData?.mrp?.toString() || "",
  //         discountAmount: initialData?.discountAmount?.toString() || "",
  //         // discountAmount:  initialData?.discountAmount != null &&
  //         // !isNaN(Number(initialData.discountAmount))
  //         // ? Number(initialData.discountAmount).toFixed(2)
  //         // : "",
  //         discountPercentage: initialData?.discountPercentage?.toString() || "",
  //         // discountPercentage:  initialData?.discountPercentage != null &&
  //         // !isNaN(Number(initialData.discountPercentage))
  //         // ? Number(initialData.discountPercentage).toFixed(2)
  //         // : "",
  //         // salesRate: initialData?.salesRate?.toString() || "",
  //         // purchaseRate: initialData?.purchaseRate?.toString() || "0",
  //         avgLandingCost: initialData?.avgLandingCost?.toString() || "",
  //         isTrackable: initialData?.isTrackable ? "trackable" : "NonTrackable",
  //         // openingStockQty: initialData?.openingStockQty?.toString() || "0",
  //         // openingStockRatePerUnit: initialData?.openingStockRatePerUnit?.toString() || "0",
  //         openingStockDate: initialData?.openingStockDate ? new Date(initialData.openingStockDate) : new Date(),
  //         locationId: initialData?.locationId?.toString() || "",
  //         serialNumber: initialData?.serialNumber || "",
  //         groupId: initialData?.groupId?.toString() || "",
  //         categoryId: initialData?.categoryId?.toString() || "",
  //         description: initialData?.description || "",
  //         isActive: initialData?.isActive ? "true" : "false",
  //         tags: initialData?.tags || [],
  //         unitId: initialData?.alternateUnits?.[0]?.unitId?.toString() || "",
  //         qty: initialData?.alternateUnits?.[0]?.qty?.toString() || ""
  //       };
  //     }
      
  //     // Default values for new item
  //     return {
  //       itemType: "goods",
  //       itemName: "",
  //       unit: "",
  //       gstType: "taxable",
  //       interGstTaxId: "",
  //       intraGstTaxId: "",
  //       hsn: "",
  //       sac: "",
  //       barcode: "",
  //       mrp: "",
  //       discountAmount: "",
  //       discountPercentage: "",
  //       salesRate: "",
  //       purchaseRate: "0",
  //       avgLandingCost: "",
  //       isTrackable: "NonTrackable",
  //       openingStockQty: "0",
  //       openingStockRatePerUnit: "0",
  //       openingStockDate: new Date(),
  //       locationId: "",
  //       serialNumber: "",
  //       groupId: "",
  //       categoryId: "",
  //       description: "",
  //       isActive: "true",
  //       tags: [],
  //       unitId: "",
  //       qty: ""
  //     };
  //   }
  // });

  const errorsData = form?.formState?.errors;

  useEffect(() => {
    if (
      !isCommonDataLoading &&
      commonInitInventoryData?.data?.organization?.gst
    ) {
      const gstData = commonInitInventoryData.data.organization.gst;

      // Only set default values if we're not in edit mode (editId is falsy)
      // and if the form fields are empty
      if (
        !editId &&
        !form.getValues("interGstTaxId") &&
        !form.getValues("intraGstTaxId")
      ) {
        // Set default Inter GST Tax ID
        if (gstData?.defaultInterStateTaxId) {
          form.setValue(
            "interGstTaxId",
            gstData?.defaultInterStateTaxId.toString()
          );
        }

        // Set default Intra GST Tax ID
        if (gstData.defaultIntraStateTaxId) {
          form.setValue(
            "intraGstTaxId",
            gstData.defaultIntraStateTaxId.toString()
          );
        }
      }
    }
  }, [isCommonDataLoading, commonInitInventoryData, editId, form]);

  useEffect(() => {
    if (initialData) {
      if (initialData?.itemImage && !isImageDeleted) {
        setUploadedImageUrl(initialData.itemImage);
      }

      form.setValue("itemType", initialData?.itemType || "goods");
      form.setValue("itemName", initialData?.itemName || "");
      form.setValue("unit", initialData?.unit?.name || "");
      form.setValue("gstType", initialData?.gstType || "taxable");
      form.setValue("interGstTaxId", initialData?.interGstTaxId || "");
      form.setValue("intraGstTaxId", initialData?.intraGstTaxId || "");
      form.setValue("hsn", initialData?.hsn || "");
      form.setValue("sac", initialData?.sac || "");
      form.setValue("barcode", initialData?.barcode || "");
      form.setValue(
        "mrp",
        initialData?.mrp != null && !isNaN(Number(initialData.mrp))
          ? Number(initialData.mrp).toFixed(2)
          : ""
      );
      form.setValue(
        "discountPercentage",
        initialData?.discountPercentage != null &&
          !isNaN(Number(initialData.discountPercentage))
          ? Number(initialData.discountPercentage).toFixed(2)
          : ""
      );
      form.setValue(
        "discountAmount",
        initialData?.discountAmount != null &&
          !isNaN(Number(initialData.discountAmount))
          ? Number(initialData.discountAmount).toFixed(2)
          : ""
      );
      form.setValue(
        "isTaxInclusiveRate",
        initialData?.isTaxInclusiveRate ? "Tax Inclusive" : "Tax Exclusive"
      );
      form.setValue(
        "salesRate",
        initialData?.salesRate != null && !isNaN(Number(initialData.salesRate))
          ? Number(initialData.salesRate).toFixed(2)
          : ""
      );
      form.setValue(
        "wholesaleQty",
        initialData?.wholesaleQty != null &&
          !isNaN(Number(initialData.wholesaleQty))
          ? Number(initialData.wholesaleQty).toFixed(2)
          : ""
      );
      form.setValue(
        "wholesaleRate",
        initialData?.wholesaleRate != null &&
          !isNaN(Number(initialData.wholesaleRate))
          ? Number(initialData.wholesaleRate).toFixed(2)
          : ""
      );

      form.setValue(
        "purchaseRate",
        initialData?.purchaseRate != null &&
          !isNaN(Number(initialData.purchaseRate))
          ? Number(initialData.purchaseRate).toFixed(2)
          : ""
      );
      form.setValue("avgLandingCost", initialData?.avgLandingCost || "");
      form.setValue(
        "isTrackable",
        editId
          ? initialData?.isTrackable
            ? "trackable"
            : "NonTrackable"
          : "NonTrackable"
      );
      form.setValue(
        "openingStockQty",
        initialData?.openingStockQty != null &&
          !isNaN(Number(initialData.openingStockQty))
          ? Number(initialData.openingStockQty).toFixed(2)
          : "0"
      );

      form.setValue(
        "openingStockRatePerUnit",
        initialData?.openingStockRatePerUnit != null &&
          !isNaN(Number(initialData.openingStockRatePerUnit))
          ? Number(initialData.openingStockRatePerUnit).toFixed(2)
          : "0"
      );
      form.setValue(
        "openingStockDate",
        initialData?.openingStockDate
          ? new Date(initialData.openingStockDate)
          : new Date()
      );
      form.setValue("locationId", initialData?.locationId?.toString() || "");
      form.setValue("serialNumber", initialData?.serialNumber || "");
      form.setValue("groupId", initialData?.groupId?.toString() || "");
      form.setValue("categoryId", initialData?.categoryId?.toString() || "");
      form.setValue("description", initialData?.description || "");
      form.setValue("isActive", initialData?.isActive ? "true" : "false");
      form.setValue("tags", initialData?.tags || []);
      form.setValue(
        "isAlternateUnits",
        initialData?.alternateUnits?.[0]?.unitId
      );

      form.setValue(
        "unitId",
        initialData?.alternateUnits?.[0]?.unitId?.toString() || ""
      );

      form.setValue("qty", initialData?.alternateUnits?.[0]?.qty);
    }
  }, [initialData, editId, isImageDeleted, form]);

  useEffect(() => {
    if (initialData) {
      if (initialData.discountPercentage > 0) {
        setDiscountType("percentage");
        form.setValue(
          "discountPercentage",
          Number(initialData.discountPercentage).toFixed(2)
        );
        form.setValue("discountAmount", "");
      } else if (initialData.discountAmount > 0) {
        setDiscountType("flat");
        form.setValue(
          "discountAmount",
          Number(initialData.discountAmount).toFixed(2)
        );
        form.setValue("discountPercentage", "");
      } else {
        setDiscountType("percentage");
        form.setValue("discountPercentage", "");
        form.setValue("discountAmount", "");
      }
    }
  }, [initialData, form]);

  const handleValueChange = (e) => {
    const value = e.target.value;
    const numValue = value === "" ? 0 : parseFloat(value);

    if (isNaN(numValue)) {
      return;
    }

    if (discountType === "percentage") {
      if (numValue >= 0 && numValue <= 100) {
        form.setValue("discountPercentage", numValue.toString());
        form.setValue("discountAmount", "0");
      }
    } else {
      if (numValue >= 0) {
        form.setValue("discountAmount", numValue.toString());
        form.setValue("discountPercentage", "0");
      }
    }
  };

  const toggleDiscountType = (e) => {
    e.preventDefault();
    const newType = discountType === "percentage" ? "flat" : "percentage";
    setDiscountType(newType);

    if (newType === "percentage") {
      const currentValue = form.getValues("discountPercentage");
      form.setValue("discountPercentage", currentValue || "0");
      form.setValue("discountAmount", "0");
    } else {
      const currentValue = form.getValues("discountAmount");
      form.setValue("discountAmount", currentValue || "0");
      form.setValue("discountPercentage", "0");
    }
  };

  const { mutate: addItemMutation, isLoading } = useMutation({
    mutationFn: (payload) => addItem(payload),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["items"] });

      if (data?.status === 201) {
        setIsFormSubmitting(false);
        onClose(false);
        form.reset();
        if (!editId) {
          if (data?.data?.id && data?.data?.itemName) {
            onItemAdded === undefined
              ? null
              : onItemAdded({
                  value: data?.data?.id.toString(),
                  label: data?.data?.itemName,
                });
          } else {
            console.error("Newly created item data is incomplete:", data);
          }
        }

        toast.success("Item added successfully ");
      } else {
        toast.error(data?.data?.error?.[0]?.message || "Something went wrong");
        setIsFormSubmitting(false);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to Add item. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
      setIsFormSubmitting(false);
    },
  });

  const { mutate: editItemMutation } = useMutation({
    mutationFn: (payload) => editItem(payload, editId),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["items"] });

      if (data?.status === 200) {
        setIsFormSubmitting(false);

        toast.success("Edit Item successfully ");
        form.reset();
        onClose(false);
      } else {
        toast.error(data?.data?.error?.[0]?.message || "Something went wrong");
        setIsFormSubmitting(false);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to edit item. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
      setIsFormSubmitting(false);
    },
  });

  const { mutate: uploadFileMutation } = useMutation({
    mutationFn: (payload) => uploadFile(payload),
    onSuccess: (data) => {
      if (data?.status === 200) {
        setIsFormSubmitting(false);
        setUploadedImageUrl(data?.data?.url);
        toast.success("image added successfully ");
      } else {
        toast.error(data?.data?.error || "Something went wrong");
        setIsFormSubmitting(false);
      }
    },
    onError: (error) => {
      toast.error(
        `Failed to Add item. Error: ${
          error?.message || error || "Something went wrong"
        }`
      );
      setIsFormSubmitting(false);
    },
  });
  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("image", file);
    setIsImageDeleted(false);
    uploadFileMutation(formData);
  };

  const onSubmit = (values) => {
    const formatDateToISO = (date) => {
      if (!date) return null;
      return format(date, "yyyy-MM-dd");
    };

    setIsFormSubmitting(true);
    const finalPayload = {};

    if (values?.itemType) finalPayload.itemType = values.itemType;
    if (values?.itemName) finalPayload.itemName = values.itemName;
    if (values?.unit) finalPayload.unit = values.unit;
    if (values?.gstType) finalPayload.gstType = values.gstType;
    if (values?.interGstTaxId)
      finalPayload.interGstTaxId = Number(values.interGstTaxId);
    if (values?.intraGstTaxId)
      finalPayload.intraGstTaxId = Number(values.intraGstTaxId);
    if (values?.hsn) finalPayload.hsn = values.hsn;
    if (values?.sac) finalPayload.sac = values.sac;
    if (values?.barcode) finalPayload.barcode = values.barcode;
    if (values?.mrp) finalPayload.mrp = values.mrp;
    // if (values?.discountPercentage)
    //   finalPayload.discountPercentage = values.discountPercentage;
    // if (values?.discountAmount)
    //   finalPayload.discountAmount = values.discountAmount;
    if (discountType === "percentage") {
      const percentageValue = values.discountPercentage
        ? Number(values.discountPercentage)
        : 0;
      finalPayload.discountPercentage = percentageValue;
      finalPayload.discountAmount = 0;
    } else if (discountType === "flat") {
      const amountValue = values.discountAmount
        ? Number(values.discountAmount)
        : 0;
      finalPayload.discountAmount = amountValue;
      finalPayload.discountPercentage = 0;
    } else {
      finalPayload.discountPercentage = 0;
      finalPayload.discountAmount = 0;
    }

    if (values?.salesRate !== undefined)
      finalPayload.salesRate = Number(values.salesRate);
    if (values?.purchaseRate !== undefined)
      // finalPayload.purchaseRate = Number(values.purchaseRate);
    finalPayload.purchaseRate = values.purchaseRate !== undefined ? 
    Number(values.purchaseRate) : 0;
    if (values?.avgLandingCost)
      finalPayload.avgLandingCost = values.avgLandingCost;
    if (values?.isTrackable)
      finalPayload.isTrackable = values.isTrackable === "trackable";

    // if (values?.openingStockQty)
    //   finalPayload.openingStockQty = values.openingStockQty ?? 0;
    // if (values?.openingStockRatePerUnit)
    //   finalPayload.openingStockRatePerUnit =
    //     values.openingStockRatePerUnit ?? 0;
    if (values?.openingStockDate)
      finalPayload.openingStockDate = formatDateToISO(
        new Date(values.openingStockDate)
      );
    if (values?.locationId) finalPayload.locationId = Number(values.locationId);
    if (values?.serialNumber) finalPayload.serialNumber = values.serialNumber;
    if (values?.groupId) finalPayload.groupId = Number(values.groupId);
    if (values?.categoryId) finalPayload.categoryId = Number(values.categoryId);
    if (values?.description) finalPayload.description = values.description;
    if (values?.tags) finalPayload.tags = values.tags;
    if (uploadedImageUrl) finalPayload.itemImage = uploadedImageUrl;
    const alternateUnits = {};
    if (values?.qty) alternateUnits.qty = Number(values.qty);
    if (values?.unitId) alternateUnits.unitId = Number(values.unitId);

    if (alternateUnits.qty && alternateUnits.unitId) {
      finalPayload.alternateUnits = [alternateUnits];
    }
    finalPayload.openingStockQty = values.openingStockQty || 0;
    finalPayload.openingStockRatePerUnit = values.openingStockRatePerUnit || 0;
    finalPayload.itemImage = isImageDeleted ? "" : uploadedImageUrl;

    editId ? editItemMutation(finalPayload) : addItemMutation(finalPayload);
  };
  const selectedUnit = form.watch("unit");

  const intertaxData = gstTaxesData?.filter(
    (val) => val?.taxSpecification === "inter"
  );
  const intraTaxData = gstTaxesData?.filter(
    (val) => val?.taxSpecification === "intra"
  );

  const optionForIntertax = intertaxData?.map((val, index) => ({
    value: `${val?.id}`,
    label: val?.name,
    id: index,
  }));

  const optionForIntratax = intraTaxData?.map((val, index) => ({
    value: `${val?.id}`,
    label: val?.name,
    id: index,
  }));

  const optionForUnit = unitData?.map((val, ind) => ({
    value: val?.name,
    label: `${val?.code} - ${val?.name}`,
    id: ind,
  }));

  const optionForAlternateUnit = unitData
    ?.filter((val) => val?.name !== selectedUnit)
    ?.map((val, ind) => ({
      value: `${val?.id}`,
      label: val?.name,
      id: ind,
    }));

  const locationIdOption = locationData?.map((val, ind) => ({
    value: `${val?.id}`,
    label: val?.name,
    id: ind,
    isActive: val?.isActive,
  }));

  const groupIdOption = initialGroupData?.map((val, ind) => ({
    value: `${val?.id}`,
    label: val?.name,
    id: ind,
    isActive: val?.isActive,
  }));

  const categoriesIdOption = initialCategoriesData?.map((val, ind) => ({
    value: `${val?.id}`,
    label: val?.name,
    id: ind,
    isActive: val?.isActive,
  }));

  const tagsOptions = initialTagData?.map((val, ind) => ({
    value: val?.name,
    label: val?.name?.toUpperCase(),
  }));

  const isTrackbleValues = form.watch("isTrackable");

  return (
    <>
      <div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
        <h2 className="text-lg font-semibold">
          {editId ? "Edit Item" : "Add Item"}
        </h2>
      </div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <main className=" h-[calc(100vh-153px)] overflow-y-auto  ">
            <div className="mx-auto w-[90%] gap-4 pt-3">
              <RadioGroupField
                control={form.control}
                name="itemType"
                label="Item Type"
                options={itemtypeOption}
              />
            </div>
            <div className="w-[90%] pt-3 mx-auto">
              <TextInputField
                form={form}
                name="itemName"
                placeholder="Enter Item Name Here"
                label="Item Name"
                type="text"
                required
              />
            </div>

            <div className="flex flex-col sm:flex-row justify-between w-[90%] gap-4 mx-auto">
              {Gst?.isGstRegistered && (
                <div className="w-full pt-2 mx-auto ">
                  {form.watch("itemType") === "goods" ? (
                    <div className="w-full pt-2 mx-auto">
                      <TextInputField
                        form={form}
                        name="hsn"
                        placeholder="Enter Number to Search"
                        label="HSN"
                        type="text"
                      />
                    </div>
                  ) : (
                    <div className="w-full pt-2 mx-auto">
                      <TextInputField
                        form={form}
                        name="sac"
                        placeholder="Enter Number To Search"
                        label="SAC"
                        type="text"
                      />
                      <div className="flex items-center gap-1 text-sm text-[#768EA7] mt-2 ">
                        <CircleAlert className="mr-1" size={16} /> Leave empt to
                        auto-ganrate
                      </div>
                    </div>
                  )}
                </div>
              )}
              {form?.watch("itemType") === "goods" ? (
                <div className="w-full pt-0 sm:pt-4 mx-auto">
                  <div className="w-full  mx-auto">
                    <TextInputField
                      form={form}
                      name="barcode"
                      placeholder="Enter Barcode Here"
                      label="Barcode"
                      type="text"
                    />
                  </div>
                </div>
              ) : null}
            </div>

            <div className="flex flex-col sm:flex-row justify-between w-[90%] gap-4 mx-auto">
              <div className="w-full pt-2 mx-auto ">
                <div className="w-full pt-2 mx-auto">
                  <FormSelectField
                    control={form.control}
                    name={"unit"}
                    intialValue={initialData?.unit?.name}
                    label={"Primary Unit"}
                    placeholder={"Choose Option"}
                    options={optionForUnit}
                    required
                  />
                </div>
              </div>
              {form?.watch("itemType") === "goods" &&
              commonInventoryData?.alternateUnit ? (
                <div className="w-full pt-0 sm:pt-4 mx-auto">
                  <div className="w-full  mx-auto">
                    <FormSelectField
                      control={form.control}
                      name={"unitId"}
                      intialValue={
                        initialData?.alternateUnits?.[0]?.unitId?.toString() ||
                        ""
                      }
                      label={"Secondary Unit"}
                      placeholder={"Choose Option"}
                      options={optionForAlternateUnit}
                    />
                  </div>
                </div>
              ) : null}
            </div>

            {form?.watch("unitId") && commonInventoryData?.alternateUnit && (
              <div className="max-w-[80%] pt-3 mx-7 my-auto">
                <div className="flex items-center gap-4">
                  {/* Left unit */}
                  <div className="text-base font-medium text-gray-700 shrink-0">
                    1 {selectedUnit}
                  </div>

                  {/* Equals sign */}
                  <div className="text-lg font-bold text-gray-900 shrink-0">
                    =
                  </div>

                  {/* Input field - wrapped in a container to handle error message */}
                  <div className="flex flex-row">
                    <TextInputField
                      form={form}
                      name="qty"
                      error={true} // For demonstration
                    />
                    <div className="text-red-500 ml-1">*</div>
                  </div>

                  {/* Right unit */}
                  <div className="text-base font-medium text-gray-700 shrink-0">
                    {optionForAlternateUnit.find(
                      (unit) => unit.value === form?.watch?.("unitId")
                    )?.label || ""}
                  </div>
                </div>
              </div>
            )}

            <div className="w-[90%] pt-2 mx-auto pb-4">
              <div className="pt-4">
                <div className="pb-2">
                  <label className=" text-sm font-medium text-[#40566D]">
                    Upload Image (500*420 px)
                  </label>
                </div>
                <Input
                  id="picture"
                  type="file"
                  onChange={handleFileChange}
                  className="w-full"
                />
              </div>

              {uploadedImageUrl && (
                <div className="relative w-full border rounded-sm borde-[#D2D6DB]  h-[146px] mt-4">
                  <div className="absolute inset-0 overflow-hidden rounded-lg">
                    <img
                      src={uploadedImageUrl}
                      alt="Uploaded"
                      className="w-full h-full p-2 object-contain"
                    />
                  </div>
                  <button
                    // onClick={() => setUploadedImageUrl("")}
                    onClick={() => {
                      setUploadedImageUrl("");
                      setIsImageDeleted(true);
                    }}
                    className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-md hover:bg-gray-100 transition-colors"
                    aria-label="Delete image"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
            {Gst?.isGstRegistered === true &&
              Gst?.gstRegistrationType === "regular" && (
                <>
                  <div className="border-t-4 border-gray-200"></div>
                  <div className="w-[90%] pt-4 mx-auto  ">
                    <FormSelectField
                      control={form.control}
                      name={"gstType"}
                      label={"GST Tax Type"}
                      intialValue={
                        editId ? `${initialData?.gstType || ""}` : ""
                      }
                      placeholder={"Select GST Tax Type"}
                      options={gsttaxTypeOption}
                    />
                  </div>

                  {form?.watch("gstType") === "taxable" && (
                    <>
                      <div className="flex flex-col sm:flex-row justify-between w-[90%] gap-4 mx-auto">
                        <div className="w-full pt-2 mx-auto ">
                          <div className="w-full pt-2 mx-auto">
                            <FormSelectField
                              control={form.control}
                              name={"interGstTaxId"}
                              intialValue={
                                // editId ? `${initialData?.interGstTaxId || ""}` : ""
                                initialData?.interGstTaxId?.toString() || ""
                              }
                              label={
                                <div className="flex items-center gap-1">
                                  Inter GST <CircleAlert size={16} />
                                </div>
                              }
                              placeholder={"Choose Option"}
                              options={optionForIntertax}
                              className={"max-w-[240px]"}
                            />
                          </div>
                        </div>
                        <div className="w-full pt-0 sm:pt-4 mx-auto">
                          <div className="w-full  mx-auto">
                            <FormSelectField
                              control={form.control}
                              name={"intraGstTaxId"}
                              intialValue={
                                // editId ? `${initialData?.intraGstTaxId || ""}` : ""
                                initialData?.intraGstTaxId?.toString() || ""
                              }
                              label={
                                <div className="flex items-center gap-1">
                                  Intra GST <CircleAlert size={16} />
                                </div>
                              }
                              placeholder={"Choose Option"}
                              options={optionForIntratax}
                              className={"max-w-[240px]"}
                            />
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </>
              )}

            <div className="pt-4 w-full">
              {isDataLoaded && (
                <Tabs
                  defaultValue="pricingDetails"
                  className="w-full  border-t-4 border-gray-200"
                >
                  <div className="border-b pb-[2px] border-gray-300 text-center overflow-x-auto overflow-y-hidden">
                    <TabsList className="w-full mt-2 flex justify-start flex-row rounded-lg bg-white">
                      <TabsTrigger
                        className={
                          errorsData?.mrp ||
                          errorsData?.discountPercentage ||
                          errorsData?.discountAmount ||
                          errorsData?.salesRate ||
                          errorsData?.purchaseRate ||
                          errorsData?.avgLandingCost
                            ? "text-red-500 pb-4 flex-1 rounded-none text-sm font-medium    data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                            : "flex-1 pb-4 rounded-none text-sm font-medium text-gray-700   data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
                        }
                        value="pricingDetails"
                      >
                        Pricing Details
                      </TabsTrigger>
                      <TabsTrigger
                        className={
                          errorsData?.openingStockQty ||
                          errorsData?.openingStockRatePerUnit ||
                          errorsData?.serialNumber ||
                          errorsData?.description
                            ? "text-red-500 pb-4 flex-1 rounded-none text-sm font-medium  data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary  data-[state=active]:border-b-2 data-[state=active]:border-primary"
                            : "flex-1 pb-4 rounded-none text-sm font-medium text-gray-700 data-[state=active]:bg-white data-[state=active]:shadow-none data-[state=active]:text-primary  data-[state=active]:border-b-2 data-[state=active]:border-primary"
                        }
                        value="otherDetails"
                      >
                        Other Details
                      </TabsTrigger>
                    </TabsList>
                  </div>

                  <TabsContent value="pricingDetails">
                    <div className="flex justify-between w-[90%] gap-4 mx-auto">
                      <div className="w-full pt-3 mx-auto ">
                        <div className="w-full pt-2 mx-auto">
                          <TextInputField
                            form={form}
                            name="salesRate"
                            placeholder="Enter Sales Price"
                            label="Sales Price"
                            type="text"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    <div className="w-[90%] pt-4  mx-auto">
                      <TextInputField
                        form={form}
                        name="purchaseRate"
                        placeholder="Enter Purchase Price"
                        label=" Purchase Price"
                        type="text"
                        required
                      />
                    </div>

                    {form?.watch("itemType") === "goods" ? (
                      <div className="w-[90%] pt-4  mx-auto">
                        <TextInputField
                          form={form}
                          name="mrp"
                          placeholder="Enter MRP"
                          label="MRP"
                          type="text"
                        />
                      </div>
                    ) : null}

                    <div className="w-[90%] pt-4 pb-5  mx-auto">
                      <Label className="text-gray-700 font-medium text-sm">
                        Discount Type
                      </Label>

                      <div className="relative pt-2">
                        <Input
                          type="text"
                          placeholder={
                            discountType === "percentage"
                              ? "Enter Discount Percentage"
                              : "Enter Flat Discount"
                          }
                          value={
                            discountType === "percentage"
                              ? form.watch("discountPercentage") || ""
                              : form.watch("discountAmount") || ""
                          }
                          onChange={handleValueChange}
                          className="pl-3 pr-12"
                        />

                        <div className="absolute right-1 top-1/2 pt-2 -translate-y-1/2 flex items-center gap-2">
                          <button
                            onClick={toggleDiscountType}
                            type="button"
                            className="flex items-center gap-1 px-2 py-2 bg-gray-100 hover:bg-gray-200 rounded-md border border-gray-300 transition-all duration-200 text-gray-600 hover:text-gray-800"
                          >
                            {discountType === "percentage" ? (
                              <>
                                <Percent size={14} />
                                <ChevronsUpDown size={14} className="ml-1" />
                              </>
                            ) : (
                              <>
                                <IndianRupee size={14} />
                                <ChevronsUpDown size={14} className="ml-1" />
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="otherDetails">
                    {form?.watch("itemType") === "goods" &&
                    commonInventoryData?.itemTracking ? (
                      <div className="w-[90%] pt-3 mx-auto">
                        <SwitchFormField
                          control={form.control}
                          name="isTrackable"
                          label="Item Is Trackable?"
                        />
                      </div>
                    ) : null}
                    <div className="flex flex-col sm:flex-row justify-between w-[90%] gap-4 mx-auto">
                      <div className="w-full pt-2 mx-auto ">
                        {form?.watch("itemType") === "goods" &&
                        commonInventoryData?.itemTracking ? (
                          <>
                            {isTrackbleValues === "NonTrackable" ? null : (
                              <div className="w-full pt-2 mx-auto">
                                <TextInputField
                                  form={form}
                                  name="openingStockQty"
                                  placeholder="Enter Opening Stock Quantity"
                                  label="Opening Stock Quantity"
                                  type="number"
                                />
                              </div>
                            )}
                          </>
                        ) : null}
                      </div>
                      <div className="w-full pt-0 sm:pt-2 mx-auto">
                        {form?.watch("itemType") === "goods" &&
                        commonInventoryData?.itemTracking ? (
                          <>
                            {isTrackbleValues === "NonTrackable" ? null : (
                              <div className="w-full pt-0 sm:pt-2 mx-auto">
                                <TextInputField
                                  form={form}
                                  name="openingStockRatePerUnit"
                                  placeholder="Enter Opening Stock Price Per Unit"
                                  label="Opening Stock Price Per Unit"
                                  type="text"
                                />
                              </div>
                            )}
                          </>
                        ) : null}
                      </div>
                    </div>

                    {form?.watch("itemType") === "goods" &&
                    commonInventoryData?.itemTracking ? (
                      <>
                        {isTrackbleValues === "NonTrackable" ? null : (
                          <div className="w-[90%] pt-4 mx-auto">
                            <CommonCalendarInput
                              form={form}
                              name="openingStockDate"
                              label="Opening Stock Date"
                              placeholder="Select Opening Stock Date"
                            />
                          </div>
                        )}
                      </>
                    ) : null}

                    {/* <div className="flex flex-col sm:flex-row justify-between w-[90%] gap-4 mx-auto"> */}
                    {/* {form?.watch("itemType") === "goods" &&
                      commonInventoryData?.multiLocation ? (
                        <div className="w-full pt-2 mx-auto">
                          <div className="w-full pt-2 mx-auto">
                            <FormSelectFieldForDisabledOption
                              control={form.control}
                              name={"locationId"}
                              label={"Location"}
                              placeholder={"Choose Location"}
                              options={locationIdOption}
                              checkIsActive={true}
                              customButtonLabel="Add Location"
                        onCustomButtonClick={() => {
                          setIsLocationSheetOpen(true);
                        }}
                            />
                          </div>
                        </div>
                      ) : null} */}
                    <div className="w-[90%] pt-4 mx-auto">
                      {commonInventoryData?.category ? (
                        <div className="">
                          <FormSelectFieldForDisabledOption
                            control={form.control}
                            name={"categoryId"}
                            label={"Category"}
                            placeholder={"Choose Category"}
                            options={categoriesIdOption}
                            checkIsActive={true}
                            customButtonLabel="Add Category"
                            onCustomButtonClick={() => {
                              setIsCategorieSheetOpen(true);
                            }}
                          />
                        </div>
                      ) : null}
                    </div>
                    {/* </div> */}

                    {form?.watch("itemType") === "goods" &&
                    commonInventoryData?.serialNumber ? (
                      <div className="w-[90%] pt-4 mx-auto">
                        <TextInputField
                          form={form}
                          name="serialNumber"
                          placeholder="Enter Serial Number"
                          label="Serial Number"
                          type="text"
                        />
                      </div>
                    ) : null}

                    {commonInventoryData?.group ? (
                      <div className="w-[90%] pt-4 mx-auto">
                        <FormSelectFieldForDisabledOption
                          control={form.control}
                          name={"groupId"}
                          label={"Group"}
                          placeholder={"Choose Group"}
                          options={groupIdOption}
                          checkIsActive={true}
                          customButtonLabel="Add Group"
                          onCustomButtonClick={() => {
                            setIsGroupSheetOpen(true);
                          }}
                        />
                      </div>
                    ) : null}

                    <div className="w-[90%] pt-4 mx-auto">
                      <TextareaInputField
                        form={form}
                        name="description"
                        placeholder="Enter Description Here"
                        label="Description"
                        rows={3}
                      />
                    </div>

                    <div className="w-[90%] pt-4 pb-4 mx-auto">
                      <Controller
                        name="tags"
                        control={form.control}
                        render={({ field }) => (
                          <MultipleSelector
                            value={
                              Array.isArray(field.value)
                                ? field.value.map((tag) =>
                                    typeof tag === "string"
                                      ? {
                                          value: tag,
                                          label: tag.toUpperCase(),
                                        }
                                      : tag
                                  )
                                : []
                            }
                            onChange={(newValue) =>
                              field.onChange(
                                newValue.map((option) => option.value || option)
                              )
                            }
                            options={tagsOptions}
                            creatable
                            placeholder="Select Tags"
                            className="w-full"
                            label="Tag"
                          />
                        )}
                      />
                    </div>
                  </TabsContent>
                </Tabs>
              )}
            </div>
          </main>

          <div className="flex justify-end  rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0  h-[76px] left-0 w-full p-4 shadow-lg">
            <Button
              type="submit"
              className="  mr-3 mt-1 text-white  "
              disabled={isFormSubmitting}
            >
              {isFormSubmitting ? (
                <>
                  <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                  {editId ? "Updating..." : "Saving..."}
                </>
              ) : editId ? (
                "Update Item"
              ) : (
                "Add Item"
              )}
            </Button>
          </div>
        </form>
      </Form>
      <Custom_Sheet
        isOpen={isLocationSheetOpen}
        onClose={() => setIsLocationSheetOpen(false)}
        activeKey={"location"}
        // editId={editUserData}
      />
      <Custom_Sheet
        isOpen={isGroupSheetOpen}
        onClose={() => setIsGroupSheetOpen(false)}
        activeKey={"groups"}
        // editId={editUserData}
      />
      <Custom_Sheet
        isOpen={isCategorieSheetOpen}
        onClose={() => setIsCategorieSheetOpen(false)}
        activeKey={"categories"}
        // editId={editUserData}
      />
    </>
  );
};

export default AddItem;
