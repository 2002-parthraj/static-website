"use client";

import React, { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  creditPeriodOption,
  gstTypeEnum,
  labelConfigLabelPrinter,
  labelConfigRegularPrinter,
  PartyTypeEnum,
  Printertype,
} from "@/components/enums/enums";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import jsPDF from "jspdf";
import JsBarcode from "jsbarcode";
import { Form } from "@/components/ui/form";
import {
  FormSelectField,
  RadioGroupField,
  TextInputField,
} from "@/components/custom-form-fields/custom-form-fields";
import { getBarcodeData } from "@/actions/barcode/get-barcode";
import { getUserOrganizations } from "@/actions/company-flow/get-user-organizations";

const formSchema = z.object({
  printerType: z.string().default("Regular Printer"),
  // barcodePrintNumber: z.string().min(1, "No of barcode to print is reqired"),
  labelConfig: z.string().default("65Labels38mmx21mm"),
  customWidth: z.string().optional(),
  customHeight: z.string().optional(),
  customTop: z.string().optional(),
  customLeft: z.string().optional(),
});

const LABEL_CONFIGURATIONS = {
  "65Labels38mmx21mm": {
    firstPageBarcodes: 65,
    barcodeWidth: 38,
    barcodeHeight: 21,
    rows: 13,
    cols: 5,
    defaultMargins: { top: 11, left: 5 },
  },
  "48Labels48mmx24mm": {
    firstPageBarcodes: 48,
    barcodeWidth: 46,
    barcodeHeight: 21,
    rows: 12,
    cols: 4,
    defaultMargins: { top: 21, left: 10 },
  },
  "24Labels64mmx34mm": {
    firstPageBarcodes: 24,
    barcodeWidth: 64,
    barcodeHeight: 34,
    rows: 8,
    cols: 3,
    defaultMargins: { top: 14, left: 8 },
  },
  "12Labels100mmx44mm": {
    firstPageBarcodes: 12,
    barcodeWidth: 99,
    barcodeHeight: 42,
    rows: 6,
    cols: 2,
    defaultMargins: { top: 21, left: 5 },
  },
  "2Leb50mm25mm": {
    firstPageBarcodes: 2,
    barcodeWidth: 50,
    barcodeHeight: 25,
    rows: 1,
    cols: 2,
    defaultMargins: { top: 11, left: 5 },
  },
  "1Leb100mm×50mm": {
    firstPageBarcodes: 1,
    barcodeWidth: 100,
    barcodeHeight: 50,
    rows: 1,
    cols: 1,
    defaultMargins: { top: 11, left: 5 },
  },
  "1Leb50mm×25mm": {
    firstPageBarcodes: 1,
    barcodeWidth: 50,
    barcodeHeight: 25,
    rows: 1,
    cols: 1,
    defaultMargins: { top: 11, left: 5 },
  },
  "2Leb38mm×25mm": {
    firstPageBarcodes: 2,
    barcodeWidth: 38,
    barcodeHeight: 25,
    rows: 1,
    cols: 2,
    defaultMargins: { top: 11, left: 5 },
  },
};

const PrinterSettingConfigurationForm = ({ onClose, selectedTableData }) => {
  
  const queryClient = useQueryClient();
  const [labelConfig, setLabelConfig] = useState("65Labels38mmx21mm");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch initial data
  const { data: initialDatas } = useQuery({
    queryKey: ["barcode_FormData"],
    queryFn: getBarcodeData,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000,
    cacheTime: 30 * 60 * 1000,
    initialData: () => {
      const cached = queryClient.getQueryData(["barcode_FormData"]);
      return cached || undefined;
    },
  });

  // Fetch organization data
  const { data: organizationsName } = useQuery({
    queryKey: ["getorganizationData"],
    queryFn: getUserOrganizations,
  });

  // Helper function to get organization name
  const organizationValue = (organizationId) => {
    const getorganizationValue = organizationsName?.data?.data?.map(
      (val) => val
    );
    return (
      getorganizationValue?.find((org) => org.id === organizationId)?.name ||
      "Unknown Organization"
    );
  };

  // Form initialization
  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      printerType: "regularPrinter",
      labelConfig: "65Labels38mmx21mm",
      customWidth: "",
      customHeight: "",
      customTop: "",
      customLeft: "",
    },
  });

  const printtype = form.watch("printerType");
  const selectedBarcodeLabel = form.watch("labelConfig");

  // Helper function to convert number to string
  const convertNumberToString = (number) => String(number);

  // Update form values when label config changes
  useEffect(() => {
    const config = LABEL_CONFIGURATIONS[selectedBarcodeLabel];
    if (config) {
      form.setValue("customWidth", convertNumberToString(config.barcodeWidth));
      form.setValue("customHeight", convertNumberToString(config.barcodeHeight));
      form.setValue("customTop", convertNumberToString(config.defaultMargins.top));
      form.setValue("customLeft", convertNumberToString(config.defaultMargins.left));
    }
  }, [selectedBarcodeLabel, form]);

  // Helper function for text alignment
  const getCorrectAlignment = (alignment) => {
    const alignments = {
      right: "left",
      left: "right",
      center: "center",
    };
    return alignments[alignment?.toLowerCase()] || "center";
  };

  // Handle label configuration change
  const handleLabelConfigChange = (event) => {
    const selectedValue = event.target?.value;
    setLabelConfig(selectedValue);

    const config = LABEL_CONFIGURATIONS[selectedValue];
    if (config) {
      form.setValue("customWidth", convertNumberToString(config.barcodeWidth));
      form.setValue("customHeight", convertNumberToString(config.barcodeHeight));
      form.setValue("customTop", convertNumberToString(config.defaultMargins.top));
      form.setValue("customLeft", convertNumberToString(config.defaultMargins.left));
    }
  };

  // Generate PDF with barcodes
  const generateBarcodePDF = async (data, barcodeData) => {
    try {
      const doc = new jsPDF({ unit: "mm", format: "a4" });
      const labelConfig = LABEL_CONFIGURATIONS[data?.labelConfig];
  
      const labelWidth = Number(data?.customWidth || labelConfig.barcodeWidth);
      const labelHeight = Number(data?.customHeight || labelConfig.barcodeHeight);
  
      const settings = {
        gapWidth: 2,
        gapHeight: 0,
        labelsPerRow: labelConfig.cols,
        labelsPerPage: labelConfig.firstPageBarcodes,
        marginLeft: Number(data?.customLeft || labelConfig.defaultMargins.left),
        marginTop: Number(data?.customTop || labelConfig.defaultMargins.top),
      };
  
      const calculateTextHeight = (fontSize) => fontSize * 0.3528;
      const defaultFontSize = 6;
      const textHeight = calculateTextHeight(defaultFontSize);
  
      const generatePage = (startIndex) => {
        const expandedData = selectedTableData?.flatMap((item) =>
          Array(parseInt(item.qty))?.fill(item)
        );
  
        for (
          let i = startIndex;
          i < Math.min(startIndex + settings.labelsPerPage, expandedData.length);
          i++
        ) {
          const currentItem = expandedData[i];
          const index = i % settings.labelsPerPage;
          const row = Math.floor(index / settings.labelsPerRow);
          const col = index % settings.labelsPerRow;
          
          // Calculate positions
          const x = settings.marginLeft + col * (labelWidth + settings.gapWidth);
          const y = settings.marginTop + row * (labelHeight + settings.gapHeight);
  
          // Draw border
          doc.setDrawColor(initialDatas?.barcodeDesign?.borderColor || 0);
          doc.rect(x, y, labelWidth, labelHeight);
  
          // Calculate text spaces
          const topTexts = initialDatas?.barcodeText?.filter(
            (field) => field.textposition === "top"
          ) || [];
          const bottomTexts = initialDatas?.barcodeText?.filter(
            (field) => field.textposition === "bottom"
          ) || [];
  
          const topTextSpace = topTexts.length * textHeight + (topTexts.length > 0 ? 1 : 0);
          const bottomTextSpace = (bottomTexts.length + 1)  * textHeight + 2; // Added extra space for barcode number
  
          // Generate barcode
          const barcodeHeight = labelHeight - topTextSpace - bottomTextSpace ; // Adjusted for barcode number

          const barcodeY = y + topTextSpace + 1;

          const barcodeWidth = labelWidth - 2;

          const contentX = x + 1;
  
          // Create and configure barcode
          const canvas = document.createElement("canvas");
          const barcodeValue = currentItem.barcode || `${1000000 + i + 1}`;
          
          
          JsBarcode(canvas, barcodeValue, {
            format: "CODE128",
          width: 1,
          height: barcodeHeight,
          displayValue: false,
          textMargin: 0,
            background: initialDatas?.barcodeDesign?.backgroundColor || "#ffffff",
            lineColor: initialDatas?.barcodeDesign?.textColor || "#000000",
          });
  
          // Add barcode image
          doc.addImage(
            canvas.toDataURL(),
            "PNG",
            contentX,
            barcodeY,
            barcodeWidth,
            barcodeHeight
          );
  
          // Add barcode number below barcode
          doc.setFontSize(defaultFontSize); // Slightly larger font for barcode number
          doc.setFont(undefined, "bold");
          // const barcodeNumberY = barcodeY + barcodeHeight + 3; // Position below barcode
          const barcodeNumberY =  y + labelHeight - (bottomTextSpace - textHeight) - 2; // Position below barcode
          doc.text(
            barcodeValue,
            x + labelWidth / 2,
            barcodeNumberY,
            { align: "center" }
          );
  
          // Reset font settings
          doc.setFontSize(defaultFontSize);
          doc.setFont(undefined, "normal");
  
          
          const renderText = (field, yPos) => {
            const value = getValue(currentItem, field);
            if (!value) return; // Skip if no value
            
            const alignment = getCorrectAlignment(field.align);
            const textX = getTextX(x, labelWidth, alignment);
          
            doc.setFontSize(field.fontSize || defaultFontSize);
            doc.setFont(undefined, field.isBold ? "bold" : "normal");
            doc.text(String(value), textX, yPos, { align: alignment });
          };
  
          // Render top texts
          topTexts.forEach((field, idx) => {
            const yPos = y + (idx + 1) * textHeight;
            renderText(field, yPos);
          });
  
          // Render bottom texts (positioned after barcode number)
          bottomTexts.forEach((field, idx) => {
            const yPos = barcodeNumberY + ((idx + 1) * textHeight);
            renderText(field, yPos);
          });
        }
      };
  
      // Generate all pages
      const totalItems = selectedTableData.reduce(
        (sum, item) => sum + parseInt(item.qty || 1),
        0
      );
      const totalPages = Math.ceil(totalItems / settings.labelsPerPage);
  
      for (let page = 0; page < totalPages; page++) {
        if (page > 0) doc.addPage();
        generatePage(page * settings.labelsPerPage);
      }
  
      doc.save("barcodes.pdf");
    } catch (error) {
      console.error("Error generating PDF:", error);
    } finally {
      setIsSubmitting(false);
      onClose();
    }
  };

 

  const getValue = (item, field) => {
    let value = "";
    
    // Get the value based on field type
    switch (field.field?.toLowerCase()) {
      case "item name":
        value = item.itemName || "";
        break;
      case "mrp":
        value = item.mrp ? Number(item.mrp).toFixed(2) : "";
        break;
      case "organizations name":
        value = organizationValue(item.organizationId) || "";
        break;
      case "barcode":
        value = item.barcode || "";
        break;
      case "hsn":
        value = item.hsn || "";
        break;
      case "customlabel":
        value = item.customlabel || "";
        break;
      case "price":
        value = item.price ? Number(item.price).toFixed(2) : "";
        break;
      case "batch":
        value = item.batch || "";
        break;
      case "expiry":
        value = item.expiry || "";
        break;
      case "mfg":
        value = item.mfg || "";
        break;
      default:
        value = item[field.field?.toLowerCase()] || "";
    }
  
    // Only add label if it exists in the field object and is not empty
    return field.label ? `${field.label}: ${value}` : value;
  };

  // Helper function to calculate text X position
  const getTextX = (x, width, alignment) => {
    switch (alignment) {
      case "left":
        return x + 2;
      case "right":
        return x + width - 2;
      default:
        return x + width / 2;
    }
  };

  

  // Form submission handler
  const onSubmit = async (data) => {
    setIsSubmitting(true);
    const barcodeData = selectedTableData?.map((item) => ({
      code: item.barcode || `${1000000 + selectedTableData.indexOf(item) + 1}`,
      itemName: item.itemName || "",
      mrp: item.mrp || "",
      hsn: item.hsn || "",
      customlabel: item.customlabel || "",
      organizationsname: item.organizationname || "",
      qty: parseInt(item.qty) || 1,
    }));

    if (barcodeData?.length) {
      await generateBarcodePDF(data, barcodeData);
    }
  };

  // Update form when printer type changes
  useEffect(() => {
    const defaultConfig = printtype === "regularPrinter" ? "65Labels38mmx21mm" : "2Leb50mm25mm";
    form.setValue("labelConfig", defaultConfig);
    setLabelConfig(defaultConfig);

    const config = LABEL_CONFIGURATIONS[defaultConfig];
    if (config) {
      form.setValue("customWidth", convertNumberToString(config.barcodeWidth));
      form.setValue("customHeight", convertNumberToString(config.barcodeHeight));
      form.setValue("customTop", convertNumberToString(config.defaultMargins.top));
      form.setValue("customLeft", convertNumberToString(config.defaultMargins.left));
    }
  }, [printtype, form]);
  return (
    <>
      <div className="flex justify-between items-center rounded-tl-2xl h-[76px] bg-indigo-50 p-6 border-b">
        <h2 className="text-lg font-semibold">Printer settings</h2>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <main className="pb-16 h-[calc(100vh-100px)] overflow-y-auto ">
            <div className="w-[90%] pt-4 space-y-4 mx-auto">
              <FormSelectField
                label="Select Printer Type"
                name="printerType"
                placeholder="Select Printer Type"
                options={Printertype}
                className="bg-white"
              />

              <FormSelectField
                label="Label Configuration"
                name="labelConfig"
                placeholder="Select Label Configuration"
                options={
                  printtype === "regularPrinter"
                    ? labelConfigRegularPrinter
                    : labelConfigLabelPrinter
                }
                className="bg-white"
                intialValue={
                  printtype === "regularPrinter"
                    ? "65Labels38mmx21mm"
                    : "2Leb50mm25mm"
                }
                onChange={handleLabelConfigChange}
              />

              {/* <TextInputField
                form={form}
                name="barcodePrintNumber"
                label="Number of Barcode to Print"
                placeholder="Enter Number of Barcode to Print"
              /> */}

              <TextInputField
                form={form}
                name="customWidth"
                label="Custom Width"
                placeholder="Enter Custom Width"
                type="number"
              />

              <TextInputField
                form={form}
                name="customHeight"
                label="Custom Height"
                placeholder="Enter Custom Height"
                type="number"
              />


              <TextInputField
                form={form}
                name="customTop"
                label="Custom Top"
                placeholder="Enter Custom Top"
                type="number"
              />

              <TextInputField
                form={form}
                name="customLeft"
                label="Custom Left"
                placeholder="Enter Custom Left"
                type="number"
              />
           
            </div>
          </main>

          <div className="flex justify-end rounded-b-2xl bg-indigo-50 gap-3 border-t sticky bottom-0  h-[76px] left-0 w-full p-4 shadow-lg">
            <Button
              type="submit"
              className="    text-white"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Generating PDF..." : "Save"}
            </Button>
            <Button
              type="button"
              onClick={onClose}
              className="bg-gray-200 hover:bg-gray-300 text-gray-800"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Form>
    </>
  );
};

export default PrinterSettingConfigurationForm;
