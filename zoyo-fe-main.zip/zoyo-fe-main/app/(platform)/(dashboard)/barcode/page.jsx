"use client";
import React, { useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import CustomTable from "@/components/custom-table/custom-table";
import { Custom_Sheet } from "@/components/custom-sheet/custom-sheet";
import { useQuery } from "@tanstack/react-query";
import { getAllItems } from "@/actions/items/get-all-items";
import useDebounce from "@/hooks/use-debounce";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getUserOrganizations } from "@/actions/company-flow/get-user-organizations";
import { getBarcodeData } from "@/actions/barcode/get-barcode";
import { Label } from "@/components/ui/label";

const BarcodePage = ({ searchPlaceholder, organizationId }) => {
  // State Management
  const [changePageCount, setChangePageCount] = useState(1);
  const [sortBy, setSortBy] = useState("createdAt");
  const [sortOrder, setSortOrder] = useState("desc");
  const [totalRowCount, setTotalRowCount] = useState(10);
  const [searchValue, setSearchValue] = useState("");
  const [selectedBarcodeId, setSelectedBarcodeId] = useState([]);
  const [selectedTableData, setSelectedTableData] = useState([]);
  const [isPrinterSheetOpen, setIsPrinterSheetOpen] = useState(false);
  const [status, setStatus] = useState({ key: "all", heading: "All" });
  const [filterBy, setFilterBy] = useState({ key: "both", heading: "All" });

  const [isSameQuantity, setIsSameQuantity] = useState(false);

  const debouncedSearchValue = useDebounce(searchValue, 500);

  // Queries
  const { data, isLoading, error } = useQuery({
    queryKey: [
      "items",
      changePageCount,
      sortBy,
      sortOrder,
      totalRowCount,
      debouncedSearchValue,
      status,
      filterBy,
    ],
    queryFn: () =>
      getAllItems(
        changePageCount,
        sortBy,
        sortOrder,
        totalRowCount,
        debouncedSearchValue,
        status,
        filterBy
      ),
  });

  const { data: initialDatas } = useQuery({
    queryKey: ["barcode_FormData"],
    queryFn: getBarcodeData,
  });

  const { data: organizationsName } = useQuery({
    queryKey: ["getorganizationData"],
    queryFn: getUserOrganizations,
  });

  // Handlers
  const handleRemoveItem = useCallback((item) => {
    const itemId = item?.id || item;
    setSelectedBarcodeId((prev) => prev.filter((id) => id !== itemId));
    setSelectedTableData((prev) =>
      prev.filter((tableItem) => tableItem.id !== itemId)
    );
  }, []);

  // const handleInputChange = useCallback((id, field, value) => {
  //   setSelectedTableData((prevData) =>
  //     prevData.map((item) =>
  //       item.id === id ? { ...item, [field]: value } : item
  //     )
  //   );
  // }, []);

   // Modified handleInputChange to update all quantities when checkbox is checked
   const handleInputChange = useCallback((id, field, value) => {
    if (field === 'qty' && isSameQuantity) {
      // If checkbox is checked, update all rows with the new quantity
      setSelectedTableData((prevData) =>
        prevData.map((item) => ({
          ...item,
          qty: value
        }))
      );
    } else {
      // Normal single field update
      setSelectedTableData((prevData) =>
        prevData.map((item) =>
          item.id === id ? { ...item, [field]: value } : item
        )
      );
    }
  }, [isSameQuantity]);

  const onSortChange = useCallback(
    (sortedBy) => {
      if (sortBy === sortedBy) {
        setSortOrder(sortOrder === "asc" ? "desc" : "asc");
      } else {
        setSortBy(sortedBy);
        setSortOrder("asc");
      }
    },
    [sortBy, sortOrder]
  );

  const renderSortIcon = useCallback(
    (columnId) => {
      if (sortBy === columnId) {
        return sortOrder === "asc" ? (
          <ChevronDown className="ml-2 h-4 w-4" />
        ) : (
          <ChevronUp className="ml-2 h-4 w-4" />
        );
      }
      return <ChevronDown className="ml-2 h-4 w-4" />;
    },
    [sortBy, sortOrder]
  );

  const handleSelectAll = useCallback(
    (checked) => {
      if (checked) {
        const itemsWithBarcode =
          data?.data?.data?.filter((item) => item.barcode) || [];
        setSelectedBarcodeId(itemsWithBarcode.map((item) => item.id));
        setSelectedTableData(
          itemsWithBarcode.map((item) => ({
            ...item,
            customlabel: "",
            qty: "",
          }))
        );
      } else {
        setSelectedBarcodeId([]);
        setSelectedTableData([]);
      }
    },
    [data?.data?.data]
  );

  const getOrganizationName = useCallback(
    (id) => {
      const organizationData = organizationsName?.data?.data || [];
      const organization = organizationData.find((org) => org.id === id);
      return organization?.name || "N/A";
    },
    [organizationsName?.data?.data]
  );

  // Column Definitions
  const mainColumns = [
    {
      id: "select",
      header: () => (
        <div className="flex justify-center">
          <Checkbox
            checked={
              selectedBarcodeId?.length > 0 &&
              selectedBarcodeId?.length ===
                (data?.data?.data?.filter((item) => item.barcode)?.length || 0)
            }
            onCheckedChange={handleSelectAll}
            aria-label="Select all"
          />
        </div>
      ),
      cell: ({ row }) => (
        <div className="flex justify-center">
          <Checkbox
            checked={selectedBarcodeId?.includes(row.original.id)}
            onCheckedChange={(checked) => {
              if (checked) {
                setSelectedBarcodeId((prev) => [...prev, row.original.id]);
                setSelectedTableData((prev) => [
                  ...prev,
                  {
                    ...row.original,
                    customlabel: "",
                    qty: "",
                  },
                ]);
              } else {
                handleRemoveItem(row.original.id);
              }
            }}
            aria-label="Select row"
            disabled={!row.original.barcode}
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
    },
    {
      id: "itemName",
      accessorKey: "itemName",
      header: () => (
        <div className="flex justify-start">
          <button
            className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900"
            onClick={() => onSortChange("itemName")}
          >
            <span className="flex items-center gap-1">
              Item Name
              {renderSortIcon("itemName")}
            </span>
          </button>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left text-nowrap">{row.getValue("itemName")}</div>
      ),
    },
    {
      id: "unit",
      accessorKey: "unit",
      header: () => (
        <div className="flex justify-start">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span className="flex items-center gap-1">Unit</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left">{row.getValue("unit")}</div>
      ),
    },
    {
      id: "barcode",
      accessorKey: "barcode",
      header: () => (
        <div className="flex justify-start">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span className="flex items-center gap-1">Barcode</span>
          </div>
        </div>
      ),
      cell: ({ row }) => (
        <div className="text-left">{row.getValue("barcode")}</div>
      ),
    },
  ];

  const selectedItemsColumns = React.useMemo(() => {
    const barcodeTextArray = Array.isArray(initialDatas?.barcodeText)
      ? initialDatas.barcodeText
      : [];
  
   
    const baseColumns = barcodeTextArray.map((textConfig) => ({
      id: textConfig.field,
      accessorKey: textConfig.field,
      header: () => (
        <div className="flex justify-start">
          <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
            <span className="flex items-center gap-1">{textConfig.field}</span>
          </div>
        </div>
      ),
      cell: ({ row }) => {
        const cellValue = (() => {
        
          switch (textConfig.field) {
            case "item name":
              return row.original.itemName;
            case "organizations name":
              return getOrganizationName(row.original.organizationId);
            case "mrp":
              return Number(row.original.mrp).toFixed(2);
            case "hsn":
              return row.original.hsn;
            case "barcode":
              return row.original.barcode;
            case "customlabel":
              return (
                <div className="w-[90px]">
                  <Input
                    value={row.original.customlabel || ""}
                    onChange={(e) =>
                      handleInputChange(
                        row.original.id,
                        "customlabel",
                        e.target.value
                      )
                    }
                  />
                </div>
              );
            default:
              return row.original[textConfig.field];
          }
        })();
        return <div className="text-left text-nowrap">{cellValue}</div>;
      },
    }));

    const additionalColumns = [
      {
        id: "qty",
        accessorKey: "qty",
        header: () => (
          <div className="flex justify-start">
            <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
              <span className="flex items-center gap-1">
                Enter Qty For Print
              </span>
            </div>
          </div>
        ),
        cell: ({ row }) => (
          <div className="w-[90px]">
            <Input
              type="number"
              value={row.original.qty || ""}
              onChange={(e) =>
                handleInputChange(row.original.id, "qty", e.target.value)
              }
              min="0"
            />
          </div>
        ),
      },
      {
        id: "actions",
        header: () => (
          <div className="flex justify-end">
            <div className="bg-inherit hover:bg-inherit font-semibold text-center text-gray-900">
              <span className="flex items-center">Actions</span>
            </div>
          </div>
        ),
        cell: ({ row }) => (
          <div className="flex items-center justify-end">
            <Button
              size="icon"
              className="bg-white hover:bg-inherit ml-2 shadow-none border text-black"
              onClick={() => handleRemoveItem(row.original)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ),
      },
    ];

    return [...baseColumns, ...additionalColumns];
  }, [
    initialDatas?.barcodeText,
    handleRemoveItem,
    handleInputChange,
    getOrganizationName,
  ]);

  

  // Add handler for checkbox
  const handleSameQuantityToggle = useCallback((checked) => {
    setIsSameQuantity(checked);
    if (checked) {
      const lastQty = selectedTableData.find(item => item.qty)?.qty || '';
      if (lastQty) {
        setSelectedTableData(prevData =>
          prevData.map(item => ({
            ...item,
            qty: lastQty
          }))
        );
      }
    }
  }, [selectedTableData]);


  const otherFields = () => {
    return  <div className="flex items-center gap-2 mr-1">
    <Checkbox 
              id="sameQtyAll"
              checked={isSameQuantity}
              onCheckedChange={handleSameQuantityToggle}
            />
            <Label htmlFor="sameQtyAll">Same Qty For All</Label>
  </div>;
  };

  return (
    <Card className="rounded-md">
      <div className="flex justify-between mt-4 ml-3 mr-2">
        <h1 className="text-xl">Barcode Generator</h1>
        <Button
          type="button"
          onClick={() => setIsPrinterSheetOpen(true)}
          disabled={selectedTableData.length === 0}
          className="mr-1"
        >
          Print
        </Button>
        
      </div>
      <div className="border-t mt-4" />
      <div className="flex flex-col sm:flex-row   ">
        <div className="w-full sm:border-r sm:w-[40%]">
         
           <CustomTable
              data={data?.data?.data || []}
              columns={mainColumns || []}
              isLoading={isLoading}
              error={error}
              tableHeader="Items"
              tableWidth={"100%"}
              pageChangeCount={setChangePageCount}
              getSerchValue={setSearchValue}
              serchPlaceholder={"Search"}
            />
        </div>
        <div className="w-full sm:w-[60%] overflow-x-auto">
         
          {selectedTableData && (
            <CustomTable
              data={selectedTableData}
              columns={selectedItemsColumns}
              isLoading={isLoading}
              error={error}
              tableHeader="Selected Items"
              tableWidth="100%"
              pageChangeCount={setChangePageCount}
              totalRowCount={setTotalRowCount}
              otherFields={otherFields()}
            />
          )}
        </div>
      </div>
      <Custom_Sheet
        isOpen={isPrinterSheetOpen}
        onClose={() => setIsPrinterSheetOpen(false)}
        activeKey="barcodeConfigurationForm"
        selectedTableData={selectedTableData}
      />
    </Card>
  );
};

export default BarcodePage;
