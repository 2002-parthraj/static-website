import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getAllAccountsData = async () => {
	const mainUrl = `${baseURL}/accounts`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
