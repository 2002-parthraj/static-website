import axios from "@/lib/axios";

export const fetchAllPages = async () => {
	const endpoint = "/api/v1/admin/category-data/get";
	try {
		const response = await axios.post(endpoint, null);
		return response.data[0].config;
	} catch (error) {
		throw new Error(error.response?.data?.message || error.message);
	}
};
