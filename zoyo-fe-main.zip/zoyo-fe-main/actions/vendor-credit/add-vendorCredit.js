import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const addVendorCredit = async (data) => {
	const endpoint = `${baseURL}/vendor-credits`;
	try {
		const response = await axios.post(endpoint, data);
		return response;
	} catch (error) {
		return error;
	}
};
