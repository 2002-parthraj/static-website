import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getVendorCreditById = async (id) => {
	const mainUrl = `${baseURL}/vendor-credits/${id}`;
	try {
		const response = await axios.get(mainUrl);

		return response?.data;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
