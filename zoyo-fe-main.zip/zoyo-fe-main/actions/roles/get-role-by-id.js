import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getPRoleById = async (id) => {
	const mainUrl = `${baseURL}/roles/${id}`;
	try {
		const response = await axios.get(mainUrl);
       
		return response?.data;
       
        
	} catch (error) {
        console.error("Error in getPRoleById:", error);
		return error.response?.data?.message || error.message;
	}
};