import axios from "@/lib/axios-image";

export const uploadFile = async (payload) => {
  try {
    const response = await axios.post('/storage/upload', payload);
    return response;
  } catch (error) {
    return error?.response;
  }
};