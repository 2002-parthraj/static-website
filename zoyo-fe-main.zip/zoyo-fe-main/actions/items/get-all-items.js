import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getAllItems = async (
	changePageCount,
	sortBy,
	sortOrder,
	totalRowCount,
	debouncedSearchValue,
	status,
	filterBy,
) => {
	const mainUrl = `${baseURL}/items?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&filter_by=${filterBy.key}&status=${status.key}&search_by=global&query=${debouncedSearchValue}`;

	try {
		const response = await axios.get(mainUrl);

		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};

export const getAllItemsLocation = async (
	changePageCount,
	sortBy,
	sortOrder,
	totalRowCount,
	debouncedSearchValue,
	status,
	filterBy,
	locationId,
) => {
	const mainUrl = `${baseURL}/items?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&filter_by=${filterBy.key}&status=${status.key}&search_by=global&query=${debouncedSearchValue}&location_id=${locationId}`;

	try {
		const response = await axios.get(mainUrl);

		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};

export const getAllItemsCategory = async (
	changePageCount,
	sortBy,
	sortOrder,
	totalRowCount,
	debouncedSearchValue,
	status,
	filterBy,
	categoryId,
) => {
	const mainUrl = `${baseURL}/items?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&filter_by=${filterBy.key}&status=${status.key}&search_by=global&query=${debouncedSearchValue}&category_id=${categoryId}`;

	try {
		const response = await axios.get(mainUrl);

		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};

export const getAllItemsGroups = async (
	changePageCount,
	sortBy,
	sortOrder,
	totalRowCount,
	debouncedSearchValue,
	status,
	filterBy,
	groupsId,
) => {
	const mainUrl = `${baseURL}/items?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&filter_by=${filterBy.key}&status=${status.key}&search_by=global&query=${debouncedSearchValue}&group_id=${groupsId}`;

	try {
		const response = await axios.get(mainUrl);

		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};

export const getAllItemsByBarcode = async (barcode) => {
	const mainUrl = `${baseURL}/items?search_by=barcode&query=${barcode}`;

	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
