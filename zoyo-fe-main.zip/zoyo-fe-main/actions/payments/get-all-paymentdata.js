import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getAllPaymentData = async (
  changePageCount,
  sortBy,
  sortOrder,
  totalRowCount,
  debouncedSearchValue
) => {
  const mainUrl = `${baseURL}/payments?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&search=${debouncedSearchValue}`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};

export const getPaymentDataById = async (id) => {
  const mainUrl = `${baseURL}/payments/${id}`;
  try {
    const response = await axios.get(mainUrl);

    return response?.data;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};

export const fetchInitialPartysforPayment = async () => {
  const response = await axios.get(
    `${process.env.NEXT_PUBLIC_BASE_URL}/parties`
  );

  const setlable = response.data.data.map((party) => ({
    label: party.name,
    value: `${party.id}`,
    type: "party",
  }));

  return setlable;
};

export const getSuggestionOfOppositeAccounts = async (debouncedSearchQuery) => {
  const response = await axios.get(
    `${process.env.NEXT_PUBLIC_BASE_URL}/suggestions?query=${debouncedSearchQuery}&type=all`
  );

  // const { parties, accounts } = response.data;

  // // Combine parties and accounts into one array, adding a 'type' field to each
  // const combinedSuggestions = [
  //   ...parties.map((party) => ({
  //     label: party.name,
  //     value: `${party.id}`,
  //     type: "party", // Add type as 'party'
  //   })),
  //   ...accounts.map((account) => ({
  //     label: account.name,
  //     value: `${account.id}`,
  //     type: "account", // Add type as 'account'
  //   })),
  // ];

  return response;
};

export const fetchInitialAccountsforPayment = async () => {
  const response = await axios.get(
    `${process.env.NEXT_PUBLIC_BASE_URL}/accounts`
  );

  const setlable = response.data.data.map((account) => ({
    label: account.name,
    value: `${account.id}`,
    type: "account",
  }));

  return setlable;
};
