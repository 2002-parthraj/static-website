import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getAllpriceList = async (
	changePageCount,
	sortBy,
	sortOrder,
	totalRowCount,
	debouncedSearchValue,
) => {
	const mainUrl = `${baseURL}/items/price-list?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&search=${debouncedSearchValue}`;
	try {
		const response = await axios.get(mainUrl);

		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
