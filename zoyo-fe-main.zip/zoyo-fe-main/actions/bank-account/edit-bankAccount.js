import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const editBankAccount = async (editdata, id) => {
	const endpoint = `${baseURL}/bank-accounts/${id}`;
	try {
		const response = await axios.put(endpoint, editdata);
		return response;
	} catch (error) {
		// return error.response?.data?.message || error.message;
		return error?.response;
	}
};
