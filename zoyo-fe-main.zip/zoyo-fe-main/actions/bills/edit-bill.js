import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const EditBillData = async (id, payload) => {
	const endpoint = `${baseURL}/bills/${id}`;
	try {
		const response = await axios.put(endpoint, payload);
		return response;
	} catch (error) {
		return error?.response;
	}
};
