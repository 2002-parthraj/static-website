import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const AddEditTDSPreference = async (preferenceData) => {
	const endpoint = `${baseURL}/settings/tds`;
	try {
		const response = await axios.post(endpoint, preferenceData);
		return response;
	} catch (error) {
		return error?.response;
	}
};
