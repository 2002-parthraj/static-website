import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getAllVoucharsEwayBills = async (
  debouncedSearchValue,
  currentApiKey
) => {
  const mainUrl = `${baseURL}/${currentApiKey}?page=1&per_page=10&sort_by=date&sort_order=desc&status=all&search_by=global&query=${debouncedSearchValue}`;

  try {
    const response = await axios.get(mainUrl);

    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};
