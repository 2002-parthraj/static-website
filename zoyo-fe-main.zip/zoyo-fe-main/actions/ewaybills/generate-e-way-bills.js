import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const generateEwayBills = async (id) => {
  const mainUrl = `${baseURL}/eway-bills/generate/${id}`;
  try {
    const response = await axios.get(mainUrl);
    console.log(response);

    return response?.data;
  } catch (error) {
    console.log(error);
    return error.response;
  }
};
