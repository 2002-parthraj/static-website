import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const editTransporter = async (id, editdata) => {
  const endpoint = `${baseURL}/eway-bills/transporters/${id}`;
  try {
    const response = await axios.put(endpoint, editdata);

    return response;
  } catch (error) {
    return error?.response;
  }
};
