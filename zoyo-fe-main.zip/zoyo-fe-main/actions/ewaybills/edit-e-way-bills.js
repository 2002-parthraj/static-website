import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const editEwayBills = async (editdata, id) => {
	const endpoint = `${baseURL}/eway-bills/${id}`;
	try {
		const response = await axios.put(endpoint, editdata);

		return response;
	} catch (error) {
		return error?.response;
	}
};
