import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getGSTDetails = async (gstin) => {
	const mainUrl = `${baseURL}/gst-api/search?gstin=${gstin}`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};