import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const addSalesCustomCharges = async (data) => {
	const endpoint = `${baseURL}/settings/sales/custom-charges`;
	try {
		const response = await axios.post(endpoint, data);
		return response;
	} catch (error) {
		return error;
	}
};
