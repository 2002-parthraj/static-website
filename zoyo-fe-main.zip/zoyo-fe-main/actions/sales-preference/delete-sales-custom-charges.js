import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const deleteSalesCustomCharges = async (id) => {
	const endpoint = `${baseURL}/settings/sales/custom-charges/${id}`;
	try {
		const response = await axios.delete(endpoint);
		return response?.data;
	} catch (error) {
		console.error("Error during deletion:", error);
		return error.response?.data?.message || error.message;
	}
};
