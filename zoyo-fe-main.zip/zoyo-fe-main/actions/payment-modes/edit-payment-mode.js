import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const editPaymentModes = async ({ id, editdata }) => {
  const endpoint = `${baseURL}/payment-modes/${id}`;
  try {
    const response = await axios.put(endpoint, editdata);
    return response;
  } catch (error) {
    return error?.response;
  }
};
