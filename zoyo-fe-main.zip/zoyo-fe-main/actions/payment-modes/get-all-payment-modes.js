import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getAllPaymentMode = async () => {
  const mainUrl = `${baseURL}/payment-modes`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};
