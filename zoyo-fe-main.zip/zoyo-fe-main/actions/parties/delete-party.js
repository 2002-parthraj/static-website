// import axios from "@/lib/axios";
import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const deleteParty = async (id) => {
	const endpoint = `${baseURL}/parties/${id}`;
	try {
		const response = await axios.delete(endpoint);

		return response;
	} catch (error) {
		return error.response?.data?.error || error.message;
	}
};
