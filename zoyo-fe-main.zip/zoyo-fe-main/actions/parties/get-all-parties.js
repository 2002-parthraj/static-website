import axios from "@/lib/axios";

// Use the correct environment variable for client-side
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getAllParties = async (
	changePageCount,
	sortBy,
	sortOrder,
	totalRowCount,
	debouncedSearchValue,
	status,
	filterBy,
) => {
	const mainUrl = `${baseURL}/parties?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&filter_by=${filterBy.key}&status=${status.key}&search_by=global&query=${debouncedSearchValue}`;

	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};

export const getAllPartiesName = async (debouncedSearchValue) => {
	const mainUrl = `${baseURL}/parties?page=1&per_page=200&search_by=global&query=${debouncedSearchValue}`;

	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};

export const getPartyTransctions = async (
	partyId,
	module,
	totalRowCount,
	changePageCount,
) => {
	const mainUrl = `${baseURL}/parties/${partyId}/transactions?module=${module.key}&page=${changePageCount}&per_page=${totalRowCount}`;

	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
export const getPartyStatement = async (partyId, formDate, toDate) => {
	const mainUrl = `${baseURL}/parties/${partyId}/statement?from_date=${formDate}&to_date=${toDate}`;

	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
