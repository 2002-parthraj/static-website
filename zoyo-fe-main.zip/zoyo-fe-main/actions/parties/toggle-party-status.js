import axios from "@/lib/axios";

// Use the correct environment variable for client-side
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const patchtogglePartyStatus = async (id) => {
	const url = `${baseURL}/parties/${id}/toggle-status`;
	try {
		const response = await axios.patch(url);
		return response;
	} catch (error) {
		return error.response?.data?.error || error.message;
	}
};
