import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const postBarcodeData = async (data) => {
	const endpoint = `${baseURL}/settings/barcode`;
	try {
		const response = await axios.post(endpoint, data);
		return response;
	} catch (error) {
		console.log(error);
	}
};
