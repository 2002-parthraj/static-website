import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getBarcodeData = async () => {
	const maninUrl = `${baseURL}/settings/barcode`;
	try {
		const response = await axios.get(maninUrl);
		
		return response?.data?.data;
	} catch (error) {
		console.log(error);
	}
};
