import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const addCreditNote = async (payload) => {
	const endpoint = `${baseURL}/credit-notes`;
	try {
		const response = await axios.post(endpoint, payload);
		return response;
	} catch (error) {
		return error?.response;
	}
};
