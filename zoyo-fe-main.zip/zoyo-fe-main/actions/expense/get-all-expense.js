import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getAllExpense = async (
  changePageCount,
  sortBy,
  sortOrder,
  totalRowCount,
  debouncedSearchValue
) => {
  const mainUrl = `${baseURL}/expenses?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&search=${debouncedSearchValue}`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};

export const fetchInitialAccounts = async () => {
  const response = await axios.get(
    `${process.env.NEXT_PUBLIC_BASE_URL}/accounts`
  );

  const setlable = response.data.data.map((party) => ({
    label: party.name,
    value: `${party.id}`,
  }));

  return setlable;
};

export const getSuggestionOfAccounts = async (debouncedSearchQuery) => {
  const response = await axios.get(
    `${process.env.NEXT_PUBLIC_BASE_URL}/suggestions?query=${debouncedSearchQuery}&type=accounts`
  );
  return response.data.suggestions.map((suggestion) => ({
    label: suggestion.name,
    value: `${suggestion.id}`,
  }));
};
