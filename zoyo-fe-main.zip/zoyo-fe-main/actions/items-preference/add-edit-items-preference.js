import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const AddEditItemsPreference = async (preferenceData) => {
	const endpoint = `${baseURL}/settings/items`;
	try {
		const response = await axios.post(endpoint, preferenceData);
		return response;
	} catch (error) {
		return error?.response;
	}
};
