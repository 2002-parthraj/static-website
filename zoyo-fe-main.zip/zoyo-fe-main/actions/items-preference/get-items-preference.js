import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getItemsPreference = async () => {
	const mainUrl = `${baseURL}/settings/items`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
