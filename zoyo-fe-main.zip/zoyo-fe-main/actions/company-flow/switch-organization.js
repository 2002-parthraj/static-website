import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const switchOrganization = async (id) => {
  console.log(id);
  const endpoint = `${baseURL}/organizations/switch-organization/${id}`;
  try {
    const response = await axios.patch(endpoint);
    return response;
  } catch (error) {
    return error?.response;
  }
};
