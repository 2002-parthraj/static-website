import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const fetchInitialItemsforComboBox = async () => {
	const response = await axios.get(
		`${baseURL}/items?page=1&per_page=10&sort_by=createdAt&sort_order=desc&filter_by=both&status=active&search_by=itemName`,
	);
	const setlable = response?.data?.data?.map((party) => ({
		label: party.itemName,
		value: `${party.id}`,
	}));
	return setlable;
};

export const getSuggestionOfItemsforComboBox = async (debouncedSearchQuery) => {
	const response = await axios.get(
		`${process.env.NEXT_PUBLIC_BASE_URL}/suggestions?query=${debouncedSearchQuery}&type=items`,
	);
	return response?.data?.items?.map((suggestion) => ({
		label: suggestion?.name,
		value: `${suggestion.id}`,
	}));
};
