import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const updateBulkOpeningBalance = async (data) => {
	const endpoint = `${baseURL}/settings/opening-balances`;
	try {
		const response = await axios.put(endpoint, data);

		return response;
	} catch (error) {
		return error;
	}
};
