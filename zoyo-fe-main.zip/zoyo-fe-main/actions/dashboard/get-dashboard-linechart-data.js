import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getDashboardLineChartData = async (
	interval,
) => {
	const mainUrl = `${baseURL}/dashboard/line-chart?startDate=2024-01-01&endDate=2026-01-01&interval=${interval}`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};