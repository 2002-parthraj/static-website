import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getDashboardSalesConversionChartData = async (
	interval,
) => {
	const mainUrl = `${baseURL}/dashboard/sales-conversion?interval=${interval}`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};


