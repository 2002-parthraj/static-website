import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getPieChaRtreceiptsByPaymentData = async () => {
	const mainUrl = `${baseURL}/dashboard/receipts-by-payment-mode`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};