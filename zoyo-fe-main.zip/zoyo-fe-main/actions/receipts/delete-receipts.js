import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const deleteReceipts = async (id) => {
	const endpoint = `${baseURL}/receipts/${id}`;
	try {
		const response = await axios.delete(endpoint);

		return response?.data;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
