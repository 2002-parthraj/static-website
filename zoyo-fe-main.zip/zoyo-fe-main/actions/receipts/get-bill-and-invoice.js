import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getBillOrInvoiceOfPartyAndAccount = async (type, id) => {
	const mainUrl =
		type === "party"
			? `${baseURL}/parties/${id}/unpaid-invoices`
			: `${baseURL}/parties/${id}/unpaid-bills`;
	try {
		const response = await axios.get(mainUrl);

		return response?.data;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};

export const getBillOrInvoiceOfPartyAndAccountTypeBill = async (id) => {
	const mainUrl = `${baseURL}/parties/${id}/unpaid-bills`;
	try {
		const response = await axios.get(mainUrl);

		return response?.data;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
