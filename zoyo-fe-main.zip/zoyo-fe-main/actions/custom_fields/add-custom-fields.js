import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const addCustomFieldData = async (payload) => {
	const endpoint = `${baseURL}/settings/voucher-custom-fields`;
	try {
		const response = await axios.post(endpoint, payload);
		return response;
	} catch (error) {
		return error?.response;
	}
};
