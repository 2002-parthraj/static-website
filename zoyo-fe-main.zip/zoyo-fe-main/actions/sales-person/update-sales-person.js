import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const editSalesPerson = async ({ id, name }) => {
	const endpoint = `${baseURL}/sales-persons/${id}`;
	try {
		const response = await axios.put(endpoint, { name });

		return response;
	} catch (error) {
		return error?.response;
	}
};
