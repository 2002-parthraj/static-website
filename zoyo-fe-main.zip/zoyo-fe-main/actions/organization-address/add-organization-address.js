import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const addOrganizationsAddress = async (data) => {
	const endpoint = `${baseURL}/organizations/address`;
	try {
		const response = await axios.post(endpoint, data);
		return response;
	} catch (error) {
		return error;
	}
};
