import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getAllInvoice = async (
	changePageCount,
	sortBy,
	sortOrder,
	totalRowCount,
	debouncedSearchValue,
	status,
	filterBy,
) => {
	const mainUrl = `${baseURL}/invoices?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&status=${status?.key}&search_by=global&query=${debouncedSearchValue}`;

	try {
		const response = await axios.get(mainUrl);

		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
