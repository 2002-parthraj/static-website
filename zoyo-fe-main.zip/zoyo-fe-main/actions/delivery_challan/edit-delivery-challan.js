import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const EditDeliveryChallan = async (id, payload) => {
	const endpoint = `${baseURL}/delivery-challans/${id}`;
	try {
		const response = await axios.put(endpoint, payload);
		return response;
	} catch (error) {
		return error?.response;
	}
};
