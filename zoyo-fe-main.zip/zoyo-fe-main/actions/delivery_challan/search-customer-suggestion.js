import axios from "@/lib/axios";

export const fetchInitialPartiesforDeleiveryChalan = async () => {
	const response = await axios.get(
		`${process.env.NEXT_PUBLIC_BASE_URL}/parties?page=1&per_page=10&sort_by=createdAt&sort_order=desc&filter_by=both&status=active&search_by=name`,
	);

	const setlable = response.data.data.map((party) => ({
		label: party.name,
		value: `${party.id}`,
	}));

	return setlable;
};

export const getSuggestionOfPartiesforDeleiveryChalan = async (
	debouncedSearchQuery,
) => {
	const response = await axios.get(
		`${process.env.NEXT_PUBLIC_BASE_URL}/suggestions?query=${debouncedSearchQuery}&type=parties`,
	);
	return response?.data?.parties?.map((suggestion) => ({
		label: suggestion.name,
		value: `${suggestion.id}`,
	}));
};

export const fetchInitialitemforDeleiveryChalan = async () => {
	const response = await axios.get(
		`${process.env.NEXT_PUBLIC_BASE_URL}/items?page=1&per_page=10&sort_by=createdAt&sort_order=desc&filter_by=both&status=active&search_by=itemName`,
	);
	const setlable = response.data.data.map((party) => ({
		label: party.itemName,
		value: `${party.id}`,
	}));

	return setlable;
};

export const getSuggestionOfItemsforDeleiveryChalan = async (
	debouncedSearchQuery,
) => {
	const response = await axios.get(
		`${process.env.NEXT_PUBLIC_BASE_URL}/suggestions?query=${debouncedSearchQuery}&type=items`,
	);
	return response.data.items.map((suggestion) => ({
		label: suggestion.name,
		value: `${suggestion.id}`,
	}));
};
