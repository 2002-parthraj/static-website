import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const stateList = async () => {
	const endpoint = `${baseURL}/states`;
	try {
		const response = await axios.get(endpoint);
		return response;
	} catch (error) {
		return error;
	}
};
