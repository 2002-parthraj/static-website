import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const editAddress = async ({
	partyIdforAddress,
	addressID,
	payload,
}) => {
	const endpoint = `${baseURL}/parties/${partyIdforAddress}/addresses/${addressID}`;
	try {
		const response = await axios.put(endpoint, payload);

		return response;
	} catch (error) {
		return error?.response;
	}
};
