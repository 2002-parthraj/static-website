import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getInventoryCategorySummaryReport = async (asOfDate) => {
	const mainUrl = `${baseURL}/reports/inventory/category-summary?asOfDate=${asOfDate}`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};