import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getTdsReceivablesReport = async (startDate,endDate) => {
	const mainUrl = `${baseURL}/reports/tds/receivables/summary?startDate=${startDate}&endDate=${endDate}`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};