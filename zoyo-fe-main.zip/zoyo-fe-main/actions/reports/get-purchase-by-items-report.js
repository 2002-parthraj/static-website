import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getPurchaseItemsReport = async (startDate,endDate) => {
	const mainUrl = `${baseURL}/reports/purchase/by-item?startDate=${startDate}&endDate=${endDate}`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};