import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getBusinessProfitLossReport = async (startDate,endDate) => {
	const mainUrl = `${baseURL}/reports/business/profit-loss?startDate=${startDate}&endDate=${endDate}&format=horizontal`;
	try {
		const response = await axios.get(mainUrl);
		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};