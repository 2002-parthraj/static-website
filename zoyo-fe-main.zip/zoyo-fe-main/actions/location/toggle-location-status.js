import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const patchtoggleLocationsStatus = async (id) => {
	const url = `${baseURL}/items/locations/${id}/toggle-status`;

	try {
		const response = await axios.patch(url);
		return response;
	} catch (error) {
		return error.response?.data?.error || error.message;
	}
};
