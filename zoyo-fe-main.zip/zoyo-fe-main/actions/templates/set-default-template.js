import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const setDefaultTemplate = async (id) => {
	const mainUrl = `${baseURL}/settings/templates/${id}/default`;
	try {
		const response = await axios.put(mainUrl);

		return response?.data;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
