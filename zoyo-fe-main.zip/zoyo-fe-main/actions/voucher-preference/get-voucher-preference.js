import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
export const getPurchaseOrderPreference = async () => {
  const mainUrl = `${baseURL}/settings/voucher-preference?voucher_type=purchaseOrder`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};

export const getBillPreference = async () => {
  const mainUrl = `${baseURL}/settings/voucher-preference?voucher_type=bill`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};
export const getRetailInvoicePreference = async () => {
  const mainUrl = `${baseURL}/settings/voucher-preference?voucher_type=retailInvoice`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};
export const getInvoicePreference = async () => {
  const mainUrl = `${baseURL}/settings/voucher-preference?voucher_type=invoice`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};
export const getEstimatePreference = async () => {
  const mainUrl = `${baseURL}/settings/voucher-preference?voucher_type=estimate`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};

export const getCreditNotePreference = async () => {
  const mainUrl = `${baseURL}/settings/voucher-preference?voucher_type=creditNote`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};
export const getdeliveryChallanPreference = async () => {
  const mainUrl = `${baseURL}/settings/voucher-preference?voucher_type=deliveryChallan`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};
export const getdeDitNotesPreference = async () => {
  const mainUrl = `${baseURL}/settings/voucher-preference?voucher_type=vendorCredit`;
  try {
    const response = await axios.get(mainUrl);
    return response;
  } catch (error) {
    return error.response?.data?.message || error.message;
  }
};
