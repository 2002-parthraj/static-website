import axios from "@/lib/axios";
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const getAllJournalsData = async (
	changePageCount,
	sortBy,
	sortOrder,
	totalRowCount,
	debouncedSearchValue,
) => {
	const mainUrl = `${baseURL}/journals?page=${changePageCount}&per_page=${totalRowCount}&sort_by=${sortBy}&sort_order=${sortOrder}&search=${
		debouncedSearchValue || ""
	}&query=${debouncedSearchValue || ""}`;
	try {
		const response = await axios.get(mainUrl);

		return response;
	} catch (error) {
		return error.response?.data?.message || error.message;
	}
};
