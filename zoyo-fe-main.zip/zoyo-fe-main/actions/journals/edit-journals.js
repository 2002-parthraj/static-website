import axios from "@/lib/axios";

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

export const editJournals = async (payload, id) => {
	const endpoint = `${baseURL}/journals/${id}`;
	try {
		const response = await axios.put(endpoint, payload);

		return response;
	} catch (error) {
		// return error.response?.data?.message || error.message;
		return error?.response;
	}
};
